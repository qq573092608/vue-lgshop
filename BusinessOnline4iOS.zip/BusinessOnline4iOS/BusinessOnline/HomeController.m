//
//  HomeController.m
//  BusinessOnline
//
//  Created by clitics on 2019/3/4.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "HomeController.h"
#import "LoginController.h"
#import "RegisterController.h"
#import "YQPresentTransitionAnimated.h"
#import "YQDismissTransitionAnimated.h"
#import "WXApi.h"
#import "BaseTabBarController.h"

#import "BaseService.h"

@interface HomeController ()<UIViewControllerTransitioningDelegate>

@property (nonatomic, strong) UIPercentDrivenInteractiveTransition *percentDrivenTransition;

@property (nonatomic, strong) BaseService *baseService;

@end

@implementation HomeController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(WeChatSuccess)
                                                 name:kWeChatSuccessNotification object:nil];
    
    [self setupSubViews];
    
    NSString *iswechatlogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsWeChatLogin];
    if (iswechatlogin.boolValue)
    {
        [self WeChatSuccess];
    }
    
}

#pragma mark - UIViewControllerTransitioningDelegate
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return [[YQPresentTransitionAnimated alloc] init];
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    return [[YQDismissTransitionAnimated alloc] init];
}

//- (id<UIViewControllerInteractiveTransitioning>)interactionControllerForPresentation:(id<UIViewControllerAnimatedTransitioning>)animator{
//    return _percentDrivenTransition;
//}
//
//- (id<UIViewControllerInteractiveTransitioning>)interactionControllerForDismissal:(id<UIViewControllerAnimatedTransitioning>)animator{
//    return _percentDrivenTransition;
//}

static CGFloat edgSpacing = 50.0f;
static CGFloat viewSpacing = 20.0f;

- (void)setupSubViews
{
    //马甲包改动
    UIImage *image;
    #if APPTYPE == BusinessOnline

    #elif APPTYPE == LGBeta
    image = [UIImage imageNamed:@"background"];
    #endif
    
    image = [UIImage imageNamed:[self.baseService getLaunchImgByAPPType:APPTYPE]];
    image = [image resizableImageWithCapInsets:UIEdgeInsetsMake(20, 20, 20, 20)
                                  resizingMode:UIImageResizingModeStretch];
    UIImageView *backImageView = [[UIImageView alloc] init];
    [self.view addSubview:backImageView];
    backImageView.contentMode = UIViewContentModeScaleAspectFill;
    backImageView.image = image;
    backImageView.userInteractionEnabled = YES;
    [backImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    
    UIButton *loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.view addSubview:loginBtn];
    [loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view).offset(edgSpacing);
        make.right.mas_equalTo(self.view).offset(-edgSpacing);
        make.bottom.mas_equalTo(self.view).offset(-180);
        make.height.mas_equalTo(43);
    }];
    loginBtn.layer.cornerRadius = 5.0f;
    loginBtn.backgroundColor = MainColor;
//    [loginBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:localizableString(@"登录") attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}] forState:UIControlStateNormal];
    [loginBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"login", nil)
                                                                 attributes:@{
                                                                     NSFontAttributeName:[UIFont systemFontOfSize:16],
                                                                     NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}]
                        forState:UIControlStateNormal];
    [loginBtn addTarget:self action:@selector(loginAction) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *registerBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.view addSubview:registerBtn];
    [registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view).offset(edgSpacing);
        make.right.mas_equalTo(self.view).offset(-edgSpacing);
        make.bottom.mas_equalTo(loginBtn.mas_top).offset(-viewSpacing);
        make.height.mas_equalTo(43);
    }];
    registerBtn.layer.cornerRadius = 5.0f;
    registerBtn.backgroundColor = UIColorFromRGB(colorFontWhite);
    registerBtn.layer.borderColor = MainColor.CGColor;
    registerBtn.layer.borderWidth = 1.0f;
    registerBtn.layer.masksToBounds = YES;
    [registerBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"register", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:MainColor}] forState:UIControlStateNormal];
    [registerBtn addTarget:self action:@selector(registerAction) forControlEvents:UIControlEventTouchUpInside];
    //马甲包微信改动
    switch (APPTYPE) {
        case 24:
        {
            UIButton *wechatBtn = [[UIButton alloc] init];
            [self.view addSubview:wechatBtn];
            [wechatBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(loginBtn.mas_bottom).offset(20);
                make.centerX.mas_equalTo(self.view);
                make.size.mas_equalTo(CGSizeMake(40, 40));
            }];
            [wechatBtn setImage:[UIImage imageNamed:@"Wechat"] forState:UIControlStateNormal];
            [wechatBtn addTarget:self action:@selector(wechatlogin) forControlEvents:UIControlEventTouchUpInside];
            
            if ([WXApi isWXAppInstalled]) {
                
                wechatBtn.hidden = NO;
            }
            else
            {
                wechatBtn.hidden = YES;
            }
        }
            break;
            
        default:
            break;
    }
    
    UIImage *bgImg = [UIImage imageNamed:@"001_return"];
    UIButton *backBtn = [[UIButton alloc] init];
    [self.view addSubview:backBtn];
    [backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(registerBtn);
        make.top.equalTo(self.view).offset(44);
        make.width.mas_equalTo(bgImg.size.width);
        make.height.mas_equalTo(bgImg.size.height);
    }];
    [backBtn setBackgroundImage:bgImg forState:UIControlStateNormal];
    [backBtn addTarget:self
                action:@selector(backHomeAction)
      forControlEvents:UIControlEventTouchUpInside];
}

- (void)backHomeAction
{
    if (self.isNeedShowTabbar) {
        BaseTabBarController *bvc = [[BaseTabBarController alloc] init];
        [UIApplication sharedApplication].keyWindow.rootViewController = bvc;
    } else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (void)loginAction
{
    LoginController *lvc = [[LoginController alloc] init];
    lvc.transitioningDelegate = self;
    lvc.modalPresentationStyle = UIModalPresentationFullScreen;
    lvc.isNeedShowBackBtn = YES;
    [self presentViewController:lvc animated:YES completion:nil];
}

- (void)registerAction
{
    RegisterController *rvc = [[RegisterController alloc] init];
    rvc.transitioningDelegate = self;
    rvc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:rvc animated:YES completion:nil];
    
}

- (void)wechatlogin
{
    
    if ([WXApi isWXAppInstalled]) {
        
        NSString *openid = [[NSUserDefaults standardUserDefaults] objectForKey:Kopenid];
        
        if (openid.length>1)
        {
            [self WeChatSuccess];
        }
        else
        {
            SendAuthReq *req = [[SendAuthReq alloc] init];
            req.state = @"App";
            req.scope = @"snsapi_userinfo";
            [WXApi sendReq:req completion:^(BOOL success) {
                NSLog(@"success=%d",success);
            }];
        }
    } else {
        [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:Kopenid];
    }
}


- (void)WeChatSuccess
{
    
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    NSString *openid = (NSString *)[[NSUserDefaults standardUserDefaults] objectForKey:Kopenid];
    NSString *Avatarpath = [[NSUserDefaults standardUserDefaults] objectForKey:kAvatarpath];
    NSString *nickname = [[NSUserDefaults standardUserDefaults] objectForKey:kNickName];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:invitationCode forKey:@"invitationCode"];
    [params setObject:openid forKey:@"weChatId"];
    [params setObject:Avatarpath forKey:@"avatarpath"];
    [params setObject:nickname forKey:@"nickname"];
    
    [MBProgressHUD showGifToView:nil];
    [NetworkManager postWithURL:CREATE_URL(url_login) params:params isUsedSignal:NO success:^(id json) {
        
        [MBProgressHUD hideHUD];
        [self loginSuccessCallback:json];
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}


- (void)loginSuccessCallback:(id)json
{
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:kIconPath];
    NSInteger state = [get_Value_for_key_from_obj(json, successKey) integerValue];
    switch (state) {
        case 1:
        {
            
            if (![[json allKeys] containsObject:dataKey])
            {
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"Loginfailed", nil)];
                return;
            }
            NSDictionary *data = get_Value_for_key_from_obj(json, dataKey);
            if (![[data allKeys] containsObject:@"cookie"])
            {
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"Loginfailed", nil)];
                return;
            }
            if (![[data allKeys] containsObject:kIconPath])
            {
                
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"Loginfailed", nil)];
                return;
            }
            NSString *iconPath = get_Value_for_key_from_obj(data, kIconPath);
            if (isNSString(iconPath))
            {
                [[NSUserDefaults standardUserDefaults] setObject:iconPath forKey:kIconPath];
            }
            
            NSString *cookie = [data objectForKey:@"cookie"];
            if (isNSString(cookie))
            {
                NSString *isSale = get_Value_for_key_from_obj(data, @"isSale");
                [[NSUserDefaults standardUserDefaults] setObject:@(isSale.boolValue) forKey:kIsSale];
                if (isSale.boolValue) {
//                    NSString *invitationQrImage = get_Value_for_key_from_obj(get_Value_for_key_from_obj(json, dataKey), @"invitationQrImage");
//                    if ([invitationQrImage isKindOfClass:[NSString class]])
//                    {
//                        [[NSUserDefaults standardUserDefaults] setObject:invitationQrImage forKey:[NSString stringWithFormat:@"%@%@",[[NSUserDefaults standardUserDefaults] objectForKey:kUserName],[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]]];
//                    }
                }
                                
                NSString *nickName = get_Value_for_key_from_obj(data, kNickName);
                if (!isNSString(nickName) || !nickName.length)
                {
//                    [MBProgressHUD showErrorMessage:localizableString(@"登录失败")];
                    nickName = @"";
//                    return;
                }
                
                NSString *avatarpath = get_Value_for_key_from_obj(data, kIconPath);
                if (!isNSString(avatarpath) || !avatarpath.length)
                {
                    avatarpath = @"";
                }
                
                NSString *phonenumber = get_Value_for_key_from_obj(data, @"phoneNumber");

                if (phonenumber.length>0) {
                    [[NSUserDefaults standardUserDefaults] setObject:phonenumber forKey:kUserName];
                }
                
                [[NSUserDefaults standardUserDefaults] setObject:nickName forKey:[NSString stringWithFormat:@"%@%@",kNickName,[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]]];
                [[NSUserDefaults standardUserDefaults] setObject:avatarpath forKey:kIconPath];
                [[NSUserDefaults standardUserDefaults] setObject:cookie forKey:kLoginCookies];
                [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:kIsWeChatLogin];
                BaseTabBarController *bvc = [[BaseTabBarController alloc] init];
                [UIApplication sharedApplication].keyWindow.rootViewController = bvc;
            } else {
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"Loginfailed", nil)];
                return;
            }
        }
            
            break;
            case 2:[MBProgressHUD showErrorMessage:NSLocalizedString(@"msg7", nil)];
            break;

        default:
//            [MBProgressHUD showErrorMessage:get_Value_for_key_from_obj(json, messageKey)];
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"accerror", nil)];
            break;
    }
}


#pragma mark - 懒加载
- (BaseService *)baseService{
    if (!_baseService) {
        _baseService = [[BaseService alloc] init];
    }
    return _baseService;
}


@end
