//
//  HomeController.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/4.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeController : UIViewController

/** 是否需要显示底部的Tabbar */
@property (nonatomic, assign) BOOL isNeedShowTabbar;

@end

NS_ASSUME_NONNULL_END
