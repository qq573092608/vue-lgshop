//
//  AppDelegate.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>


#define kDownloadProgressNotification @"downloadProgressNotification"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (copy, nonatomic) NSString *language;
@property (copy, nonatomic) NSString *classimage;
@property (copy, nonatomic) NSString *reveal;

@end

