//
//  AppDelegate.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "AppDelegate.h"
#import "HomeController.h"
#import "LoginController.h"
#import "BaseTabBarController.h"
#import "WXApi.h"

#import "BaseService.h"
#import "DataBaseManager.h"
#import "LGMineNetWorkService.h"
#import "LgResultModel.h"

#import "LGUpdateView.h"

@interface AppDelegate ()<WXApiDelegate,BuglyDelegate>

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [WXApi registerApp:@"wx5ef1a529dc6887a8" universalLink:@"https://www.gzlgsoft.com/apps/akypet/"];
        
    [self configBugly];
    
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    
    [IQKeyboardManager sharedManager].enable = YES;
    
    NSString *islogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsLogin];
    NSString *iswechatlogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsWeChatLogin];
    if (islogin.boolValue)
    {
        LoginController *bvc = [[LoginController alloc] init];
        bvc.isNeedShowBackBtn = NO;
        self.window.rootViewController = bvc;
    } else if (!islogin.boolValue && iswechatlogin.boolValue) {
        HomeController *vc = [[HomeController alloc] init];
        self.window.rootViewController = vc;
    } else {
        BaseTabBarController *bvc = [[BaseTabBarController alloc] init];
        self.window.rootViewController = bvc;
    }
    
    //马甲包
    BaseService *baseService = [[BaseService alloc] init];
    NSString *invitationCode = [baseService getInvitationCodeByAPPTYPE:APPTYPE];
    [[NSUserDefaults standardUserDefaults] setObject:invitationCode forKey:KInvitationCode];
    
    self.language = NSLocalizedString(@"意大利", nil);
    [self.window makeKeyAndVisible];
    [[UITextField appearance] setTintColor:[UIColor redColor]];
    
    // 升级数据库
    BOOL isMigrationSucc = [[DataBaseManager shared] updateDataBase:shoppingcar];
    if (!isMigrationSucc) {
        [Bugly reportException:[NSException exceptionWithName:@"升级数据库失败"
                                                       reason:@"升级数据库" userInfo:nil]];
    }
    
    // 检查App更新
    [self checkAppUpdate];
    
    return YES;
}

- (void)checkAppUpdate{
    
//    BOOL isUpdateInfoShowed = [[NSUserDefaults standardUserDefaults] boolForKey:kIsUpdateInfoShowed];
//    if (isUpdateInfoShowed) {
//        return;
//    }

    LGMineNetWorkService *mineNetWorkService = [[LGMineNetWorkService alloc] init];
    [mineNetWorkService checkUpdateWithAppVersionCallBack:^(LgResultModel *result, NSString *downLoadUrl, NSString *versionStr, NSArray *contentList) {
        
        if (result.isSucc) {
//            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:kIsUpdateInfoShowed];
            
            LGUpdateView *view = [[LGUpdateView alloc] initWithVersion:versionStr updateList:contentList];
            KLCPopup *popup = [KLCPopup popupWithContentView:view
                                                    showType:KLCPopupShowTypeFadeIn
                                                 dismissType:KLCPopupDismissTypeFadeOut
                                                    maskType:KLCPopupMaskTypeDimmed
                                    dismissOnBackgroundTouch:NO
                                       dismissOnContentTouch:NO];
            view.cancelAction  = ^{
                [popup dismissPresentingPopup];
            };
            view.sureAction = ^{
                NSString *urlString = [NSString stringWithFormat:@"itms-apps://itunes.apple.com/app/%@",downLoadUrl];
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
            };
            [popup show];
        }
    }];
}

- (void)configBugly {
    BuglyConfig *config = [[BuglyConfig alloc] init];
    config.unexpectedTerminatingDetectionEnable = YES; //非正常退出事件记录开关，默认关闭
    config.reportLogLevel = BuglyLogLevelWarn; //报告级别
    config.blockMonitorEnable = YES; //开启卡顿监控
    config.blockMonitorTimeout = 5; //卡顿监控判断间隔，单位为秒
    config.delegate = self;
    config.debugMode = YES; //SDK Debug信息开关, 默认关闭
    
    #if DEBUG
        config.channel = @"debug";
    #else
        config.channel = @"release";
    #endif
        
    [Bugly startWithAppId:@"def6847897"
    #if DEBUG
            developmentDevice:YES
    #endif
                       config:config];
}

#pragma mark - BuglyDelegate
//此方法返回的数据，可在bugly平台中异常上报，具体异常信息的跟踪数据附件信息中的crash_attach.log中查看
-(NSString *)attachmentForException:(NSException *)exception{
    return [NSString stringWithFormat:@"exceptionInfo:\nname:%@\nreason:%@",exception.name,exception.reason];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}

//iOS 9 之前
-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    return [WXApi handleOpenURL:url delegate:self];
}
-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    return [WXApi handleOpenURL:url delegate:self];
}

//iOS 9之后
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options
{
    if ([url.host isEqualToString:@"oauth"]){//微信登录
        return [WXApi handleOpenURL:url delegate:self];
    }
    return YES;
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

-(void)onResp:(BaseResp *)resp {
    NSLog(@"resp %d",resp.errCode);
    if ([resp isKindOfClass: [SendAuthResp class]]) {
        SendAuthResp* authResp = (SendAuthResp*)resp;
        
        if (authResp.errCode != 0 ) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [MBProgressHUD showMessage:NSLocalizedString(@"用户取消授权", nil)];
            });
            return;
        }
        NSString *code = authResp.code;
        [self getWeiXinOpenId:code];
    }
}

//通过code获取access_token，openid，unionid
- (void)getWeiXinOpenId:(NSString *)code{
    
    NSString *url =[NSString stringWithFormat:@"https://api.weixin.qq.com/sns/oauth2/access_token?appid=%@&secret=%@&code=%@&grant_type=authorization_code",WXAPPid,WXAppSecret,code];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSURL *zoneUrl = [NSURL URLWithString:url];
        NSString *zoneStr = [NSString stringWithContentsOfURL:zoneUrl encoding:NSUTF8StringEncoding error:nil];
        NSData *data1 = [zoneStr dataUsingEncoding:NSUTF8StringEncoding];
        
        if (!data1) {
            [MBProgressHUD showMessage:@"微信授权失败"];
            return ;
        }
        
        // 授权成功，获取token、openID字典
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data1 options:NSJSONReadingMutableContainers error:nil];
        NSLog(@"token、openID字典===%@",dic);
        NSString *access_token = dic[@"access_token"];
        NSString *openid= dic[@"openid"];
        
        //         获取微信用户信息
        [self getUserInfoWithAccessToken:access_token WithOpenid:openid];
        
    });
}

-(void)getUserInfoWithAccessToken:(NSString *)access_token WithOpenid:(NSString *)openid
{
    NSString *url =[NSString stringWithFormat:@"https://api.weixin.qq.com/sns/userinfo?access_token=%@&openid=%@",access_token,openid];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSURL *zoneUrl = [NSURL URLWithString:url];
        NSString *zoneStr = [NSString stringWithContentsOfURL:zoneUrl encoding:NSUTF8StringEncoding error:nil];
        NSData *data = [zoneStr dataUsingEncoding:NSUTF8StringEncoding];
        dispatch_async(dispatch_get_main_queue(), ^{
            
            // 获取用户信息失败
            if (!data) {
                [MBProgressHUD showMessage:@"微信授权失败"];
                return ;
            }
            
            // 获取用户信息字典
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            //用户信息中没有access_token 我将其添加在字典中
            [dic setValue:access_token forKey:@"token"];
            NSLog(@"用户信息字典:===%@",dic);
            
//            [[NSUserDefaults standardUserDefaults] setObject:dic forKey:WeChatUserInfo];
            
            NSString *nickname = dic[@"nickname"];
            [[NSUserDefaults standardUserDefaults]setObject:nickname forKey:kNickName];
            
            NSString *imagepath = dic[@"headimgurl"];
            [[NSUserDefaults standardUserDefaults] setObject:imagepath forKey:kAvatarpath];
            
            NSString *openid = dic[@"openid"];
            [[NSUserDefaults standardUserDefaults] setObject:openid forKey:Kopenid];
            
            //保存改用户信息(我用单例保存)
//            [GLUserManager shareManager].weiXinIfon = dic;
          //微信返回信息后,会跳到登录页面,添加通知进行其他逻辑操作
            [[NSNotificationCenter defaultCenter] postNotificationName:kWeChatSuccessNotification object:nil];
            
        });
        
    });
    
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kWeChatSuccessNotification object:self];
}

@end
