//
//  UIFont+Externed.m
//  SwiftTool
//
//  Created by lgtech on 2020/9/2.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "UIFont+Externed.h"

@implementation UIFont (Externed)

+ (UIFont *)lgFontFamily:(NSString *)fontFamily size:(CGFloat)size
{
    UIFont *resFont = nil;
    if ([fontFamily isEqualToString:@""] || fontFamily == nil) {
        resFont = [UIFont fontWithName:@"PingFangSC-Regular" size:size];
    } else {
        resFont = [UIFont fontWithName:fontFamily size:size];
    }
    
    return resFont;
}

@end
