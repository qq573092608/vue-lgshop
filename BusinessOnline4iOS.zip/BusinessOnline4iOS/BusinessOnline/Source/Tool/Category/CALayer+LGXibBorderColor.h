//
//  CALayer+LGXibBorderColor.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/10.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

NS_ASSUME_NONNULL_BEGIN

@interface CALayer (LGXibBorderColor)

@end

NS_ASSUME_NONNULL_END
