//
//  NSString+check.m
//  jobStudentiOS
//
//  Created by CGC on 2017/4/17.
//  Copyright © 2017年 clitics. All rights reserved.
//

#import "NSString+check.h"

#define PHONENUMBER_REG @"^[1][3456789][0-9]{9}$"
#define IDCARD_REG      @"(^[0-9]{15}$)|([0-9]{17}([0-9]|X)$)"
#define YEAR_MONTH_DAY @"^(?:(?!0000)[0-9]{4}-(?:(?:0[1-9]|1[0-2]):(?:0[1-9]|1[0-9]|2[0-8])|(?:0[13-9]|1[0-2]):(?:29|30)|(?:0[13578]|1[02])-31)|(?:[0-9]{2}(?:0[48]|[2468][048]|[13579][26])|(?:0[48]|[2468][048]|[13579][26])00)-02-29)$"
#define HOUR_MINATE_SECONDS @"([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]"
#define IP_FORMAT @"((?:(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d))))";
#define FILE_NAME @"[/\\*?\"'<>|]+"

@implementation NSString (Check)

-(BOOL)isAllNumber
{
    NSPredicate *regexPhone = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", HOUR_MINATE_SECONDS];
    BOOL res1 = [regexPhone evaluateWithObject:self];
    return res1;
}

-(BOOL)isFileName
{
    NSPredicate *regexPhone = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", @"^[0-9]*$"];
    BOOL result = [regexPhone evaluateWithObject:self];
    return !result;
}
-(BOOL)isYearMonthDay
{
    NSPredicate *regexPhone = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", YEAR_MONTH_DAY];
    BOOL res1 = [regexPhone evaluateWithObject:self];
    if (res1) {
        return YES;
    } else {
        return NO;
    }
}
-(BOOL)isHourMinateSeconds
{
    NSPredicate *regexPhone = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", HOUR_MINATE_SECONDS];
    BOOL res1 = [regexPhone evaluateWithObject:self];
    if (res1) {
        return YES;
    } else {
        return NO;
    }
}
-(BOOL)isIP
{
    NSPredicate *regexPhone = [NSPredicate predicateWithFormat:@"SELF MATCHES ^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.""([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.""([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.""([01]?\\d\\d?|2[0-4]\\d|25[0-5])$"];
    BOOL res1 = [regexPhone evaluateWithObject:self];
    if (res1) {
        return YES;
    } else {
        return NO;
    }
}

-(BOOL)isFormat1
{
    NSPredicate *regexPhone = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",@"^[0123456789qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM]{1,40}"];
    BOOL res1 = [regexPhone evaluateWithObject:self];
    if (res1) {
        return YES;
    } else {
        return NO;
    }
}
-(BOOL)isAZaz
{
    NSPredicate *regexPhone = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",@"^[,-0123456789qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM]{1,40}"];
    BOOL res1 = [regexPhone evaluateWithObject:self];
    if (res1) {
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)isInt
{
    NSPredicate *regexPhone = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",@"^\\d+$"];
    BOOL res1 = [regexPhone evaluateWithObject:self];
    if (res1) {
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)isFloat
{
    NSPredicate *regexPhone = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",@"^\\d+(.\\d+)?$"];
    BOOL res1 = [regexPhone evaluateWithObject:self];
    if (res1) {
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)isFormat2
{
    NSPredicate *regexPhone = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",@"^[-0123456789]{1,40}"];
    BOOL res1 = [regexPhone evaluateWithObject:self];
    if (res1) {
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)isTelephone
{
    
    NSPredicate *regexPhone = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", PHONENUMBER_REG];
    BOOL res1 = [regexPhone evaluateWithObject:self];
    if (res1) {
        return YES;
    } else {
        return NO;
    }
}
- (BOOL)checkEmailInput {
    
    NSString *EMAIL = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    
    NSPredicate *regextestemail = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", EMAIL];
	
	NSCharacterSet  *set = [NSCharacterSet whitespaceAndNewlineCharacterSet];
	NSString* testStr = [self stringByTrimmingCharactersInSet:set];
	
    BOOL res = [regextestemail evaluateWithObject:testStr];
    
    if (res) {
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)isPassword
{
    NSString *      regex = @"(^[_A-Za-z0-9\u3000-\u301e\ufe10-\ufe19\ufe30-\ufe44\ufe50-\ufe6b\uff01-\uffee]{6,150}$)";
    NSPredicate *   pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    return [pred evaluateWithObject:self];
}

-(BOOL)isUserName{
    NSString *      regexName = @"(^{1,20}$)";
    NSPredicate *   predName = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regexName];
    
    return [predName evaluateWithObject:self];
}

- (BOOL)isIDCard
{
    NSPredicate *regexIDCard = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", IDCARD_REG];
    BOOL res = [regexIDCard evaluateWithObject:self];
    if (res) {
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)isQQ{
    NSString *      regex = @"^([1-9][0-9]*)$";
    NSPredicate *   pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isPostCode
{
    NSString *      regex = @"[1-9]\\d{5}(?!\\d)";
    NSPredicate *   pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    return [pred evaluateWithObject:self];
}
- (BOOL)isTelephoneNumber{
    //    NSString *      regex = @"^(\\d{3,4}-)\\d{7,8}$";
    NSString *      regex = @"^(\\d{3,4}-)\\d{7,8}$";
    NSPredicate *   pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    return [pred evaluateWithObject:self];
}

- (BOOL)isScore{
    NSString *      regex = @"^([1-9][0-9]{0,3}$)";
    NSPredicate *   pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [pred evaluateWithObject:self];
}

#pragma mark - 检查字符串是否全为空格
- (BOOL)checkStringIsAllSpace {
    
    NSString *string = [self stringByReplacingOccurrencesOfString:@" " withString:@""];
	string = [string stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    if (string.length > 0) {
        
        return NO;
    }
    return YES;
    
}

#pragma mark - 加密手机号
- (NSString *)encryPhone {
    if ([self isTelephone]) {
        
        NSRange eRange = NSMakeRange(3, 4);
        
        NSString *replaceStr = @"****";
        
        NSString *regExpString  = [self substringWithRange:eRange];
        NSString *result = nil;
        for (NSInteger i = 0; i < self.length; i++) {
            result = [self stringByReplacingOccurrencesOfString:regExpString withString:replaceStr options:NSRegularExpressionSearch range:eRange];
        }
        return result;
    }
    
    return @"";
}

#pragma mark - 加密邮箱
- (NSString *)encryEmail {
    if ([self checkEmailInput]) {
        NSRange range = [self rangeOfString:@"@"];
        NSString *subStr = [self substringToIndex:range.location];
        NSInteger center = subStr.length / 2;
        NSInteger interval = 0;
        interval = center / 2;
        
        NSInteger loc = interval > 0 ? center - interval : 0;
        NSInteger length = interval > 0 ? interval : 0;
        
        NSRange eRange = NSMakeRange(loc, length * 2);
        
        NSString *replaceStr = @"*";
        NSInteger replaceTotal = (interval * 2 - 1) > 3 ? 3 : (interval * 2 - 1);
        
        for (NSInteger count = 0; count <replaceTotal ; count++) {
            replaceStr = [replaceStr stringByAppendingString:@"*"];
        }
        
        NSString *regExpString  = [subStr substringWithRange:eRange];
        NSString *result = nil;
        for (NSInteger i = 0; i < 10; i++) {
            result = [self stringByReplacingOccurrencesOfString:regExpString withString:replaceStr options:NSRegularExpressionSearch range:eRange];
        }
        return result;
    }
    
    return @"";
}

- (BOOL)isUrl
{
    NSString *regex =@"[a-zA-z]+://[^\\s]*";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    return [urlTest evaluateWithObject:self]; 
}

+ (BOOL)isBlankDictionary:(NSDictionary *)dic
{
    if (!dic) {
        return YES;
    }
    
    if ([dic isKindOfClass:[NSNull class]]) {
        return YES;
    }
    
    if (![dic isKindOfClass:[NSDictionary class]]) {
        return YES;
    }
    
    if (!dic.count) {
        return YES;
    }
    
    if (dic == nil) {
        return YES;
    }
    
    if (dic == NULL) {
        return YES;
    }
    
    return NO;
}






@end

