//
//  UITextField+NoBar.h
//  SwiftTool
//
//  Created by clitics on 2018/11/23.
//  Copyright © 2018年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITextField (NoBar)

-(instancetype)init;

@end

NS_ASSUME_NONNULL_END
