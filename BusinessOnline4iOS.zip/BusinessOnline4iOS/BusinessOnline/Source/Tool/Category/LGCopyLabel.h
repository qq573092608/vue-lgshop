//
//  LGCopyLabel.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/28.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGCopyLabel : UILabel

/**
        是否允许复制
 */
@property (nonatomic, assign) BOOL enableCopy;

///  初始化标签
- (instancetype)init;


@end

NS_ASSUME_NONNULL_END
