//
//  NSString+Tool.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/20.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


/// 常用的公共方法的封装,不涉及任何项目中的类
@interface NSString (Tool)

/// 获取时间差
/// @param starTime 开始的时间对象
+ (NSDateComponents *)getTimeInfoByStarTime:(NSString *)starTime;





///  获取有中间下划线的字符串文本
- (NSMutableAttributedString *)getMiddleLineLableString;

/**
    校验字符串是否为空
 */
- (BOOL)isEmptyString; ///< 是否为空或者是空格





@end

NS_ASSUME_NONNULL_END
