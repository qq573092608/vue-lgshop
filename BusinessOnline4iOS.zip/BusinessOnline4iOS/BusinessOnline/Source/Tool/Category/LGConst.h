//
//  LGConst.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/14.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

/** 订单单选还是批量售后的枚举 */
typedef enum : NSUInteger {
    kSingalOrMutableTypeSigal = 0,    // 单个
    kSingalOrMutableTypeMutable = 1,  // 批量
} SingalOrMutableType;/**< 售后数量(单个还是批量)  */

typedef enum : NSUInteger {
    kReturnMoneyOrProductTypeMoney = 2,           /**< 售后类型(退款)  */
    kReturnMoneyOrProductTypeMoneyAndProduct = 3, /**< 售后类型(退货退款)  */
} ReturnMoneyOrProductType;/**< 售后类型(退款还是退货退款)  */

typedef enum : NSUInteger {
    kSpecificaModifyTypeADD = 1,
    kSpecificaModifyTypeModify = 2,
} SpecificaModifyType;

NS_ASSUME_NONNULL_BEGIN


/** 售后服务的有效期限 */
static NSString *kAfterSalesValidPeriod = @"afterSalesValidPeriod";

/** 是否展示Paypal支付  0:展示 1:不展示*/
static NSString *kIsPayPalShow = @"isPayPalShow";

/** 商家声明 */
static NSString *kCompanyStatement= @"companyStatement";

/** 申请退货退款数量变化的通知 */
static NSString *kApplyReturnRefundNumberChangeNotifier= @"kApplyReturnRefundNumberChangeNotifier";
/** 底部规格通知 */
static NSString *kSpecifacaBottomDataNotifier= @"kSpecifacaBottomDataNotifier";


/** 顶部规格通知 */
static NSString *kSpecifacaHeadDataNotifier= @"kSpecifacaHeadDataNotifier";
static NSString *kSpecifacaHeadDataShowDefaultNotifier= @"kSpecifacaHeadDataShowDefaultNotifier";
static NSString *kChangeViewGoodsCountNotification= @"kChangeViewGoodsCountNotification";
static NSString *kSpecifacaisEnableNumOprationNotifier= @"kSpecifacaisEnableNumOprationNotifier";

/** 记录购物车表是否执行过删除操作(YES:是的 NO:不存在)  执行过删除操作则跳过*/
static NSString *kIsShoppingCarDeleted= @"kIsShoppingCarDeleted";

/** 查询所有商品数量的通知 */
static NSString *kQueryAllGoodsNumNotifacation= @"kQueryAllGoodsNumNotifacation";
/** 所有分类的集合 */
static NSString *kAllTypesCollection= @"kAllTypesCollection";
/** 更新提示是否已经显示过 YES:已经显示过 NO: 没有显示 */
static NSString *kIsUpdateInfoShowed = @"kIsUpdateInfoShowed";



/**
    数据库购物车表的列名
 */
extern NSString *const shoppingcar_invitationCode_key;
extern NSString *const shoppingcar_goodsCode_key;
extern NSString *const shoppingcar_count_key;
extern NSString *const shoppingcar_createDate_key;
extern NSString *const shoppingcar_imageUrl_key;
extern NSString *const shoppingcar_italyName_key;
extern NSString *const shoppingcar_price_key;
extern NSString *const shoppingcar_packageNumber_key;
extern NSString *const shoppingcar_zhName_key;
extern NSString *const shoppingcar_specifications_key;
extern NSString *const shoppingcar_infolistid_key;
extern NSString *const shoppingcar_weightKg_key;
extern NSString *const shoppingcar_s_price_old_key;
extern NSString *const shoppingcar_s_discount_key;
extern NSString *const shoppingcarKey;

extern NSString *const shoppingcar_tasteList_Key;
extern NSString *const shoppingcar_tasteInfoList_Key;
extern NSString *const dataIdKey;
extern NSString *const shoppingcar_userName_key;
extern NSString *const shoppingcar_goodsDescription_key;
extern NSString *const shoppingcar_realInventory_Key;


/**
    检测更新
 */
extern NSString *const app_newVersion_Key;

/**
 
        项目中共用的宏以及常量
 */
@interface LGConst : NSObject



@end

NS_ASSUME_NONNULL_END
