//
//  CALayer+LGXibBorderColor.m
//  BusinessOnline
//
//  Created by lgerp on 2020/10/10.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "CALayer+LGXibBorderColor.h"

@implementation CALayer (LGXibBorderColor)

- (void)setBorderColorWithUIColor:(UIColor *)color
{
    self.borderColor = color.CGColor;
}


@end
