//
//  NSString+Tool.m
//  BusinessOnline
//
//  Created by lgerp on 2020/10/20.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "NSString+Tool.h"

@implementation NSString (Tool)

+ (NSDateComponents *)getTimeInfoByStarTime:(NSString *)starTime
{
    NSDate *nowDate = [NSDate date];
    NSDateFormatter *dateFomatter = [[NSDateFormatter alloc] init];
    dateFomatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
     // 当前时间字符串格式
    NSString *nowDateStr = [dateFomatter stringFromDate:nowDate];
    NSDate *expireDate = [dateFomatter dateFromString:nowDateStr];
     // 要计算的时间    截止时间data格式
    nowDate = [dateFomatter dateFromString:starTime];
     // 当前日历
    NSCalendar *calendar = [NSCalendar currentCalendar];
    // 需要对比的时间数据
    NSCalendarUnit unit = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    // 对比时间差
    NSDateComponents *dateCom = [calendar components:unit fromDate:nowDate toDate:expireDate options:0];
    return  dateCom;
}

- (NSMutableAttributedString *)getMiddleLineLableString {
    
    NSMutableAttributedString *finaleMiddleLineStr = [[NSMutableAttributedString alloc] initWithString:self];
    [finaleMiddleLineStr addAttribute:NSStrikethroughStyleAttributeName
                            value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle)
                            range:NSMakeRange(0, finaleMiddleLineStr.length)];
    return finaleMiddleLineStr;
}

/// 是否为空或者是空格
- (BOOL)isEmptyString ///< 是否为空或者是空格
{
    NSString * newSelf = [self stringByReplacingOccurrencesOfString:@" " withString:@""];
    if(nil == self
       || self.length ==0
       || [self isEqualToString:@""]
       || [self isEqualToString:@"<null>"]
       || [self isEqualToString:@"(null)"]
       || [self isEqualToString:@"null"]
       || newSelf.length ==0
       || [newSelf isEqualToString:@""]
       || [newSelf isEqualToString:@"<null>"]
       || [newSelf isEqualToString:@"(null)"]
       || [newSelf isEqualToString:@"null"]
       || [self isKindOfClass:[NSNull class]] ){
        
        return YES;
    }else{
        // <object returned empty description> 会来这里
        NSCharacterSet *set = [NSCharacterSet whitespaceAndNewlineCharacterSet];
        NSString *trimedString = [self stringByTrimmingCharactersInSet:set];
        return [trimedString isEqualToString: @""];
    }
    
    return NO;
}

@end
