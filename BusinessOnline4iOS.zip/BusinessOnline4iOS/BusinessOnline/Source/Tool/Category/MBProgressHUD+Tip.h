//
//  MBProgressHUD+Tip.h
//  SwiftTool
//
//  Created by clitics on 2018/9/4.
//  Copyright © 2018年 clitics. All rights reserved.
//

#import "MBProgressHUD.h"

@interface MBProgressHUD (Tip)

+ (void)showGifToView:(UIView *)view;

+ (void)hideHUD;

+ (void)showMessage:(NSString *)message;


+ (void)showMessage:(NSString *)message displayTime:(NSTimeInterval)delay;

//+ (void)showSuccessMessage:(NSString *)message;

+ (void)showErrorMessage:(NSString *)message;

@end
