//
//  UIColor+HexString.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/20.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (HexString)


/// 16进制转UIColor不带透明度
/// @param color 16进制字符串 0Xxxxxx #xxxxxx
+ (UIColor *)ColorWithHexString:(NSString *)color;


///  16进制转UIColor带透明度
/// @param color 16进制字符串 0Xxxxxx #xxxxxx
/// @param alpha 透明度
+ (UIColor *)ColorwithHexString:(NSString *)color Alpha:(CGFloat)alpha;


/// UIColor转成字符串
/// @param color 目标颜色
/// @param hasAlpha 透明度
+ (NSString *)HexStringWithColor:(UIColor *)color HasAlpha:(BOOL)hasAlpha;

@end

NS_ASSUME_NONNULL_END
