//
//  LGShowPPriceTextField.m
//  SwiftTool
//
//  Created by lgtech on 2020/9/4.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGShowPPriceTextField.h"
@interface LGShowPPriceTextField(){
}

@end

@implementation LGShowPPriceTextField


// 重写来编辑区域，可以改变光标起始位置，以及光标最右到什么地方，placeHolder的位置也会改变
-(CGRect)editingRectForBounds:(CGRect)bounds
{
    CGRect inset = CGRectMake(bounds.origin.x + 20, bounds.origin.y, bounds.size.width -25, bounds.size.height);//更好理解些
    return inset;
}

- (CGRect)placeholderRectForBounds:(CGRect)bounds
{
    CGRect inset = CGRectMake(bounds.origin.x + 20, bounds.origin.y, bounds.size.width -10, bounds.size.height);//更好理解些
    return inset;
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
