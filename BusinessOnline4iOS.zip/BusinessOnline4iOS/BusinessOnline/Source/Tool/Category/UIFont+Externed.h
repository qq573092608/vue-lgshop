//
//  UIFont+Externed.h
//  SwiftTool
//
//  Created by lgtech on 2020/9/2.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIFont (Externed)

/**
        对传入的字体做一个封装不传参数默认PingFang-Raugluer
 */
+ (UIFont *)lgFontFamily:(NSString *)fontFamily size:(CGFloat)size;


@end

NS_ASSUME_NONNULL_END
