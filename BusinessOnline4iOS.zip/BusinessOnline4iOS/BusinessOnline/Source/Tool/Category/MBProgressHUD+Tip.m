//
//  MBProgressHUD+Tip.m
//  SwiftTool
//
//  Created by clitics on 2018/9/4.
//  Copyright © 2018年 clitics. All rights reserved.
//

#import "MBProgressHUD+Tip.h"

@implementation MBProgressHUD (Tip)

+ (void)showGifToView:(UIView *)view
{
    if (view == nil) view = (UIView*)[UIApplication sharedApplication].delegate.window;
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    UIImage *image = [UIImage sd_animatedGIFNamed:@"loading60"];
    UIImageView *cusImageV = [[UIImageView alloc] init];
    cusImageV.frame = CGRectMake(0, 0, 100, 100);
    cusImageV.contentMode = UIViewContentModeScaleAspectFit;
    cusImageV.image = image;
    hud.mode = MBProgressHUDModeCustomView;
    hud.removeFromSuperViewOnHide = YES;
    
    //设置提示性文字
    
    //    hud.label.text = @"正在加载中";
    
    //    // 设置文字大小
    
    //    hud.label.font = [UIFont systemFontOfSize:20];
    
    //    //设置文字的背景颜色
    
    //    //    hud.label.backgroundColor = [UIColor redColor];
    
    //
    
    //设置方框view为该模式后修改颜色才有效果
    
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    
    //设置方框view背景色
    
    hud.bezelView.backgroundColor = [UIColor clearColor];
    
    //设置总背景view的背景色，并带有透明效果
    
    //    hud.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    
    hud.customView = cusImageV;
}
+ (void)hideHUDForView:(UIView *)view
{
    if (view == nil) view = (UIView*)[UIApplication sharedApplication].delegate.window;
    [self hideHUDForView:view animated:YES];
}

+ (void)hideHUD
{
    [self hideHUDForView:nil];
}

+ (void)showSuccessMessage:(NSString *)message displayTime:(NSTimeInterval)delay
{
    MBProgressHUD *hud = [self showHUDByMessage:message displayTime:delay];
    hud.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Path"]];
}

+ (void)showErrorMessage:(NSString *)message displayTime:(NSTimeInterval)delay
{
    MBProgressHUD *hud = [self showHUDByMessage:message displayTime:delay];
    hud.label.text = @"";
//    hud.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"error"]];
}

+ (void)showMessage:(NSString *)message
{
    [self showMessage:message displayTime:0.5];
}

+ (void)showMessage:(NSString *)message displayTime:(NSTimeInterval)delay
{
    MBProgressHUD* hud = [self showHUDByMessage:message displayTime:delay];
    hud.label.text = @"";
}

+ (void)showSuccessMessage:(NSString *)message
{
    [MBProgressHUD showSuccessMessage:message displayTime:0.5];
}

+ (void)showErrorMessage:(NSString *)message
{
    [MBProgressHUD showErrorMessage:message displayTime:2];
}

+ (MBProgressHUD *)showHUDByMessage:(NSString *)message displayTime:(NSTimeInterval)delay
{
    if (!NotNilAndNull(message))
    {
        message = @"";
    }
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication] keyWindow] animated:YES];
    hud.bezelView.color = [UIColor blackColor];
    hud.contentColor = [UIColor whiteColor];
    hud.label.text = @" ";
    hud.detailsLabel.text = message;
    hud.label.font = [UIFont systemFontOfSize:12.f];
    hud.mode = MBProgressHUDModeCustomView;
    hud.removeFromSuperViewOnHide = YES;
    [hud hideAnimated:YES afterDelay:delay];
    return hud;
}
@end
