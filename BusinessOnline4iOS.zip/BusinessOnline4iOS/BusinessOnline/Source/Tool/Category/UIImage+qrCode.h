//
//  UIImage+qrCode.h
//  RegulusPro
//
//  Created by clitics on 2018/5/30.
//  Copyright © 2018年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (qrCode)

+ (UIImage *)imageWithString:(NSString *)string;

+ (UIImage *)compressImageQuality:(UIImage *)image toByte:(NSInteger)maxLength size:(CGSize)size;

@end
