//
//  NSString+check.h
//  jobStudentiOS
//
//  Created by CGC on 2017/4/17.
//  Copyright © 2017年 clitics. All rights reserved. 
//

#import <Foundation/Foundation.h>

@interface NSString (check)
/**
 *  文件名不包含字符
 */
- (BOOL)isFileName;

/**
 *  匹配手机号码
 */
- (BOOL)isTelephone;
/**
 *  匹配邮箱
 */
- (BOOL)checkEmailInput;
/**
 *  匹配密码
 */
- (BOOL)isPassword;
/**
 *  匹配用户名
 */
- (BOOL)isUserName;
/**
 *  匹配身份证号码
 */
- (BOOL)isIDCard;
/**
 *  匹配QQ号码
 */
- (BOOL)isQQ;
/**
 *  匹配邮政编码
 */
- (BOOL)isPostCode;
/**
 *  加区号的电话号码
 */
- (BOOL)isTelephoneNumber;
/**
 *  四位的分数
 */
- (BOOL)isScore;
/**
 *  检查字符串是否全为空格
 */
- (BOOL)checkStringIsAllSpace;

/**
 *  加密手机号
 */
- (NSString *)encryPhone;

/**
 *  加密邮箱
 */
- (NSString *)encryEmail;

- (BOOL)isUrl;

/**
 * 匹配yyyy:MM:dd
 */
- (BOOL)isYearMonthDay;
/**
 * 匹配HH:mm:ss
 */
- (BOOL)isHourMinateSeconds;
/**
 *匹配ip地址
 */
- (BOOL)isIP;

/**
 *匹配a-zA-Z-,
 */
- (BOOL)isAZaz;
-(BOOL)isFormat1;
- (BOOL)isFormat2;

- (BOOL)isAllNumber;

- (BOOL)isFloat;
- (BOOL)isInt;


/// 判断字典是否为空
/// @param dic 目标字典
+ (BOOL)isBlankDictionary:(NSDictionary *)dic;

@end
