//
//  UITextField+NoBar.m
//  SwiftTool
//
//  Created by clitics on 2018/11/23.
//  Copyright © 2018年 clitics. All rights reserved.
//

#import "UITextField+NoBar.h"

@implementation UITextField (NoBar)

-(instancetype)init
{
    if (self = [super init])
    {
        self.inputAccessoryView = [UIView new];
    }
    return self;
}

@end
