//
//  LGConst.m
//  BusinessOnline
//
//  Created by lgerp on 2020/10/14.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGConst.h"

NSString *const shoppingcar_invitationCode_key = @"invitationCode";
NSString *const shoppingcar_goodsCode_key = @"goodsCode";
NSString *const shoppingcar_count_key = @"count";
NSString *const shoppingcar_createDate_key = @"createDate";
/**
   图片
 */
NSString *const shoppingcar_imageUrl_key = @"imageUrl";

NSString *const shoppingcar_italyName_key = @"italyName";
/**
    价格
 */
NSString *const shoppingcar_price_key = @"price";
NSString *const shoppingcar_packageNumber_key = @"packageNumber";
NSString *const shoppingcar_zhName_key = @"zhName";
NSString *const shoppingcar_specifications_key = @"specifications";

NSString *const shoppingcar_infolistid_key = @"infolistid";
NSString *const shoppingcar_weightKg_key = @"weightKg";
NSString *const shoppingcar_s_price_old_key = @"s_price_old";
NSString *const shoppingcar_s_discount_key = @"s_discount";
NSString *const shoppingcarKey = @"shoppingcar";

NSString *const shoppingcar_tasteList_Key = @"tasteList";
NSString *const shoppingcar_tasteInfoList_Key = @"tasteInfoList";
NSString *const dataIdKey = @"dataId";
NSString *const shoppingcar_userName_key = @"userName";
NSString *const shoppingcar_goodsDescription_key = @"goodsDescription";

NSString *const shoppingcar_realInventory_Key = @"realInventory";

NSString *const app_newVersion_Key = @"hasNewVersionKey";

@implementation LGConst

 


@end
