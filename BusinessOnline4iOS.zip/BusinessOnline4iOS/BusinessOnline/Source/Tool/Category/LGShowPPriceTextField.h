//
//  LGShowPPriceTextField.h
//  SwiftTool
//
//  Created by lgtech on 2020/9/4.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGShowPPriceTextField : UITextField

@end

NS_ASSUME_NONNULL_END
