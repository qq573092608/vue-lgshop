//
//  LGDataBaseManager.h
//  BusinessOnline
//
//  Created by lgerp on 2020/12/3.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**

  新版本的数据库操作文件
 */
@interface LGDataBaseManager : NSObject

/**
     创建数据库操作的单例对象
 */
+(instancetype)shared;

/**
    将空的数据库里面的数据库表内容拷贝到当前用户的数据库表里面
 */
+ (void)copyNullDBData2CurrentUserDBData;

@end

NS_ASSUME_NONNULL_END
