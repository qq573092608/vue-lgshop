//
//  LGDataBaseManager.m
//  BusinessOnline
//
//  Created by lgerp on 2020/12/3.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGDataBaseManager.h"

@interface LGDataBaseManager ()

@property (nonatomic,strong)FMDatabaseQueue *queue;
@property (nonatomic,copy)NSString *filePath;
@end

@implementation LGDataBaseManager

NSString *const shoppingCarTable = @"shoppingCarTable";
NSString *const shoppingCarTable_invitationCode_key = @"invitationCode";
NSString *const shoppingCarTable_goodsCode_key = @"goodsCode";
NSString *const shoppingCarTable_count_key = @"count";
NSString *const shoppingCarTable_createDate_key = @"createDate";
NSString *const shoppingCarTable_imageUrl_key = @"imageUrl";
NSString *const shoppingCarTable_italyName_key = @"italyName";
NSString *const shoppingCarTable_price_key = @"price";
NSString *const shoppingCarTable_packageNumber_key = @"packageNumber";
NSString *const shoppingCarTable_zhName_key = @"zhName";
NSString *const shoppingCarTable_specifications_key = @"specifications";
NSString *const shoppingCarTable_infolistid_key = @"infolistid";
NSString *const shoppingCarTable_weightKg_key = @"weightKg";
NSString *const shoppingCarTable_s_price_old_key = @"s_price_old";
NSString *const shoppingCarTable_s_discount_key = @"s_discount";
NSString *const shoppingCarTable_userName_key = @"userName";
NSString *const shoppingCarTable_goodsDescription_key = @"goodsDescription";

+(instancetype)shared
{
    static LGDataBaseManager *_model = nil;
    static dispatch_once_t tocken = 0;
    dispatch_once(&tocken, ^{
        _model = [[LGDataBaseManager alloc] init];
        // 获取DocumentDirectory目录的路径
        NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
       // 获取文件路径
        _model.filePath = [documentsPath stringByAppendingPathComponent:@"BusinessOnline.db"];
        // 创建数据库
        _model.queue = [FMDatabaseQueue databaseQueueWithPath:_model.filePath];
        
        // 创建数据库表
        //取出数据库，这里的db就是数据库，在数据库中创建表
        [_model.queue inDatabase:^(FMDatabase *db) {
            //创建表
            NSString *createSQL = [NSString stringWithFormat:@"create table if not exists %@ (dataId integer primary key autoincrement, %@ text, %@ text, %@ text,%@ text, %@ text, %@ text, %@ text, %@ text, %@ text, %@ text, %@ text, %@ text, %@ text, %@ text,%@ text,%@ text)", shoppingCarTable,shoppingCarTable_userName_key, shoppingCarTable_invitationCode_key, shoppingCarTable_goodsCode_key, shoppingCarTable_count_key, shoppingCarTable_createDate_key, shoppingCarTable_imageUrl_key, shoppingCarTable_italyName_key, shoppingCarTable_price_key, shoppingCarTable_packageNumber_key, shoppingCarTable_zhName_key, shoppingCarTable_specifications_key, shoppingCarTable_infolistid_key, shoppingCarTable_weightKg_key, shoppingCarTable_s_price_old_key,shoppingCarTable_s_discount_key,shoppingCarTable_goodsDescription_key];
            BOOL isCreateSucc =  [db executeUpdate:createSQL];
            if (isCreateSucc) {
                [Bugly reportException:[NSException exceptionWithName:@"DBCreateTableInfo"
                                                               reason:[NSString stringWithFormat:@"新建 %@ 表成功!", shoppingCarTable]
                                                             userInfo:nil]];
            } else {
                [Bugly reportException:[NSException exceptionWithName:@"DBCreateTableInfo"
                                                               reason:[NSString stringWithFormat:@"新建 %@ 表失败!", shoppingCarTable]
                                                             userInfo:nil]];
            }
        }];
    });
    return _model;
}

+ (void)copyNullDBData2CurrentUserDBData
{
    // 获取DocumentDirectory目录的路径
    NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    // 根据用户名创建文件夹
    [[NSFileManager defaultManager] createDirectoryAtPath:[documentsPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/",[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]]]
                              withIntermediateDirectories:YES attributes:nil error:nil];
   
    if ([[NSUserDefaults standardUserDefaults] objectForKey:kUserName] != nil) {
        // 判断存放NULL的文件夹是否存在，不存在则创建对应文件夹
        NSFileManager *fileManager = [NSFileManager defaultManager];
        BOOL isDir = FALSE;
        BOOL isDirExist = [fileManager fileExistsAtPath:[NSString stringWithFormat:@"%@/%@", documentsPath, @"(null)"] isDirectory:&isDir];
        if (isDirExist) {
            NSLog(@"(null)文件存在");
            if (isDir) {
                NSLog(@"该(null)文件是一个目录");
                
                // 未登录用户的数据库路径((null)/totalData.db)
                NSString *nullDbFilePath = [NSString stringWithFormat:@"%@/(null)/totalData.db", documentsPath];
                // 当前用户的数据库路径
                NSString *toPathStr = [NSString stringWithFormat:@"%@/%@/totalData.db",documentsPath,[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]];

                // 判断(null)目录下的totalData.db文件是否存在
                BOOL isFileExist = [fileManager fileExistsAtPath:nullDbFilePath isDirectory:&isDir];
                if (isFileExist &&  [[fileManager attributesOfItemAtPath:nullDbFilePath error:nil] fileSize] > 0) {
                    
                    // 判断当前用户目录下是否有已经存在的数据库文件(非常重要:存在则将未登录的用户数据读写到当前已登录的用户的数据库表中，不存在则直接拷贝过来)
                    BOOL isCurrentLoginedUserDBFileExist = [fileManager fileExistsAtPath:toPathStr];
                    if (isCurrentLoginedUserDBFileExist) {
                        NSMutableArray *allNullDataList = [NSMutableArray array];
                        
                        // 数据库中内容的迁移
                        // 1. 读取(null)/totalData.db
                        //创建数据库，并加入到队列中，此时已经默认打开了数据库，无须手动打开，只需要从队列中取出数据库即可
                        FMDatabaseQueue *nullDbQueue=[FMDatabaseQueue databaseQueueWithPath:nullDbFilePath];
                        [nullDbQueue inDatabase:^(FMDatabase *db) {

                            //获取结果集，返回参数就是查询结果
                            if (![db open]) {
                                NSLog(@"(null)/totalData.db数据库关闭或者不存在");
                                return ;
                            }
                            NSString *sql = [NSString stringWithFormat:@"select * from shoppingcar%@", shoppingcarKey];
                            FMResultSet *result = [db executeQuery:sql];
                            while ([result next]) {
                                NSMutableDictionary *params = [NSMutableDictionary dictionary];
                                
                                int dataId = [result intForColumn:dataIdKey];
                                [params setObject:@(dataId) forKey:dataIdKey];
                                
                                NSString *invitationCode = [result stringForColumn:shoppingcar_invitationCode_key];
                                if ([invitationCode isKindOfClass:[NSString class]])
                                {
                                    [params setObject:invitationCode forKey:shoppingcar_invitationCode_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_invitationCode_key];
                                }
                                
                                NSString *goodscode_value = [result stringForColumn:shoppingcar_goodsCode_key];
                                if ([goodscode_value isKindOfClass:[NSString class]])
                                {
                                    [params setObject:goodscode_value forKey:shoppingcar_goodsCode_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_goodsCode_key];
                                }
                                
                                NSString *count_value = [result stringForColumn:shoppingcar_count_key];
                                if ([count_value isKindOfClass:[NSString class]])
                                {
                                    [params setObject:count_value forKey:shoppingcar_count_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_count_key];
                                }
                                
                                NSString *creatdate_value = [result stringForColumn:shoppingcar_createDate_key];
                                if ([creatdate_value isKindOfClass:[NSString class]])
                                {
                                    [params setObject:creatdate_value forKey:shoppingcar_createDate_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_createDate_key];
                                }
                                
                                NSString *imageurl_value = [result stringForColumn:shoppingcar_imageUrl_key];
                                if ([imageurl_value isKindOfClass:[NSString class]])
                                {
                                    [params setObject:imageurl_value forKey:shoppingcar_imageUrl_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_imageUrl_key];
                                }
                                
                                NSString *italyname_value = [result stringForColumn:shoppingcar_italyName_key];
                                if ([italyname_value isKindOfClass:[NSString class]])
                                {
                                    [params setObject:italyname_value forKey:shoppingcar_italyName_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_italyName_key];
                                }
                                
                                NSString *price_value = [result stringForColumn:shoppingcar_price_key];
                                if ([price_value isKindOfClass:[NSString class]])
                                {
                                    [params setObject:price_value forKey:shoppingcar_price_key];
                                } else  {
                                    [params setObject:@"" forKey:shoppingcar_price_key];
                                }
                                
                                NSString *packagenumber_value = [result stringForColumn:shoppingcar_packageNumber_key];
                                if ([packagenumber_value isKindOfClass:[NSString class]])
                                {
                                    [params setObject:packagenumber_value forKey:shoppingcar_packageNumber_key];
                                } else  {
                                    [params setObject:@"" forKey:shoppingcar_packageNumber_key];
                                }
                                
                                NSString *zhname_value = [result stringForColumn:shoppingcar_zhName_key];
                                if ([zhname_value isKindOfClass:[NSString class]])
                                {
                                    [params setObject:zhname_value forKey:shoppingcar_zhName_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_zhName_key];
                                }
                                
                                NSString *apecifications_value = [result stringForColumn:shoppingcar_specifications_key];
                                if ([apecifications_value isKindOfClass:[NSString class]])
                                {
                                    [params setObject:apecifications_value forKey:shoppingcar_specifications_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_specifications_key];
                                }
                                
                                NSString *infolist_value = [result stringForColumn:shoppingcar_infolistid_key];
                                if ([infolist_value isKindOfClass:[NSString class]])
                                {
                                    [params setObject:infolist_value forKey:shoppingcar_infolistid_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_infolistid_key];
                                }
                                
                                NSString *weight_value = [result stringForColumn:shoppingcar_weightKg_key];
                                if ([weight_value isKindOfClass:[NSString class]])
                                {
                                    [params setObject:weight_value forKey:shoppingcar_weightKg_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_weightKg_key];
                                }
                                
                                NSString *s_old_price_value = [result stringForColumn:shoppingcar_s_price_old_key];
                                if ([s_old_price_value isKindOfClass:[NSString class]]) {
                                    [params setObject:s_old_price_value forKey:shoppingcar_s_price_old_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_s_price_old_key];
                                }
                                
                                NSString *discount_value = [result stringForColumn:shoppingcar_s_discount_key];
                                if ([discount_value isKindOfClass:[NSString class]]) {
                                    [params setObject:discount_value forKey:shoppingcar_s_discount_key];
                                } else {
                                    [params setObject:@"" forKey:shoppingcar_s_discount_key];
                                }
                                
                                [allNullDataList addObject:params];
                            }
                            
                            [db close];
                        }];

                        // 2. 写入当前用户所用的db当中
                        FMDatabaseQueue *currentDbQueue=[FMDatabaseQueue databaseQueueWithPath:toPathStr];
                        [currentDbQueue inDatabase:^(FMDatabase *db) {
                            
                            if (![db open]) {
                                NSLog(@"打开%@/totalData.db失败",[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]);
                                return ;
                            }
                            
                            for (NSDictionary *dictionary in allNullDataList) {
                                NSString *insertSQL = [NSString stringWithFormat:@"insert into shoppingcar%@ (%@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@) values ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)", shoppingcarKey,shoppingcar_invitationCode_key, shoppingcar_goodsCode_key, shoppingcar_count_key, shoppingcar_createDate_key, shoppingcar_imageUrl_key, shoppingcar_italyName_key, shoppingcar_price_key, shoppingcar_packageNumber_key, shoppingcar_zhName_key, shoppingcar_specifications_key, shoppingcar_infolistid_key, shoppingcar_weightKg_key, shoppingcar_s_price_old_key,shoppingcar_s_discount_key];
                                BOOL insertRes = [db executeUpdate:insertSQL,dictionary[shoppingcar_invitationCode_key], dictionary[shoppingcar_goodsCode_key], dictionary[shoppingcar_packageNumber_key], dictionary[shoppingcar_createDate_key], dictionary[shoppingcar_imageUrl_key], dictionary[shoppingcar_italyName_key], dictionary[shoppingcar_price_key], dictionary[shoppingcar_packageNumber_key], dictionary[shoppingcar_zhName_key], dictionary[shoppingcar_specifications_key], dictionary[shoppingcar_infolistid_key], dictionary[shoppingcar_weightKg_key],dictionary[shoppingcar_s_price_old_key],dictionary[shoppingcar_s_discount_key]];
                                if (insertRes) {
                                    NSLog(@"向%@/totalData.db 的shoppingcar表新增数据成功",[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]);
                                } else {
                                    NSLog(@"向%@/totalData.db 的shoppingcar表新增数据失败",[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]);
                                }
                            }
                                                        
                            [db close];
                        }];
                    } else {
                        NSError * error = nil;
                        // 执行移动操作
                        BOOL isMoveSucc = [fileManager moveItemAtPath:nullDbFilePath
                                              toPath:toPathStr
                                               error:&error];
                        if (isMoveSucc) {
                            NSLog(@"移动(null)中的totalData.db数据库成功");
                        } else {
                            NSLog(@"移动(null)中的totalData.db数据库失败");
                        }
                        
                        NSLog(@"Unable to move file: %@", [error localizedDescription]);
                    }
                    
                    // 3. 删除原来的(null)的文件
                    BOOL isDeleteSucc = [fileManager removeItemAtPath:[NSString stringWithFormat:@"%@/(null)", documentsPath] error:nil];
                    if (isDeleteSucc) {
                        NSLog(@"删除(null)文件夹数据库成功");
                    } else {
                        NSLog(@"删除(null)文件夹数据库失败");
                    }
                }
            } else{
                NSLog(@"(null)该文件不存在或已被删除");
            }
        }
    }
    
}



@end
