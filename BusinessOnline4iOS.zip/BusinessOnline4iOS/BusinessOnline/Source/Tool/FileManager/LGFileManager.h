//
//  LGFileManager.h
//  BusinessOnline
//
//  Created by lgerp on 2020/12/4.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGFileManager : NSObject

+(instancetype)shared;


/**
    获取数据库操作的文件路径
 */
+ (NSString *)getDataBaseFilePath;

/** 设置新的数据库操作路径 */
+ (NSString *)setNewDBFilePathWithCurrentUser:(NSString *)userName;



@end

NS_ASSUME_NONNULL_END
