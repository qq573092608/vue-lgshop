//
//  LGFileManager.m
//  BusinessOnline
//
//  Created by lgerp on 2020/12/4.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGFileManager.h"

@implementation LGFileManager

+(instancetype)shared
{
    static LGFileManager *_fileManager = nil;
    static dispatch_once_t tocken = 0;
    dispatch_once(&tocken, ^{
        _fileManager = [[LGFileManager alloc] init];
    });
    return _fileManager;
}

+ (NSString *)getDataBaseFilePath
{
    NSString *currentUser = [[NSUserDefaults standardUserDefaults] objectForKey:kUserName];
    NSString *documentsPath = [LGFileManager getDBBasePath];
    NSString *finalDBPath = [documentsPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/totalData.db",currentUser]];
    return finalDBPath;
}


+ (NSString *)setNewDBFilePathWithCurrentUser:(NSString *)userName
{
    NSString *documentsPath = [LGFileManager getDBBasePath];
    NSString *finalDBPath = [documentsPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/totalData.db",userName]];
    return  finalDBPath;
}


+ (NSString *)getDBBasePath{
    return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
}


@end
