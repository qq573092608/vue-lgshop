//
//  LgFileManagerUtil.h
//  BusinessOnline
//
//  Created by lgerp on 2020/9/10.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LgFileManagerUtil : NSObject


/// 保存远程图片到本地
/// @param imgs 目标图片数组
+ (void)saveUrlImgsToLocal:(NSArray *)imgs;


/// 查询本地图片
+ (NSArray *)queryLocalImgs;

@end

NS_ASSUME_NONNULL_END
