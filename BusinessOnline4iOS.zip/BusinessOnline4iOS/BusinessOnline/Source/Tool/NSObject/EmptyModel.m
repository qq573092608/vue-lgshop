//
//  EmptyModel.m
//  ERPApp
//
//  Created by clitics on 2018/10/20.
//  Copyright © 2018年 clitics. All rights reserved.
//

#import "EmptyModel.h"
#import <UIScrollView+EmptyDataSet.h>

@interface EmptyModel ()<DZNEmptyDataSetSource, DZNEmptyDataSetDelegate>
{
    UIScrollView *_scrollView;
}

@end
@implementation EmptyModel

-(instancetype)initWithScrollView:(UIScrollView *)scrollView type:(ControllerState)state
{
    if (self = [super init])
    {
        _scrollView = scrollView;
        scrollView.emptyDataSetSource = self;
        scrollView.emptyDataSetDelegate = self;
        
        self.state = state;
        
    }
    return self;
}
- (void)reload
{
    [_scrollView reloadEmptyDataSet];
}
-(void)setState:(ControllerState)state
{
    _state = state;
    
    switch (_state) {
        case ControllerStateNoNetwork:
            [self setStatus:NSLocalizedString(@"zusj", nil)];
            break;
        case ControllerStateNoUser:
            [self setStatus:NSLocalizedString(@"zusj", nil)];
            break;
        case ControllerStateNoBill:
            [self setStatus:NSLocalizedString(@"zusj", nil)];
            break;
        case ControllerStateNoProduct:
            [self setStatus:NSLocalizedString(@"zusj", nil)];
            break;
        case ControllerStateNoLogicstics:
            [self setStatus:NSLocalizedString(@"zusj", nil)];
            break;
        case ControllerStateNoThirdParties:
            [self setStatus:NSLocalizedString(@"zusj", nil)];
            break;
        case ControllerStateNoInvoiceSendOut:
            [self setStatus:NSLocalizedString(@"zusj", nil)];
            break;
        case ControllerStateNoInvoiceReceipt:
            [self setStatus:NSLocalizedString(@"zusj", nil)];
            break;
        case ControllerStateListNoData:
            
            break;
        
        default:
            [self setStateImageName:@"" title:@"" btnImageName:@""];
            break;
    }
    [_scrollView reloadEmptyDataSet];
}

- (void)setStateImageName:(NSString *)stateImageName title:(NSString *)title btnImageName:(NSString *)btnImageName
{
    self.stateImageName = stateImageName;
    self.title = title;
    self.btnImageName = btnImageName;
}

- (void)setStatus:(NSString *)status
{
    self.title = status;
    self.stateImageName = @"046_i";
    [_scrollView reloadEmptyDataSet];
}

#pragma mark empty data set delegate methods
- (UIImage *)imageForEmptyDataSet:(UIScrollView *)scrollView
{
    return [UIImage imageNamed:self.stateImageName];
}

- (NSAttributedString *)descriptionForEmptyDataSet:(UIScrollView *)scrollView
{
    NSMutableParagraphStyle *paragraph = [NSMutableParagraphStyle new];
    paragraph.lineBreakMode = NSLineBreakByWordWrapping;
    paragraph.alignment = NSTextAlignmentCenter;
    
    NSDictionary *attributes = @{NSFontAttributeName: [UIFont systemFontOfSize:16.0f],
                                 NSForegroundColorAttributeName: [UIColor lightGrayColor],
                                 NSParagraphStyleAttributeName: paragraph};
    
    return [[NSAttributedString alloc] initWithString:self.title attributes:attributes];
}

- (UIImage *)buttonImageForEmptyDataSet:(UIScrollView *)scrollView forState:(UIControlState)state
{
    return [UIImage imageNamed:self.btnImageName];
}

- (CGFloat)spaceHeightForEmptyDataSet:(UIScrollView *)scrollView
{
    return 20.0f;
}

- (BOOL)emptyDataSetShouldDisplay:(UIScrollView *)scrollView
{
    return YES;
}

- (BOOL)emptyDataSetShouldAllowTouch:(UIScrollView *)scrollView
{
    return YES;
}

- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView
{
    return YES;
}

- (void)emptyDataSet:(UIScrollView *)scrollView didTapButton:(UIButton *)button
{
    self.state = ControllerStateNormal;
    
    if (self.callback)
    {
        self.callback();
    }
}

@end
