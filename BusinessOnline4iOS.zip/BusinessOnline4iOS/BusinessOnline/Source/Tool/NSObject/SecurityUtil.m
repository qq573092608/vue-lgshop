//
//  SecurityUtil.h
//  Smile
//
//  Created by 蒲晓涛 on 12-11-24.
//  Copyright (c) 2012年 BOX. All rights reserved.
//

// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com

#import "SecurityUtil.h"
#import "NSData+AES.h"


@implementation SecurityUtil

#pragma mark - AES加密
//将string转成带密码的data
+(NSString*)encryptAESData:(NSString*)string app_key:(NSString*)key
{
    //将nsstring转化为nsdata
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    //使用密码对nsdata进行加密
    NSData *encryptedData = [data AES128EncryptWithKey:key];
    //NSLog(@"加密后的字符串 :%@",[encryptedData base64Encoding]);
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    return [encryptedData base64Encoding];
#pragma clang diagnostic pop
}

#pragma mark - AES解密
//将带密码的data转成string
+(NSString*)decryptAESData:(NSData*)data  app_key:(NSString*)key
{
    //使用密码对data进行解密
    NSData *decryData = [data AES128DecryptWithKey:key];
    //将解了密码的nsdata转化为nsstring
    NSString *str = [[NSString alloc] initWithData:decryData encoding:NSUTF8StringEncoding];
    return str;
}
//调用
+ (NSString *)inputNsstring:(NSString *)inputString{
    NSString *stringxx = [SecurityUtil encryptAESData:inputString app_key:@"f9318bb5ea4fc2a5"];
//    stringxx = [stringxx stringByReplacingOccurrencesOfString:@"=" withString:@""];
//    stringxx = [stringxx stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
//    return [stringxx stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
    return stringxx;
}
+ (NSString *)outputNsstring:(NSString *)outputString{
    
    
//    outputString = [outputString stringByReplacingOccurrencesOfString:@"_" withString:@"/"];
//    outputString = [outputString stringByReplacingOccurrencesOfString:@"-" withString:@"+"];
//    outputString = [outputString stringByAppendingString:@"=="];
    
    NSData *datax = [[NSData alloc] initWithBase64EncodedString:outputString options:NSUTF8StringEncoding];
    NSString *string1 = [SecurityUtil decryptAESData:datax app_key:@"f9318bb5ea4fc2a5"];
    return string1;
}
@end
