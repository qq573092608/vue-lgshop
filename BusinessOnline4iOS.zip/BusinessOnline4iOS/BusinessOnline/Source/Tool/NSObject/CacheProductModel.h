//
//  CacheProductModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/4/1.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CacheProductModel : NSObject<NSCoding>

@property (nonatomic,copy)NSString *invitationCode;
@property (nonatomic,copy)NSString *goodsCode;
@property (nonatomic,copy)NSString *count;
@property (nonatomic,copy)NSString *createDate;
/**
   图片
 */
@property (nonatomic,copy)NSString *imageUrl;

@property (nonatomic,copy)NSString *italyName;
/**
   价格
 */
@property (nonatomic,copy)NSString *price;
@property (nonatomic,copy)NSString *packageNumber;
@property (nonatomic,copy)NSString *zhName;
@property (nonatomic,copy)NSString *specifications;

@property (nonatomic,copy)NSString *infolistid;
@property (nonatomic,copy)NSString *weightKg;
/** 折扣价 */
@property (nonatomic,copy)NSString *s_price_old;
/** 折扣率 */
@property (nonatomic,copy)NSString *s_discount;
/** 用户名 */
@property (nonatomic,copy)NSString *userName;

/** 商品描述信息 */
@property (nonatomic,copy)NSString *goodsDescription;
/** 对应商品的规格列表 */
@property (nonatomic,copy)NSString *tasteList;
/** 对应商品的规格价格以及库存的列表 */
@property (nonatomic,copy)NSString *tasteInfoList;
/**realInventory */
@property (nonatomic,copy)NSString *realInventory;

@end

NS_ASSUME_NONNULL_END
