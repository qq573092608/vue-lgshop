//
//  LgFileManagerUtil.m
//  BusinessOnline
//
//  Created by lgerp on 2020/9/10.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LgFileManagerUtil.h"

@implementation LgFileManagerUtil

+ (void)saveUrlImgsToLocal:(NSArray *)imgs
{
    NSString *filePath = [self getSavePathWithFileName:@"homePic.plist"];
    NSMutableArray *savePicArr = [[NSMutableArray alloc] init];
    for (UIImage *img in imgs) {
        // 图片转为base64字符
        NSData *_data = UIImageJPEGRepresentation(img, 1.0f);
        // 将图片转为字符串
        NSString *encodedImageStr = [_data base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
        [savePicArr addObject:encodedImageStr];
    }
    
    // 数组写入plist文件中
    if ([savePicArr writeToFile:filePath atomically:YES]) {
        NSLog(@"写入成功");
    };
}

+ (NSArray *)queryLocalImgs
{
    NSString *filePath = [self getSavePathWithFileName:@"homePic.plist"];
    NSMutableArray *imageArr = [[NSMutableArray alloc] initWithContentsOfFile:filePath];

    NSMutableArray *returnArr = [[NSMutableArray alloc] init];
    for (NSString *base64ImgStr in imageArr) {
        NSData *decodedImageData = [[NSData alloc] initWithBase64EncodedString:base64ImgStr
                                                                       options:NSDataBase64DecodingIgnoreUnknownCharacters];
        UIImage *decodedImage = [UIImage imageWithData:decodedImageData];
        [returnArr addObject:decodedImage];
    }
    
    return returnArr;
}

+ (NSString *)getSavePathWithFileName:(NSString *)fileName
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    NSString *finalFilePath = [path stringByAppendingPathComponent:fileName];
    return finalFilePath;
}


@end
