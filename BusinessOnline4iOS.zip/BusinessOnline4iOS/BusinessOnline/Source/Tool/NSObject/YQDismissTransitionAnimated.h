//
//  YQDismissTransitionAnimated.h
//  YQPresentLikePush
//
//  Created by 杨麒 on 16/8/13.
//  Copyright © 2016年 杨麒. All rights reserved.
//

#import <Foundation/Foundation.h>
@import UIKit;

@interface YQDismissTransitionAnimated : NSObject<UIViewControllerAnimatedTransitioning>

@end
