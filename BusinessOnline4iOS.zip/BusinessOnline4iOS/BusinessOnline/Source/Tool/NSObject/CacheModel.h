//
//  CacheModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/4/1.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CacheProductModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CacheModel : NSObject

@property (nonatomic,copy,readonly)NSString *filePath;

@property (nonatomic,strong)NSMutableDictionary *products;

+ (instancetype)shared;

- (void)addShoppingCar:(CacheProductModel *)model;

- (void)deleteFromShoppingCar:(NSString *)productCode;

- (void)clearShoppingCar;

- (void)clearShoppingCarWithInvitationCode:(NSString *)invitationCode;

- (CacheProductModel *)modelForKey:(NSString *)goodsCode;

- (NSArray<CacheProductModel *> *)modelsForInvitationCode:(NSString *)invitationCode;

@end

NS_ASSUME_NONNULL_END
