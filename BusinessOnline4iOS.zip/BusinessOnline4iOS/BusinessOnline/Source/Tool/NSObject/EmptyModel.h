//
//  EmptyModel.h
//  ERPApp
//
//  Created by clitics on 2018/10/20.
//  Copyright © 2018年 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum : NSInteger
{
    ControllerStateNormal,
    ControllerStateNoNetwork,
    ControllerStateListNoData,
    ControllerStateNoUser,
    ControllerStateNoBill,
    ControllerStateNoProduct,
    ControllerStateNoLogicstics,
    ControllerStateNoThirdParties,
    ControllerStateNoInvoiceSendOut,
    ControllerStateNoInvoiceReceipt
}ControllerState;
NS_ASSUME_NONNULL_BEGIN

@interface EmptyModel : NSObject

@property (nonatomic,strong)NSString *stateImageName;

@property (nonatomic,strong)NSString *title;

@property (nonatomic,strong)NSString *btnImageName;

@property (nonatomic,assign)ControllerState state;

@property (nonatomic,copy)void(^callback)(void);

- (instancetype)initWithScrollView:(UIScrollView *)scrollView type:(ControllerState)state;

- (void)setStatus:(NSString *)status;

@end

NS_ASSUME_NONNULL_END
