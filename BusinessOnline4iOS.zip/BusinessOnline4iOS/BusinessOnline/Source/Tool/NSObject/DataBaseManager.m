//
//  DataBaseManager.m
//  BusinessOnline
//
//  Created by clitics on 2019/4/23.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "DataBaseManager.h"
#import "LGDataBaseManager.h"
#import "FMDBMigrationManager.h"
#import "Migration.h"

@interface DataBaseManager ()

@property (nonatomic,strong)FMDatabaseQueue *queue;
@property (nonatomic,strong)NSString *filePath;

@end
@implementation DataBaseManager


+(instancetype)shared
{
    static DataBaseManager *_model = nil;
    static dispatch_once_t tocken = 0;
    dispatch_once(&tocken, ^{
        _model = [[DataBaseManager alloc] init];
        // 获取DocumentDirectory目录的路径
        NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
        // 将就数据迁移进来
        [LGDataBaseManager copyNullDBData2CurrentUserDBData];
        // 获取文件路径
        _model.filePath = [documentsPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/totalData.db",[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]]];
        _model.queue = [FMDatabaseQueue databaseQueueWithPath:_model.filePath];
    });
    
    return _model;
}

-(void)changeUser:(NSString *)userName
{
    NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    if ([[NSFileManager defaultManager] createDirectoryAtPath:[documentsPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/",[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]]]
                                  withIntermediateDirectories:YES
                                                   attributes:nil
                                                        error:nil]) {
        self.filePath = [documentsPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/totalData.db",userName]];
        self.queue = [FMDatabaseQueue databaseQueueWithPath:self.filePath];
        
    } else {
        NSLog(@"创建失败");
    }
}

- (BOOL)updateDataBase:(NSString *)fileName{
    NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString *filePath =  [documentsPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/totalData.db",[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]]];
    FMDBMigrationManager * manager=[FMDBMigrationManager managerWithDatabaseAtPath:filePath
                                                                  migrationsBundle:[NSBundle mainBundle]];
    
    NSString *addUserStr = [NSString stringWithFormat:@"alter table %@%@ add userName text",fileName,shoppingcarKey];
    NSString *addGoodsDesStr = [NSString stringWithFormat:@"alter table %@%@ add goodsDescription text",fileName,shoppingcarKey];
    NSString *addrealInventoryStr = [NSString stringWithFormat:@"alter table %@%@ add %@ text",fileName,shoppingcarKey,shoppingcar_realInventory_Key];

    NSString *tasteListStr = [NSString stringWithFormat:@"alter table %@%@ add %@ text",fileName,shoppingcarKey,shoppingcar_tasteList_Key];
    NSString *tasteInfoListStr = [NSString stringWithFormat:@"alter table %@%@ add %@ text",fileName,shoppingcarKey,shoppingcar_tasteInfoList_Key];

    Migration * migration_1=[[Migration alloc]initWithName:@"新增用户、商品描述、库存、多规格内容、多规格对应的价格以及库存相关字段"
                                                andVersion:1
                                     andExecuteUpdateArray:@[addUserStr,addGoodsDesStr,addrealInventoryStr,tasteListStr,tasteInfoListStr]];//给User表添加email字段

    [manager addMigration:migration_1];

    BOOL resultState = NO;
    NSError * error = nil;
    if (!manager.hasMigrationsTable) {
        resultState=[manager createMigrationsTable:&error];
    }
    resultState = [manager migrateDatabaseToVersion:UINT64_MAX progress:nil error:&error];
    return resultState;
}

- (void)getshoppingcarwithFileName:(NSString *)fileName success:(void(^)(NSArray<NSDictionary *> * classifies))block
{
    [self.queue inDatabase:^(FMDatabase *db) {
        if (![db open]) {
            block(@[]);
            return ;
        }
        NSMutableArray *temp = [NSMutableArray array];
        NSString *sql = [NSString stringWithFormat:@"select * from %@%@ order by %@ asc", fileName, shoppingcarKey, dataIdKey];
        
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            NSMutableDictionary *params = [NSMutableDictionary dictionary];
            
            int dataId = [result intForColumn:dataIdKey];
            [params setObject:@(dataId) forKey:dataIdKey];
            
            NSString *invitationCode = [result stringForColumn:shoppingcar_invitationCode_key];
            if ([invitationCode isKindOfClass:[NSString class]]) {
                [params setObject:invitationCode forKey:shoppingcar_invitationCode_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_invitationCode_key];
            }
            
            NSString *goodscode_value = [result stringForColumn:shoppingcar_goodsCode_key];
            if ([goodscode_value isKindOfClass:[NSString class]]) {
                [params setObject:goodscode_value forKey:shoppingcar_goodsCode_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_goodsCode_key];
            }
            
            NSString *count_value = [result stringForColumn:shoppingcar_count_key];
            if ([count_value isKindOfClass:[NSString class]]) {
                [params setObject:count_value forKey:shoppingcar_count_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_count_key];
            }
            
            NSString *creatdate_value = [result stringForColumn:shoppingcar_createDate_key];
            if ([creatdate_value isKindOfClass:[NSString class]]) {
                [params setObject:creatdate_value forKey:shoppingcar_createDate_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_createDate_key];
            }
            
            NSString *imageurl_value = [result stringForColumn:shoppingcar_imageUrl_key];
            
            if ([imageurl_value isKindOfClass:[NSString class]]) {
                [params setObject:imageurl_value forKey:shoppingcar_imageUrl_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_imageUrl_key];
            }
            
            NSString *italyname_value = [result stringForColumn:shoppingcar_italyName_key];
            if ([italyname_value isKindOfClass:[NSString class]]) {
                [params setObject:italyname_value forKey:shoppingcar_italyName_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_italyName_key];
            }
            
            NSString *price_value = [result stringForColumn:shoppingcar_price_key];
            if ([price_value isKindOfClass:[NSString class]]) {
                [params setObject:price_value forKey:shoppingcar_price_key];
            } else  {
                [params setObject:@"" forKey:shoppingcar_price_key];
            }
            
            NSString *packagenumber_value = [result stringForColumn:shoppingcar_packageNumber_key];
            if ([packagenumber_value isKindOfClass:[NSString class]]) {
                [params setObject:packagenumber_value forKey:shoppingcar_packageNumber_key];
            } else  {
                [params setObject:@"" forKey:shoppingcar_packageNumber_key];
            }
            
            NSString *zhname_value = [result stringForColumn:shoppingcar_zhName_key];
            if ([zhname_value isKindOfClass:[NSString class]]) {
                [params setObject:zhname_value forKey:shoppingcar_zhName_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_zhName_key];
            }
            
            NSString *apecifications_value = [result stringForColumn:shoppingcar_specifications_key];
            if ([apecifications_value isKindOfClass:[NSString class]]) {
                [params setObject:apecifications_value forKey:shoppingcar_specifications_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_specifications_key];
            }
            
            NSString *infolist_value = [result stringForColumn:shoppingcar_infolistid_key];
            if ([infolist_value isKindOfClass:[NSString class]]) {
                [params setObject:infolist_value forKey:shoppingcar_infolistid_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_infolistid_key];
            }
                                                             
            NSString *weight_value = [result stringForColumn:shoppingcar_weightKg_key];
            if ([weight_value isKindOfClass:[NSString class]]) {
                [params setObject:weight_value forKey:shoppingcar_weightKg_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_weightKg_key];
            }
            
            NSString *s_old_price_value = [result stringForColumn:shoppingcar_s_price_old_key];
            if ([s_old_price_value isKindOfClass:[NSString class]]) {
                [params setObject:s_old_price_value forKey:shoppingcar_s_price_old_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_s_price_old_key];
            }
            
            NSString *discount_value = [result stringForColumn:shoppingcar_s_discount_key];
            if ([discount_value isKindOfClass:[NSString class]]) {
                [params setObject:discount_value forKey:shoppingcar_s_discount_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_s_discount_key];
            }
            
            NSString *userName_value = [result stringForColumn:shoppingcar_userName_key];
            if ([userName_value isKindOfClass:[NSString class]]) {
                [params setObject:userName_value forKey:shoppingcar_userName_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_userName_key];
            }

            NSString *goodDes_value = [result stringForColumn:shoppingcar_goodsDescription_key];
            if ([goodDes_value isKindOfClass:[NSString class]]) {
                [params setObject:goodDes_value forKey:shoppingcar_goodsDescription_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_goodsDescription_key];
            }
            
            NSString *tasteList_value = [result stringForColumn:shoppingcar_tasteList_Key];
            if ([tasteList_value isKindOfClass:[NSString class]]) {
                [params setObject:tasteList_value forKey:shoppingcar_tasteList_Key];
            } else {
                [params setObject:@"" forKey:shoppingcar_tasteList_Key];
            }

            NSString *tasteInfoList_value = [result stringForColumn:shoppingcar_tasteInfoList_Key];
            if ([tasteInfoList_value isKindOfClass:[NSString class]]) {
                [params setObject:tasteInfoList_value forKey:shoppingcar_tasteInfoList_Key];
            } else {
                [params setObject:@"" forKey:shoppingcar_tasteInfoList_Key];
            }
            
            NSString *realInventory_value = [result stringForColumn:shoppingcar_realInventory_Key];
            if ([realInventory_value isKindOfClass:[NSString class]]) {
                [params setObject:tasteInfoList_value forKey:shoppingcar_realInventory_Key];
            } else {
                [params setObject:@"" forKey:shoppingcar_realInventory_Key];
            }
            
            [temp addObject:params];
        }
        if (block) {
            block(temp);
        }
        [db close];
    }];
}

- (void)deleteshoppingcarcallback:(void(^)(BOOL success))block
{
    [self.queue inDatabase:^(FMDatabase *db) {
        if (![db open]) {
            block(NO);
            return ;
        }
        
        NSString *deleteSQL = [NSString stringWithFormat:@"delete from shoppingcar%@",shoppingcarKey];
        
        [db executeUpdate:deleteSQL];
        
        [db close];
        block(YES);
    }];
}

- (void)addshoppingcar:(NSDictionary *)dictionary
          withfilename:(NSString *)fileName
     isMayBeMutableNum:(BOOL)isMayBeMutable
     isSpecifationType:(BOOL)isSpecifationType
               success:(void(^)(BOOL success))block
{
    [self.queue inDatabase:^(FMDatabase *db) {
        if (![db open]) {
            block(NO);
            return ;
        }
        
        BOOL isTableDeleted = [[NSUserDefaults standardUserDefaults] boolForKey:kIsShoppingCarDeleted];
        if (!isTableDeleted) {
            NSString *dropTables = [NSString stringWithFormat:@"DROP TABLE IF EXISTS %@%@;",fileName,shoppingcarKey];
            BOOL isDropSucc = [db executeUpdate:dropTables];
            if (isDropSucc) {
                [Bugly reportException:[NSException exceptionWithName:@"DBDropInfo"
                                                               reason:[NSString stringWithFormat:@"删除 %@%@ 成功",fileName,shoppingcarKey]
                                                             userInfo:nil]];
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:kIsShoppingCarDeleted];
            } else {
                [Bugly reportException:[NSException exceptionWithName:@"DBDropInfo"
                                                               reason:[NSString stringWithFormat:@"删除 %@%@ 失败",fileName,shoppingcarKey]
                                                             userInfo:nil]];
            }
        }
        
        NSString *createSQL = [NSString stringWithFormat:@"create table if not exists %@%@ (dataId integer primary key autoincrement,%@ text, %@ text,  %@ text, %@ text, %@ text,%@ text, %@ text, %@ text, %@ text, %@ text, %@ text, %@ text, %@ text, %@ text, %@ text, %@ text,%@ text, %@ text,%@ text)", fileName, shoppingcarKey, shoppingcar_invitationCode_key, shoppingcar_goodsCode_key, shoppingcar_count_key, shoppingcar_createDate_key, shoppingcar_imageUrl_key, shoppingcar_italyName_key, shoppingcar_price_key, shoppingcar_packageNumber_key, shoppingcar_zhName_key, shoppingcar_specifications_key, shoppingcar_infolistid_key, shoppingcar_weightKg_key, shoppingcar_s_price_old_key,shoppingcar_s_discount_key,shoppingcar_userName_key,shoppingcar_goodsDescription_key,shoppingcar_tasteList_Key,shoppingcar_tasteInfoList_Key,shoppingcar_realInventory_Key];
        BOOL isCreateSucc =  [db executeUpdate:createSQL];
        if (isCreateSucc) {
            [Bugly reportException:[NSException exceptionWithName:@"DBCreateTableInfo"
                                                           reason:[NSString stringWithFormat:@"新增 %@%@ 表成功!",fileName, shoppingcarKey]
                                                         userInfo:nil]];
        } else {
            [Bugly reportException:[NSException exceptionWithName:@"DBCreateTableInfo"
                                                           reason:[NSString stringWithFormat:@"新增 %@%@ 表失败!",fileName, shoppingcarKey]
                                                         userInfo:nil]];
        }
        
        BOOL ispresence = NO;
        
        // 查询插入的数据是否存在
        NSString *selectSQL = [NSString stringWithFormat:@"select * from %@%@ where %@ == '%@' and %@ == '%@'",fileName, shoppingcarKey, shoppingcar_goodsCode_key, dictionary[shoppingcar_goodsCode_key],shoppingcar_specifications_key,dictionary[shoppingcar_specifications_key]];
        FMResultSet *result = [db executeQuery:selectSQL];
        NSString *count;
        if ([result next]) {
            // 获取库存中原本的数量
            NSString *num = [result stringForColumn:shoppingcar_count_key];
            
            NSString *packagenumber = @"";
            if (isMayBeMutable) {
                packagenumber = dictionary[shoppingcar_packageNumber_key];
            } else {
                packagenumber = [result stringForColumn:shoppingcar_packageNumber_key];
            }
            
            // 原来的        + packagenumber
          //  count = [NSString stringWithFormat:@"%d",num.intValue + packagenumber.intValue];
            
            if (isSpecifationType) {
                count = [NSString stringWithFormat:@"%d",num.intValue + [dictionary[shoppingcar_count_key] intValue]];
            } else {
                // 原来的        + packagenumber
                count = [NSString stringWithFormat:@"%d",num.intValue + packagenumber.intValue];
            }
            
            ispresence = YES;
        }
        
        if (ispresence == YES) {
            NSString *updataSQL = [NSString stringWithFormat:@"update %@%@ set %@ = ? where %@ = '%@' and %@ = '%@'",fileName, shoppingcarKey, shoppingcar_count_key, shoppingcar_goodsCode_key, dictionary[shoppingcar_goodsCode_key], shoppingcar_specifications_key, dictionary[shoppingcar_specifications_key]];
            [db executeUpdate:updataSQL,count];
        } else {
             NSString *insertSQL = [NSString stringWithFormat:@"insert into %@%@ (%@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@,%@,%@,%@,%@,%@) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?)", fileName, shoppingcarKey, shoppingcar_userName_key,shoppingcar_invitationCode_key, shoppingcar_goodsCode_key, shoppingcar_count_key, shoppingcar_createDate_key, shoppingcar_imageUrl_key, shoppingcar_italyName_key, shoppingcar_price_key, shoppingcar_packageNumber_key, shoppingcar_zhName_key, shoppingcar_specifications_key, shoppingcar_infolistid_key, shoppingcar_weightKg_key, shoppingcar_s_price_old_key,shoppingcar_s_discount_key,shoppingcar_goodsDescription_key,shoppingcar_tasteList_Key,shoppingcar_tasteInfoList_Key,shoppingcar_realInventory_Key];
            
            NSString *countValStr = @"";
            // 如果是多规格类型
            if (isSpecifationType) {
                countValStr = dictionary[shoppingcar_count_key];
            } else {
                countValStr = dictionary[shoppingcar_packageNumber_key];
            }
            
            BOOL insertRes = [db executeUpdate:insertSQL,
                               dictionary[shoppingcar_userName_key],
                               dictionary[shoppingcar_invitationCode_key],
                               dictionary[shoppingcar_goodsCode_key],
                               countValStr,
                               dictionary[shoppingcar_createDate_key],
                               dictionary[shoppingcar_imageUrl_key],
                               dictionary[shoppingcar_italyName_key],
                               dictionary[shoppingcar_price_key],
                               dictionary[shoppingcar_packageNumber_key],
                               dictionary[shoppingcar_zhName_key],
                               dictionary[shoppingcar_specifications_key],
                               dictionary[shoppingcar_infolistid_key],
                               dictionary[shoppingcar_weightKg_key],
                               dictionary[shoppingcar_s_price_old_key],
                               dictionary[shoppingcar_s_discount_key],
                               dictionary[shoppingcar_goodsDescription_key],
                               dictionary[shoppingcar_tasteList_Key],
                               dictionary[shoppingcar_tasteInfoList_Key],
                               dictionary[shoppingcar_realInventory_Key]];

            if (insertRes) {
                NSLog(@"新增数据成功");
            } else {
                NSLog(@"新增数据失败");
            }
        }
        
        [db close];
        block(YES);
    }];
}

- (void)updateshopnumber:(NSDictionary *)dictionary withfilename:(NSString *)fileName success:(void(^)(BOOL success))block
{
    [self.queue inDatabase:^(FMDatabase *db) {
        if (![db open]) {
            block(NO);
            return ;
        }
        
        NSString *updataSQL = [NSString stringWithFormat:@"update %@%@ set %@ = ? where %@ = '%@' and %@ = '%@'",fileName, shoppingcarKey, shoppingcar_count_key, shoppingcar_goodsCode_key, dictionary[shoppingcar_goodsCode_key], shoppingcar_specifications_key, dictionary[shoppingcar_specifications_key]];
        
        [db executeUpdate:updataSQL,dictionary[shoppingcar_count_key]];
        
        [db close];
        block(YES);
    }];
}

- (void)deletegoods:(NSDictionary *)dictionary withfilename:(NSString *)fileName success:(void(^)(BOOL success))block
{
    [self.queue inDatabase:^(FMDatabase *db) {
        if (![db open]) {
            block(NO);
            return ;
        }
        
        NSString *updataSQL = [NSString stringWithFormat:@"delete from %@%@ where %@ = '%@' and %@ = '%@'",
                               fileName, shoppingcarKey, shoppingcar_goodsCode_key, dictionary[shoppingcar_goodsCode_key], shoppingcar_specifications_key, dictionary[shoppingcar_specifications_key]];
        [db executeUpdate:updataSQL];
        [db close];
        block(YES);
    }];
}

- (void)modifySpecifaGoodsWithOldModel:(NSDictionary *)oldModelDic  newSpecifaDic:(NSDictionary *)dictionary success:(void(^)(BOOL success))block
{
    [self.queue inDatabase:^(FMDatabase *db) {
        if (![db open]) {
            block(NO);
            return ;
        }
        
        // 先删除之前的
        NSString *updataSQL = [NSString stringWithFormat:@"delete from shoppingcar%@ where %@ = '%@' and %@ = '%@'",
                                shoppingcarKey, shoppingcar_goodsCode_key, oldModelDic[shoppingcar_goodsCode_key], shoppingcar_specifications_key, oldModelDic[shoppingcar_specifications_key]];
        if ([db executeUpdate:updataSQL]) {
            NSLog(@"删除多规格成功");
            
            // 新增新的数据
            NSString *insertSQL = [NSString stringWithFormat:@"insert into shoppingcar%@ (%@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@,%@,%@,%@,%@,%@) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?)", shoppingcarKey, shoppingcar_userName_key,shoppingcar_invitationCode_key, shoppingcar_goodsCode_key, shoppingcar_count_key, shoppingcar_createDate_key, shoppingcar_imageUrl_key, shoppingcar_italyName_key, shoppingcar_price_key, shoppingcar_packageNumber_key, shoppingcar_zhName_key, shoppingcar_specifications_key, shoppingcar_infolistid_key, shoppingcar_weightKg_key, shoppingcar_s_price_old_key,shoppingcar_s_discount_key,shoppingcar_goodsDescription_key,shoppingcar_tasteList_Key,shoppingcar_tasteInfoList_Key,shoppingcar_realInventory_Key];
            BOOL insertRes = [db executeUpdate:insertSQL,
                              dictionary[shoppingcar_userName_key],
                              dictionary[shoppingcar_invitationCode_key],
                              dictionary[shoppingcar_goodsCode_key],
                              dictionary[shoppingcar_count_key],
                              dictionary[shoppingcar_createDate_key],
                              dictionary[shoppingcar_imageUrl_key],
                              dictionary[shoppingcar_italyName_key],
                              dictionary[shoppingcar_price_key],
                              dictionary[shoppingcar_packageNumber_key],
                              dictionary[shoppingcar_zhName_key],
                              dictionary[shoppingcar_specifications_key],
                              dictionary[shoppingcar_infolistid_key],
                              dictionary[shoppingcar_weightKg_key],
                              dictionary[shoppingcar_s_price_old_key],
                              dictionary[shoppingcar_s_discount_key],
                              dictionary[shoppingcar_goodsDescription_key],
                              dictionary[shoppingcar_tasteList_Key],
                              dictionary[shoppingcar_tasteInfoList_Key],
                              dictionary[shoppingcar_realInventory_Key]];

           if (insertRes) {
               NSLog(@"新增数据成功!");
               [db close];
               block(YES);
           } else {
               NSLog(@"新增数据失败!");
               [db close];
               block(NO);
           }
        } else {
            NSLog(@"删除多规格失败!");
            [db close];
            block(NO);
        }
    }];
}

- (void)reducegoods:(NSDictionary *)dictionary withfilename:(NSString *)fileName success:(void(^)(BOOL success))block
{
    [self.queue inDatabase:^(FMDatabase *db) {
        if (![db open]) {
            block(NO);
            return ;
        }
        
        NSString *selectSQL = [NSString stringWithFormat:@"select * from %@%@ where %@ == '%@' and %@ == '%@'",fileName, shoppingcarKey, shoppingcar_goodsCode_key, dictionary[shoppingcar_goodsCode_key],shoppingcar_specifications_key,dictionary[shoppingcar_specifications_key]];
        
        FMResultSet *result = [db executeQuery:selectSQL];
        NSString *count=@"0";
        BOOL isselect = NO;
        if ([result next]) {
            
            NSString *num = [result stringForColumn:shoppingcar_count_key];
            NSString *packagenumber = [result stringForColumn:shoppingcar_packageNumber_key];
            count = [NSString stringWithFormat:@"%d",num.intValue - packagenumber.intValue];
            
            isselect = YES;
        }
        
        if (count.intValue==0) {
            NSString *updataSQL = [NSString stringWithFormat:@"delete from %@%@ where %@ = '%@' and %@ = '%@'",fileName, shoppingcarKey, shoppingcar_goodsCode_key, dictionary[shoppingcar_goodsCode_key], shoppingcar_specifications_key, dictionary[shoppingcar_specifications_key]];
            [db executeUpdate:updataSQL];
            
        } else {
            NSString *updataSQL = [NSString stringWithFormat:@"update %@%@ set %@ = ? where %@ = '%@' and %@ = '%@'",fileName, shoppingcarKey, shoppingcar_count_key, shoppingcar_goodsCode_key, dictionary[shoppingcar_goodsCode_key], shoppingcar_specifications_key, dictionary[shoppingcar_specifications_key]];
            
            [db executeUpdate:updataSQL,count];
        }
        
        [db close];
        block(isselect);
    }];
}

- (void)getgoodsnumberwithFileName:(NSString *)fileName goodscode:(NSString *)goodscode success:(void(^)(NSArray<NSDictionary *> * classifies))block
{
    [self.queue inDatabase:^(FMDatabase *db) {
        if (![db open]) {
            block(@[]);
            return ;
        }
        NSMutableArray *temp = [NSMutableArray array];
        NSString *sql = [NSString stringWithFormat:@"select * from %@%@ where %@ = \'%@\' order by %@ asc", fileName, shoppingcarKey, shoppingcar_goodsCode_key, goodscode, dataIdKey];
        
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            NSMutableDictionary *params = [NSMutableDictionary dictionary];
            
            int dataId = [result intForColumn:dataIdKey];
            [params setObject:@(dataId) forKey:dataIdKey];
            
            NSString *invitationCode = [result stringForColumn:shoppingcar_invitationCode_key];
            if ([invitationCode isKindOfClass:[NSString class]])
            {
                [params setObject:invitationCode forKey:shoppingcar_invitationCode_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_invitationCode_key];
            }
            
            NSString *goodscode_value = [result stringForColumn:shoppingcar_goodsCode_key];
            if ([goodscode_value isKindOfClass:[NSString class]])
            {
                [params setObject:goodscode_value forKey:shoppingcar_goodsCode_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_goodsCode_key];
            }
            
            NSString *count_value = [result stringForColumn:shoppingcar_count_key];
            if ([count_value isKindOfClass:[NSString class]])
            {
                [params setObject:count_value forKey:shoppingcar_count_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_count_key];
            }
            
            NSString *creatdate_value = [result stringForColumn:shoppingcar_createDate_key];
            if ([creatdate_value isKindOfClass:[NSString class]])
            {
                [params setObject:creatdate_value forKey:shoppingcar_createDate_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_createDate_key];
            }
            
            NSString *imageurl_value = [result stringForColumn:shoppingcar_imageUrl_key];
            
            if ([imageurl_value isKindOfClass:[NSString class]])
            {
                [params setObject:imageurl_value forKey:shoppingcar_imageUrl_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_imageUrl_key];
            }
            
            NSString *italyname_value = [result stringForColumn:shoppingcar_italyName_key];
            if ([italyname_value isKindOfClass:[NSString class]])
            {
                [params setObject:italyname_value forKey:shoppingcar_italyName_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_italyName_key];
            }
            
            NSString *price_value = [result stringForColumn:shoppingcar_price_key];
            if ([price_value isKindOfClass:[NSString class]])
            {
                [params setObject:price_value forKey:shoppingcar_price_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_price_key];
            }
            
            NSString *packagenumber_value = [result stringForColumn:shoppingcar_packageNumber_key];
            if ([packagenumber_value isKindOfClass:[NSString class]])
            {
                [params setObject:packagenumber_value forKey:shoppingcar_packageNumber_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_packageNumber_key];
            }
            
            NSString *zhname_value = [result stringForColumn:shoppingcar_zhName_key];
            if ([zhname_value isKindOfClass:[NSString class]]) {
                [params setObject:zhname_value forKey:shoppingcar_zhName_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_zhName_key];
            }
            
            NSString *apecifications_value = [result stringForColumn:shoppingcar_specifications_key];
            if ([apecifications_value isKindOfClass:[NSString class]]) {
                [params setObject:apecifications_value forKey:shoppingcar_specifications_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_specifications_key];
            }
            
            NSString *infolist_value = [result stringForColumn:shoppingcar_infolistid_key];
            if ([infolist_value isKindOfClass:[NSString class]]) {
                [params setObject:infolist_value forKey:shoppingcar_infolistid_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_infolistid_key];
            }
            
            NSString *weight_value = [result stringForColumn:shoppingcar_weightKg_key];
            if ([weight_value isKindOfClass:[NSString class]]) {
                [params setObject:weight_value forKey:shoppingcar_weightKg_key];
            } else  {
                [params setObject:@"" forKey:shoppingcar_weightKg_key];
            }
            
            NSString *s_old_price_value = [result stringForColumn:shoppingcar_s_price_old_key];
            if ([s_old_price_value isKindOfClass:[NSString class]]) {
                [params setObject:s_old_price_value forKey:shoppingcar_s_price_old_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_s_price_old_key];
            }
            
            NSString *discount_value = [result stringForColumn:shoppingcar_s_discount_key];
            if ([discount_value isKindOfClass:[NSString class]]) {
                [params setObject:discount_value forKey:shoppingcar_s_discount_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_s_discount_key];
            }
            
            NSString *userName_value = [result stringForColumn:shoppingcar_userName_key];
            if ([userName_value isKindOfClass:[NSString class]]) {
                [params setObject:userName_value forKey:shoppingcar_userName_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_userName_key];
            }

            NSString *goodDes_value = [result stringForColumn:shoppingcar_goodsDescription_key];
            if ([goodDes_value isKindOfClass:[NSString class]]) {
                [params setObject:goodDes_value forKey:shoppingcar_goodsDescription_key];
            } else {
                [params setObject:@"" forKey:shoppingcar_goodsDescription_key];
            }
            
            NSString *tasteList_value = [result stringForColumn:shoppingcar_tasteList_Key];
            if ([tasteList_value isKindOfClass:[NSString class]]) {
                [params setObject:tasteList_value forKey:shoppingcar_tasteList_Key];
            } else {
                [params setObject:@"" forKey:shoppingcar_tasteList_Key];
            }

            NSString *tasteInfoList_value = [result stringForColumn:shoppingcar_tasteInfoList_Key];
            if ([tasteInfoList_value isKindOfClass:[NSString class]]) {
                [params setObject:tasteInfoList_value forKey:shoppingcar_tasteInfoList_Key];
            } else {
                [params setObject:@"" forKey:shoppingcar_tasteInfoList_Key];
            }
            
            NSString *realInventory_value = [result stringForColumn:shoppingcar_realInventory_Key];
            if ([realInventory_value isKindOfClass:[NSString class]]) {
                [params setObject:tasteInfoList_value forKey:shoppingcar_realInventory_Key];
            } else {
                [params setObject:@"" forKey:shoppingcar_realInventory_Key];
            }
            
            [temp addObject:params];
        }
        if (block) {
            block(temp);
        }
        [db close];
    }];
    
    // 发送通知显示全部商品数量
    [[DataBaseManager shared] getAllGoodsNumForShoppingCarWithFileName:shoppingcar
                                                               success:^(int totalCount) {
        // 发送通知并且将商品数量传递过去
        [[NSNotificationCenter defaultCenter] postNotificationName:kQueryAllGoodsNumNotifacation
                                                            object:nil
                                                          userInfo:@{@"allGoodsNum":@(totalCount)}];
    }];
}

- (void)deletegoodsforshoppingcar:(NSArray<NSString *> *)goodscodes withFileName:(NSString *)fileName success:(void(^)(BOOL success))block
{
    [self.queue inDatabase:^(FMDatabase *db) {
        if (![db open]) {
            block(NO);
            return ;
        }
        
        for (NSString *goodscode in goodscodes) {
            NSString *updataSQL = [NSString stringWithFormat:@"delete from %@%@ where %@ = '%@'",fileName, shoppingcarKey, shoppingcar_goodsCode_key, goodscode];
            
            [db executeUpdate:updataSQL];
        }
        
        [db close];
        block(YES);
    }];
}

// 统计数据库表中所有的商品数量
- (void)getAllGoodsNumForShoppingCarWithFileName:(NSString *)fileName success:(void(^)(int totalCount))block
{
    [self.queue inDatabase:^(FMDatabase *db) {
        if (![db open]) {
            block(0);
            return ;
        }
        
        NSString *sql = [NSString stringWithFormat:@"select * from %@%@ order by %@ asc", fileName, shoppingcarKey, dataIdKey];
        
        int totalCount = 0;
        FMResultSet *result = [db executeQuery:sql];
        while ([result next]) {
            NSString *countValueStr = [result stringForColumn:shoppingcar_count_key];
            if ([countValueStr isKindOfClass:[NSString class]]){
                totalCount += countValueStr.intValue;
            }
        }
        
        if (block) {
            block(totalCount);
        }
        [db close];
    }];
}

@end
