//
//  UUIDKeyChainManager.m
//  BusinessOnline
//
//  Created by clitics on 2019/4/24.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "UUIDKeyChainManager.h"
#import <SAMKeychain.h>

@implementation UUIDKeyChainManager

NSString *const bundleId = @"com.gzlg.ERPOnline.";

+(NSString *)idfvForService:(NSString *)service account:(NSString *)account
{
    return [SAMKeychain passwordForService:[bundleId stringByAppendingString:service] account:account];
}

+(BOOL)saveIDFV:(NSString *)idfv forService:(NSString *)serviceName account:(NSString *)account
{
    return [SAMKeychain setPassword:idfv forService:[bundleId stringByAppendingString:serviceName] account:account];
}

@end
