//
//  LGLanguageManager.m
//  BusinessOnline
//
//  Created by lgerp on 2020/12/22.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGLanguageManager.h"

@implementation LGLanguageManager

+ (NSString *)getCurrentLanguage {
    
    NSString *languageCode = [NSLocale preferredLanguages][0];// 返回的也是国际通用语言Code+国际通用国家地区代码
    NSString *countryCode = [NSString stringWithFormat:@"-%@", [[NSLocale currentLocale] objectForKey:NSLocaleCountryCode]];
        if (languageCode) {
            languageCode = [languageCode stringByReplacingOccurrencesOfString:countryCode withString:@""];
        }
    NSLog(@"languageCode : %@", languageCode);
    
    return languageCode;
}

+ (NSString *)getRecomandImageCurrentLanguage {
    
    NSString *curLanStr = [LGLanguageManager getCurrentLanguage];
    NSString *finalImgStr = @"";
    if ([curLanStr containsString:@"zh"]) {
        finalImgStr = @"img_recommend";
    } else if ([curLanStr containsString:@"en"]){
        finalImgStr = @"img_recommend_en";
    } else if ([curLanStr containsString:@"it"]){
        finalImgStr = @"img_recommend_in";
    }
    return finalImgStr;
}

@end
