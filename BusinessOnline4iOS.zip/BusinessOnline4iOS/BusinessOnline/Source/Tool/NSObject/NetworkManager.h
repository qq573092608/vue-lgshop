//
//  NetworkManager.h
//  SwiftTool
//
//  Created by clitics on 2018/9/4.
//  Copyright © 2018年 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NetworkManager : NSObject

/**
 *  一个响应未序列化的POST请求
 *
 *  @param url     请求路径
 *  @param params  请求参数
 *  @param isUsedSignal  是否使用到了信号量(YES:使用到了 NO: 没使用到)
 *  @param success 请求成功后的回调
 *  @param failure 请求失败后的回调
 */
//+ (void)postWithURL:(NSString *)url params:(NSDictionary *)params success:(void (^)(id json))success failure:(void (^)(NSError *error))failure;
+ (void)postWithURL:(NSString *)url
      params:(NSDictionary *)params
isUsedSignal:(BOOL)isUsedSignal
     success:(void (^)(id))success
            failure:(void (^)(NSError *))failure;

+(void)uploadImage:(UIImage *)image url:(NSString *)url success:(void (^)(id))success failure:(void (^)(NSError *))failure;

+ (void)postWithURL:(NSString *)url success:(void (^)(id json))success failure:(void (^)(NSError *error))failure;
+ (void)forgetPasswordWithURL:(NSString *)url params:(NSDictionary *)params success:(void (^)(id))success failure:(void (^)(NSError *))failure;

+ (void)downloadWithURL:(NSString *)url cachePath:(NSURL *)cachePath progress:(void(^)(NSProgress *progress))progress success:(void (^)(id json, NSString *filePath))success failure:(void (^)(NSError *error))failure;

+ (void)getWithURL:(NSString *)url params:(NSDictionary *)params success:(void (^)(id))success failure:(void (^)(NSError *))failure;

+ (void)companyWithURL:(NSString *)url params:(NSDictionary *)params success:(void (^)(id))success failure:(void (^)(NSError *))failure;

@end
