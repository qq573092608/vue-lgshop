//
//  UUIDKeyChainManager.h
//  BusinessOnline
//
//  Created by clitics on 2019/4/24.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UUIDKeyChainManager : NSObject

+ (NSString *)idfvForService:(NSString *)service account:(NSString *)account;

+ (BOOL)saveIDFV:(NSString *)idfv forService:(NSString *)serviceName account:(NSString *)account;

@end

NS_ASSUME_NONNULL_END
