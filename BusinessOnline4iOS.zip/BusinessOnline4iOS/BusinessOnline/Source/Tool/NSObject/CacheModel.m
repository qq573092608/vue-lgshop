//
//  CacheModel.m
//  BusinessOnline
//
//  Created by clitics on 2019/4/1.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "CacheModel.h"
#import <objc/runtime.h>

@interface CacheModel ()

@property (nonatomic,copy)NSString *filePath;

@end
@implementation CacheModel

static CacheModel *_model = nil;

+(instancetype)shared
{
    static dispatch_once_t tocken = 0;
    dispatch_once(&tocken, ^{
        _model = [[CacheModel alloc] init];
    });
    return _model;
}

-(void)addShoppingCar:(CacheProductModel *)model
{
    if ([model.goodsCode isKindOfClass:[NSString class]])
    {
        NSMutableDictionary *modelDic = [NSMutableDictionary dictionaryWithDictionary:[self dictionaryFromModel:model]];
        [self.products setObject:modelDic forKey:model.goodsCode];
        [self saveToDisk];
    }
}

-(void)deleteFromShoppingCar:(NSString *)productCode
{
    [self.products removeObjectForKey:productCode];
    [self saveToDisk];
}

-(void)clearShoppingCar
{
    
    NSString *code = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    
    NSArray *allkey = [self.products allKeys];
//    NSArray *allvalue = [self.products allValues];

    for (NSString *key in allkey) {
        
        NSDictionary *dic = [self.products objectForKey:key];
        if ([dic[@"invitationCode"] isEqualToString:code]) {
            [self.products removeObjectForKey:key];
        }
    }
    
    
//    [self.products removeAllObjects];
    [self saveToDisk];
}

- (void)clearShoppingCarWithInvitationCode:(NSString *)invitationCode
{
    invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    
    if (!isNSString(invitationCode))
    {
        return;
    }
    NSMutableDictionary *temp = [NSMutableDictionary dictionaryWithDictionary:self.products];
    for (NSDictionary *dic in temp.allValues)
    {
        CacheProductModel *model = [[CacheProductModel alloc] init];
        [model setValuesForKeysWithDictionary:dic];
        if ([model.invitationCode isEqualToString:invitationCode]) {
            [self deleteFromShoppingCar:model.goodsCode];
        }
    }
}

- (void)saveToDisk
{
    BOOL success = [NSKeyedArchiver archiveRootObject:self.products toFile:self.filePath];
    
    if (success)
    {
        NSLog(@"成功");
    }
    else
    {
        NSLog(@"失败");
    }
}

-(CacheProductModel *)modelForKey:(NSString *)goodsCode
{
    if (![self.products objectForKey:goodsCode])
    {
        return nil;
    }
    CacheProductModel *model = [[CacheProductModel alloc] init];
    [model setValuesForKeysWithDictionary:[self.products objectForKey:goodsCode]];
    return model;
}

-(NSArray<CacheProductModel *> *)modelsForInvitationCode:(NSString *)invitationCode
{
    NSMutableArray *temp = [NSMutableArray array];
    for (NSDictionary *dic in self.products.allValues)
    {
        CacheProductModel *model = [[CacheProductModel alloc] init];
        [model setValuesForKeysWithDictionary:dic];
        if ([model.invitationCode isEqualToString:invitationCode])
        {
            if (model.count) {
                [temp addObject:model];
            }
        }
    }
    return [self sortArray:temp];
}

- (NSArray<CacheProductModel *> *)sortArray:(NSArray<CacheProductModel *> *)array
{
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"createDate" ascending:NO];
    return [array sortedArrayUsingDescriptors:@[sortDescriptor]];
}

- (NSDictionary *)dictionaryFromModel:(CacheProductModel *)model
{
    unsigned int count = 0;
    
    objc_property_t *properties = class_copyPropertyList(model.class, &count);
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithCapacity:count];
    
    for (int i = 0; i < count; i++) {
        NSString *key = [NSString stringWithUTF8String:property_getName(properties[i])];
        id value = [model valueForKey:key];
        
        //only add it to dictionary if it is not nil
        if (key && value) {
            if ([value isKindOfClass:[NSString class]]
                || [value isKindOfClass:[NSNumber class]]) {
                // 普通类型的直接变成字典的值
                [dict setObject:value forKey:key];
            }
            else
            {
                [dict setObject:@"" forKey:key];
            }
        } else if (key && value == nil) {
            // 如果当前对象该值为空，设为nil。在字典中直接加nil会抛异常，需要加NSNull对象
            [dict setObject:@"" forKey:key];
        }
    }
    
    free(properties);
    NSLog(@"%@",dict);
    return dict;
}

-(NSMutableDictionary *)products
{
    if (!_products)
    {
        _products = [NSMutableDictionary dictionary];
        NSDictionary *models = [NSKeyedUnarchiver unarchiveObjectWithFile:self.filePath];
        if (models.allValues.count)
        {
            for (NSDictionary *dic in models.allValues)
            {
                CacheProductModel *model = [[CacheProductModel alloc] init];
                [model setValuesForKeysWithDictionary:dic];
                if ([model.goodsCode isKindOfClass:[NSString class]])
                {
                    NSMutableDictionary *modelDic = [NSMutableDictionary dictionaryWithDictionary:[self dictionaryFromModel:model]];
                    [_products setObject:modelDic forKey:model.goodsCode];
                }
            }
        }
        
    }
    return _products;
}

-(NSString *)filePath
{
    if (!_filePath)
    {
        NSString *path = [NSSearchPathForDirectoriesInDomains(9, 1, 1) firstObject];
        _filePath = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.plist",[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]]];
    }
    NSLog(@"%@",_filePath);
    return _filePath;
}

@end
