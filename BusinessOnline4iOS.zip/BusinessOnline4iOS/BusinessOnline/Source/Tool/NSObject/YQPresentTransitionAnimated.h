//
//  YQPresentTransition.h
//  YQPresentLikePush
//
//  Created by 杨麒 on 16/8/13.
//  Copyright © 2016年 杨麒. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface YQPresentTransitionAnimated : NSObject<UIViewControllerAnimatedTransitioning>

@end
