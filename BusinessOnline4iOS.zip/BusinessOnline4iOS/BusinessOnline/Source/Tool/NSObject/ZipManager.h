//
//  ZipManager.h
//  BusinessOnline
//
//  Created by clitics on 2019/4/25.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ZipManager;
@protocol ZipManagerDelegate <NSObject>

- (void)zipManager:(ZipManager *_Nullable)manager failedOnZipFileWithError:(NSError *_Nullable)error;
- (void)zipManagerWillBeginUnzip:(ZipManager *_Nullable)manager;
- (void)zipManager:(ZipManager *_Nullable)manager unZipFileName:(NSString *_Nullable)unZipFileName documentsPath:(NSString *_Nullable)ducumentsPath;
- (void)zipManagerDidEndUnzip:(ZipManager *_Nullable)manager;

@end
NS_ASSUME_NONNULL_BEGIN

@interface ZipManager : NSObject<ZipManagerDelegate>

@property (nonatomic,weak)id<ZipManagerDelegate> delegate;

- (void)unZipFileWithFilePath:(NSString *)filePath;

- (void)unZipFileWithFilePath:(NSString *)zipFilePath toFilePath:(NSString *)unzipFilePath;

@end

NS_ASSUME_NONNULL_END
