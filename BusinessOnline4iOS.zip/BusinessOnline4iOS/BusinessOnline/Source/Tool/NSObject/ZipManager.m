//
//  ZipManager.m
//  BusinessOnline
//
//  Created by clitics on 2019/4/25.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "ZipManager.h"
#import <ZipArchive/ZipArchive.h>
#import <SSZipArchive/SSZipArchive.h>

@interface ZipManager ()

@end
@implementation ZipManager

-(void)unZipFileWithFilePath:(NSString *)zipFilePath toFilePath:(NSString *)unzipFilePath
{
    NSString *zipPath = [[NSBundle mainBundle] pathForResource:@"testZipFile" ofType:@"zip"];
    NSString *unzipPath = [[[[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:nil] URLByAppendingPathComponent:@"test/"] absoluteString];
    unzipPath = [unzipPath stringByReplacingOccurrencesOfString:@"file://" withString:@""];
    NSLog(@"%@",unzipPath);
    
    [SSZipArchive unzipFileAtPath:zipPath toDestination:unzipPath progressHandler:^(NSString * _Nonnull entry, unz_file_info zipInfo, long entryNumber, long total) {
        NSLog(@"%ld",total);
    } completionHandler:^(NSString * _Nonnull path, BOOL succeeded, NSError * _Nullable error) {
        NSLog(@"%@",error);
    }];
    
    ZipArchive *zip = [[ZipArchive alloc] init];
    if ([zip UnzipOpenFile:zipFilePath])
    {
        BOOL ret = [zip UnzipFileTo:unzipFilePath overWrite:YES];
        NSLog(@"ret: %d",ret);
        if (!ret) {
            [zip UnzipCloseFile];
            NSString *domain = @"com.gzlg.hszx";
            NSString *desc = NSLocalizedString(@"解压后写入指定路径失败", nil);
            NSError *error = [[NSError alloc] initWithDomain:domain code:102 userInfo:@{NSLocalizedDescriptionKey:desc}];
            [self zipManager:self failedOnZipFileWithError:error];
            return;
        }
        [self zipManagerDidEndUnzip:self];
    }
    else
    {
        NSString *domain = @"com.gzlg.hszx";
        NSString *desc = NSLocalizedString(@"解压失败", nil);
        NSError *error = [[NSError alloc] initWithDomain:domain code:101 userInfo:@{NSLocalizedDescriptionKey:desc}];
        [self zipManager:self failedOnZipFileWithError:error];
    }
}

-(void)unZipFileWithFilePath:(NSString *)filePath
{
    NSLog(@"%@",filePath);
    if ([filePath hasPrefix:@"file://"]) {
        filePath = [filePath stringByReplacingOccurrencesOfString:@"file://" withString:@""];
    }
    [self zipManagerWillBeginUnzip:self];
    
    NSString *ducumentsPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    ducumentsPath = [ducumentsPath stringByAppendingPathComponent:@"unZipFile/"];
    
    ZipArchive *zip = [[ZipArchive alloc] init];
    if ([zip UnzipOpenFile:filePath])
    {
        BOOL ret = [zip UnzipFileTo:ducumentsPath overWrite:YES];
        NSLog(@"ret: %d",ret);
        if (!ret) {
            [zip UnzipCloseFile];
            NSString *domain = @"com.gzlg.hszx";
            NSString *desc = NSLocalizedString(@"解压后写入指定路径失败", nil);
            NSError *error = [[NSError alloc] initWithDomain:domain code:102 userInfo:@{NSLocalizedDescriptionKey:desc}];
            [self zipManager:self failedOnZipFileWithError:error];
            return;
        }
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSDirectoryEnumerator *enumerator = [fileManager enumeratorAtPath:ducumentsPath];
        NSString *file;
        while (file = [enumerator nextObject]) {
            if ([file.pathExtension isEqualToString:@"txt"]) {
                NSLog(@"%@",file);
                [self zipManager:self unZipFileName:file documentsPath:ducumentsPath];
            }
            else if ([file.pathExtension isEqualToString:@"zip"]) {
                NSLog(@"%@",file);
                [self zipManager:self unZipFileName:file documentsPath:ducumentsPath];
            }
        }
        [fileManager removeItemAtPath:filePath error:nil];
        [self zipManagerDidEndUnzip:self];
    }
    else
    {
        NSString *domain = @"com.gzlg.hszx";
        NSString *desc = NSLocalizedString(@"解压失败", nil);
        NSError *error = [[NSError alloc] initWithDomain:domain code:101 userInfo:@{NSLocalizedDescriptionKey:desc}];
        [self zipManager:self failedOnZipFileWithError:error];
    }
}

#pragma mark delegate methods
-(void)zipManagerWillBeginUnzip:(ZipManager *)manager
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(zipManagerWillBeginUnzip:)]) {
        [self.delegate zipManagerWillBeginUnzip:manager];
    }
}

-(void)zipManager:(ZipManager *)manager unZipFileName:(NSString *)unZipFileName documentsPath:(NSString *)ducumentsPath
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(zipManager:unZipFileName:documentsPath:)]) {
        [self.delegate zipManager:manager unZipFileName:unZipFileName documentsPath:ducumentsPath];
    }
}

-(void)zipManagerDidEndUnzip:(ZipManager *)manager
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(zipManagerDidEndUnzip:)]) {
        [self.delegate zipManagerDidEndUnzip:manager];
    }
}

-(void)zipManager:(ZipManager *)manager failedOnZipFileWithError:(NSError *)error
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(zipManager:failedOnZipFileWithError:)]) {
        
        [self.delegate zipManager:manager failedOnZipFileWithError:error];
    }
}

@end
