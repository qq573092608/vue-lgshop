//
//  LGLanguageManager.h
//  BusinessOnline
//
//  Created by lgerp on 2020/12/22.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


/// 语言的管理类
@interface LGLanguageManager : NSObject


/**
     获取当前的系统语言
 */
+ (NSString *)getCurrentLanguage;

/**
    根据当前系统语言获取对应的推荐图片
 */
+ (NSString *)getRecomandImageCurrentLanguage;



@end

NS_ASSUME_NONNULL_END
