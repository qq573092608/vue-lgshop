//
//  NetworkManager.m
//  SwiftTool
//
//  Created by clitics on 2018/9/4.
//  Copyright © 2018年 clitics. All rights reserved.
//

#import "NetworkManager.h"

@implementation NetworkManager

+ (void)getWithURL:(NSString *)url params:(NSDictionary *)params success:(void (^)(id))success failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.requestSerializer.timeoutInterval = 30;
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/plain",@"text/json",@"application/json",@"text/javascript",@"text/html",@"image/jpeg",@"image/*",@"image/png",@"text/xml", nil];
    NSMutableDictionary *baseDict;
    if (params) {
        baseDict = [NSMutableDictionary dictionaryWithDictionary:params];
        
    } else {
        baseDict = [NSMutableDictionary dictionary];
    }
    
    if ((![url isEqualToString:CREATE_URL(url_login)])
        || (![url isEqualToString:CREATE_URL(url_register)])
        || (![url isEqualToString:CREATE_URL(url_forget_password)])
        || (![url isEqualToString:CREATE_URL(url_logout)])) {
        [manager.requestSerializer setValue:[[NSUserDefaults standardUserDefaults] objectForKey:kLoginCookies]
                         forHTTPHeaderField:@"JSESSIONID"];
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    });
    [manager GET:url parameters:baseDict progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSArray *cookies = [NSHTTPCookieStorage sharedHTTPCookieStorage].cookies;
        
        for (NSHTTPCookie*cookie in cookies)
        {
            if ([cookie.name isEqualToString:@"JSESSIONID"])
            {
                if (cookie.value)
                {
                    [[NSUserDefaults standardUserDefaults] setObject:cookie.value forKey:kLoginCookies];
                }
            }
        }
        if (success) {
            success(responseObject);
        }
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
            [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        }
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    }];
}

+ (void)postWithURL:(NSString *)url
             params:(NSDictionary *)params
       isUsedSignal:(BOOL)isUsedSignal
            success:(void (^)(id))success
            failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    if (isUsedSignal) {
        manager.completionQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    } else {
        manager.completionQueue = dispatch_get_main_queue();
    }
    
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.requestSerializer.timeoutInterval = 30.f;
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
    if ([url isEqualToString:CREATE_URL(url_commit_order_new)]
        || [url isEqualToString:CREATE_URL(url_order_after_Sale)]
        ) {
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
    } else {
        manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    }
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/plain",@"text/json",@"application/json",@"text/javascript",@"text/html",@"image/jpeg",@"image/*",@"image/png",@"text/xml", nil];
    NSMutableDictionary *baseDict;
    if (params) {
        baseDict = [NSMutableDictionary dictionaryWithDictionary:params];
    }else{
        baseDict = [NSMutableDictionary dictionary];
    }
    
    if ((![url isEqualToString:CREATE_URL(url_login)])
        || (![url isEqualToString:CREATE_URL(url_register)])
        || (![url isEqualToString:CREATE_URL(url_forget_password)])
        || (![url isEqualToString:CREATE_URL(url_logout)]))
    {
        [manager.requestSerializer setValue:[[NSUserDefaults standardUserDefaults]
                                             objectForKey:kLoginCookies]
                         forHTTPHeaderField:@"JSESSIONID"];
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    });
    [manager POST:url parameters:baseDict progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSArray *cookies = [NSHTTPCookieStorage sharedHTTPCookieStorage].cookies;
        for (NSHTTPCookie*cookie in cookies) {
            if ([cookie.name isEqualToString:@"JSESSIONID"]) {
                if (cookie.value) {
                    [[NSUserDefaults standardUserDefaults] setObject:cookie.value forKey:kLoginCookies];
                }
            }
        }
        if (success) {
            success(responseObject);
        }
        
        if (isUsedSignal) {
            dispatch_async(dispatch_get_main_queue(), ^{
                   [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
               });
        } else {
            [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        if (isUsedSignal) {
            dispatch_async(dispatch_get_main_queue(), ^{
                              [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
                          });
        } else {
            [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        }
        
        if (failure) {
            failure(error);
        }
    }];
}


+(void)uploadImage:(UIImage *)image url:(NSString *)url success:(void (^)(id))success failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/html",@"image/jpeg",@"image/png",@"application/octet-stream",@"text/json",nil];
    manager.requestSerializer= [AFHTTPRequestSerializer serializer];
    manager.responseSerializer= [AFHTTPResponseSerializer serializer];
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    });
    [manager.requestSerializer setValue:[[NSUserDefaults standardUserDefaults] objectForKey:kLoginCookies] forHTTPHeaderField:@"JSESSIONID"];
    [manager POST:url parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        NSData *data = UIImagePNGRepresentation(image);
        data = [data base64EncodedDataWithOptions:NSDataBase64Encoding64CharacterLineLength];
        [formData appendPartWithFileData:data name:@"img_file" fileName:@"img_file" mimeType:@"image/png"];
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (success) {
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            success(dic);
        }
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
            [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        }
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    }];
}

+ (void)postWithURL:(NSString *)url success:(void (^)(id))success failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.requestSerializer.timeoutInterval = 30.f;
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/plain",@"text/json",@"application/json",@"text/javascript",@"text/html",@"image/jpeg",@"image/*",@"image/png", nil];
    [manager.requestSerializer setValue:[[NSUserDefaults standardUserDefaults] objectForKey:kLoginCookies] forHTTPHeaderField:@"JSESSIONID"];
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    });
    [manager POST:url parameters:nil progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (success) {
            success(responseObject);
        }
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
            [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        }
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    }];
}

+ (void)forgetPasswordWithURL:(NSString *)url params:(NSDictionary *)params success:(void (^)(id))success failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.requestSerializer.timeoutInterval = 30.f;
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/plain",@"text/json",@"application/json",@"text/javascript",@"text/html",@"image/jpeg",@"image/*",@"image/png", nil];
    NSMutableDictionary *baseDict;
    if (params) {
        baseDict = [NSMutableDictionary dictionaryWithDictionary:params];
    }else{
        baseDict = [NSMutableDictionary dictionary];
    }
    [baseDict setObject:@"app" forKey:@"requestType"];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    });
    [manager POST:url parameters:baseDict progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (success) {
            success(responseObject);
        }
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
            [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        }
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    }];
}

+(void)downloadWithURL:(NSString *)url cachePath:(NSURL *)cachePath progress:(void(^)(NSProgress *progress))progress success:(void (^)(id, NSString *))success failure:(void (^)(NSError *))failure
{
//    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration backgroundSessionConfigurationWithIdentifier:@"backgroundIdentifier"];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    
    NSURL *URL = [NSURL URLWithString:url];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    });
    
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull downloadProgress) {
        if (progress) {
            progress(downloadProgress);
        }
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        return cachePath;
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        
        if (!error)
        {
            if (success)
            {
                success(response, filePath.absoluteString);
            }
        }
        else
        {
            if (failure)
            {
                failure(error);
            }
        }
    }];
    [downloadTask resume];
}


+ (void)companyWithURL:(NSString *)url params:(NSDictionary *)params success:(void (^)(id))success failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.requestSerializer.timeoutInterval = 30.f;
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
//    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/json",@"application/json",@"text/html", nil];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/plain",@"text/json",@"application/json",@"text/javascript",@"text/html",@"image/jpeg",@"image/*",@"image/png",@"text/xml", nil];

    NSMutableDictionary *baseDict;
    if (params) {
        baseDict = [NSMutableDictionary dictionaryWithDictionary:params];
        
    }else{
        baseDict = [NSMutableDictionary dictionary];
    }
    
    
    if ((![url isEqualToString:CREATE_URL(url_login)]) || (![url isEqualToString:CREATE_URL(url_register)]) || (![url isEqualToString:CREATE_URL(url_forget_password)]) ||(![url isEqualToString:CREATE_URL(url_logout)]))
    {
        [manager.requestSerializer setValue:[[NSUserDefaults standardUserDefaults] objectForKey:kLoginCookies] forHTTPHeaderField:@"Cookie"];
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    });
    [manager POST:url parameters:baseDict progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSArray *cookies = [NSHTTPCookieStorage sharedHTTPCookieStorage].cookies;
        for (NSHTTPCookie*cookie in cookies)
        {
            if ([cookie.name isEqualToString:@"JSESSIONID"])
            {
                if (cookie.value)
                {
                    [[NSUserDefaults standardUserDefaults] setObject:cookie.value forKey:kLoginCookies];
                }
            }
        }
        if (success) {
            success(responseObject);
        }
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
            [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        }
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    }];
}
@end
