//
//  DataBaseManager.h
//  BusinessOnline
//
//  Created by clitics on 2019/4/23.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FMDB.h>

NS_ASSUME_NONNULL_BEGIN

@interface DataBaseManager : NSObject

@property (nonatomic,strong,readonly)FMDatabaseQueue *queue;
@property (nonatomic,copy,readonly)NSString *filePath;

+ (instancetype)shared;

/**
     更换用户
 */
- (void)changeUser:(NSString *)userName;

/// 查询表里面所有的数据
/// @param fileName 表名
/// @param block 返回的回调
- (void)getshoppingcarwithFileName:(NSString *)fileName
                           success:(void(^)(NSArray<NSDictionary *> * classifies))block;


/// 添加商品到表
/// @param dictionary 添加的对象
/// @param fileName 对应的表名
/// @param isMayBeMutable 是否有可能是多条(主要是对应多规格新增的时候数量不一定是1)
/// @param isSpecifationType 是否是多规格类型的操作(多规格类型中的操作，如首页以及详情页面中多规格的新增以及购物车界面中多规格的修改则为YES)
/// @param block 返回的回调
- (void)addshoppingcar:(NSDictionary *)dictionary
          withfilename:(NSString *)fileName
     isMayBeMutableNum:(BOOL)isMayBeMutable
        isSpecifationType:(BOOL)isSpecifationType
               success:(void(^)(BOOL success))block;


/// 更新对应的商品数量
/// @param dictionary 对应的商品信息
/// @param fileName 表的名称
/// @param block 返回的回调
- (void)updateshopnumber:(NSDictionary *)dictionary
            withfilename:(NSString *)fileName
                 success:(void(^)(BOOL success))block;

- (void)deletegoods:(NSDictionary *)dictionary
       withfilename:(NSString *)fileName
            success:(void(^)(BOOL success))block;

- (void)reducegoods:(NSDictionary *)dictionary
       withfilename:(NSString *)fileName
            success:(void(^)(BOOL success))block;

///  根据单个商品编号查询对应的商品数量
/// @param fileName 操作的表名
/// @param goodscode 商品的编码
/// @param block 成功的回调
- (void)getgoodsnumberwithFileName:(NSString *)fileName
                         goodscode:(NSString *)goodscode
                           success:(void(^)(NSArray<NSDictionary *> * classifies))block;

/// 删除对应的表
/// @param block 操作的回调
- (void)deleteshoppingcarcallback:(void(^)(BOOL success))block;

/// 删除商品编号对应的商品
/// @param goodscodes 商品编号
/// @param fileName 表名
/// @param block 返回的回调
- (void)deletegoodsforshoppingcar:(NSArray<NSString *> *)goodscodes
                     withFileName:(NSString *)fileName
                          success:(void(^)(BOOL success))block;


///  统计数据库表中所有的商品个数
/// @param fileName 数据库名称
/// @param block 返回的回调
- (void)getAllGoodsNumForShoppingCarWithFileName:(NSString *)fileName success:(void(^)(int totalCount))block;

///  升级数据库
/// @param fileName 文件名称
- (BOOL)updateDataBase:(NSString *)fileName;


///  修改多规格对应的数据内容
/// @param oldModelDic 需要删除的对象
/// @param dictionary 新增的对象信息
/// @param block 操作返回的回调
- (void)modifySpecifaGoodsWithOldModel:(NSDictionary *)oldModelDic
                         newSpecifaDic:(NSDictionary *)dictionary
                               success:(void(^)(BOOL success))block;



@end

NS_ASSUME_NONNULL_END
