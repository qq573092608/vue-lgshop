//
//  Migration.m
//  BusinessOnline
//
//  Created by lgerp on 2020/12/7.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "Migration.h"

@interface Migration ()

@property (nonatomic,strong)NSString *name;
@property (nonatomic, assign) uint64_t version;
@property (nonatomic, strong) NSArray *updateArray;

@end

@implementation Migration

- (instancetype)initWithName:(NSString *)name andVersion:(uint64_t)version andExecuteUpdateArray:(NSArray *)updateArray
{
    if (self = [super init]) {
        _name = name;
        _version = version;
        _updateArray = updateArray;
    }
    return  self;
}

- (NSString *)name
{
    return _name;
}

- (uint64_t)version
{
    return _version;
}

- (BOOL)migrateDatabase:(FMDatabase *)database error:(out NSError *__autoreleasing  _Nullable *)error
{
    for (NSString *updateStr in _updateArray) {
        [database executeUpdate:updateStr];
    }
    return YES;
}

@end
