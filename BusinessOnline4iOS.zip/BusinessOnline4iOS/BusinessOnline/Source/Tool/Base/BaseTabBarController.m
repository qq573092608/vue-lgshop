//
//  BaseTabBarController.m
//  Invoice
//
//  Created by clitics on 2019/1/11.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "BaseTabBarController.h"
#import "BaseNavigationController.h"
#import "ProductController.h"
#import "ShoppingController.h"
#import "OrderController.h"
#import "MineController.h"
#import "ClassificationController.h"


@interface BaseTabBarController ()

@end

@implementation BaseTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 注册通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(configBridgeNum:)
                                                 name:kQueryAllGoodsNumNotifacation
                                               object:nil];
    
    self.tabBar.tintColor = MainColor;
    ProductController *hvc = [[ProductController alloc] init];
    [self addChildController:hvc
                       title:NSLocalizedString(@"product", nil)
                   imageName:@"026_k"
           selectedImageName:@"027_k"
                       navVc:[UINavigationController class]];
//    ClassificationController *classVC = [[ClassificationController alloc] init];
//    [self addChildController:classVC title:NSLocalizedString(@"分类", nil) imageName:@"026_k" selectedImageName:@"027_k" navVc:[UINavigationController class]];
    
    ShoppingController *shopcarVC = [[ShoppingController alloc] init];
    [self addChildController:shopcarVC title:NSLocalizedString(@"shoppingtrolley", nil)
                   imageName:@"028_v"
           selectedImageName:@"029_v"
                       navVc:[UINavigationController class]];
    
    OrderController *ovc = [[OrderController alloc] init];
    [self addChildController:ovc title:NSLocalizedString(@"order", nil) imageName:@"024_l" selectedImageName:@"025_l" navVc:[UINavigationController class]];
    
    MineController *MineVC = [[MineController alloc] init];
    [self addChildController:MineVC
                       title:NSLocalizedString(@"usercenter", nil)
                   imageName:@"019_b"
           selectedImageName:@"020_b" navVc:[UINavigationController class]];
    
    
//    [[UITabBar appearance] setBackgroundImage:[UIImage imageWithColor:UIColorFromRGB(0xffffff)]];
//    //  设置tabbar
//    [[UITabBar appearance] setShadowImage:[UIImage imageWithColor:UIColorFromRGB(0x919191)]];
    // 设置自定义的tabbar
//    [self setCustomtabbar];
    
    [[UITabBarItem appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName:MainColor} forState:UIControlStateSelected];
    [[UITabBarItem appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor lightGrayColor]} forState:UIControlStateNormal];
    
}

//- (void)setCustomtabbar
//{
//    ITabBar *tabbar = [[ITabBar alloc]init];
//    [self setValue:tabbar forKeyPath:@"tabBar"];
//    [tabbar.centerBtn addTarget:self action:@selector(centerBtnClick:) forControlEvents:UIControlEventTouchUpInside];
//}
//
//- (void)centerBtnClick:(UIButton *)btn
//{
//    IGenerateInvoiceController *gvc = [[IGenerateInvoiceController alloc] init];
//    BaseNavigationController *nvc = [[BaseNavigationController alloc] initWithRootViewController:gvc];
//    [self presentViewController:nvc animated:YES completion:nil];
//}


- (void)addChildController:(UIViewController*)childController title:(NSString*)title imageName:(NSString*)imageName selectedImageName:(NSString*)selectedImageName navVc:(Class)navVc
{
    childController.title = title;
    childController.tabBarItem.image = [[UIImage imageNamed:imageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    childController.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    BaseNavigationController* nav = [[BaseNavigationController alloc] initWithRootViewController:childController];
    [self addChildViewController:nav];
}

- (void)configBridgeNum:(NSNotification *)no {
    UITabBarController * root = self; // self当前的viewController
    UITabBarItem * tabBarItem = root.tabBar.items[1];
    [tabBarItem setBadgeColor:MainColor];
    
    NSNumber *allGoodsNum = no.userInfo[@"allGoodsNum"];
    int a = [allGoodsNum intValue];
    if (a == 0) {
        [tabBarItem setBadgeValue:nil];// 隐藏角标
    } else {
        [tabBarItem setBadgeValue:[NSString stringWithFormat:@"%d",[allGoodsNum intValue]]];
    }
}

@end
