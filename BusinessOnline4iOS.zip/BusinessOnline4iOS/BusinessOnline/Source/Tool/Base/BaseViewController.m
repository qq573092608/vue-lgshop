//
//  BaseViewController.m
//  Invoice
//
//  Created by clitics on 2019/1/10.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _rows = 20;
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeNone;
//    [self setStatusBarBackgroundColor:UIColorFromRGB(mainColor)];
//    [IQKeyboardManager sharedManager].shouldResignOnTouchOutside = YES;
}

- (void)setStatusBarBackgroundColor:(UIColor *)color
{
    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)])
    {
        statusBar.backgroundColor = color;
    }
}

@end
