//
//  BaseNavigationController.h
//  Invoice
//
//  Created by clitics on 2019/1/10.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseNavigationController : UINavigationController

@end

NS_ASSUME_NONNULL_END
