//
//  BaseTabBarController.h
//  Invoice
//
//  Created by clitics on 2019/1/11.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseTabBarController : UITabBarController

@end

NS_ASSUME_NONNULL_END
