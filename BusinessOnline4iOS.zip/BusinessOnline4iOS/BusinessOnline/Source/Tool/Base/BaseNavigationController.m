//
//  BaseNavigationController.m
//  Invoice
//
//  Created by clitics on 2019/1/10.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "BaseNavigationController.h"

@interface BaseNavigationController ()

@end

@implementation BaseNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationBar.titleTextAttributes = @{NSFontAttributeName:[UIFont systemFontOfSize:18],
                                               NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)};
    
    [self.navigationBar setBackgroundImage:[UIImage imageWithColor:[UIColor whiteColor]] forBarMetrics:UIBarMetricsDefault];
   // [self.navigationBar setShadowImage:[UIImage imageWithColor:UIColorFromRGB(colorTextPlaceholder)]];
//    self.navigationBar.backgroundColor = UIColorFromRGB(mainColor);
//
//    [self setStatusBarBackgroundColor:UIColorFromRGB(mainColor)];
}

- (void)setStatusBarBackgroundColor:(UIColor *)color
{
    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)])
    {
        statusBar.backgroundColor = color;
    }
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if ([self.childViewControllers count] > 0)
    {
        viewController.hidesBottomBarWhenPushed = YES;
        viewController.navigationController.navigationBar.backIndicatorImage = NULL;
        viewController.navigationItem.leftBarButtonItem = [self createBackButtonItem];
    }
    else
    {
        viewController.hidesBottomBarWhenPushed = NO;
        viewController.navigationItem.leftBarButtonItem = NULL;
    }
    
    [super pushViewController:viewController animated:animated];
    // 修改tabBra的frame
//    CGRect frame = self.tabBarController.tabBar.frame;
//    frame.origin.y = [UIScreen mainScreen].bounds.size.height - frame.size.height;
//    self.tabBarController.tabBar.frame = frame;
}

- (UIBarButtonItem *)createBackButtonItem
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    //button.frame = CGRectMake(0, 0, 40, 40);
    [button setImage:[UIImage imageNamed:@"001_return"] forState:UIControlStateNormal];
    [button addTarget:self
               action:@selector(backItemClicked)
     forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    return backItem;
}

- (void)backItemClicked
{
    [self popViewControllerAnimated:YES];
}




@end
