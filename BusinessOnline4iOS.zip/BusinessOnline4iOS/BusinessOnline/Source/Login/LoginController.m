//
//  LoginController.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "LoginController.h"
#import "LoginView.h"
#import "BaseTabBarController.h"
#import "ForgetPasswordController.h"
#import "YQPresentTransitionAnimated.h"
#import "YQDismissTransitionAnimated.h"
#import "RegisterController.h"
#import "CacheModel.h"
//#import "CacheProductModel.h"
#import "UUIDKeyChainManager.h"
#import "CompleteInfoController.h"

#import "BaseService.h"
#import "DataBaseManager.h"
#import "LGDataBaseManager.h"

@interface LoginController ()<UIViewControllerTransitioningDelegate>
{
    NSString *_userName, *_password;
}
@property (nonatomic, strong) UIPercentDrivenInteractiveTransition *percentDrivenTransition;
@property (nonatomic,strong)UIImageView *imageview;

@property (nonatomic, strong) BaseService *baseService;

@end

@implementation LoginController

#pragma mark - UIViewControllerTransitioningDelegate
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return [[YQPresentTransitionAnimated alloc] init];
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    return [[YQDismissTransitionAnimated alloc] init];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupSubViews];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
//    [self autoLogin];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self autoLogin];
    
}

- (void)autoLogin
{
    NSString *cookie = [[NSUserDefaults standardUserDefaults] objectForKey:kAutoLogin];
    
    if (cookie.boolValue)
    {
        
        _imageview = [[UIImageView alloc]initWithFrame:[UIScreen mainScreen].bounds];
        
//        CGSize viewSize = [UIScreen mainScreen].bounds.size;
//        NSString *viewOr = @"Portrait";//垂直
//        NSString *launchImage = nil;
//        NSArray *launchImages =  [[[NSBundle mainBundle] infoDictionary] valueForKey:@"UILaunchImages"];
//
//        for (NSDictionary *dict in launchImages) {
//            CGSize imageSize = CGSizeFromString(dict[@"UILaunchImageSize"]);
//
//            if (CGSizeEqualToSize(viewSize, imageSize) && [viewOr isEqualToString:dict[@"UILaunchImageOrientation"]]) {
//                launchImage = dict[@"UILaunchImageName"];
//            }
//        }

//        _imageview.image = [UIImage imageNamed:launchImage];
        _imageview.image = [UIImage imageNamed:[self.baseService getLaunchImgByAPPType:APPTYPE]];
        _imageview.contentMode = UIViewContentModeScaleAspectFill;
        [self.view addSubview:_imageview];
        
        NSString *phoneNumber = [[NSUserDefaults standardUserDefaults] objectForKey:kUserName];
        NSString *password = [[NSUserDefaults standardUserDefaults] objectForKey:kPassword];
        [self loginCallback:phoneNumber password:password];
    }
}

- (void)setupSubViews
{
    LoginView *loginView = [[LoginView alloc] init];
    loginView.isNeedShowBackBtn = self.isNeedShowBackBtn;
    [self.view addSubview:loginView];
    [loginView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    WEAK_SELF(weakSelf);
    loginView.dismissCallback = ^{
        [weakSelf dismissCallback];
    };
    loginView.loginCallback = ^(NSString * _Nonnull userName, NSString * _Nonnull password) {
        [weakSelf loginCallback:userName password:password];
    };
    loginView.registerCallback = ^{
        [weakSelf registerCallback];
    };
    loginView.forgetPasswordCallback = ^{
        [weakSelf forgetPasswordCallback];
    };
    
//    [self autoLogin];
}

- (void)dismissCallback
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)loginCallback:(NSString *)userName password:(NSString *)password
{
    _userName = userName;
    _password = password;
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    if (!isNSString(userName))
    {
        return;
    }
    if (!isNSString(password))
    {
        return;
    }
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [params setObject:userName forKey:@"phone"];
    [params setObject:password forKey:@"password"];
    [params setObject:invitationCode forKey:@"invitationCode"];
    [self doNetworkRequestForLoginWithParams:params];
}

- (void)doNetworkRequestForLoginWithParams:(NSDictionary *)params
{
    [MBProgressHUD showGifToView:nil];
    [NetworkManager postWithURL:CREATE_URL(url_login) params:params isUsedSignal:NO success:^(id json) {
        [MBProgressHUD hideHUD];
        [self loginSuccessCallback:json];
    } failure:^(NSError *error) {
        [self->_imageview removeFromSuperview];
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
        [Bugly reportException:[NSException exceptionWithName:@"HttpError"
                                                       reason:@"登录接口Http请求错误" userInfo:@{@"error":error.localizedDescription}]];
    }];
}

- (void)loginSuccessCallback:(id)json
{
    [self->_imageview removeFromSuperview];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kIconPath];
    NSInteger state = [get_Value_for_key_from_obj(json, successKey) integerValue];
    switch (state) {
        case 1:
        {
            if (![[[NSUserDefaults standardUserDefaults] objectForKey:kUserName] isEqualToString:_userName]) {
                [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kMerchantLogoUrl];
            }
            [[NSUserDefaults standardUserDefaults] setObject:_userName forKey:kUserName];
            [[NSUserDefaults standardUserDefaults] setObject:_password forKey:kPassword];

            // 处理数据库合并的内容
            DataBaseManager *db = [DataBaseManager shared];
            [LGDataBaseManager copyNullDBData2CurrentUserDBData];
            [db changeUser:_userName];
            
            if (![[json allKeys] containsObject:dataKey]) {
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"Loginfailed", nil)];
                return;
            }
            NSDictionary *data = get_Value_for_key_from_obj(json, dataKey);
            if (![[data allKeys] containsObject:@"cookie"]) {
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"Loginfailed", nil)];
                return;
            }
            if (![[data allKeys] containsObject:kIconPath]) {
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"Loginfailed", nil)];
                return;
            }
            NSString *iconPath = get_Value_for_key_from_obj(data, kIconPath);
            if (isNSString(iconPath)) {
                [[NSUserDefaults standardUserDefaults] setObject:iconPath forKey:kIconPath];
            }
                        
            [[NSUserDefaults standardUserDefaults] setValue:data[@"phoneNumber"]
                                                     forKey:kphoneNumberLogin];
            
            NSString *cookie = [data objectForKey:@"cookie"];
            if (isNSString(cookie)) {
                NSString *isSale = get_Value_for_key_from_obj(data, @"isSale");
                [[NSUserDefaults standardUserDefaults] setObject:@(isSale.boolValue) forKey:kIsSale];
                if (isSale.boolValue)
                {
//                    NSString *invitationQrImage = get_Value_for_key_from_obj(get_Value_for_key_from_obj(json, dataKey), @"invitationQrImage");
//                    if ([invitationQrImage isKindOfClass:[NSString class]])
//                    {
//                        [[NSUserDefaults standardUserDefaults] setObject:invitationQrImage forKey:[NSString stringWithFormat:@"%@%@",[[NSUserDefaults standardUserDefaults] objectForKey:kUserName],[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]]];
//                    }
                }
                NSString *uuid = [UUIDKeyChainManager idfvForService:_userName account:_userName];
                if (![uuid isKindOfClass:[NSString class]])
                {
                    NSString *identifierForVendor = [[UIDevice currentDevice].identifierForVendor UUIDString];
                    BOOL success = [UUIDKeyChainManager saveIDFV:identifierForVendor forService:_userName account:_userName];
                    if (!success) {
                        [MBProgressHUD showErrorMessage:NSLocalizedString(@"Loginfailed", nil)];
                        return;
                    }

                }
                
                NSString *nickName = get_Value_for_key_from_obj(data, kNickName);
                if (!isNSString(nickName) || !nickName.length) {
//                    [MBProgressHUD showErrorMessage:localizableString(@"登录失败")];
                    nickName = @"";
//                    return;
                }
                
                NSString *avatarpath = get_Value_for_key_from_obj(data, kIconPath);
                if (!isNSString(avatarpath) || !avatarpath.length)
                {
                    avatarpath = @"";
                }
                                
                [[NSUserDefaults standardUserDefaults] setObject:nickName forKey:[NSString stringWithFormat:@"%@%@",kNickName,[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]]];
                [[NSUserDefaults standardUserDefaults] setObject:avatarpath forKey:kIconPath];
                [[NSUserDefaults standardUserDefaults] setObject:cookie forKey:kLoginCookies];
                [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:kIsLogin];
                [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:kAutoLogin];
                BaseTabBarController *bvc = [[BaseTabBarController alloc] init];
                [UIApplication sharedApplication].keyWindow.rootViewController = bvc;
            } else {
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"Loginfailed", nil)];
                return;
            }
        }
            break;
            case 2:[MBProgressHUD showErrorMessage:NSLocalizedString(@"msg7", nil)];
            break;

        default:
//            [MBProgressHUD showErrorMessage:get_Value_for_key_from_obj(json, messageKey)];
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"accerror", nil)];
            break;
    }
}

- (void)registerCallback
{
    RegisterController *rvc = [[RegisterController alloc] init];
    rvc.transitioningDelegate = self;
    rvc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:rvc animated:YES completion:nil];
    rvc.registerSuccessCallback = ^{
        
    };
}

- (void)forgetPasswordCallback
{
    ForgetPasswordController *lvc = [[ForgetPasswordController alloc] init];
    lvc.transitioningDelegate = self;
    lvc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:lvc animated:YES completion:nil];
}

#pragma mark - 懒加载
- (BaseService *)baseService
{
    if (!_baseService) {
        _baseService = [[BaseService alloc] init];
    }
    return _baseService;
}

@end
