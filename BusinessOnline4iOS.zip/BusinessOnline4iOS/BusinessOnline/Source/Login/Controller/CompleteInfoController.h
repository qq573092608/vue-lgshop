//
//  CompleteInfoController.h
//  BusinessOnline
//
//  Created by clitics on 2019/5/20.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CompleteInfoController : BaseViewController

@end

NS_ASSUME_NONNULL_END
