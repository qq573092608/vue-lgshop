//
//  CompleteInfoController.m
//  BusinessOnline
//
//  Created by clitics on 2019/5/20.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "CompleteInfoController.h"
#import "CompleteInfoView.h"
#import "AreaSelectController.h"
#import "AreaModel.h"
#import "YQPresentTransitionAnimated.h"
#import "YQDismissTransitionAnimated.h"
#import "LoginController.h"
#import "BaseTabBarController.h"
#import "HomeController.h"

@interface CompleteInfoController ()<UIViewControllerTransitioningDelegate>
{
    CompleteInfoView *registerView;
    AreaModel *_areaModel;
    NSString *_password;
}
@property (nonatomic, strong) UIPercentDrivenInteractiveTransition *percentDrivenTransition;

@end

@implementation CompleteInfoController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupSubViews];
}

- (void)setupSubViews
{
    registerView = [[CompleteInfoView alloc] init];
    [self.view addSubview:registerView];
    [registerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    WEAK_SELF(weakSelf);
    registerView.registerCallback = ^(NSString * _Nonnull area, NSString * _Nonnull phoneNumber, NSString * _Nonnull password) {
        [weakSelf registerViewCallback:area phoneNumber:phoneNumber password:password];
    };
    registerView.dismissCallback = ^{
        [weakSelf dismissCallback];
    };
    registerView.SelectAreaCallback = ^{
        [weakSelf areaSelectCallback];
    };
}

- (void)registerViewCallback:(NSString *)area phoneNumber:(NSString *)phoneNumber password:(NSString *)password
{
    if (!isNSString(_areaModel.code))
    {
        return;
    }
    if (!isNSString(phoneNumber))
    {
        return;
    }
    if (!isNSString(password))
    {
        return;
    }
    NSString *memberCode = [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"%@%@",kNickName,[[NSUserDefaults standardUserDefaults] objectForKey:kUserName]]];
    if (!isNSString(memberCode) || !memberCode.length)
    {
        return;
    }
    _password = password;
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithCapacity:5];
    [params setObject:memberCode forKey:@"memberCode"];
    [params setObject:phoneNumber forKey:@"phoneNumber"];
    [params setObject:password forKey:@"password"];
    [params setObject:_areaModel.code forKey:@"areaCode"];
    [params setObject:[[NSUserDefaults standardUserDefaults] objectForKey:kLoginCookies] forKey:@"cookieName"];
    [self doNetworkRequestForRegisterWithParams:params];
}

- (void)doNetworkRequestForRegisterWithParams:(NSDictionary *)params
{
    [MBProgressHUD showGifToView:nil];
    [NetworkManager postWithURL:CREATE_URL(url_complete_info) params:params isUsedSignal:NO success:^(id json) {
        [MBProgressHUD hideHUD];
        [self registerSuccessCalback:json];
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}

- (void)registerSuccessCalback:(id)json
{
    NSInteger state = [get_Value_for_key_from_obj(json, successKey) integerValue];
    switch (state) {
        case 0:
        {
            HomeController *homeVC = [[HomeController alloc]init];
            homeVC.modalPresentationStyle = UIModalPresentationFullScreen;
            [self presentViewController:homeVC animated:YES completion:nil];
        }
            break;
        case 1:
        {
            [[NSUserDefaults standardUserDefaults] setObject:_password forKey:kPassword];
            [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:kAutoLogin];
            BaseTabBarController *bvc = [[BaseTabBarController alloc] init];
            [UIApplication sharedApplication].keyWindow.rootViewController = bvc;
        }
            break;
        default:
            [MBProgressHUD showErrorMessage:get_Value_for_key_from_obj(json, messageKey)];
//            [MBProgressHUD showErrorMessage:NSLocalizedString(@"failure", nil)];
            break;
    }
}

- (void)dismissCallback
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)areaSelectCallback
{
    AreaSelectController *avc = [[AreaSelectController alloc] init];
    avc.transitioningDelegate = self;
    avc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:avc animated:YES completion:nil];
    WEAK_SELF(weakSelf);
    avc.callback = ^(AreaModel * _Nonnull model) {
        [weakSelf areaCallback:model];
    };
}

- (void)areaCallback:(AreaModel *)model
{
    _areaModel = model;
    [registerView setArea:[NSString stringWithFormat:@"%@+%@",_areaModel.area,_areaModel.code]];
}

#pragma mark - UIViewControllerTransitioningDelegate
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return [[YQPresentTransitionAnimated alloc] init];
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    return [[YQDismissTransitionAnimated alloc] init];
}


@end
