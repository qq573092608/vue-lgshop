//
//  LoginController.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LoginController : BaseViewController

/** 是否显示返回按钮 */
@property (nonatomic, assign) BOOL isNeedShowBackBtn;


@end

NS_ASSUME_NONNULL_END
