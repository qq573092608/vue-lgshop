//
//  LGLoginLogicService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/19.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
    登录注册逻辑处理相关服务类
 */
@interface LGLoginLogicService : NSObject


/// 获取用户名
+ (NSString *)getUserName;


@end

NS_ASSUME_NONNULL_END
