//
//  LGLoginLogicService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/10/19.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGLoginLogicService.h"

@implementation LGLoginLogicService


+ (NSString *)getUserName
{
    // 未登录就设置一个默认的用户名
    NSString *returnUserNameStr = @"unLogin";
    if (nil != [[NSUserDefaults standardUserDefaults] stringForKey:kUserName]) {
        returnUserNameStr = [[NSUserDefaults standardUserDefaults] stringForKey:kUserName];
    }
    return returnUserNameStr;
}


@end
