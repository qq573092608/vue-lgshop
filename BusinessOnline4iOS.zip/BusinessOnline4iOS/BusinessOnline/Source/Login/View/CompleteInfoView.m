//
//  CompleteInfoView.m
//  BusinessOnline
//
//  Created by clitics on 2019/5/20.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "CompleteInfoView.h"

@interface CompleteInfoView ()<UITextFieldDelegate>

@property (nonatomic,strong)UITextField *areaTextfield;
@property (nonatomic,strong)UITextField *phoneNumberTextfield;
@property (nonatomic,strong)UITextField *passwordTextfield;
@property (nonatomic,strong)UIButton *registerBtn;
@property (nonatomic,strong)UIButton *passwordSecurityBtn;
@property (nonatomic,assign)BOOL shouldAuthCodeBtnCanChangeBackgroundColor;

@end
@implementation CompleteInfoView

-(instancetype)init
{
    if (self = [super init])
    {
        _shouldAuthCodeBtnCanChangeBackgroundColor = YES;
        
        [self setupSubViews];
    }
    return self;
}

-(void)setArea:(NSString *)area
{
    if (!isNSString(area))
    {
        return;
    }
    self.areaTextfield.attributedText = [[NSAttributedString alloc] initWithString:area attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];;
}

static CGFloat edgSpacing = 20.0f;
static CGFloat viewSpacing = 10.0f;

- (void)setupSubViews
{
    UIView *container = [UIView new];
    container.userInteractionEnabled = YES;
    [self addSubview:container];
    [container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
        make.width.equalTo(self);
    }];
    
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [container addSubview:backBtn];
    [backBtn setImage:[UIImage imageNamed:@"001_return"] forState:UIControlStateNormal];
    [backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(container).offset(edgSpacing);
        make.top.mas_equalTo(container).offset(edgSpacing+STATUSBAR_HEIGHT);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    [backBtn addTarget:self action:@selector(backBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    [container addSubview:titleLabel];
    titleLabel.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"sup", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(backBtn.mas_right).offset(viewSpacing);
        make.right.mas_equalTo(-60);
        make.centerY.mas_equalTo(backBtn.mas_centerY);
        make.height.mas_equalTo(30);
    }];
    
    self.areaTextfield = [[UITextField alloc] init];
    self.areaTextfield.delegate = self;
    self.areaTextfield.textAlignment = NSTextAlignmentRight;
    self.areaTextfield.borderStyle = UITextBorderStyleNone;
    UILabel *areaLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 120, 20)];
    areaLabel.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"phonearea", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    self.areaTextfield.leftView = areaLabel;
    self.areaTextfield.leftViewMode = UITextFieldViewModeAlways;
    UIButton *areaBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    areaBtn.frame = CGRectMake(0, 0, 30, 30);
    [areaBtn setImage:[UIImage imageNamed:@"registered-icon-go"] forState:UIControlStateNormal];
    [areaBtn addTarget:self action:@selector(areaBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    //    areaBtn.backgroundColor = [UIColor redColor];
    self.areaTextfield.rightView = areaBtn;
    self.areaTextfield.rightViewMode = UITextFieldViewModeAlways;
    [container addSubview:self.areaTextfield];
    [self.areaTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(titleLabel.mas_bottom).offset(40);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    UIView *line1 = [UIView new];
    [container addSubview:line1];
    line1.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.areaTextfield.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    
    self.phoneNumberTextfield = [[UITextField alloc] init];
    self.phoneNumberTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"hint3", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.phoneNumberTextfield.borderStyle = UITextBorderStyleNone;
    self.phoneNumberTextfield.delegate = self;
    self.phoneNumberTextfield.returnKeyType = UIReturnKeyNext;
    UIImageView *phoneNumberImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"registered-icon-phone"]];
    phoneNumberImageView.frame = CGRectMake(0, 3, 20, 20);
    UIView *phonenumberView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [phonenumberView addSubview:phoneNumberImageView];
    self.phoneNumberTextfield.leftView = phonenumberView;
    self.phoneNumberTextfield.leftViewMode = UITextFieldViewModeAlways;
    self.phoneNumberTextfield.clearButtonMode = UITextFieldViewModeWhileEditing;
    [container addSubview:self.phoneNumberTextfield];
    [self.phoneNumberTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(line1.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    UIView *line2 = [UIView new];
    [container addSubview:line2];
    line2.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.phoneNumberTextfield.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    
    self.passwordTextfield = [[UITextField alloc] init];
    self.passwordTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"hint5", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.passwordTextfield.borderStyle = UITextBorderStyleNone;
    self.passwordTextfield.delegate = self;
    self.passwordTextfield.returnKeyType = UIReturnKeyDone;
    self.passwordTextfield.secureTextEntry = YES;
    UIImageView *passwordImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"registered-icon-password"]];
    passwordImageView.frame = CGRectMake(0, 3, 20, 20);
    UIView *passwordview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [passwordview addSubview:passwordImageView];
    self.passwordTextfield.leftView = passwordview;
    self.passwordTextfield.leftViewMode = UITextFieldViewModeAlways;
    self.passwordTextfield.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.passwordSecurityBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.passwordSecurityBtn.frame = CGRectMake(0, 0, 30, 30);
    [self.passwordSecurityBtn addTarget:self action:@selector(securityBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.passwordSecurityBtn setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    self.passwordTextfield.rightView = self.passwordSecurityBtn;
    self.passwordTextfield.rightViewMode = UITextFieldViewModeAlways;
    [container addSubview:self.passwordTextfield];
    [self.passwordTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(line2.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    UIView *line4 = [UIView new];
    [container addSubview:line4];
    line4.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line4 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.passwordTextfield.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    
    self.registerBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.registerBtn.backgroundColor = UIColorFromRGB(colorLoginNotEnable);
    [self.registerBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"commit", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite),NSFontAttributeName:[UIFont systemFontOfSize:17]}] forState:UIControlStateNormal];
    self.registerBtn.layer.cornerRadius = 5.0;
    self.registerBtn.layer.masksToBounds = YES;
    [self.registerBtn addTarget:self action:@selector(registerBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:self.registerBtn];
    [self.registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(line4.mas_bottom).offset(40);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(50);
        make.bottom.mas_equalTo(container.mas_bottom).offset(-10);
    }];
    
    RACSignal *validPhoneNumberSignal = [self.phoneNumberTextfield.rac_textSignal
                                         map:^id(NSString *text) {
                                             return @([self isValidString:text]);
                                         }];
    RACSignal *validPasswordSignal = [self.passwordTextfield.rac_textSignal
                                      map:^id(NSString *text) {
                                          return @([self isValidString:text]);
                                      }];
    
    RACSignal *signUpActiveSignal = [RACSignal combineLatest:@[validPhoneNumberSignal,validPasswordSignal]
                                                      reduce:^id(NSNumber *phoneNumberValid, NSNumber *passwordValid){
                                                          return @(phoneNumberValid.boolValue && passwordValid.boolValue);
                                                      }];
    
    [signUpActiveSignal subscribeNext:^(NSNumber *signupActive) {
        self.registerBtn.enabled = signupActive.boolValue;
        if (self.registerBtn.enabled && self.areaTextfield.text.length)
        {
            self.registerBtn.backgroundColor = MainColor;
        }
        else
        {
            self.registerBtn.backgroundColor = UIColorFromRGB(colorLoginNotEnable);
        }
    }];
}

- (void)backBtnClicked
{
    [self endEditing:YES];
    if (self.dismissCallback)
    {
        self.dismissCallback();
    }
}

- (void)areaBtnClicked
{
    [self endEditing:YES];
    if (self.SelectAreaCallback)
    {
        self.SelectAreaCallback();
    }
}

- (void)securityBtnClicked
{
    self.passwordTextfield.secureTextEntry = !self.passwordTextfield.secureTextEntry;
    if (self.passwordTextfield.secureTextEntry)
    {
        [self.passwordSecurityBtn setImage:[UIImage imageNamed:@"008_turnon"] forState:UIControlStateNormal];
    }
    else
    {
        [self.passwordSecurityBtn setImage:[UIImage imageNamed:@"008_turnon"] forState:UIControlStateNormal];
    }
}

- (void)registerBtnClicked
{
    [self endEditing:YES];
    if (self.registerCallback)
    {
        self.registerCallback(self.areaTextfield.text, self.phoneNumberTextfield.text, self.passwordTextfield.text);
    }
}


- (BOOL)isValidString:(NSString *)string
{
    return string.length > 0;
}

#pragma mark delegate methods
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField == self.areaTextfield)
    {
        [textField resignFirstResponder];
        return NO;
    }
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    if (textField == self.phoneNumberTextfield)
    {
        [self.passwordTextfield becomeFirstResponder];
    }
    else if (textField == self.passwordTextfield)
    {
        [self endEditing:YES];
    }
    return YES;
}

@end
