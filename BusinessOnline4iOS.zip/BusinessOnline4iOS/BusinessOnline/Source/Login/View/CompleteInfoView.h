//
//  CompleteInfoView.h
//  BusinessOnline
//
//  Created by clitics on 2019/5/20.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CompleteInfoView : UIScrollView

- (void)setArea:(NSString *)area;

@property (nonatomic,copy)void(^registerCallback)(NSString *area, NSString *phoneNumber, NSString *password);
@property (nonatomic,copy)void(^dismissCallback)(void);
@property (nonatomic,copy)void(^SelectAreaCallback)(void);

@end

NS_ASSUME_NONNULL_END
