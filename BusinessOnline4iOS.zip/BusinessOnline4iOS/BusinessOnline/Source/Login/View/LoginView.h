//
//  LoginView.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginView : UIScrollView

@property (nonatomic,copy)void(^loginCallback)(NSString *userName, NSString *password);
@property (nonatomic,copy)void(^registerCallback)(void);
@property (nonatomic,copy)void(^forgetPasswordCallback)(void);
@property (nonatomic,copy)void(^dismissCallback)(void);

@property (nonatomic, assign) BOOL isNeedShowBackBtn;

@end

NS_ASSUME_NONNULL_END
