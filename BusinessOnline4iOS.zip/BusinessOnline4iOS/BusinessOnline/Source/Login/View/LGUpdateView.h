//
//  LGUpdateView.h
//  BusinessOnline
//
//  Created by lgerp on 2021/1/21.
//  Copyright © 2021 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^LGSureAction)(void);
typedef void(^LGCancelAction)(void);

NS_ASSUME_NONNULL_BEGIN

/**
   更新的提示界面
 */
@interface LGUpdateView : UIView

@property (nonatomic,copy)LGCancelAction cancelAction;

@property (nonatomic,copy)LGSureAction sureAction;


- (instancetype)initWithVersion:(NSString *)versionStr updateList:(NSArray *)updateList;


@end

NS_ASSUME_NONNULL_END
