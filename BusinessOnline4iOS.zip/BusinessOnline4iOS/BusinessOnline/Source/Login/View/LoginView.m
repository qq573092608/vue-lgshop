//
//  LoginView.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "LoginView.h"

@interface LoginView ()<UITextFieldDelegate>
{
    
}
@property (nonatomic,strong)UITextField *acountTextfield;
@property (nonatomic,strong)UITextField *passwordTextfield;
@property (nonatomic,strong)UIButton *loginBtn;
@property (nonatomic,strong)UIButton *forgetPasswordBtn;
@property (nonatomic,strong)UIButton *registerBtn;

@end
@implementation LoginView

-(instancetype)init
{
    if (self = [super init])
    {
        [self setupSubViews];
    }
    return self;
}

static CGFloat edgSpacing = 20.0f;
static CGFloat viewSpacing = 10.0f;

- (void)setupSubViews
{
    UIView *container = [UIView new];
    container.userInteractionEnabled = YES;
    [self addSubview:container];
    [container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
        make.width.equalTo(self);
    }];
    
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [container addSubview:backBtn];
    [backBtn setImage:[UIImage imageNamed:@"001_return"] forState:UIControlStateNormal];
    [backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(container).offset(edgSpacing);
        make.top.mas_equalTo(container).offset(edgSpacing+STATUSBAR_HEIGHT);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    [backBtn addTarget:self
                action:@selector(backBtnClicked)
      forControlEvents:UIControlEventTouchUpInside];
    
    if (self.isNeedShowBackBtn) {
        backBtn.hidden = NO;
    } else {
        backBtn.hidden = YES;
    }
    
    UILabel *titleLabel = [[UILabel alloc] init];
    [container addSubview:titleLabel];
    if (@available(iOS 8.2, *)) {
        titleLabel.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"login", nil)
                                                                    attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:20 weight:UIFontWeightBold],
                                                                                 NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    } else {
        titleLabel.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"login", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:20],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    }
    
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(backBtn.mas_right).offset(viewSpacing);
        make.right.mas_equalTo(-60);
        make.centerY.mas_equalTo(backBtn.mas_centerY);
        make.height.mas_equalTo(30);
    }];
    
    self.acountTextfield = [[UITextField alloc] init];
    self.acountTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"hint1", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.acountTextfield.borderStyle = UITextBorderStyleNone;
    self.acountTextfield.delegate = self;
    self.acountTextfield.returnKeyType = UIReturnKeyNext;
    self.acountTextfield.keyboardType = UIKeyboardTypeNumberPad;
    UIImageView *acountImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"registered-icon-phone"]];
    acountImageView.frame = CGRectMake(0, 3, 20, 20);
    UIView *acountView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 35, 30)];
    [acountView addSubview:acountImageView];
    self.acountTextfield.leftView = acountView;
    self.acountTextfield.leftViewMode = UITextFieldViewModeAlways;
    [container addSubview:self.acountTextfield];
    self.acountTextfield.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.acountTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(titleLabel.mas_bottom).offset(40);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    UIView *line1 = [UIView new];
    [container addSubview:line1];
    line1.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.acountTextfield.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    
    self.passwordTextfield = [[UITextField alloc] init];
    self.passwordTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"hint2", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.passwordTextfield.borderStyle = UITextBorderStyleNone;
    self.passwordTextfield.delegate = self;
    self.passwordTextfield.returnKeyType = UIReturnKeyDone;
    self.passwordTextfield.secureTextEntry = YES;

    UIImageView *passwordImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"registered-icon-password"]];
    passwordImageView.frame = CGRectMake(0, 3, 20, 20);
    UIView *passwordView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 35, 30)];
    [passwordView addSubview:passwordImageView];
    self.passwordTextfield.leftView = passwordView;
    self.passwordTextfield.leftViewMode = UITextFieldViewModeAlways;
    self.passwordTextfield.clearButtonMode = UITextFieldViewModeWhileEditing;
    [container addSubview:self.passwordTextfield];
    [self.passwordTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(line1.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    UIView *line2 = [UIView new];
    [container addSubview:line2];
    line2.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.passwordTextfield.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    
    self.loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.loginBtn.backgroundColor = UIColorFromRGB(colorLoginNotEnable);
    [self.loginBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"login", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(0xffffff),NSFontAttributeName:[UIFont systemFontOfSize:15]}] forState:UIControlStateNormal];
    self.loginBtn.layer.cornerRadius = 5.0;
    self.loginBtn.layer.masksToBounds = YES;
    [self.loginBtn addTarget:self action:@selector(loginBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:self.loginBtn];
    [self.loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(line2.mas_bottom).offset(40);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(50);
    }];
    
    self.forgetPasswordBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.forgetPasswordBtn.backgroundColor = UIColorFromRGB(0xffffff);
    [self.forgetPasswordBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"forgetPwd2", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(0x4B5162),NSFontAttributeName:[UIFont systemFontOfSize:15]}] forState:UIControlStateNormal];
    self.forgetPasswordBtn.contentHorizontalAlignment = ASHorizontalAlignmentLeft;
    [self.forgetPasswordBtn addTarget:self action:@selector(forgetPasswordBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:self.forgetPasswordBtn];
    [self.forgetPasswordBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.loginBtn.mas_bottom).offset(25);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.size.mas_equalTo(CGSizeMake(190, 30));
        make.bottom.mas_equalTo(container.mas_bottom).offset(-10);
    }];
    
    self.registerBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.registerBtn.backgroundColor = UIColorFromRGB(0xffffff);
    [self.registerBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"newRegister", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(0x4B5162),NSFontAttributeName:[UIFont systemFontOfSize:15]}] forState:UIControlStateNormal];
    self.registerBtn.contentHorizontalAlignment = ASHorizontalAlignmentRight;
    [self.registerBtn addTarget:self action:@selector(registerBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:self.registerBtn];
    [self.registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.loginBtn.mas_bottom).offset(25);
        make.right.mas_equalTo(container.mas_right).offset(20);
        make.size.mas_equalTo(CGSizeMake(120, 30));
    }];
    
    NSString *userName = [[NSUserDefaults standardUserDefaults] objectForKey:kUserName];
    NSString *password = [[NSUserDefaults standardUserDefaults] objectForKey:kPassword];
    if (isNSString(userName))
    {
        self.acountTextfield.text = userName;
    }
    if (isNSString(password))
    {
        self.passwordTextfield.text = password;
    }
    
    RACSignal *validUsernameSignal = [self.acountTextfield.rac_textSignal
     map:^id(NSString *text) {
         return @([self isValidString:text]);
     }];
    RACSignal *validPasswordSignal =
    [self.passwordTextfield.rac_textSignal
     map:^id(NSString *text) {
         return @([self isValidString:text]);
     }];
    
    RACSignal *signUpActiveSignal = [RACSignal combineLatest:@[validUsernameSignal, validPasswordSignal]
        reduce:^id(NSNumber*usernameValid, NSNumber *passwordValid){
            return @([usernameValid boolValue]&&[passwordValid boolValue]);
    }];
    
    [signUpActiveSignal subscribeNext:^(NSNumber *signupActive) {
        self.loginBtn.enabled = signupActive.boolValue;
        if (self.loginBtn.enabled)
        {
            self.loginBtn.backgroundColor = MainColor;
        }
        else
        {
            self.loginBtn.backgroundColor = UIColorFromRGB(colorLoginNotEnable);
        }
    }];
}

- (void)backBtnClicked
{
    [self endEditing:YES];
    if (self.dismissCallback)
    {
        self.dismissCallback();
    }
}

- (void)loginBtnClicked
{
    [self endEditing:YES];
    if (self.loginCallback)
    {
        self.loginCallback(self.acountTextfield.text, self.passwordTextfield.text);
    }
}

- (void)forgetPasswordBtnClicked
{
    [self endEditing:YES];
    if (self.forgetPasswordCallback)
    {
        self.forgetPasswordCallback();
    }
}

- (void)registerBtnClicked
{
    [self endEditing:YES];
    if (self.registerCallback)
    {
        self.registerCallback();
    }
}

- (BOOL)isValidString:(NSString *)string
{
    return string.length > 0;
}

#pragma mark delegate methods
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    if (textField == self.acountTextfield)
    {
        [self.passwordTextfield becomeFirstResponder];
    }
    else if (textField == self.passwordTextfield)
    {
        [self endEditing:YES];
    }
    return YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == self.acountTextfield) {
        self.passwordTextfield.text = @"";
    }
    return YES;
}
-(BOOL)textFieldShouldClear:(UITextField *)textField
{
    if (textField == self.acountTextfield) {
        self.passwordTextfield.text = @"";
    }
    return YES;
}
@end
