//
//  PromptView.m
//  BusinessOnline
//
//  Created by clitics on 2020/5/13.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "PromptView.h"

@implementation PromptView

-(instancetype)init
{
    if (self = [super init])
    {
//        self.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
        self.backgroundColor = [UIColor whiteColor];
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH-150, 340);
        
        UIImageView *imageview = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"prompt"]];
        [self addSubview:imageview];
        [imageview mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self).offset(30);
            make.centerX.mas_equalTo(self);
            make.size.mas_equalTo(CGSizeMake(120, 110));
        }];
        imageview.backgroundColor = [UIColor whiteColor];
//        imageview.image = [UIImage imageNamed:@"prompt"];
        
        UILabel *label1 = [[UILabel alloc] init];
        [self addSubview:label1];
        [label1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(imageview.mas_bottom).offset(10);
            make.left.right.mas_equalTo(self);
            make.height.mas_equalTo(30);
        }];
        label1.text = NSLocalizedString(@"您还没登录", nil);
        label1.font = [UIFont systemFontOfSize:18];
        label1.textColor = UIColorFromRGB(colorTextBlack);
        label1.textAlignment = NSTextAlignmentCenter;
        
        UILabel *label2 = [[UILabel alloc] init];
        [self addSubview:label2];
        [label2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(label1.mas_bottom).offset(0);
            make.left.right.mas_equalTo(self);
            make.height.mas_equalTo(30);
        }];
        label2.text = NSLocalizedString(@"请先登录再进行此操作", nil);
        label2.font = [UIFont systemFontOfSize:15];
        label2.textColor = UIColorFromRGB(colorTextLight);
        label2.textAlignment = NSTextAlignmentCenter;
        
        UIButton *loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:loginBtn];
        [loginBtn addTarget:self
                     action:@selector(logoutBtnClicked)
           forControlEvents:UIControlEventTouchUpInside];
        [loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(label2.mas_bottom).offset(10);
            make.centerX.mas_equalTo(self);
            make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH-250, 40));
        }];
        loginBtn.layer.cornerRadius = 20;
        loginBtn.backgroundColor = MainColor;
        [loginBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"立即登录", nil)
                                                                     attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}] forState:UIControlStateNormal];
        
        UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:cancelBtn];
        [cancelBtn addTarget:self action:@selector(cancelBtnClicked) forControlEvents:UIControlEventTouchUpInside];
        [cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(loginBtn.mas_bottom).offset(10);
            make.centerX.mas_equalTo(self);
            make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH-250, 40));
        }];
        cancelBtn.layer.borderColor = [MainColor CGColor];
        cancelBtn.layer.borderWidth = 1.0f;
        cancelBtn.layer.cornerRadius = 20;
        cancelBtn.backgroundColor = [UIColor whiteColor];
        [cancelBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"暂不登录", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:MainColor}] forState:UIControlStateNormal];
        
    }
    return self;
}

- (void)cancelBtnClicked
{
    if (self.cancel)
    {
        self.cancel();
    }
}

- (void)logoutBtnClicked
{
    if (self.login)
    {
        self.login();
    }
}

@end
