//
//  LGUpdateView.m
//  BusinessOnline
//
//  Created by lgerp on 2021/1/21.
//  Copyright © 2021 clitics. All rights reserved.
//

#import "LGUpdateView.h"

@interface LGUpdateView ()<UITableViewDelegate,UITableViewDataSource> {
    
    NSArray *_dataSource;
}

@property (nonatomic, strong) UITableView *contentTableV;

@end

@implementation LGUpdateView

- (instancetype)initWithVersion:(NSString *)versionStr updateList:(NSArray *)updateList
{
    if (self = [super init]) {
        self.backgroundColor = [UIColor whiteColor];
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH - 150, 320);
        
        _dataSource = updateList;
        
        UIImageView *imageview = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"update_img"]];
        [self addSubview:imageview];
        [imageview mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self).offset(23);
            make.centerX.mas_equalTo(self);
            make.size.mas_equalTo(CGSizeMake(120, 110));
        }];
        imageview.backgroundColor = [UIColor whiteColor];
        
        UILabel *label1 = [[UILabel alloc] init];
        [self addSubview:label1];
        [label1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(imageview.mas_bottom).offset(10);
            make.left.right.mas_equalTo(self);
            make.height.mas_equalTo(18);
        }];
        label1.text = [NSString stringWithFormat:@"%@%@",NSLocalizedString(@"发现新版本V", nil),versionStr];
        label1.font = [UIFont fontWithName:@"PingFang SC" size:16.0f];
        label1.textColor = UIColorFromRGB(colorTextBlack);
        label1.textAlignment = NSTextAlignmentCenter;
                
        [self addSubview:self.contentTableV];
        [self.contentTableV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(label1.mas_bottom).offset(0);
            make.left.mas_equalTo(self.mas_left).offset(23);
            make.right.mas_equalTo(self.mas_right).offset(-23);
            make.bottom.mas_equalTo(self.mas_bottom).offset(-46);
        }];
        
        UIButton *loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:loginBtn];
        [loginBtn addTarget:self action:@selector(logoutBtnClicked) forControlEvents:UIControlEventTouchUpInside];
        [loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self);
            make.bottom.mas_equalTo(self);
            make.size.mas_equalTo(CGSizeMake((SCREEN_WIDTH - 150) * 0.5, 46));
        }];
        loginBtn.backgroundColor = MainColor;
        loginBtn.layer.borderColor = [MainBackgroundColor CGColor];
        [loginBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"立即更新", nil)
                                                                     attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],
                                                                                  NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}]
                            forState:UIControlStateNormal];
        
        UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:cancelBtn];
        [cancelBtn addTarget:self
                      action:@selector(cancelBtnClicked)
            forControlEvents:UIControlEventTouchUpInside];
        [cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self);
            make.bottom.mas_equalTo(self);
            make.size.mas_equalTo(CGSizeMake((SCREEN_WIDTH - 150) * 0.5, 46));
        }];
        cancelBtn.layer.borderColor = [MainBackgroundColor CGColor];
        cancelBtn.layer.borderWidth = 1.0f;
        cancelBtn.backgroundColor = [UIColor whiteColor];
        [cancelBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"以后再说", nil)
                                                                      attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],
                                                                                   NSForegroundColorAttributeName:[UIColor ColorWithHexString:@"#666666"]}]
                             forState:UIControlStateNormal];
        
    }
    return self;
}

- (void)cancelBtnClicked {
    if (self.cancelAction) {
        self.cancelAction();
    }
}

- (void)logoutBtnClicked {
    if (self.sureAction) {
        self.sureAction();
    }
}

#pragma mark - dalegate && datasource

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = [NSString stringWithFormat:@"%ld. %@",(long)indexPath.row + 1,_dataSource[indexPath.row]];
    cell.textLabel.font = [UIFont systemFontOfSize:15];
    cell.textLabel.textColor = UIColorFromRGB(colorTextLight);
    cell.textLabel.textAlignment = NSTextAlignmentLeft;


    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 23.0f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataSource.count;
}

#pragma mark - 懒加载

- (UITableView *)contentTableV{
    
    if (!_contentTableV) {
        _contentTableV = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 206, 75) style:UITableViewStylePlain];
        _contentTableV.delegate = self;
        _contentTableV.dataSource = self;
        _contentTableV.separatorStyle = UITableViewCellSeparatorStyleNone;
        _contentTableV.tableFooterView = [UIView alloc];
    
    }
    return _contentTableV;
}

@end
