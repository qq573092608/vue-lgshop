//
//  RightCollectionViewCell.h
//  BusinessOnline
//
//  Created by clitics on 2020/3/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RightCategoryModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface RightCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong)RightCategoryModel *model;

@end

NS_ASSUME_NONNULL_END
