//
//  ClassificationHeadView.m
//  BusinessOnline
//
//  Created by clitics on 2020/3/11.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "ClassificationHeadView.h"

@implementation ClassificationHeadView

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
//        self.backgroundColor = [UIColor orangeColor];
        self.title = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, SCREEN_WIDTH - 80, 20)];
        self.title.font = [UIFont systemFontOfSize:14];
        self.title.textAlignment = NSTextAlignmentLeft;
//        self.title.backgroundColor = [UIColor redColor];
        [self addSubview:self.title];
    }
    return self;
}

@end
