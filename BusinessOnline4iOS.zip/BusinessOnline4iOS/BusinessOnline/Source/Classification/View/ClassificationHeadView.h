//
//  ClassificationHeadView.h
//  BusinessOnline
//
//  Created by clitics on 2020/3/11.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClassificationHeadView : UICollectionReusableView

@property (nonatomic, strong) UILabel *title;

@end

