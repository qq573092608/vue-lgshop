//
//  LeftTableViewCell.m
//  BusinessOnline
//
//  Created by clitics on 2020/3/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LeftTableViewCell.h"

@interface LeftTableViewCell ()

@property (nonatomic,strong)UIView *redview;

@end

@implementation LeftTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.classname = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, 60, 20)];
        self.classname.center = CGPointMake(50, 25);
        self.classname.numberOfLines = 0;
        self.classname.font = [UIFont systemFontOfSize:14];
        self.classname.textColor = [UIColor blackColor];
        self.classname.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:self.classname];
        
        self.redview = [[UIView alloc]initWithFrame:CGRectMake(0, 10, 5, 20)];
        self.redview.backgroundColor = [UIColor redColor];
        self.redview.center = CGPointMake(5, 25);
        [self.contentView addSubview:self.redview];
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    self.contentView.backgroundColor = selected ? [UIColor whiteColor] : [UIColor colorWithWhite:0 alpha:0.1];
    
    self.highlighted = selected;
    self.classname.highlighted = selected;
    self.redview.hidden = !selected;
    
}

@end
