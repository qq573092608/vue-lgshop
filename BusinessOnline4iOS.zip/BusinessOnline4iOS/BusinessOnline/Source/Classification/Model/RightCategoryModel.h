//
//  RightCategoryModel.h
//  BusinessOnline
//
//  Created by clitics on 2020/3/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RightCategoryModel : NSObject

@property (nonatomic, copy) NSString *icon_url;
@property (nonatomic, copy) NSString *name;

@end

NS_ASSUME_NONNULL_END
