//
//  LeftCategoryModel.h
//  BusinessOnline
//
//  Created by clitics on 2020/3/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RightCategoryModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LeftCategoryModel : NSObject

@property (nonatomic,copy)NSString *name;
@property (nonatomic,copy)NSArray<RightCategoryModel *> *subcategories;

@end

NS_ASSUME_NONNULL_END
