//
//  RightCategoryModel.m
//  BusinessOnline
//
//  Created by clitics on 2020/3/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "RightCategoryModel.h"

@implementation RightCategoryModel

@end
