//
//  LGShoppingNetWorkService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/11/4.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGShoppingNetWorkService.h"
#import "LgResultModel.h"

@implementation LGShoppingNetWorkService


+ (void)checkGoodsShelevesWithGoodsCodes:(NSString *)goodsCodeStr callBack:(LGCheckGoodsShelvesCallBack)callback
{
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];

    [params setObject:invitationCode forKey:@"invitationCode"];
    [params setObject:goodsCodeStr forKey:@"goodsCodes"];

    [NetworkManager postWithURL:CREATE_URL(url_goods_shelves) params:params isUsedSignal:NO success:^(id json) {
        LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
        tempResModel.isSucc = YES;
        tempResModel.data = get_Value_for_key_from_obj(json, dataKey);
        // 该接口有返回即是成功
        callback(tempResModel);
    } failure:^(NSError *error) {
        LgResultModel *result = [[LgResultModel alloc] init];
        result.isSucc = NO;
        result.errMsg = error.localizedDescription;
        callback(result);
    }];
}




@end
