//
//  LGShoppingNetWorkService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/11/4.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LgResultModel;

typedef void(^LGCheckGoodsShelvesCallBack)(LgResultModel *resultModel);

NS_ASSUME_NONNULL_BEGIN

@interface LGShoppingNetWorkService : NSObject

//检测商品是否下架
+ (void)checkGoodsShelevesWithGoodsCodes:(NSString *)goodsCode callBack:(LGCheckGoodsShelvesCallBack)callback;



@end

NS_ASSUME_NONNULL_END
