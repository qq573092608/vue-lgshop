//
//  ShoppingController.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "ShoppingController.h"
#import "JSDropDownMenu.h"
#import "ShoppingModel.h"
#import "ShoppingNode.h"
#import "ShoppingInfoController.h"
#import "ProductDetailController.h"
#import "ShoppingDeleteView.h"
#import "ClearView.h"
#import "CacheModel.h"
#import "HomeController.h"
#import "MMerchantModel.h"
#import "ProductModel.h"
#import "PromptView.h"
#import "LoginController.h"
#import "MerchantInfoModel.h"
#import "InventoryModel.h"
#import "ProductDetailModel.h"
#import "StockView.h"
#import "RelatedPhoneController.h"

#import "BaseService.h"
#import "LGShoppingNetWorkService.h"
#import "LgResultModel.h"
#import "STPopupController.h"
#import "LGProductSpecificaVC.h"

#import "LGProductNetWorkService.h"
#import "LgResultModel.h"
#import "ShoppingRecommendCell.h"
#import "ShoppingEmptyCell.h"
#import "LGSpecifiLogicService.h"

#import "LGUserNetWorkService.h"

@interface ShoppingController ()<ASTableDelegate,ASTableDataSource>
{
    NSInteger _currentIndex;
    CGFloat _totalCharge;
    NSString *_invitationCode;
    NSIndexPath *_indexPath;
    int _number;
    // 当前页
    int _currentTuiJianPage;
    // 推荐总条数
    int _totalTuiJianSumNum;
}
@property (nonatomic,strong)ASTableNode *tableNode;
@property (nonatomic,strong)NSMutableArray *dataSource;
@property (nonatomic,strong)NSMutableArray *perchants;
//@property (nonatomic,strong)JSDropDownMenu *menu;
@property (nonatomic,strong)UILabel *totalLabel;
@property (nonatomic,strong)UIButton *commitBtn;
/**
    库存返回的内容
 */
@property (nonatomic,strong)NSMutableArray *invenrorysdata;
/**
    存储的是将购物车内容转为库存内容的数组
 */
@property (nonatomic,strong)NSMutableArray *invenrorys;

/**
     推荐的产品列表
 */
@property (nonatomic,strong)NSMutableArray *productListSource;

@end

@implementation ShoppingController

-(instancetype)init
{
    if (self = [super init])
    {
        _dataSource = [NSMutableArray array];
        _invenrorysdata = [NSMutableArray array];
        _invenrorys = [NSMutableArray array];
        _perchants = [NSMutableArray arrayWithCapacity:10];
        _totalCharge = 0.00;
        _invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
        _currentTuiJianPage = 1;
        _totalTuiJianSumNum = 0;
        if (!isNSString(_invitationCode)) {
            _invitationCode = @"";
        }
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didReceivedAddAddOrderSuccessNotification:)
                                                 name:kCommitOrderNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didReceivedAddShoppingCarSuccessNotification:)
                                                 name:kProductDetailProductCountChangeNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didReceivedAddShoppingCarSuccessNotification:)
                                                 name:kProductListProductCountChangeNotification
                                               object:nil];
    
    [self setupSubViews];
}

- (void)setupSubViews {
    if (self.perchants.count > 0) {
        int i = 0;
        for (MMerchantModel *model in self.perchants) {
            if ([model.invitationCode isEqualToString:_invitationCode]) {
                break;
            }
            i++;
        }
        MMerchantModel *model = self.perchants[i];
        [self.perchants removeAllObjects];
        [self.perchants addObject:model];
    }
    
    _commitBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.view addSubview:_commitBtn];
    [_commitBtn addTarget:self
                   action:@selector(commitBtnClicked)
         forControlEvents:UIControlEventTouchUpInside];
    _commitBtn.backgroundColor = UIColorFromRGB(colorLoginNotEnable);
    _commitBtn.enabled = NO;
    [_commitBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_go", nil)
                                                                   attributes:@{
                                                                       NSFontAttributeName:[UIFont lgFontFamily:@"" size:15.0f],
                                                            NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}]
                          forState:UIControlStateNormal];
    [_commitBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.bottom.mas_equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(100, 50));
    }];
    
    _totalLabel = [UILabel new];
    [self.view addSubview:_totalLabel];
    [self setTotalCharge:_totalCharge];
    [_totalLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.mas_equalTo(self.view);
        make.right.mas_equalTo(self.commitBtn.mas_left);
        make.height.mas_equalTo(50);
    }];
    
    _tableNode = [[ASTableNode alloc] initWithStyle:UITableViewStyleGrouped];
    [self.view addSubnode:_tableNode];
    _tableNode.view.separatorColor = MainBackgroundColor;
   // UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, CGFLOAT_MIN)];
    _tableNode.view.tableFooterView = [[UIView alloc] init];
    _tableNode.backgroundColor = MainBackgroundColor;
    [_tableNode.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
//        make.top.mas_equalTo(self.menu.mas_bottom).offset(0.5);
        make.top.mas_equalTo(self.view).offset(0.5);
        make.bottom.mas_equalTo(self.commitBtn.mas_top);
    }];
    
    WEAK_SELF(weakSelf);
    self.refresh = [[QPGRefreshTool alloc] init];
    [self.refresh gifModelRefresh:_tableNode.view
                      refreshType:RefreshTypeDouble
                     firstRefresh:NO
                    dropDownBlock:^{
        if ([weakSelf.tableNode.view.mj_header isRefreshing]) {
            [weakSelf doNetworkRequestForHeader];
        }
    } upDropBlock:^{
        if ([_tableNode.view.mj_footer isRefreshing]) {
            [weakSelf doNetworkRequestForFooter];
        }
    }];
    
    self.emptyModel = [[EmptyModel alloc] initWithScrollView:_tableNode.view type:ControllerStateNormal];
    [self.refresh beginRefreshing];
}

- (void)doNetworkRequestForHeader {
    _currentTuiJianPage = 1;
    _totalTuiJianSumNum = 0;

    [self.dataSource removeAllObjects];
    [self.tableNode reloadData];
    [self.emptyModel setState:ControllerStateNormal];
        
    [self.refresh endRefresh];
    
    WEAK_SELF(weakSelf);
    [MBProgressHUD showGifToView:self.view];
    [[DataBaseManager shared] getshoppingcarwithFileName:shoppingcar success:^(NSArray<NSDictionary *> * _Nonnull classifies) {
       
        if (!classifies.count) {
            [weakSelf.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
            [weakSelf deleteClearBtn];
        } else {
            [weakSelf addClearBtn];
        }
        NSMutableArray *models = [NSMutableArray array];
        for (int i=0; i<classifies.count; i++) {
            CacheProductModel *model = [CacheProductModel mj_objectWithKeyValues:classifies[i]];
            [models addObject:model];
        }
        
        for (int i = 0; i < models.count; i ++) {
            for (int j = i + 1; j < models.count; j ++) {
                CacheProductModel *imodel = models[i];
                CacheProductModel *jmodel = models[j];
                if (imodel.count.intValue < jmodel.count.intValue) {
                    [models exchangeObjectAtIndex:i withObjectAtIndex:j];
                }
            }
        }
        
        NSMutableArray * dataArray = [NSMutableArray array];
        while (models.count) {
            CacheProductModel *model = [models firstObject];
            NSArray * tmpArray = [models filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"goodsCode = %@",model.goodsCode]];
            [dataArray addObject:tmpArray];
            [models removeObjectsInArray:tmpArray];
        }
        
        NSMutableArray *allmodels = [NSMutableArray array];
        for (NSArray *array in dataArray) {
            for (CacheProductModel *model in array) {
                NSLog(@"classInfo===%@",[model.tasteList.mj_JSONObject class]);
                [allmodels addObject:model];
            }
        }
        [weakSelf.dataSource removeAllObjects];
        [weakSelf.productListSource removeAllObjects];
        // 配置购物车的数据源
        [weakSelf.dataSource addObjectsFromArray:allmodels];
        [weakSelf totalCharge];
        weakSelf.tableNode.delegate = self;
        weakSelf.tableNode.dataSource = self;
        __strong ShoppingController *strongSelf = weakSelf;
        // 查询推荐商品
        [LGProductNetWorkService getProductListWithType:@"2"
                                                pageNum:@(1)
                                                rowsNum:@(20)
                                               callBack:^(LgResultModel *resultModel, NSArray *productList, int totalNum) {
            [MBProgressHUD hideHUDForView:strongSelf.view animated:NO];
            if (resultModel.isSucc) {
                _currentTuiJianPage = 2;
                _totalTuiJianSumNum = totalNum;
                // 推荐列表的数据源
                [strongSelf.productListSource addObjectsFromArray:productList];
                [strongSelf.tableNode reloadData];
            } else {
              //  [strongSelf.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
              //  [MBProgressHUD showErrorMessage:resultModel.errMsg];
            }
            [strongSelf.tableNode reloadData];

        }];
    }];
}

#pragma mark - 底部刷新===============STAR==============
- (void)doNetworkRequestForFooter{
    
    WEAK_SELF(weakSelf);
    [LGProductNetWorkService getProductListWithType:@"2"
                                            pageNum:@(_currentTuiJianPage)
                                            rowsNum:@(20)
                                           callBack:^(LgResultModel *resultModel, NSArray *productList,int totalNum) {
        [MBProgressHUD hideHUDForView:weakSelf.view animated:NO];
        [weakSelf.refresh endRefresh];

        if (resultModel.isSucc) {
            _totalTuiJianSumNum = totalNum;
            // 没有更多数据了
            if (weakSelf.productListSource.count >= (_totalTuiJianSumNum)) {
                [weakSelf.tableNode.view.mj_footer endRefreshingWithNoMoreData];
            } else {
                [weakSelf.refresh endRefresh];
                [weakSelf.productListSource addObjectsFromArray:productList];
                _currentTuiJianPage ++;
                [weakSelf.tableNode reloadData];
            }             
        } else {
//            [MBProgressHUD showErrorMessage:resultModel.errMsg];
        }
    }];
}

#pragma mark - 底部刷新===============END==============
-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

# pragma mark - 自定义方法

// 获取总价
- (void)totalCharge {
    _totalCharge = 0.0;
    for (CacheProductModel *model in self.dataSource) {
        // 存在折扣就用折扣价
        if (model.s_price_old.floatValue > 0) {
            _totalCharge = _totalCharge + model.s_price_old.floatValue * model.count.floatValue;
        } else {
            _totalCharge = _totalCharge + model.price.floatValue * model.count.floatValue;
        }
    }
    [self setTotalCharge:_totalCharge];
    if (_totalCharge) {
        _commitBtn.backgroundColor = MainColor;
        _commitBtn.enabled = YES;
    }  else {
        _commitBtn.backgroundColor = UIColorFromRGB(colorLoginNotEnable);
        _commitBtn.enabled = NO;
    }
    [self setTotalCharge:_totalCharge];
}

// 提交订单事件
- (void)commitBtnClicked {
    NSString *username = [[NSUserDefaults standardUserDefaults] objectForKey:kUserName];
    NSString *iswechatlogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsWeChatLogin];
    if (username.length<=0 && !iswechatlogin.boolValue) {
        [self showpromptloginview];
        return;
    } else if (username.length<=0 && iswechatlogin.boolValue) {
        //绑定手机号
        RelatedPhoneController *rpVC = [[RelatedPhoneController alloc] init];
        [self.navigationController pushViewController:rpVC animated:YES];
        return;
    }
    
    NSString *goodscodes;
    for (int i=0; i<self.dataSource.count; i++) {
        CacheProductModel *model = self.dataSource[i];
        if (i==0) {
            goodscodes = model.goodsCode;
        } else {
            goodscodes = [goodscodes stringByAppendingString:[NSString stringWithFormat:@",%@",model.goodsCode]];
        }
    }
    [MBProgressHUD showGifToView:nil];
    WEAK_SELF(weakSelf);
    [LGShoppingNetWorkService checkGoodsShelevesWithGoodsCodes:goodscodes
                                                      callBack:^(LgResultModel *resultModel) {
        [MBProgressHUD hideHUD];
        if (resultModel.isSucc) {
            if ([resultModel.stateCode isEqualToString:@"2"]) {
                [weakSelf merchantinfo];
            } else if([resultModel.stateCode isEqualToString:@"1"]){
                NSArray *array = resultModel.data;
                [[DataBaseManager shared] deletegoodsforshoppingcar:array withFileName:shoppingcar success:^(BOOL success) {
                }];
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"部分商品已下架", nil)
                                                                               message:nil
                                                                        preferredStyle:UIAlertControllerStyleAlert];
                __strong __typeof(weakSelf)strongSelf = weakSelf;
                UIAlertAction* quedingAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"queding", nil) style:UIAlertActionStyleDefault
                                                                      handler:^(UIAlertAction * action) {
                                                                          //响应事件
                                                                          [strongSelf.refresh beginRefreshing];
                                                                      }];
                [quedingAction setValue:[UIColor blackColor] forKey:@"titleTextColor"];
                [alert addAction:quedingAction];
                [weakSelf presentViewController:alert animated:YES completion:nil];
            } else if([resultModel.stateCode isEqualToString:@"0"]){
                __strong __typeof(weakSelf)strongSelf = weakSelf;
                LGUserNetWorkService *userNetWorkService = [[LGUserNetWorkService alloc] init];
                [userNetWorkService autoLoginActionWithCallBack:^(LgResultModel * _Nonnull result, id  _Nullable json) {
                    if (result.isSucc) {
                        [strongSelf commitBtnClicked];
                    } else {
                        [MBProgressHUD showErrorMessage:result.message];
                    }
                }];
            } else {
                [MBProgressHUD showErrorMessage:resultModel.message];
            }
        } else {
            [MBProgressHUD showErrorMessage:resultModel.errMsg];
        }
    }];
}

- (void)setTotalCharge:(CGFloat)charge {
    NSMutableAttributedString *attributes = [[NSMutableAttributedString alloc] init];
    [attributes appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"    %@ ",NSLocalizedString(@"total_price", nil)]
                                                                       attributes:@{
                                                                           NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),
                                                                           NSFontAttributeName:[UIFont systemFontOfSize:15]}
                                        ]];
    if (@available(iOS 8.2, *)) {
        [attributes appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %.2f",charge]
                                                                           attributes:@{NSForegroundColorAttributeName:MainColor,
                                                                                        NSFontAttributeName:[UIFont systemFontOfSize:18 weight:UIFontWeightBold]}]];
    } else {
        [attributes appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %.2f",charge]
                                                                           attributes:@{
                                                                               NSForegroundColorAttributeName:MainColor,
                                                                                        NSFontAttributeName:[UIFont systemFontOfSize:18]}
                                            ]];
    }
    
    _totalLabel.attributedText = attributes;
}

- (void)merchantListCallback:(id)json {
    if (!isNSDictionary(json)) {
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"unknownerror", nil)];
        return;
    }
    NSInteger success = [get_Value_for_key_from_obj(json, successKey) integerValue];
    
    if (success == 0) {
        HomeController *homeVC = [[HomeController alloc]init];
        homeVC.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:homeVC animated:YES completion:nil];
    } else if (success == 1) {
        NSMutableArray *temp = [MMerchantModel mj_objectArrayWithKeyValuesArray:get_Value_for_key_from_obj(json, dataKey)];
        
        if (!temp.count) {
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"zusj", nil)];
            return;
        }
        [self.perchants addObjectsFromArray:temp];
        [self setupSubViews];
    } else {
//        [MBProgressHUD showErrorMessage:get_Value_for_key_from_obj(json, messageKey)];
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"failure", nil)];
    }
}

- (void)deleteClearBtn {
    self.navigationItem.rightBarButtonItem = nil;
}

- (void)addClearBtn {
    UIButton *clearBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    clearBtn.frame = CGRectMake(0, 0, 30, 30);
    [clearBtn setImage:[UIImage imageNamed:@"053_g"] forState:UIControlStateNormal];
    [clearBtn addTarget:self action:@selector(clearBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:clearBtn];
    self.navigationItem.rightBarButtonItem = rightItem;
}

- (void)clearBtnClicked
{
    ClearView *view = [[ClearView alloc] init];
    WEAK_SELF(weakSelf);
    view.cancel = ^{
        [weakSelf cancelClear];
    };
    view.clear = ^{
        [weakSelf doNetworkRequestForClearShoppingCar];
    };
    KLCPopup *popup = [KLCPopup popupWithContentView:view showType:KLCPopupShowTypeFadeIn dismissType:KLCPopupDismissTypeFadeOut maskType:KLCPopupMaskTypeDimmed dismissOnBackgroundTouch:NO dismissOnContentTouch:NO];
    [popup show];
}

- (void)cancelClear {
    [KLCPopup dismissAllPopups];
}

- (void)doNetworkRequestForClearShoppingCar {
    [KLCPopup dismissAllPopups];
    [self clearShoppingCarCallback:nil];
}

- (void)clearShoppingCarCallback:(id)json {
    [[CacheModel shared] clearShoppingCar];
    [[DataBaseManager shared] deleteshoppingcarcallback:^(BOOL success) {
        
    }];
    [self.dataSource removeAllObjects];
    [self totalCharge];
    [self deleteClearBtn];
    [self.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
    [self.tableNode reloadData];
    [[NSNotificationCenter defaultCenter] postNotificationName:kShoppingCarClearNotification object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:kQueryAllGoodsNumNotifacation
                                                        object:nil
                                                      userInfo:@{@"allGoodsNum":@(0)}];
}

#pragma mark - UITableView delegate methods
-(NSInteger)numberOfSectionsInTableNode:(ASTableNode *)tableNode {
    if(_dataSource.count == 0){
        return 2;
    } else {
        return _dataSource.count + 2;
    }
//    return 0;
}

-(NSInteger)tableNode:(ASTableNode *)tableNode numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 5;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return CGFLOAT_MIN;
}

-(ASCellNode *)tableNode:(ASTableNode *)tableNode nodeForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(_dataSource.count == 0){
        if (indexPath.section == 0) {
            
            BOOL isNeedHiddenBgImg = NO;
            BOOL isNeedFull = NO;

            if (self.productListSource.count == 0) {
                isNeedHiddenBgImg = YES;
                isNeedFull = YES;
            }
            ShoppingEmptyCell *node = [[ShoppingEmptyCell alloc] initWithEmptyViewIsEmpImgShow:YES
                                                                             isNeedHiddenBgImg:isNeedHiddenBgImg
                                                                                   isFullTable:isNeedFull
                                       ];
            return node;
        } else {
            // 推荐的cell
            WEAK_SELF(weakSelf);
            ShoppingRecommendCell *node = [[ShoppingRecommendCell alloc] initWithProductInfoList:self.productListSource];
            node.recommendCellClickCallBack = ^(ProductModel * _Nonnull productModel) {
                ProductDetailController *pvc = [[ProductDetailController alloc] initWithText:productModel.goods_code
                                                                              invitationCode:@""
                                                                                   indexPath:nil
                                                                                productModel:productModel
                                                                           cacheProductModel:nil
                                                                            isFromShoppingVC:NO
                                                ];
                [weakSelf.navigationController pushViewController:pvc animated:YES];
            };
            return node;
        }
        return nil;
    } else {
        // 针对为你推荐头部的section
        if (indexPath.section == _dataSource.count + 2 - 2) {
            
            if (self.productListSource.count == 0) {
                return [[ASCellNode alloc] init];
            } else {
                ShoppingEmptyCell *node = [[ShoppingEmptyCell alloc] initWithEmptyViewIsEmpImgShow:NO
                                                                                 isNeedHiddenBgImg:NO
                                                                                       isFullTable:NO];
                return node;
            }
            
         // 针对为你推荐的section
        } else if (indexPath.section == _dataSource.count + 2 -1 ) {
            // 配置最后推荐Cell的内容
            WEAK_SELF(weakSelf);
            ShoppingRecommendCell *node = [[ShoppingRecommendCell alloc] initWithProductInfoList:self.productListSource];
            node.recommendCellClickCallBack = ^(ProductModel * _Nonnull productModel) {
                ProductDetailController *pvc = [[ProductDetailController alloc] initWithText:productModel.goods_code
                                                                              invitationCode:@""
                                                                                   indexPath:nil
                                                                                productModel:productModel
                                                                           cacheProductModel:nil
                                                                            isFromShoppingVC:NO
                                                ];
                [weakSelf.navigationController pushViewController:pvc animated:YES];                
            }; 
            return node;
            
        // 针对购物车内容
        } else {
            ShoppingNode *node = [[ShoppingNode alloc] initWithProductModel:self.dataSource[indexPath.section]];
            WEAK_SELF(weakSelf);
            node.showSpecifiCallBack = ^(CGFloat quantity, NSIndexPath * _Nonnull selIndexPath) {
                NSLog(@"quantity====%f,indexPath====%@",quantity,indexPath);
                // _productModelInfo
                CacheProductModel *cacheModel = weakSelf.dataSource[indexPath.section];
                ProductModel *productModel = [[ProductModel alloc] init];
                productModel.tasteList = cacheModel.tasteList.mj_JSONObject;
                productModel.tasteInfoList = cacheModel.tasteInfoList.mj_JSONObject;
                productModel.goods_code = cacheModel.goodsCode;
                productModel.specifications = cacheModel.specifications;
                productModel.real_inventory = cacheModel.realInventory;
                productModel.italian_name = cacheModel.italyName;
                
                PhotoModel *photoImgModel = [[PhotoModel alloc] init];
                photoImgModel.pathName = cacheModel.imageUrl;
                productModel.photoList = [@[photoImgModel] mutableCopy];
                productModel.packquantity = [NSString stringWithFormat:@"%.0f",quantity];
                __strong ShoppingController *strongSelf = weakSelf;
                LGProductSpecificaVC *specificaVa = [[LGProductSpecificaVC alloc] initWithProductModel:productModel
                                                                                             isDefault:YES
                                                                                   specificaModifyType:kSpecificaModifyTypeModify];
                specificaVa.specificaCallBack = ^(NSString * _Nonnull singlePrice, NSString * _Nonnull specificaStr, NSString * _Nonnull totalPriceStr) {
                    NSLog(@"singlePrice===%@ specificaStr====%@  totalPriceStr====%@",singlePrice,specificaStr,totalPriceStr);
                    CacheProductModel *selectModel = strongSelf.dataSource[selIndexPath.section];
                    selectModel.price = singlePrice;
                    [strongSelf.tableNode reloadData];
                };
                
                STPopupController *popVericodeController = [[STPopupController alloc] initWithRootViewController:specificaVa];
                popVericodeController.style = STPopupStyleBottomSheet;
                popVericodeController.hidesCloseButton = YES;
                [popVericodeController presentInViewController:self];
            };
            
            node.selectIndexPath = indexPath;
            node.callback = ^(CGFloat quantity, NSIndexPath * _Nonnull indexPath) {
                [weakSelf nodeCallback:quantity indexPath:indexPath];
            };
            node.selectionStyle = UITableViewCellSelectionStyleNone;
            return node;
        }
        return  nil;
    }
}

- (void)nodeCallback:(CGFloat )quantity indexPath:(NSIndexPath *)indexPath {
    [self totalCharge];
    CacheProductModel *model = self.dataSource[indexPath.section];
    if (!quantity) {
        if (self.dataSource.count > indexPath.section) {
            [self.dataSource removeObjectAtIndex:indexPath.section];
//            [self.emptyModel setState:ControllerStateListNoData];
            [self.tableNode reloadData];
            if (!self.dataSource.count)
            {
                [[CacheModel shared] deleteFromShoppingCar:model.invitationCode];
                [[DataBaseManager shared] deleteshoppingcarcallback:^(BOOL success) {
                }];
            }
        }
    }
}

-(void)tableNode:(ASTableNode *)tableNode didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.dataSource.count == 0
        || self.dataSource == nil
        || indexPath.section > (self.dataSource.count - 1)) {
        return;
    }
    
    CacheProductModel *model = self.dataSource[indexPath.section];
    
    ProductModel *productModel = [[ProductModel alloc] init];
    productModel.specifications = model.specifications;
    productModel.goods_code = model.goodsCode;
    productModel.tasteList = model.tasteList.mj_JSONObject;
    productModel.tasteInfoList = model.tasteInfoList.mj_JSONObject;
    productModel.italian_name = model.italyName;
    
    PhotoModel *photoModel = [[PhotoModel alloc] init];
    photoModel.pathName = model.imageUrl;
   // productModel.photoList = [@[photoModel] mutableCopy];
    ProductDetailController *pvc = [[ProductDetailController alloc] initWithText:model.goodsCode
                                                                  invitationCode:model.invitationCode
                                                                       indexPath:indexPath
                                                                    productModel:productModel
                                                               cacheProductModel:nil
                                                                isFromShoppingVC:NO
                                    ];
    WEAK_SELF(weakSelf);
    pvc.callback = ^(NSIndexPath * _Nonnull indexPath) {
        [weakSelf callbackWithIndexPath:indexPath];
    };
    [self.navigationController pushViewController:pvc animated:YES];
}

- (void)callbackWithIndexPath:(NSIndexPath *)indexPath
{
    
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(_dataSource.count == 0){
        return  NO;
    } else {
        if (indexPath.section == _dataSource.count + 2 -1 ){
            return  NO;
        } else {
            return YES;
        }
    }
}

-(NSArray<UITableViewRowAction *> *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewRowAction *deleteAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:NSLocalizedString(@"delete", nil) handler:^(UITableViewRowAction * _Nonnull action, NSIndexPath * _Nonnull indexPath) {
        [self deleteAtIndex:indexPath];
    }];
    deleteAction.backgroundColor = MainColor;
    return @[deleteAction];
}

- (void)deleteAtIndex:(NSIndexPath *)indexPath {
    CacheProductModel *model = self.dataSource[indexPath.section];
    WEAK_SELF(weakSelf);
    ShoppingDeleteView *view = [[ShoppingDeleteView alloc] initWithTitle:model.italyName index:indexPath];
    view.cancel = ^{
        [weakSelf cancelCallback];
    };
    view.deleteCallback = ^(NSIndexPath * _Nonnull indexPath) {
        [weakSelf deleteCallback:indexPath];
    };
    KLCPopup *popup = [KLCPopup popupWithContentView:view showType:KLCPopupShowTypeFadeIn dismissType:KLCPopupDismissTypeFadeOut maskType:KLCPopupMaskTypeDimmed dismissOnBackgroundTouch:NO dismissOnContentTouch:NO];
    [popup show];
}

- (void)cancelCallback
{
    [KLCPopup dismissAllPopups];
}

- (void)deleteCallback:(NSIndexPath *)indexPath
{
    [KLCPopup dismissAllPopups];
    _indexPath = indexPath;
    [self deleteSuccessCallback:nil];
}

- (void)deleteSuccessCallback:(id)json {
    CacheProductModel *productModel = self.dataSource[_indexPath.section];
    [[CacheModel shared] deleteFromShoppingCar:productModel.goodsCode];
    [[DataBaseManager shared] deletegoods:productModel.mj_keyValues withfilename:shoppingcar success:^(BOOL success) {
        
    }];
    
    [[DataBaseManager shared] getgoodsnumberwithFileName:shoppingcar goodscode:productModel.goodsCode success:^(NSArray<NSDictionary *> * _Nonnull classifies) {
        int count = 0;
        if (classifies.count) {
            int num = 0;
            for (int i=0; i<classifies.count; i++) {
                CacheProductModel *model = [CacheProductModel mj_objectWithKeyValues:classifies[i]];
                num = num + model.count.intValue;
            }
            count = num;
        }
        NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
        [[NSNotificationCenter defaultCenter] postNotificationName:kShoppingCarDeleteProductNotification
                                                            object:nil
                                                          userInfo:@{keyGoodsCode:productModel.goodsCode,
                                                                     keyGoodsCount:@(count),
                                                                     keyInvitationCode:invitationCode}];
        
    }];
    
//    [[NSNotificationCenter defaultCenter] postNotificationName:kShoppingCarDeleteProductNotification object:nil userInfo:@{keyGoodsCode:productModel.goodsCode,keyGoodsCount:@0,keyInvitationCode:productModel.invitationCode}];
    [self.dataSource removeObjectAtIndex:_indexPath.section];
    [self totalCharge];
    [self.tableNode reloadData];
    if (!self.dataSource.count)
    {
        [self.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
        [self deleteClearBtn];
    }
}

#pragma mark - dropmenu delegate methods
//- (NSInteger)numberOfColumnsInMenu:(JSDropDownMenu *)menu {
//    return 1;
//}
//
//- (BOOL)displayByCollectionViewInColumn:(NSInteger)column {
//    return NO;
//}
//
//- (BOOL)haveRightTableViewInColumn:(NSInteger)column {
//    return NO;
//}
//
//-(CGFloat)widthRatioOfLeftColumn:(NSInteger)column {
//    return 1;
//}
//
//-(NSInteger)currentLeftSelectedRow:(NSInteger)column{
//    return _currentIndex;
//}
//
//- (NSInteger)menu:(JSDropDownMenu *)menu numberOfRowsInColumn:(NSInteger)column leftOrRight:(NSInteger)leftOrRight leftRow:(NSInteger)leftRow {
//    return self.perchants.count;
//}
//
//- (NSString *)menu:(JSDropDownMenu *)menu titleForColumn:(NSInteger)column {
//    MMerchantModel *model = self.perchants[_currentIndex];
//    return model.companyName;
//}
//
//- (NSString *)menu:(JSDropDownMenu *)menu titleForRowAtIndexPath:(JSIndexPath *)indexPath {
//    MMerchantModel *model = self.perchants[indexPath.row];
//    return model.companyName;
//}
//
//- (void)menu:(JSDropDownMenu *)menu didSelectRowAtIndexPath:(JSIndexPath *)indexPath {
//
//    if (_currentIndex == indexPath.row) {
//        return;
//    }
//    _currentIndex = indexPath.row;
//    MMerchantModel *model = self.perchants[_currentIndex];
//    _invitationCode = model.invitationCode;
//    if (!isNSString(_invitationCode)) {
//        [MBProgressHUD showErrorMessage:NSLocalizedString(@"unknownerror", nil)];
//        return;
//    }
//    [self.refresh beginRefreshing];
//}

//- (void)viewWillAppear:(BOOL)animated {
//
//    [self.refresh beginRefreshing];
//
//}

- (void)showpromptloginview {
    PromptView *view = [[PromptView alloc] init];
    WEAK_SELF(weakSelf);
    view.cancel = ^{
        [weakSelf cancelCallback];
    };
    view.login = ^{
        [weakSelf loginCallback];
    };
    KLCPopup *popup = [KLCPopup popupWithContentView:view
                                            showType:KLCPopupShowTypeFadeIn
                                         dismissType:KLCPopupDismissTypeFadeOut
                                            maskType:KLCPopupMaskTypeDimmed
                            dismissOnBackgroundTouch:NO
                               dismissOnContentTouch:NO];
    [popup show];
}

- (void)loginCallback {
    [KLCPopup dismissAllPopups];
    HomeController *homeVC = [[HomeController alloc] init];
    homeVC.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:homeVC animated:YES completion:nil];
}

- (void)merchantinfo {
    WEAK_SELF(weakSelf);
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [MBProgressHUD showGifToView:nil];
    [NetworkManager postWithURL:CREATE_URL(url_merchantinfo) params:@{@"invitationCode":invitationCode} isUsedSignal:NO success:^(id json) {
        [MBProgressHUD hideHUD];
        
        [BaseService updateClassificationIconAndProductList:json];
        [weakSelf inventoryIsLose:json];
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}

- (void)inventoryIsLose:(id)json {
    [self.refresh endRefresh];
    if (!isNSDictionary(json)) {
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"unknownerror", nil)];
        return;
    }
    if ([get_Value_for_key_from_obj(json, @"success") integerValue] == 0) {
        WEAK_SELF(weakSelf);
       LGUserNetWorkService *userNetWorkService = [[LGUserNetWorkService alloc] init];
       [userNetWorkService autoLoginActionWithCallBack:^(LgResultModel * _Nonnull result, id  _Nullable json) {
           if (result.isSucc) {
               [weakSelf merchantinfo];
           } else {
               [MBProgressHUD showErrorMessage:result.message];
           }
       }];
                   
    } else if ([get_Value_for_key_from_obj(json, @"success") integerValue] == 1) {
        MerchantInfoModel *model = [MerchantInfoModel mj_objectWithKeyValues:get_Value_for_key_from_obj(json, dataKey)];
        // 是否允许负库存
        if (model.inventoryIsLose.intValue==0) {
            [self Checkinventory];
        } else {
            NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
            ShoppingInfoController *svc = [[ShoppingInfoController alloc] initWithString:[NSString stringWithFormat:@"%.2f",_totalCharge]
                                                                          invitationCode:invitationCode];
            [self.navigationController pushViewController:svc animated:YES];
        }
    } else {
        NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
        ShoppingInfoController *svc = [[ShoppingInfoController alloc] initWithString:[NSString stringWithFormat:@"%.2f",_totalCharge]
                                                                      invitationCode:invitationCode];
        [self.navigationController pushViewController:svc animated:YES];
    }
}

// 检查库存
- (void)Checkinventory {
    [self.invenrorysdata removeAllObjects];
    [self.invenrorys removeAllObjects];
    
    for (CacheProductModel *model in self.dataSource) {
        InventoryModel *imodel = [InventoryModel mj_objectWithKeyValues:model.mj_keyValues];
        // 本地数据库对应的库存信息
        [self.invenrorys addObject:imodel];
    }
    
    [MBProgressHUD showGifToView:nil];
    for (int i = 0; i < self.invenrorys.count; i++) {
        InventoryModel *model = self.invenrorys[i];
        NSMutableDictionary *params = [NSMutableDictionary dictionary];
        NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
        [params setObject:invitationCode forKey:@"invitationCode"];
        [params setObject:model.goodsCode forKey:@"goods_code"];
        WEAK_SELF(weakeSelf);
        // 遍历查询库存信息
        [NetworkManager postWithURL:CREATE_URL(url_findGoodsInfo) params:params isUsedSignal:NO success:^(id json) {
            [MBProgressHUD hideHUD];
            [weakeSelf getInvenrorys:json];
        } failure:^(NSError *error) {
            [MBProgressHUD showErrorMessage:error.localizedDescription];
        }];
    }
}

- (void)getInvenrorys:(id)json {
    NSString *state = get_Value_for_key_from_obj(json, successKey);
    if (state.intValue == 0) {
        WEAK_SELF(weakSelf);
        LGUserNetWorkService *userNetWorkService = [[LGUserNetWorkService alloc] init];
        [userNetWorkService autoLoginActionWithCallBack:^(LgResultModel * _Nonnull result, id  _Nullable json) {
           if (result.isSucc) {
               [weakSelf Checkinventory];
           } else {
               [MBProgressHUD showErrorMessage:result.message];
           }
        }];
    } else if (state.intValue == 1) {
        ProductDetailModel *model = [ProductDetailModel mj_objectWithKeyValues:get_Value_for_key_from_obj(json, dataKey)];
        // 将查询到的库存对象放入集合
        [self.invenrorysdata addObject:model];
        // 表示全部都返回之后再做处理
        if (self.invenrorysdata.count == self.invenrorys.count) {
            [self printInventory];
        }
    } else {
        [MBProgressHUD showMessage:NSLocalizedString(@"msg2", nil)];
    }
}

- (void)printInventory {
//    NSMutableArray *shortageArr = [NSMutableArray array];
    NSMutableSet *shortageSet = [[NSMutableSet alloc] init];
    for (int i = 0; i< self.invenrorysdata.count; i++) {
        
        for (int j = 0; j < self.invenrorys.count; j++) {
            
            ProductDetailModel *pmodel = self.invenrorysdata[i];
            InventoryModel *imodel = self.invenrorys[j];
            if ([pmodel.goods_code isEqualToString:imodel.goodsCode]) {
                // 多规格的情况
                if (pmodel.tasteInfoList.count != 0) {
                    
                    for (NSDictionary *tasetDic in pmodel.tasteInfoList) {
                      NSString *specIdStr = [LGSpecifiLogicService getContitionStr:tasetDic];
                      if ([specIdStr isEqualToString:imodel.infolistid]
                            && [tasetDic[@"realInventory"] intValue] < imodel.count.intValue) {
                          //  pmodel.specifiRealInventory = tasetDic[@"realInventory"];
                          //  [shortageArr addObject:imodel];
                          
                          imodel.realInventory = tasetDic[@"realInventory"];
                          [shortageSet addObject:imodel];
                          
                        }
                    }
                } else {
                    // 真实库存数量小于购物车数量
                    if (pmodel.real_inventory.intValue < imodel.count.intValue ) {
                        [shortageSet addObject:pmodel];
                    }
                }
            }
        }
    }
        
    if (shortageSet.count > 0) {
        
        NSMutableArray *finalArr = [NSMutableArray array];

        NSEnumerator *numerator = [shortageSet objectEnumerator];
        for (id tempObject in numerator) {

            if ([tempObject isKindOfClass:[InventoryModel class]]) {
                InventoryModel *invenModel = tempObject;
                ProductDetailModel *tempDetailModel = [[ProductDetailModel alloc] init];
                tempDetailModel.italian_name = invenModel.italyName;
                tempDetailModel.specifiRealInventory = invenModel.realInventory;
                tempDetailModel.speciDesInfoStr = [LGSpecifiLogicService turnSpecifiFormateWith:invenModel.specifications];
                [finalArr addObject:tempDetailModel];
            } else {
                [finalArr addObject:tempObject];
            }
        }
        
        StockView *view = [[StockView alloc] initWithstockdata:finalArr];
        WEAK_SELF(weakSelf);
        view.cancel = ^{
            [weakSelf cancelCallback];
        };
        view.comfirm = ^{
            [weakSelf cancelCallback];
        };
        KLCPopup *popup = [KLCPopup popupWithContentView:view showType:KLCPopupShowTypeFadeIn
                                             dismissType:KLCPopupDismissTypeFadeOut
                                                maskType:KLCPopupMaskTypeDimmed
                                dismissOnBackgroundTouch:NO
                                   dismissOnContentTouch:NO];
        [popup show];
    } else {
        NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
        ShoppingInfoController *svc = [[ShoppingInfoController alloc] initWithString:[NSString stringWithFormat:@"%.2f",_totalCharge] invitationCode:invitationCode];
        [self.navigationController pushViewController:svc animated:YES];
    }    
}


#pragma mark - 通知相关
- (void)didReceivedAddAddOrderSuccessNotification:(NSNotification *)notification
{
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [[CacheModel shared] clearShoppingCarWithInvitationCode:invitationCode];
    if ([invitationCode isKindOfClass:[NSString class]]) {
        [self doNetworkRequestForHeader];
    }
}

// 刷新表格的通知
- (void)didReceivedAddShoppingCarSuccessNotification:(NSNotification *)notification {
    [self.refresh beginRefreshing];
}

#pragma mark - 懒加载

- (NSMutableArray *)productListSource {
    if (!_productListSource) {
        _productListSource = [[NSMutableArray alloc] init];
    }
    return _productListSource;
}


@end
