//
//  ShoppingEmptyCell.m
//  BusinessOnline
//
//  Created by lgerp on 2020/12/16.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "ShoppingEmptyCell.h"
#import "LGLanguageManager.h"
#import "NSString+Size.h"

@interface ShoppingEmptyCell(){
    // 空白的图片
    ASImageNode *_empImageNode;
    // 空白的描述信息
    ASTextNode *_contentNode;
    // 推荐的图标
    ASImageNode *_recomandImageNode;
    // 是否隐藏空白的图片以及描述信息
    BOOL _isEmpImgShow;
    // 是否需要隐藏背景图
    BOOL _isNeedHiddenBgImg;
    // 是否充满屏幕
    BOOL _isFullTable;
}

@end

@implementation ShoppingEmptyCell

- (instancetype)initWithEmptyViewIsEmpImgShow:(BOOL)isEmpImgShow
                            isNeedHiddenBgImg:(BOOL)isNeedHiddenBgImg
                                  isFullTable:(BOOL)isFTable{
    if (self = [super init]) {
        _isEmpImgShow = isEmpImgShow;
        _isNeedHiddenBgImg = isNeedHiddenBgImg;
        _isFullTable = isFTable;
        [self configEmpView];
    }
    return self;
}

- (void)configEmpView {
    self.backgroundColor = MainBackgroundColor;
    _empImageNode = [[ASImageNode alloc] init];
    _empImageNode.image = [UIImage imageNamed:@"046_i"];
    [self addSubnode:_empImageNode];

    _recomandImageNode = [[ASImageNode alloc] init];
        
    _recomandImageNode.image = [UIImage imageNamed:[LGLanguageManager getRecomandImageCurrentLanguage]];
    _recomandImageNode.hidden = _isNeedHiddenBgImg;
    
    [self addSubnode:_recomandImageNode];
    
    _contentNode = [[ASTextNode alloc] init];
    _contentNode.attributedText =  [[NSAttributedString alloc] initWithString:NSLocalizedString(@"zusj", nil)
                                                                       attributes:@{NSForegroundColorAttributeName:[UIColor ColorWithHexString:@"#B2B1B1"],
                                                                                    NSFontAttributeName:[UIFont fontWithName:@"PingFang SC" size: 16]}];
    [self addSubnode:_contentNode];
}


#pragma mark - 自动展示布局
-(ASLayoutSpec *)layoutSpecThatFits:(ASSizeRange)constrainedSize {
    
    if (_isEmpImgShow) {

        CGFloat width =  [NSLocalizedString(@"zusj", nil) widthWithFont:[UIFont fontWithName:@"PingFang SC" size: 16] constrainedToHeight:16];
        _contentNode.style.preferredSize = CGSizeMake(width, 20);
        _empImageNode.style.preferredSize = CGSizeMake([UIImage imageNamed:@"046_i"].size.width, [UIImage imageNamed:@"046_i"].size.height);
        ASStackLayoutSpec *spec6 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                               spacing:12
                                                                        justifyContent:ASStackLayoutJustifyContentCenter
                                                                            alignItems:ASStackLayoutAlignItemsCenter
                                                                              children:@[_empImageNode,_contentNode]];
        ASStackLayoutSpec *recomandImgNode = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                                     spacing:150
                                                                              justifyContent:ASStackLayoutJustifyContentCenter
                                                                                  alignItems:ASStackLayoutAlignItemsCenter
                                                                                    children:@[spec6,_recomandImageNode]];
        
        if (_isFullTable) {
            return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(240, 10, 12, 10) child:recomandImgNode];
        } else {
            return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(24, 10, 12, 10) child:recomandImgNode];
        }
    } else {
         UIImage *recomandImg = [UIImage imageNamed:[LGLanguageManager getRecomandImageCurrentLanguage]];
        _recomandImageNode.hidden = NO;
        _recomandImageNode.style.preferredSize = CGSizeMake(recomandImg.size.width, recomandImg.size.height);
        ASStackLayoutSpec *headerStackSpec = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                                     spacing:0
                                                                              justifyContent:ASStackLayoutJustifyContentCenter
                                                                                  alignItems:ASStackLayoutAlignItemsCenter
                                                                                    children:@[_recomandImageNode]];
        return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(24, 10, 12, 10) child:headerStackSpec];
    }
}

@end
