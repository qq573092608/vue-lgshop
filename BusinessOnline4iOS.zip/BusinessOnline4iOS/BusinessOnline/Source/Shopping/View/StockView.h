//
//  StockView.h
//  BusinessOnline
//
//  Created by clitics on 2020/6/30.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface StockView : UIView

@property (nonatomic,copy)void(^cancel)(void);
@property (nonatomic,copy)void(^comfirm)(void);

-(instancetype)initWithstockdata:(NSMutableArray *)models;

@end

NS_ASSUME_NONNULL_END
