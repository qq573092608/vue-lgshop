//
//  ShoppingRecommendCell.m
//  BusinessOnline
//
//  Created by lgerp on 2020/12/15.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "ShoppingRecommendCell.h"
#import "ProductModel.h"
#import "ProductNode.h"
#import "ShoppingEmptyCell.h"
#import "LGProductLogicService.h"

@interface ShoppingRecommendCell ()<ASCollectionDataSource,UICollectionViewDataSource,ASCollectionDelegate,ASCollectionDelegateFlowLayout, ASCollectionGalleryLayoutPropertiesProviding>{
    CGSize _kItemSize;
    NSArray *_dataSource;
}
@property (nonatomic, strong) ASCollectionNode *collectionNode;

@end


@implementation ShoppingRecommendCell

- (instancetype)initWithProductInfoList:(NSArray *)productInfoList{
    
    self = [super init];
    if(self){
        [self configView];
        _dataSource = [LGProductLogicService getFinalProductListWithOutExplain:productInfoList];
    }
    return self;
}

- (void)configView {
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.minimumLineSpacing = 10.0f;
    layout.minimumInteritemSpacing = 10.0f;
    layout.sectionInset = UIEdgeInsetsMake(0, 10, 10, 10);
    _kItemSize = CGSizeMake((SCREEN_WIDTH-33)/2, (SCREEN_WIDTH-30)/2*10/9+60);
    layout.itemSize = _kItemSize;
    // self.view.bounds
    CGRect rect = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    self.collectionNode = [[ASCollectionNode alloc] initWithFrame:rect collectionViewLayout:layout];
    self.collectionNode.dataSource = self;
    self.collectionNode.delegate = self;
    self.collectionNode.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.collectionNode.backgroundColor = MainBackgroundColor;
   // self.collectionNode.view.separatorColor = [UIColor clearColor];
    
   // self.collectionNode.view.scrollEnabled = NO;
    [self.view addSubnode:self.collectionNode];
   // self.collectionNode.frame = rect;
}

#pragma mark - ASCollectionGalleryLayoutPropertiesProviding
- (CGSize)galleryLayoutDelegate:(ASCollectionGalleryLayoutDelegate *)delegate sizeForElements:(ASElementMap *)elements {
    ASDisplayNodeAssertMainThread();
    return _kItemSize;
}

#pragma mark - ASCollectionDataSource
- (NSInteger)collectionNode:(ASCollectionNode *)collectionNode numberOfItemsInSection:(NSInteger)section {
    return _dataSource.count;
}

- (NSInteger)numberOfSectionsInCollectionNode:(ASCollectionNode *)collectionNode {
    return 1;
}

-(ASCellNode *)collectionNode:(ASCollectionNode *)collectionNode nodeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    ProductNode *node = [[ProductNode alloc] initWithModel:_dataSource[indexPath.row] isNeedHiddenBuyBtn:YES isRecordmend:YES];
   // node.selectionStyle = UITableViewCellSelectionStyleNone;
    node.collectionNode = collectionNode;
    return node;
}

#pragma mark - ASCollectionDelegate

- (void)collectionNode:(ASCollectionNode *)collectionNode willBeginBatchFetchWithContext:(ASBatchContext *)context
{
    NSLog(@"fetch additional content");
    [context completeBatchFetching:YES];
}

-(void)collectionNode:(ASCollectionNode *)collectionNode didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    ProductModel *model = _dataSource[indexPath.row];
    if (!isNSString(model.goods_code)) {
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"unknownerror", nil)];
        return;
    }
    
    if (self.recommendCellClickCallBack) {
        self.recommendCellClickCallBack(model);
    }
}


#pragma mark - 自动展示布局

#pragma mark - ASDisplayNode
-(ASLayoutSpec *)layoutSpecThatFits:(ASSizeRange)constrainedSize {
    
    long cellNum = 0;
    if (_dataSource.count % 2 == 1) {
        cellNum = _dataSource.count / 2 + 1;
    } else {
        cellNum = _dataSource.count / 2;
    }
     float cellHeight = (SCREEN_WIDTH - 30) / 2 * 10 / 9 + 60;
    /**
        通过计算出collection的高度来撑开表格
     */
    // ((cellHeight + 10) * cellNum) + 20
    self.collectionNode.style.preferredSize = CGSizeMake(SCREEN_WIDTH, (cellHeight + 10) * cellNum );
    ASStackLayoutSpec *spec6 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                       spacing:0
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[self.collectionNode]];
    return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(0, 0, 0, 0) child:spec6];
}

@end
