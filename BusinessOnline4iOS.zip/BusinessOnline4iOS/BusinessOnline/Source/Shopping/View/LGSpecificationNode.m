//
//  LGSpecificationNode.m
//  BusinessOnline
//
//  Created by lgerp on 2020/12/24.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGSpecificationNode.h"
#import "CacheProductModel.h"
#import "LGSpecifiLogicService.h"
#import "NSString+Size.h"

@interface LGSpecificationNode (){
    ASTextNode *_specificationsNode;
    ASImageNode *_unfoldImgNode;
    CacheProductModel *_productModel;
    NSString *_specificationStr;
}

@end

@implementation LGSpecificationNode

-(instancetype)initWithProductModel:(CacheProductModel *)productModel{
    
    if (self = [super init]){
        _productModel = productModel;
        [self configViewWithModel:productModel];
    }

    return self;
}

- (void)configViewWithModel:(CacheProductModel *)model{
    
    self.backgroundColor = MainBackgroundColor;
    
    // 多规格旁边的图片展开控件
    _unfoldImgNode = [ASImageNode new];
    [self addSubnode:_unfoldImgNode];
    _unfoldImgNode.image = [UIImage imageNamed:@"icon_arrow_Unfold"];
    
    // 多规格控件
    NSString *specifications;
    specifications = _productModel.specifications;
    if (!isNSString(specifications) || [specifications isEqualToString:@"not"]) {
        specifications = @"";
    }
    _specificationStr = specifications;
    _specificationsNode = [ASTextNode new];
    [self addSubnode:_specificationsNode];
    if (specifications.length != 0) {
        _specificationsNode.backgroundColor = [UIColor ColorWithHexString:@"#F6F6F6"];
        [_specificationsNode addTarget:self
                                action:@selector(choiseSpecifiAction)
                      forControlEvents:ASControlNodeEventTouchUpInside];
        _unfoldImgNode.hidden = NO;
    } else {
        self.backgroundColor = [UIColor clearColor];
        _unfoldImgNode.hidden = YES;
    }
    
    //文字水平居中
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.alignment = NSTextAlignmentCenter;
    _specificationsNode.maximumNumberOfLines = 1;
    _specificationsNode.truncationMode = NSLineBreakByTruncatingTail;
    _specificationsNode.attributedText = [[NSAttributedString alloc] initWithString:[LGSpecifiLogicService turnSpecifiFormateWith:specifications]
                                                                         attributes:@{
                                                                             NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),
                                                                                        NSFontAttributeName:[UIFont fontWithName:@"PingFang SC" size: 12],
                                                                              NSParagraphStyleAttributeName:paragraphStyle
                                                                         }];
}

- (void)choiseSpecifiAction{
    if (self.specifiBtnClickCallBack) {
        self.specifiBtnClickCallBack();
    }
}

static CGFloat edgSpacing = 8;
-(ASLayoutSpec *)layoutSpecThatFits:(ASSizeRange)constrainedSize {
    _specificationsNode.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH - 90 - 4 * edgSpacing);
   float speciWidth = [[LGSpecifiLogicService turnSpecifiFormateWith:_specificationStr]
                       widthWithFont:[UIFont fontWithName:@"PingFang SC" size: 12]
                    constrainedToHeight:12.0f];
    // 24
    _specificationsNode.style.preferredSize = CGSizeMake(speciWidth + 12, 16.0f);
    UIImage *unfoldImg = [UIImage imageNamed:@"icon_arrow_Unfold"];
    _unfoldImgNode.style.preferredSize = CGSizeMake(unfoldImg.size.width, unfoldImg.size.height);
    ASStackLayoutSpec *specificaSpec = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                               spacing:0
                                                                        justifyContent:ASStackLayoutJustifyContentCenter
                                                                            alignItems:ASStackLayoutAlignItemsCenter
                                                                              children:@[_specificationsNode,_unfoldImgNode]];
    ASInsetLayoutSpec *insetSpec = [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(0, 0, 0, 0)
                                                                          child:specificaSpec];
    return insetSpec;
}


@end
