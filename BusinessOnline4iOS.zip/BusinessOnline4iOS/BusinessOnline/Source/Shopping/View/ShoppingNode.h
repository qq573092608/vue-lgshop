//
//  ShoppingNode.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/28.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <AsyncDisplayKit/ASCellNode.h>
@class ShoppingModel, CacheProductModel;

NS_ASSUME_NONNULL_BEGIN

typedef void(^LGShowSpecifiCallBack)(CGFloat quantity,NSIndexPath *indexPath);

@interface ShoppingNode : ASCellNode

@property (nonatomic,strong)NSIndexPath *selectIndexPath;

@property (nonatomic,copy)void(^callback)(CGFloat quantity,NSIndexPath *indexPath);

@property (nonatomic,copy) LGShowSpecifiCallBack showSpecifiCallBack;


- (instancetype)initWithProductModel:(CacheProductModel *)productModel;

@end

NS_ASSUME_NONNULL_END
