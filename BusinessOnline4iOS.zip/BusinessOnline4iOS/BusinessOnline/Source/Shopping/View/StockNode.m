//
//  StockNode.m
//  BusinessOnline
//
//  Created by clitics on 2020/6/30.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "StockNode.h"
#import "ProductDetailModel.h"
#import "AppDelegate.h"

@interface StockNode ()
{
    ASTextNode *_productname,*_stocknode;
    ASTextNode *_speciDesNode;
    ProductDetailModel *_productModel;
}

@end

@implementation StockNode

- (instancetype)initWithInventory:(ProductDetailModel *)model
{
    if (self = [super init])
    {
        _productModel = model;
        
        _productname = [ASTextNode new];
        [self addSubnode:_productname];
        
        NSString *name = _productModel.italian_name;
        if (!isNSString(name)) {
            name = @"";
        }
        _productname.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"【%@】: %@",NSLocalizedString(@"商品", nil),name]
                                                                      attributes:@{
                                                                          NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),
                                                                          NSFontAttributeName:[UIFont systemFontOfSize:18]}
                                       ];
        
        _speciDesNode = [ASTextNode new];
        [self addSubnode:_speciDesNode];
        _speciDesNode.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"                    %@",_productModel.speciDesInfoStr]
                                                                       attributes:@{
                                                                           NSForegroundColorAttributeName:[UIColor ColorWithHexString:@"#666666"],
                                                                           NSFontAttributeName:[UIFont lgFontFamily:@"" size:12.0]}];

        _stocknode = [ASTextNode new];
        [self addSubnode:_stocknode];
        
        NSString *count = @"";
        if (_productModel.specifiRealInventory == nil) {
            count = _productModel.real_inventory;
        } else {
            if (![_productModel.specifiRealInventory isKindOfClass:[NSString class]]) {
                count = [NSString stringWithFormat:@"%@",_productModel.specifiRealInventory];
            } else {
                count = _productModel.specifiRealInventory;
            }
        }
        if (!isNSString(count))
        {
            count = @"";
        }
        
        _stocknode.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"  %@: %@",NSLocalizedString(@"剩余库存", nil),count]
                                                                    attributes:@{
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),
                                                                        NSFontAttributeName:[UIFont systemFontOfSize:18]}
                                     ];
    }
    return self;
}

static CGFloat edgSpacing = 20;

-(ASLayoutSpec *)layoutSpecThatFits:(ASSizeRange)constrainedSize
{
    ASStackLayoutSpec *spec1 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                       spacing:5
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_productname,_speciDesNode,_stocknode]];
    
    return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(10, edgSpacing, 10, edgSpacing) child:spec1];
}

@end
