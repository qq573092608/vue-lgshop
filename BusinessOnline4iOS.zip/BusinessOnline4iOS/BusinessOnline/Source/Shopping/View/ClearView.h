//
//  ClearView.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/26.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ClearView : UIView

@property (nonatomic,copy)void(^cancel)(void);
@property (nonatomic,copy)void(^clear)(void);

@end

NS_ASSUME_NONNULL_END
