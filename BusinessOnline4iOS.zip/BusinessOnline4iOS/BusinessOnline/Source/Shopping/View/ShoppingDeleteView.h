//
//  ShoppingDeleteView.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/11.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ShoppingDeleteView : UIView

- (instancetype)initWithTitle:(NSString *)title index:(NSIndexPath *)indexPath;

@property (nonatomic,copy)void(^cancel)(void);
@property (nonatomic,copy)void(^deleteCallback)(NSIndexPath *indexPath);

@end

NS_ASSUME_NONNULL_END
