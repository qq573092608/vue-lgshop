//
//  ShoppingNode.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/28.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "ShoppingNode.h"
#import "ShoppingModel.h"
#import "PPNumberButton.h"
#import "CacheProductModel.h"
#import "CacheModel.h"
#import "AppDelegate.h"

#import "UIColor+HexString.h"
#import "NSString+Size.h"
#import "LGSpecifiLogicService.h"
#import "LGSpecificationNode.h"

@interface ShoppingNode ()
{
    ASNetworkImageNode *_iconNode;
    ASTextNode *_productNameNode,*_chargeNode,*_totalChargeNode,*_specificationsNode,* _oldpriceNode;
    ASImageNode *_unfoldImgNode;
    ASDisplayNode *_lineNode,*_alterCountNode;
    // 多规格内容
    NSString *_specificationStr;
    /**
       多规格控件
     */
    LGSpecificationNode *_specifiNode;
}
@property (nonatomic,strong)PPNumberButton *button;
@property (nonatomic,assign)CGFloat quantity;
@property (nonatomic,strong)CacheProductModel *productModel;

@end
@implementation ShoppingNode

-(instancetype)initWithProductModel:(CacheProductModel *)productModel
{
    if (self = [super init])
    {
        self.backgroundColor = [UIColor whiteColor];
        _productModel = productModel;
        _quantity = _productModel.count.intValue;
        
        _iconNode = [ASNetworkImageNode new];
        [self addSubnode:_iconNode];
        _iconNode.backgroundColor = [UIColor whiteColor];
        _iconNode.defaultImage = [UIImage imageNamed:@"shoppingCarDefault"];
        _iconNode.contentMode = UIViewContentModeScaleAspectFit;
        _iconNode.URL = [NSURL URLWithString:_productModel.imageUrl];
        
        NSString *productName = _productModel.italyName;
        if (!isNSString(productName)) {
            productName = @"";
        }
        _productNameNode = [ASTextNode new];
        [self addSubnode:_productNameNode];
        _productNameNode.maximumNumberOfLines = 1;
        _productNameNode.truncationMode = NSLineBreakByTruncatingTail;
        _productNameNode.attributedText = [[NSAttributedString alloc] initWithString:productName
                                                                          attributes:@{
                                                                              NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),
                                                                              NSFontAttributeName:[UIFont systemFontOfSize:18]
                                                                          }];
        _productNameNode.maximumNumberOfLines = 2;
        
        
        _specifiNode = [[LGSpecificationNode alloc] initWithProductModel:_productModel];
        WEAK_SELF(weakSelf);
        _specifiNode.specifiBtnClickCallBack = ^{
            [weakSelf choiseSpecifiAction];
        };
        [self addSubnode:_specifiNode];
        
        /***/
        // 多规格旁边的图片展开控件
        _unfoldImgNode = [ASImageNode new];
        [self addSubnode:_unfoldImgNode];
        _unfoldImgNode.image = [UIImage imageNamed:@"icon_arrow_Unfold"];
        
        // 多规格控件
        NSString *specifications;
        specifications = _productModel.specifications;
        if (!isNSString(specifications) || [specifications isEqualToString:@"not"]) {
            specifications = @"";
        }
        _specificationStr = specifications;
        _specificationsNode = [ASTextNode new];
        [self addSubnode:_specificationsNode];
        if (specifications.length != 0) {
            _specificationsNode.backgroundColor = [UIColor ColorWithHexString:@"#F6F6F6"];
            [_specificationsNode addTarget:self
                                    action:@selector(choiseSpecifiAction)
                          forControlEvents:ASControlNodeEventTouchUpInside];
            _unfoldImgNode.hidden = NO;
        } else {
            _unfoldImgNode.hidden = YES;
        }
        
        _specificationsNode.maximumNumberOfLines = 1;
        _specificationsNode.truncationMode = NSLineBreakByTruncatingTail;
        _specificationsNode.attributedText = [[NSAttributedString alloc] initWithString:[LGSpecifiLogicService turnSpecifiFormateWith:specifications]
                                                                             attributes:@{
                                                                                 NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),
                                                                                          NSFontAttributeName:[UIFont fontWithName:@"PingFang SC" size: 12]}
                                                                                ];
        
        NSMutableAttributedString *charge = [[NSMutableAttributedString alloc] init];
        [charge appendAttributedString:[[NSAttributedString alloc] initWithString:@"€ "
                                                                       attributes:@{
                                                                           NSForegroundColorAttributeName:MainColor,
                                                                           NSFontAttributeName:[UIFont systemFontOfSize:18
                                                                                                                 weight:UIFontWeightBold]}
                                        ]];
        
        NSString *showPriceStr = @"";
        _oldpriceNode = [ASTextNode new];
        if (_productModel.s_discount.floatValue > 0) {
            showPriceStr = _productModel.s_price_old;
            _oldpriceNode.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %@",_productModel.price]
                                                                           attributes:@{
                                                                               NSFontAttributeName:DISCOUNT_PRICE_FONT,
                                                                               NSForegroundColorAttributeName:UnderLineColor
                                                                           }];
            [self addSubnode:_oldpriceNode];
        } else {
            showPriceStr = _productModel.price;
        }
        _lineNode = [ASDisplayNode new];
        _lineNode.backgroundColor = UnderLineColor;
        [self addSubnode:_lineNode];
        
        if (@available(iOS 8.2, *)) {
            [charge appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%.2f",showPriceStr.floatValue]
                                                                           attributes:@{
                                                                               NSForegroundColorAttributeName:MainColor,
                                                                               NSFontAttributeName:[UIFont systemFontOfSize:18 weight:UIFontWeightBold]}]
             ];
        } else {
            [charge appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%.2f",showPriceStr.floatValue]
                                                                           attributes:@{
                                                                               NSForegroundColorAttributeName:MainColor,
                                                                               NSFontAttributeName:[UIFont systemFontOfSize:18]}]
             ];
        }
//        [charge appendAttributedString:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"jianshu2", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:18]}]];
        _chargeNode = [ASTextNode new];
        [self addSubnode:_chargeNode];
        _chargeNode.maximumNumberOfLines = 1;
        _chargeNode.truncationMode = NSLineBreakByTruncatingTail;
        _chargeNode.attributedText = charge;
        
        _alterCountNode = [[ASDisplayNode alloc] initWithViewBlock:^UIView * _Nonnull{
            self.button = [[PPNumberButton alloc] init];
            self.button.editing = NO;
            self.button.minValue = 0;
            self.button.stepValue = self.productModel.packageNumber.floatValue ? self.productModel.packageNumber.floatValue : 1;
            self.button.borderColor = MainColor;
            self.button.buttonTitleFont = 20;
            self.button.increaseTitle = @"+";
            self.button.decreaseTitle = @"-";
            self.button.currentNumber = self.productModel.count.intValue;
            WEAK_SELF(weakSelf);
            self.button.resultBlock = ^(PPNumberButton *ppBtn, CGFloat number, BOOL increaseStatus) {
                [weakSelf alterCount:number isIncrease:increaseStatus];
            };
            return self.button;
        }];
        [self addSubnode:_alterCountNode];
                
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        style.alignment = NSTextAlignmentRight;
        NSMutableAttributedString *totalCharge = [[NSMutableAttributedString alloc] init];
        [totalCharge appendAttributedString:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"total_price", nil)
                                                                            attributes:@{
                                                                                NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),
                                                                                NSFontAttributeName:[UIFont systemFontOfSize:18],
                                                                                NSParagraphStyleAttributeName:style}]];
       
        if (@available(iOS 8.2, *)) {
            [totalCharge appendAttributedString:[[NSAttributedString alloc] initWithString:@"€ "
                                                                                attributes:@{
                                                                                    NSForegroundColorAttributeName:MainColor,
                                                                                    NSFontAttributeName:[UIFont systemFontOfSize:18 weight:UIFontWeightBold],NSParagraphStyleAttributeName:style}
                                                 ]];
        } else {
            [totalCharge appendAttributedString:[[NSAttributedString alloc] initWithString:@"€ "
                                                                                attributes:@{NSForegroundColorAttributeName:MainColor,
                                                                                             NSFontAttributeName:[UIFont systemFontOfSize:18 weight:UIFontWeightBold],
                                                                                             NSParagraphStyleAttributeName:style}
                                                 ]];
        }
        
        NSString *showTotalPrice = @"";
        if (_productModel.s_discount.floatValue > 0) {
            showTotalPrice = [NSString stringWithFormat:@"%.2f",_productModel.s_price_old.floatValue * _productModel.count.intValue];;
        } else {
            showTotalPrice = [NSString stringWithFormat:@"%.2f",_productModel.price.floatValue*_productModel.count.intValue];
        }
        
        if (@available(iOS 8.2, *)) {
            [totalCharge appendAttributedString:[[NSAttributedString alloc] initWithString:showTotalPrice
                                                                                attributes:@{
                                                                                    NSForegroundColorAttributeName:MainColor,
                                                                                    NSFontAttributeName:
                                                                                        [UIFont systemFontOfSize:18 weight:UIFontWeightBold],
                                                                                        NSParagraphStyleAttributeName:style}
                                                 ]];
        } else {
            [totalCharge appendAttributedString:[[NSAttributedString alloc] initWithString:showTotalPrice
                                                                                attributes:@{
                                                                                    NSForegroundColorAttributeName:MainColor,
                                                                                    NSFontAttributeName:[UIFont systemFontOfSize:18],
                                                                                    NSParagraphStyleAttributeName:style}
                                                 ]];
        }
        _totalChargeNode = [ASTextNode new];
        [self addSubnode:_totalChargeNode];
        _totalChargeNode.attributedText = totalCharge;
        
        //        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didReceivedAddShoppingCarSuccessNotification:) name:kProductDetailProductCountChangeNotification object:nil];
        //        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didReceivedAddShoppingCarSuccessNotification:) name:kProductListProductCountChangeNotification object:nil];
        
    }
    return self;
}

- (void)choiseSpecifiAction {
    if (self.showSpecifiCallBack) {
        self.showSpecifiCallBack(self.quantity,self.selectIndexPath);
    }
}

- (void)didReceivedAddShoppingCarSuccessNotification:(NSNotification *)notification {
    NSString *invitationCode = [notification.userInfo objectForKey:keyInvitationCode];
    if (![invitationCode isEqualToString:_productModel.invitationCode]) {
        return;
    }
    NSString *goodCode = [notification.userInfo objectForKey:keyGoodsCode];
    if (![goodCode isEqualToString:_productModel.goodsCode]) {
        return;
    }
    _productModel = [[CacheModel shared] modelForKey:_productModel.goodsCode];
    _quantity = _productModel.count.intValue;
    self.button.currentNumber = _quantity;
    if (self.callback)
    {
        self.callback(self.quantity,self.selectIndexPath);
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        [self setNeedsLayout];
    });
}

- (void)alterCount:(CGFloat)number isIncrease:(BOOL)isIncrease {
    if (number < 0)
    {
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"slbnxy0", nil)];
    }
    _quantity = number;
    
    [self commitBtnClicked:number];
}

- (void)commitBtnClicked:(CGFloat)quantity
{
    if (![_productModel.goodsCode isKindOfClass:[NSString class]])
    {
        return;
    }
    if (0 > _quantity)
    {
        return;
    }
    CacheProductModel *model = [CacheProductModel new];
    if (_productModel) {
        model.invitationCode = _productModel.invitationCode;
    }
    else
    {
        model.invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    }
    
    model.goodsCode = _productModel.goodsCode?_productModel.goodsCode:@"";
    model.count = [NSString stringWithFormat:@"%f",_quantity];
    NSDate *date = [NSDate date];
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    format.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    model.createDate = [format stringFromDate:date];
    model.imageUrl = _productModel.imageUrl;
    model.italyName = _productModel.italyName;
    model.price = _productModel.price;
    model.packageNumber = _productModel.packageNumber;
    if (quantity)
    {
        [[CacheModel shared] addShoppingCar:model];
        model.specifications = _productModel.specifications;
//        [[DataBaseManager shared] addshoppingcar:model.mj_keyValues withfilename:shoppingcar success:^(BOOL success) {
//            NSLog(@"succese=%d",success);
//        }];
        [[DataBaseManager shared] updateshopnumber:model.mj_keyValues withfilename:shoppingcar success:^(BOOL success) {
            
        }];
    } else {
        [[CacheModel shared] deleteFromShoppingCar:model.goodsCode];
        
        model.specifications = _productModel.specifications;
        [[DataBaseManager shared] deletegoods:model.mj_keyValues withfilename:shoppingcar success:^(BOOL success) {
           
        }];
    }
    
    [self addShoppingCarSuccessCallback:nil];
}

- (void)addShoppingCarSuccessCallback:(id)json
{
    _productModel.count = [NSString stringWithFormat:@"%f",_quantity];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self setNeedsLayout];
    });
    
//    if ([_productModel.invitationCode isEqualToString:invitationCode])
//    {
        if (isNSString(_productModel.goodsCode)) {
            [[DataBaseManager shared] getgoodsnumberwithFileName:shoppingcar goodscode:_productModel.goodsCode success:^(NSArray<NSDictionary *> * _Nonnull classifies) {
                int count = 0;
                if (classifies.count) {
                    int num = 0;
                    for (int i=0; i<classifies.count; i++) {
                        CacheProductModel *model = [CacheProductModel mj_objectWithKeyValues:classifies[i]];
                        num = num + model.count.intValue;
                    }
                    
                    count = num;
                }
                NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
                NSLog(@"%d",count);
                [[NSNotificationCenter defaultCenter] postNotificationName:kShoppingCarProductCountChangeNotification object:self userInfo:@{keyGoodsCode:self->_productModel.goodsCode,keyGoodsCount:@(count),keyInvitationCode:invitationCode}];
                
            }];
        }
//    }
    
    if (self.callback) {
        self.callback(self.quantity,self.selectIndexPath);
    }
    
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
    style.alignment = NSTextAlignmentRight;
    NSMutableAttributedString *totalCharge = [[NSMutableAttributedString alloc] init];
    [totalCharge appendAttributedString:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"total_price", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),NSFontAttributeName:[UIFont systemFontOfSize:18],NSParagraphStyleAttributeName:style}]];
    if (@available(iOS 8.2, *)) {
        [totalCharge appendAttributedString:[[NSAttributedString alloc] initWithString:@"€ "
                                                                            attributes:@{
                                                                                NSForegroundColorAttributeName:MainColor,
                                                                                NSFontAttributeName:[UIFont systemFontOfSize:18 weight:UIFontWeightBold],
                                                                                NSParagraphStyleAttributeName:style}
                                             ]];
    } else {
        [totalCharge appendAttributedString:[[NSAttributedString alloc] initWithString:@"€ "
                                                                            attributes:@{
                                                                                NSForegroundColorAttributeName:MainColor,
                                                                                NSFontAttributeName:[UIFont systemFontOfSize:18],
                                                                                NSParagraphStyleAttributeName:style}
                                             ]];
    }
    
    NSString *totalShowPrice = @"";
    if (_productModel.s_discount.floatValue > 0) {
        totalShowPrice = [NSString stringWithFormat:@"%.2f",_productModel.s_price_old.floatValue*_quantity];
    } else {
        totalShowPrice = [NSString stringWithFormat:@"%.2f",_productModel.price.floatValue*_quantity];
    }
    
    if (@available(iOS 8.2, *)) {
        [totalCharge appendAttributedString:[[NSAttributedString alloc] initWithString:totalShowPrice
                                                                            attributes:@{
                                                                                NSForegroundColorAttributeName:MainColor,
                                                                                NSFontAttributeName:[UIFont systemFontOfSize:18 weight:UIFontWeightBold],
                                                                                NSParagraphStyleAttributeName:style}
                                             ]];
    } else {
        [totalCharge appendAttributedString:[[NSAttributedString alloc] initWithString:totalShowPrice
                                                                            attributes:@{
                                                                                NSForegroundColorAttributeName:MainColor,
                                                                                NSFontAttributeName:[UIFont systemFontOfSize:18],
                                                                                NSParagraphStyleAttributeName:style}
                                             ]];
    }
    _totalChargeNode.attributedText = totalCharge;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self reloadTotalChargeNode];
    });
}

- (void)reloadTotalChargeNode
{
    [_totalChargeNode setNeedsDisplay];
}

static CGFloat edgSpacing = 8;

-(ASLayoutSpec *)layoutSpecThatFits:(ASSizeRange)constrainedSize
{
    CGFloat linewidth = _oldpriceNode.attributedText.size.width;
    _lineNode.style.preferredSize = CGSizeMake(linewidth, 1);
    _iconNode.style.preferredSize = CGSizeMake(90, 90);
    _productNameNode.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH - 90 - 4 * edgSpacing);
    //
    _specificationsNode.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH - 90 - 4 * edgSpacing);
    
    float speciWidth = [[LGSpecifiLogicService turnSpecifiFormateWith:_specificationStr]
                        widthWithFont:[UIFont fontWithName:@"PingFang SC" size: 12]
                     constrainedToHeight:12.0f];
    // _specificationsNode.style.maxWidth = ASDimensionMakeWithPoints(speciWidth);
    
    UIImage *unFoldImg = [UIImage imageNamed:@"icon_arrow_Unfold"];
    _specifiNode.style.preferredSize = CGSizeMake(speciWidth + 12 + unFoldImg.size.width, 24.0f);
    
   // _specificationsNode.style.maxWidth = ASDimensionMakeWithPoints(speciWidth);
//    _specificationsNode.style.preferredSize = CGSizeMake(speciWidth, 18.0f);

    _totalChargeNode.style.width = ASDimensionMakeWithPoints(SCREEN_WIDTH-90-4*edgSpacing);
   // _unfoldImgNode.style.preferredSize = CGSizeMake(6.0f, 24.0f);
    _chargeNode.style.maxWidth = ASDimensionMakeWithPoints(120);
//    _lineNode.style.height = ASDimensionMakeWithPoints(0.5);
//    _lineNode.style.flexGrow = 1.0;
    _alterCountNode.style.preferredSize = CGSizeMake(120, 40);
    ASLayoutSpec *spacing = [ASLayoutSpec new];
    spacing.style.flexGrow = 1.0f;
    
    ASRelativeLayoutSpec *spec9 = [ASRelativeLayoutSpec
    relativePositionLayoutSpecWithHorizontalPosition:ASRelativeLayoutSpecPositionCenter
                                    verticalPosition:ASRelativeLayoutSpecPositionCenter
                                        sizingOption:ASRelativeLayoutSpecSizingOptionDefault child:_lineNode];
    
    ASOverlayLayoutSpec *spec10 = [ASOverlayLayoutSpec overlayLayoutSpecWithChild:_oldpriceNode overlay:spec9];
    
    ASStackLayoutSpec *spec1 = nil;
    if (_productModel.s_discount.floatValue > 0) {
        ASStackLayoutSpec *tempSpec = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                              spacing:-4
                                                                       justifyContent:ASStackLayoutJustifyContentStart
                                                                           alignItems:ASStackLayoutAlignItemsStart
                                                                             children:@[ _chargeNode,spec10]];
        
        spec1 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                           spacing:edgSpacing
                                                                    justifyContent:ASStackLayoutJustifyContentSpaceAround
                                                                        alignItems:ASStackLayoutAlignItemsCenter
                                                                          children:@[tempSpec,spacing,_alterCountNode]];
    } else {
        spec1 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                           spacing:edgSpacing
                                                                    justifyContent:ASStackLayoutJustifyContentSpaceAround
                                                                        alignItems:ASStackLayoutAlignItemsCenter
                                                                          children:@[_chargeNode,spacing, _alterCountNode]];
    }
    
//    ASStackLayoutSpec *specificaSpec = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
//                                                                               spacing:5
//                                                                        justifyContent:ASStackLayoutJustifyContentStart
//                                                                            alignItems:ASStackLayoutAlignItemsCenter
//                                                                              children:@[_specificationsNode,_unfoldImgNode]];
//
//    ASInsetLayoutSpec *insetSpec = [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(24, 10, 12, 10) child:specificaSpec];
    
    // specificaSpec    _specificationsNode  specificaSpec
    ASStackLayoutSpec *spec2 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                       spacing:edgSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStretch
                                                                      children:@[_productNameNode,_specifiNode,spec1]];
//    ASStackLayoutSpec *spec1 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical spacing:edgSpacing justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsStretch children:@[_productNameNode,_specificationsNode,_chargeNode]];
//    ASStackLayoutSpec *spec2 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal spacing:edgSpacing justifyContent:ASStackLayoutJustifyContentSpaceAround alignItems:ASStackLayoutAlignItemsEnd children:@[spec1,spacing,_alterCountNode]];
    ASInsetLayoutSpec *spec3 = [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(0, 0, 0, edgSpacing) child:spec2];
    ASInsetLayoutSpec *spec4 = [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(0, 0, 0, edgSpacing) child:_totalChargeNode];
    ASStackLayoutSpec *spec5 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                       spacing:edgSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStretch
                                                                      children:@[spec3,spec4]];
    ASStackLayoutSpec *spec6 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                       spacing:edgSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_iconNode,spec5]];
    return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(edgSpacing, edgSpacing, edgSpacing, edgSpacing) child:spec6];
}

@end
