//
//  LGSpecificationNode.h
//  BusinessOnline
//
//  Created by lgerp on 2020/12/24.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <AsyncDisplayKit/ASCellNode.h>

NS_ASSUME_NONNULL_BEGIN

@class CacheProductModel;

typedef void(^LGSpecifiBtnClickCallBack)(void);


@interface LGSpecificationNode : ASDisplayNode

@property (nonatomic, copy)LGSpecifiBtnClickCallBack specifiBtnClickCallBack;

-(instancetype)initWithProductModel:(CacheProductModel *)productModel;

@end

NS_ASSUME_NONNULL_END
