//
//  ShoppingRecommendCell.h
//  BusinessOnline
//
//  Created by lgerp on 2020/12/15.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <AsyncDisplayKit/ASCellNode.h>
@class ProductModel;

NS_ASSUME_NONNULL_BEGIN

typedef void(^LGRecommendCellClickCallBack)(ProductModel *productModel);

@interface ShoppingRecommendCell : ASCellNode


@property (nonatomic, copy) LGRecommendCellClickCallBack recommendCellClickCallBack;

///  展示列表数据
/// @param productInfoList 数据源
- (instancetype)initWithProductInfoList:(NSArray *)productInfoList;


@end

NS_ASSUME_NONNULL_END
