//
//  StockNode.h
//  BusinessOnline
//
//  Created by clitics on 2020/6/30.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <AsyncDisplayKit/ASCellNode.h>
@class ProductDetailModel;

NS_ASSUME_NONNULL_BEGIN

@interface StockNode : ASCellNode

- (instancetype)initWithInventory:(ProductDetailModel *)model;

@end

NS_ASSUME_NONNULL_END
