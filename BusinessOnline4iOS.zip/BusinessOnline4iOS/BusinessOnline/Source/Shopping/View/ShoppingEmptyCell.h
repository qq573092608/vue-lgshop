//
//  ShoppingEmptyCell.h
//  BusinessOnline
//
//  Created by lgerp on 2020/12/16.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <AsyncDisplayKit/ASCellNode.h>

NS_ASSUME_NONNULL_BEGIN

/// 配置推荐页面的空白页面
@interface ShoppingEmptyCell : ASCellNode


/// isEmpImgShow(是否隐藏空白的图片以及文字 YES:显示  NO:隐藏 )
/// isNeedHiddenBgImg(是否需要隐藏背景图)
- (instancetype)initWithEmptyViewIsEmpImgShow:(BOOL)isEmpImgShow isNeedHiddenBgImg:(BOOL)isNeedHiddenBgImg isFullTable:(BOOL)isFTable;
@end

NS_ASSUME_NONNULL_END
