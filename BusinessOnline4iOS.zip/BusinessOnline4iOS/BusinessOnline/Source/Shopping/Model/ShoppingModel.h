//
//  ShoppingModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/28.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ShoppingModel : NSObject

/*
 boxNumber = 1;
 cartState = 1;
 companyId = 3;
 companyName = "\U767e\U5ea6\U96c6\U56e2";
 createDate = 1551174226000;
 
 discount = 0;
 goodsCode = meihao1;
 goodsId = 47004;
 goodsImage = "";
 goodsName = "\U66f2\U5947";
 
 goodsQuantity = 2;
 invitationCode = lgerp;
 itaName = cookie;
 overDel = 0;
 packageNumber = 1;
 
 price = 10000;
 quantity = 2;
 shoppingCartId = 470;
 userId = 6;
 */
@property (nonatomic,copy)NSString *boxNumber;
@property (nonatomic,copy)NSString *cartState;
@property (nonatomic,copy)NSString *companyId;
@property (nonatomic,copy)NSString *companyName;
@property (nonatomic,copy)NSString *createDate;

@property (nonatomic,copy)NSString *discount;
@property (nonatomic,copy)NSString *goodsCode;
@property (nonatomic,copy)NSString *goodsId;
@property (nonatomic,copy)NSString *goodsImage;
@property (nonatomic,copy)NSString *goodsName;

@property (nonatomic,copy)NSString *goodsQuantity;
@property (nonatomic,copy)NSString *invitationCode;
@property (nonatomic,copy)NSString *itaName;
@property (nonatomic,copy)NSString *zhName;
@property (nonatomic,copy)NSString *overDel;
@property (nonatomic,copy)NSString *packageNumber;

@property (nonatomic,copy)NSString *price;
@property (nonatomic,copy)NSString *quantity;
@property (nonatomic,copy)NSString *shoppingCartId;
@property (nonatomic,copy)NSString *userId;




//test
@property (nonatomic,copy)NSString *real_inventory;

@end

NS_ASSUME_NONNULL_END
