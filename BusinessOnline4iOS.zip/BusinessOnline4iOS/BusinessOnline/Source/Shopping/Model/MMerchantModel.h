//
//  MMerchantModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/27.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MMerchantModel : NSObject

/*
 address = nb;
 cloudUrl = "http://www.lgtechita.com/LgErp";
 companyId = 5;
 companyName = lgerp;
 contactName = lgerp;
 
 contactPhone = 15475421358;
 email = "";
 fax = "";
 invitationCode = lgerp;
 legalPerson = lgerp;
 
 legalPhone = 15879543258;
 logoImage = "";
 state = 1;
 zipCode = 000000;
 introduction = "";
 */

/*
 "address": "中国深圳",
 "companyId": 2,
 "companyName": "mille",
 "state": 1,
 "zipCode": "4008789",
 
 "legalPhone": "18794368249",
 "legalPerson": "马化腾",
 "contactName": "林湘",
 "contactPhone": "17943287954",
 "fax": "0592-88887777",
 
 "email": "649821673@qq.com",
 "invitationCode": "mille",
 "cloudUrl": "http://192.168.0.151:13000/LgErpServer/",
 "logoImage": "https://gss0.jpg",
 "introduction": "",
 
 "invitationQrImage":
 */
@property (nonatomic,copy)NSString *address;
@property (nonatomic,copy)NSString *cloudUrl;
@property (nonatomic,copy)NSString *companyId;
@property (nonatomic,copy)NSString *companyName;
@property (nonatomic,copy)NSString *contactName;

@property (nonatomic,copy)NSString *contactPhone;
@property (nonatomic,copy)NSString *email;
@property (nonatomic,copy)NSString *fax;
@property (nonatomic,copy)NSString *invitationCode;
@property (nonatomic,copy)NSString *legalPerson;

@property (nonatomic,copy)NSString *legalPhone;
@property (nonatomic,copy)NSString *logoImage;
@property (nonatomic,copy)NSString *state;
@property (nonatomic,copy)NSString *zipCode;
@property (nonatomic,copy)NSString *introduction;

@property (nonatomic,copy)NSString *invitationQrImage;

@end

NS_ASSUME_NONNULL_END
