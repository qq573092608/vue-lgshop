//
//  MMerchantModel.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/27.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "MMerchantModel.h"

@implementation MMerchantModel

@end
