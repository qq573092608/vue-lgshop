//
//  ShoppingModel.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/28.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "ShoppingModel.h"

@implementation ShoppingModel

@end
