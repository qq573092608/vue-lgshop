//
//  InventoryModel.m
//  BusinessOnline
//
//  Created by clitics on 2020/6/30.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "InventoryModel.h"

@implementation InventoryModel

@end
