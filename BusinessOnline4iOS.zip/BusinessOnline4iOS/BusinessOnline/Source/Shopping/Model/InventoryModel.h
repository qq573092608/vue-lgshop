//
//  InventoryModel.h
//  BusinessOnline
//
//  Created by clitics on 2020/6/30.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/** 库存模型 */
@interface InventoryModel : NSObject

@property (nonatomic,copy)NSString *goodsCode;
@property (nonatomic,copy)NSString *zhName;
@property (nonatomic,copy)NSString *italyName;
/** 当前库存数 */
@property (nonatomic,copy)NSString *count;

/** 服务器库实际库存数 */
@property (nonatomic,copy)NSString *realInventory;
/**
    多规格内容
 */
@property (nonatomic,copy)NSString *specifications;
/**
    多规格id的字符串
 */
@property (nonatomic,copy)NSString *infolistid;

@end

NS_ASSUME_NONNULL_END
