//
//  RegisterController.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface RegisterController : BaseViewController

@property (nonatomic,copy)void(^registerSuccessCallback)(void);

@end

NS_ASSUME_NONNULL_END
