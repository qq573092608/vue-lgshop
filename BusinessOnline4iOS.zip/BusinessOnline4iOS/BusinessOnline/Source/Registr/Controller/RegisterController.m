//
//  RegisterController.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "RegisterController.h"
#import "RegisterView.h"
#import "AreaSelectController.h"
#import "AreaModel.h"
#import "YQPresentTransitionAnimated.h"
#import "YQDismissTransitionAnimated.h"
#import "LoginController.h"
#import "AgreementController.h"
#import "AppDelegate.h"

@interface RegisterController ()<UIViewControllerTransitioningDelegate>
{
    RegisterView *registerView;
    AreaModel *_areaModel;
}
@property (nonatomic, strong) UIPercentDrivenInteractiveTransition *percentDrivenTransition;

@end

@implementation RegisterController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupSubViews];
}

- (void)setupSubViews
{
    registerView = [[RegisterView alloc] init];
    [self.view addSubview:registerView];
    [registerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    WEAK_SELF(weakSelf);
    registerView.registerCallback = ^(NSString * _Nonnull area, NSString * _Nonnull phoneNumber, NSString * _Nonnull authCode, NSString * _Nonnull password, BOOL isagree) {
        [weakSelf registerViewCallback:area phoneNumber:phoneNumber authCode:authCode password:password isagree:isagree];
    };
    registerView.dismissCallback = ^{
        [weakSelf dismissCallback];
    };
    registerView.SelectAreaCallback = ^{
        [weakSelf areaSelectCallback];
    };
    registerView.sendAuthCodeCallback = ^(NSString * _Nonnull phone) {
        [weakSelf authCodeCallback:phone];
    };
    registerView.agreement = ^{
        [weakSelf Checktheagreement];
    };
}

- (void)registerViewCallback:(NSString *)area phoneNumber:(NSString *)phoneNumber authCode:(NSString *)authCode password:(NSString *)password isagree:(BOOL)isagree
{
    
    if (!isNSString(_areaModel.code))
    {
        return;
    }
    if (!isNSString(phoneNumber))
    {
        return;
    }
    if (!isNSString(authCode))
    {
        return;
    }
    if (!isNSString(password))
    {
        return;
    }
    if (!isagree) {
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"尚未勾选注册协议", nil)];
        return;
    }
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithCapacity:5];
    [params setObject:phoneNumber forKey:@"phone"];
    [params setObject:password forKey:@"password"];
    [params setObject:authCode forKey:@"sum"];
    [params setObject:_areaModel.code forKey:@"areaCode"];
    
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    
    [params setObject:invitationCode forKey:@"invitationCode"];
    [self doNetworkRequestForRegisterWithParams:params];
}

- (void)doNetworkRequestForRegisterWithParams:(NSDictionary *)params
{
    [MBProgressHUD showGifToView:nil];
    [NetworkManager postWithURL:CREATE_URL(url_register) params:params isUsedSignal:NO success:^(id json) {
        [MBProgressHUD hideHUD];
        [self registerSuccessCalback:json];
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}

- (void)registerSuccessCalback:(id)json
{
    NSInteger state = [get_Value_for_key_from_obj(json, successKey) integerValue];
    switch (state) {
        case 1:
        {
            [MBProgressHUD showMessage:NSLocalizedString(@"msg4", nil) displayTime:2];
            if (self.registerSuccessCallback)
            {
//                [MBProgressHUD showErrorMessage:NSLocalizedString(@"msg4", nil)];
               // [MBProgressHUD showMessage:NSLocalizedString(@"msg4", nil)];
//                LoginController *lvc = [[LoginController alloc] init];
//                lvc.transitioningDelegate = self;
//                lvc.modalPresentationStyle = UIModalPresentationFullScreen;
//                [self presentViewController:lvc animated:YES completion:nil];
                [self performSelector:@selector(presentloginview) withObject:nil afterDelay:0.6];
            }
            else
            {
                [self dismissCallback];
            }
        }
            break;
        case 2:
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"msg5", nil)];
        default:
//            [MBProgressHUD showErrorMessage:get_Value_for_key_from_obj(json, messageKey)];
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"msg6", nil)];
            break;
    }
}

- (void)dismissCallback
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)areaSelectCallback
{
    AreaSelectController *avc = [[AreaSelectController alloc] init];
    avc.transitioningDelegate = self;
    avc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:avc animated:YES completion:nil];
    WEAK_SELF(weakSelf);
    avc.callback = ^(AreaModel * _Nonnull model) {
        [weakSelf areaCallback:model];
    };
}

- (void)areaCallback:(AreaModel *)model
{
    _areaModel = model;
    [registerView setArea:[NSString stringWithFormat:@"%@+%@",_areaModel.area,_areaModel.code]];
}

- (void)authCodeCallback:(NSString *)phone
{
    [self.view endEditing:YES];
    if (!isNSString(phone))
    {
        return;
    }
    if (!isNSString(_areaModel.code))
    {
        return;
    }
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithCapacity:4];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [params setObject:phone forKey:@"phone"];
    [params setObject:_areaModel.code forKey:@"areaCode"];
    [params setObject:@"register" forKey:@"operation"];
    [params setObject:invitationCode forKey:@"invitationCode"];
    [self doNetworkRequestForAuthCode:params];
}

- (void)doNetworkRequestForAuthCode:(NSDictionary *)params
{
    [MBProgressHUD showGifToView:nil];
    [NetworkManager postWithURL:CREATE_URL(url_send_auth_code) params:params isUsedSignal:NO success:^(id json) {
        [MBProgressHUD hideHUD];
        [self authCodeSuccessCalback:json];
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}

- (void)authCodeSuccessCalback:(id)json
{
    NSInteger state = [get_Value_for_key_from_obj(json, successKey) integerValue];
    switch (state) {
        case 1:
        {
//            if (!self.registerSuccessCallback)
//            {
//                LoginController *lvc = [[LoginController alloc] init];
//                lvc.transitioningDelegate = self;
//                [self presentViewController:lvc animated:YES completion:nil];
//            }
//            else
//            {
//                [self dismissCallback];
//            }
//            [MBProgressHUD showErrorMessage:get_Value_for_key_from_obj(json, messageKey)];
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"msg1", nil)];
        }
            break;
            
        case 2:
        {
            
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"msg2", nil)];
            
        }
            break;
        case 3:
        {
            
            [MBProgressHUD showErrorMessage:get_Value_for_key_from_obj(json, messageKey)];
            
        }
            break;
        default:
//            [MBProgressHUD showErrorMessage:get_Value_for_key_from_obj(json, messageKey)];
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"msg3", nil)];
            break;
    }
}

#pragma mark - UIViewControllerTransitioningDelegate
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return [[YQPresentTransitionAnimated alloc] init];
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    return [[YQDismissTransitionAnimated alloc] init];
}

- (void)Checktheagreement
{
    NSString *urlStr;
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    if ([appdelegate.language isEqualToString:@"意大利"])
    {
        urlStr = @"http://image.lgtechita.com:8001/LgPortal/eula-user-zh_CN.html";
    }
    else if([appdelegate.language isEqualToString:@"italy"])
    {
        urlStr = @"http://image.lgtechita.com:8001/LgPortal/eula-user-en.html";
    }
    else if ([appdelegate.language isEqualToString:@"italian"])
    {
        urlStr = @"http://image.lgtechita.com:8001/LgPortal/eula-user-it.html";
    }
    AgreementController *agreeVC = [[AgreementController alloc] init];
    agreeVC.type = @"0";
    agreeVC.htmlurl = urlStr;
    agreeVC.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:agreeVC animated:YES completion:nil];
}

- (void)presentloginview
{
    LoginController *lvc = [[LoginController alloc] init];
    lvc.transitioningDelegate = self;
    lvc.modalPresentationStyle = UIModalPresentationFullScreen;
    lvc.isNeedShowBackBtn = YES;
    [self presentViewController:lvc animated:YES completion:nil];
}

@end
