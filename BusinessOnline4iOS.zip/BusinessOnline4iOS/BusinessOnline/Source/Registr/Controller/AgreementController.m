//
//  AgreementController.m
//  BusinessOnline
//
//  Created by clitics on 2020/4/30.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "AgreementController.h"
#import <WebKit/WebKit.h>
//#import "AppDelegate.h"

@interface AgreementController ()

@property (nonatomic,strong)WKWebView *webView;
@property (nonatomic, strong) UIProgressView *myProgressView;

@end

@implementation AgreementController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if ([self.type isEqualToString:@"0"])
    {
        UIView *whiteview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 30)];
        whiteview.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:whiteview];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(20, 30, 30, 30);
        [button setImage:[UIImage imageNamed:@"001_return"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:button];
        
        WKWebViewConfiguration *webConfiguration = [WKWebViewConfiguration new];
        _webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 60, SCREEN_WIDTH, SCREEN_HEIGHT-30) configuration:webConfiguration];
        NSURL *url = [NSURL URLWithString:self.htmlurl];
        NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
        [_webView loadRequest:request];
        
        [self.view addSubview:_webView];
    }
    else
    {
        self.title = self.htmlurl;
        WKWebViewConfiguration *webConfiguration = [WKWebViewConfiguration new];
        _webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-30) configuration:webConfiguration];
        NSURL *url = [NSURL URLWithString:self.htmlurl];
        NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
        [_webView loadRequest:request];
        
        [self.view addSubview:_webView];
    }
    
}

- (void)dismiss
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (UIProgressView *)myProgressView
{
    if (_myProgressView == nil) {
        _myProgressView = [[UIProgressView alloc] initWithFrame:CGRectMake(0, 65, [UIScreen mainScreen].bounds.size.width, 0)];
        _myProgressView.tintColor = [UIColor blueColor];
        _myProgressView.trackTintColor = [UIColor whiteColor];
    }
    
    return _myProgressView;
}

@end
