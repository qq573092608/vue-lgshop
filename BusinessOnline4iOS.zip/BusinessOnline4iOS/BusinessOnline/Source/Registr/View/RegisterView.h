//
//  RegisterView.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RegisterView : UIScrollView

- (void)setArea:(NSString *)area;

@property (nonatomic,copy)void(^registerCallback)(NSString *area, NSString *phoneNumber, NSString *authCode, NSString *password, BOOL isagree);
@property (nonatomic,copy)void(^dismissCallback)(void);
@property (nonatomic,copy)void(^sendAuthCodeCallback)(NSString *phone);
@property (nonatomic,copy)void(^SelectAreaCallback)(void);
@property (nonatomic,copy)void(^agreement)(void);

@end

NS_ASSUME_NONNULL_END
