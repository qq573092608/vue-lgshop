//
//  RegisterView.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "RegisterView.h"

@interface RegisterView ()<UITextFieldDelegate>
{
    NSTimer *_timer;
    NSInteger _timeForAuthBtnActive;
}
@property (nonatomic,strong)UITextField *areaTextfield;
@property (nonatomic,strong)UITextField *phoneNumberTextfield;
@property (nonatomic,strong)UITextField *authCodeTextfield;
@property (nonatomic,strong)UITextField *passwordTextfield;
@property (nonatomic,strong)UIButton *agreementimageview;
@property (nonatomic,strong)UIButton *agreementbutton;
@property (nonatomic,strong)UIButton *registerBtn;
@property (nonatomic,strong)UIButton *passwordSecurityBtn;
@property (nonatomic,strong)UIButton *authCodeBtn;
@property (nonatomic,strong)UIView *whiteview;
@property (nonatomic,assign)BOOL shouldAuthCodeBtnCanChangeBackgroundColor;
@property (nonatomic,assign)BOOL isagree;

@property (nonatomic,strong)UILabel *phoneLbl;

@end
@implementation RegisterView

NSInteger sendAuthCodeTimeSpacing = 5;

-(instancetype)init
{
    if (self = [super init])
    {
        _shouldAuthCodeBtnCanChangeBackgroundColor = YES;
        _timeForAuthBtnActive = sendAuthCodeTimeSpacing;
        _isagree = NO;
        [self setupSubViews];
    }
    return self;
}

-(void)setArea:(NSString *)area
{
    if (!isNSString(area))
    {
        return;
    }
    
    self.phoneLbl.attributedText = [[NSAttributedString alloc] initWithString:area
                                                                   attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],
                                                                                                NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
}

static CGFloat edgSpacing = 20.0f;
static CGFloat viewSpacing = 10.0f;

- (void)setupSubViews
{
    UIView *container = [UIView new];
    container.userInteractionEnabled = YES;
    [self addSubview:container];
    [container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
        make.width.equalTo(self);
    }];
    
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [container addSubview:backBtn];
    [backBtn setImage:[UIImage imageNamed:@"001_return"] forState:UIControlStateNormal];
    [backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(container).offset(edgSpacing);
        make.top.mas_equalTo(container).offset(edgSpacing+STATUSBAR_HEIGHT);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    [backBtn addTarget:self action:@selector(backBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    // 注册图标
    UILabel *titleLabel = [[UILabel alloc] init];
    [container addSubview:titleLabel];
    if (@available(iOS 8.2, *)) {
        titleLabel.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"register", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:20 weight:UIFontWeightBold],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    } else {
        titleLabel.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"register", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:20],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    }
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(backBtn.mas_right).offset(viewSpacing);
        make.right.mas_equalTo(-60);
        make.centerY.mas_equalTo(backBtn.mas_centerY);
        make.height.mas_equalTo(30);
    }];
        
    self.areaTextfield = [[UITextField alloc] init];
//    self.areaTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:localizableString(@"请输入手机号码") attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.areaTextfield.delegate = self;
    self.areaTextfield.textAlignment = NSTextAlignmentRight;
    self.areaTextfield.borderStyle = UITextBorderStyleNone;
    
    UILabel *areaLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 120, 20)];
    areaLabel.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"phonearea", nil)
                                                               attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:18],
                                                                            NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    [areaLabel sizeToFit];
    [self addSubview:areaLabel];
    [areaLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(titleLabel.mas_bottom).offset(40);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
       // make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    UIImage *arrowImg = [UIImage imageNamed:@"registered-icon-go"];
    UIImageView *rightImgV = [[UIImageView alloc] init];
    rightImgV.image = arrowImg;
    [container addSubview:rightImgV];
    [rightImgV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(container.mas_right).offset(-edgSpacing);
        make.centerY.equalTo(areaLabel.mas_centerY);
        make.width.equalTo(@(arrowImg.size.width));
        make.height.equalTo(@(arrowImg.size.height));
    }];
    
    self.phoneLbl = [[UILabel alloc] init];
   // self.phoneLbl.attributedText = [[NSAttributedString alloc] initWithString:@"aa"
   //                                                                attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],
    //                                                                            NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    self.phoneLbl.textAlignment = NSTextAlignmentRight;
    [container addSubview:self.phoneLbl];
    [self.phoneLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(rightImgV.mas_left).offset(-5);
        make.centerY.equalTo(areaLabel.mas_centerY);
        make.height.mas_equalTo(40);
    }];
    
    UIButton *cleanBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    cleanBtn.backgroundColor = [UIColor clearColor];
    [container addSubview:cleanBtn];
    [cleanBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(titleLabel.mas_bottom).offset(40);
        make.left.equalTo(areaLabel.mas_left);
        make.right.equalTo(rightImgV.mas_right);
        make.height.mas_equalTo(40);
    }];
    [cleanBtn addTarget:self
                 action:@selector(areaBtnClicked)
       forControlEvents:UIControlEventTouchUpInside];
    
//    self.areaTextfield.leftView = areaLabel;
//    self.areaTextfield.leftViewMode = UITextFieldViewModeAlways;
//    UIButton *areaBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    areaBtn.frame = CGRectMake(0, 0, 30, 30);
//    [areaBtn setImage:[UIImage imageNamed:@"registered-icon-go"] forState:UIControlStateNormal];
//    [areaBtn addTarget:self action:@selector(areaBtnClicked) forControlEvents:UIControlEventTouchUpInside];
////    areaBtn.backgroundColor = [UIColor redColor];
//    self.areaTextfield.rightView = areaBtn;
//    self.areaTextfield.rightViewMode = UITextFieldViewModeAlways;
//    [container addSubview:self.areaTextfield];
//    [self.areaTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.mas_equalTo(titleLabel.mas_bottom).offset(40);
//        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
//        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
//        make.height.mas_equalTo(40);
//    }];
    
    UIView *line1 = [UIView new];
    [container addSubview:line1];
    line1.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(areaLabel.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    
    self.phoneNumberTextfield = [[UITextField alloc] init];
    self.phoneNumberTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"hint3", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.phoneNumberTextfield.borderStyle = UITextBorderStyleNone;
//    self.phoneNumberTextfield.delegate = self;
    self.phoneNumberTextfield.returnKeyType = UIReturnKeyNext;
    self.phoneNumberTextfield.keyboardType = UIKeyboardTypeNumberPad;
    UIImageView *phoneNumberImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"registered-icon-phone"]];
    phoneNumberImageView.frame = CGRectMake(0, 3, 20, 20);
    UIView *phonenumberView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [phonenumberView addSubview:phoneNumberImageView];
    self.phoneNumberTextfield.leftView = phonenumberView;
//    self.phoneNumberTextfield.leftView.frame = CGRectMake(0, 0, 20, 30);
    self.phoneNumberTextfield.leftViewMode = UITextFieldViewModeAlways;
    self.phoneNumberTextfield.clearButtonMode = UITextFieldViewModeWhileEditing;
    [container addSubview:self.phoneNumberTextfield];
    [self.phoneNumberTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(line1.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    UIView *line2 = [UIView new];
    [container addSubview:line2];
    line2.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.phoneNumberTextfield.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    
    self.authCodeTextfield = [[UITextField alloc] init];
    self.authCodeTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"hint4", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.authCodeTextfield.borderStyle = UITextBorderStyleNone;
    self.authCodeTextfield.keyboardType = UIKeyboardTypeNumberPad;
//    self.authCodeTextfield.delegate = self;
    self.authCodeTextfield.returnKeyType = UIReturnKeyNext;
    UIImageView *authImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"registered-icon-check"]];
    authImageView.frame = CGRectMake(0, 3, 20, 20);
    UIView *authView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [authView addSubview:authImageView];
    self.authCodeTextfield.leftView = authView;
    self.authCodeTextfield.leftViewMode = UITextFieldViewModeAlways;
    self.authCodeTextfield.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.authCodeTextfield.borderStyle = UITextBorderStyleNone;
    self.authCodeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.authCodeBtn.frame = CGRectMake(0, 0, 100, 40);
//    self.authCodeBtn.layer.cornerRadius = 5.0f;
//    self.authCodeBtn.layer.masksToBounds = YES;
    [self.authCodeBtn addTarget:self action:@selector(authCodeBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.authCodeBtn.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [self.authCodeBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"getcode", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}] forState:UIControlStateNormal];
    self.whiteview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 100, 40)];
    self.whiteview.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    self.whiteview.layer.cornerRadius = 5;
    self.whiteview.layer.masksToBounds = YES;
    [self.whiteview addSubview:self.authCodeBtn];
    self.authCodeTextfield.rightView = self.whiteview;
    self.authCodeTextfield.rightViewMode = UITextFieldViewModeAlways;
    [container addSubview:self.authCodeTextfield];
    [self.authCodeTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(line2.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    UIView *line3 = [UIView new];
    [container addSubview:line3];
    line3.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.authCodeTextfield.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    
    self.passwordTextfield = [[UITextField alloc] init];
    self.passwordTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"hint5", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.passwordTextfield.borderStyle = UITextBorderStyleNone;
//    self.passwordTextfield.delegate = self;
    self.passwordTextfield.returnKeyType = UIReturnKeyDone;
    self.passwordTextfield.secureTextEntry = YES;
    UIImageView *passwordImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"registered-icon-password"]];
    passwordImageView.frame = CGRectMake(0, 3, 20, 20);
    UIView *passwordview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [passwordview addSubview:passwordImageView];
    self.passwordTextfield.leftView = passwordview;
    self.passwordTextfield.leftViewMode = UITextFieldViewModeAlways;
    self.passwordTextfield.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.passwordSecurityBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.passwordSecurityBtn.frame = CGRectMake(0, 0, 30, 30);
    [self.passwordSecurityBtn addTarget:self action:@selector(securityBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.passwordSecurityBtn setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    self.passwordTextfield.rightView = self.passwordSecurityBtn;
    self.passwordTextfield.rightViewMode = UITextFieldViewModeAlways;
    [container addSubview:self.passwordTextfield];
    [self.passwordTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(line3.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    UIView *line4 = [UIView new];
    [container addSubview:line4];
    line4.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line4 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.passwordTextfield.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    //协议
    self.agreementimageview = [[UIButton alloc] init];;
    [container addSubview:self.agreementimageview];
    [self.agreementimageview setImage:[UIImage imageNamed:@"register_select"] forState:UIControlStateNormal];
    [self.agreementimageview addTarget:self action:@selector(Agreeagreement) forControlEvents:UIControlEventTouchUpInside];
    [self.agreementimageview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(line4.mas_bottom).offset(20);
        make.left.mas_equalTo(container.mas_left).offset(20);
        make.width.mas_equalTo(20);
        make.height.mas_equalTo(20);
    }];
    
    self.agreementbutton = [[UIButton alloc] init];
    [container addSubview:self.agreementbutton];
    [self.agreementbutton setTitle:NSLocalizedString(@"《用户注册使用协议》", nil) forState:UIControlStateNormal];
    [self.agreementbutton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [self.agreementbutton addTarget:self action:@selector(Checktheagreement) forControlEvents:UIControlEventTouchUpInside];
    self.agreementbutton.titleLabel.font = [UIFont systemFontOfSize:16];
//    self.agreementbutton.backgroundColor = [UIColor redColor];
    self.agreementbutton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self.agreementbutton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(line4.mas_bottom).offset(20);
        make.left.mas_equalTo(self.agreementimageview.mas_right).offset(0);
        make.width.mas_equalTo(300);
        make.height.mas_equalTo(20);
    }];
    
    self.registerBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.registerBtn.backgroundColor = UIColorFromRGB(colorLoginNotEnable);
    [self.registerBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"regist", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite),NSFontAttributeName:[UIFont systemFontOfSize:17]}] forState:UIControlStateNormal];
    self.registerBtn.layer.cornerRadius = 5.0;
    self.registerBtn.layer.masksToBounds = YES;
    [self.registerBtn addTarget:self action:@selector(registerBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:self.registerBtn];
    [self.registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.agreementimageview.mas_bottom).offset(20);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(50);
    }];
    
    UILabel *tipLabel = [[UILabel alloc] init];
    [container addSubview:tipLabel];
    tipLabel.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"register_msg", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13],NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)}];
    [tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.registerBtn.mas_bottom).offset(20);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(15);
        make.bottom.mas_equalTo(container.mas_bottom).offset(-10);
    }];
    
    [[self.phoneNumberTextfield.rac_textSignal
      map:^id(NSString *text) {
          return @([self isValidString:text]);
      }] subscribeNext:^(NSNumber *valid) {
          
          if (self.shouldAuthCodeBtnCanChangeBackgroundColor)
          {
              self.authCodeBtn.enabled = valid.boolValue;
              if (valid.boolValue)
              {
                  self.authCodeBtn.backgroundColor = MainColor;
              }
              else
              {
                  self.authCodeBtn.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
              }
          }
      }];
    
    RACSignal *validPhoneNumberSignal = [self.phoneNumberTextfield.rac_textSignal
                                         map:^id(NSString *text) {
                                             return @([self isValidString:text]);
                                         }];
    RACSignal *validAuthCodeSignal = [self.authCodeTextfield.rac_textSignal
                                      map:^id(NSString *text) {
                                          return @([self isValidString:text]);
                                      }];
    RACSignal *validPasswordSignal = [self.passwordTextfield.rac_textSignal
                                      map:^id(NSString *text) {
                                          return @([self isValidString:text]);
                                      }];
    
    RACSignal *signUpActiveSignal = [RACSignal combineLatest:@[validPhoneNumberSignal, validAuthCodeSignal,validPasswordSignal]
                                                      reduce:^id(NSNumber *phoneNumberValid, NSNumber *authCodeValid, NSNumber *passwordValid){
                                                          return @(phoneNumberValid.boolValue && authCodeValid.boolValue && passwordValid.boolValue);
                                                      }];
    
    [signUpActiveSignal subscribeNext:^(NSNumber *signupActive) {
        self.registerBtn.enabled = signupActive.boolValue;
        if (self.registerBtn.enabled)
        {
            self.registerBtn.backgroundColor = MainColor;
        }
        else
        {
            self.registerBtn.backgroundColor = UIColorFromRGB(colorLoginNotEnable);
        }
    }];
//    self.areaTextfield.text = @"xxxxxx";
}

- (void)backBtnClicked
{
    [self endEditing:YES];
    if (self.dismissCallback)
    {
        self.dismissCallback();
    }
}

- (void)areaBtnClicked
{
//    [self endEditing:YES];
    if (self.SelectAreaCallback)
    {
        self.SelectAreaCallback();
    }
}

- (void)authCodeBtnClicked
{
    if ([self.phoneLbl.text isEqualToString:@""]) {
        
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"请选择归属地", nil)];
        
        return;
        
    }
    
    if (self.sendAuthCodeCallback)
    {
        self.sendAuthCodeCallback(self.phoneNumberTextfield.text);
    }
    self.shouldAuthCodeBtnCanChangeBackgroundColor = NO;
    self.authCodeBtn.enabled = NO;
    self.authCodeBtn.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    self.whiteview.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [self.authCodeBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@(%lu)",NSLocalizedString(@"getcode2", nil),(long)_timeForAuthBtnActive] attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}] forState:UIControlStateNormal];
    
    _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerAction) userInfo:nil repeats:YES];
    [_timer fire];
}

- (void)timerAction
{
    _timeForAuthBtnActive--;
    if (_timeForAuthBtnActive > 0)
    {
        [self.authCodeBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@(%lu)",NSLocalizedString(@"getcode2", nil),(long)_timeForAuthBtnActive] attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}] forState:UIControlStateNormal];
    }
    else
    {
        [_timer invalidate];
        self.authCodeBtn.enabled = YES;
        self.shouldAuthCodeBtnCanChangeBackgroundColor = YES;
        _timeForAuthBtnActive = sendAuthCodeTimeSpacing;
        if ([self isValidString:self.phoneNumberTextfield.text])
        {
            self.authCodeBtn.backgroundColor = MainColor;
            self.whiteview.backgroundColor = MainColor;
        }
        else
        {
            self.authCodeBtn.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
            self.whiteview.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
        }
        
        [self.authCodeBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"getcode", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}] forState:UIControlStateNormal];
    }
}

- (void)securityBtnClicked
{
    self.passwordTextfield.secureTextEntry = !self.passwordTextfield.secureTextEntry;
    if (self.passwordTextfield.secureTextEntry)
    {
        [self.passwordSecurityBtn setImage:[UIImage imageNamed:@"008_turnon"] forState:UIControlStateNormal];
    }
    else
    {
        [self.passwordSecurityBtn setImage:[UIImage imageNamed:@"008_turnon"] forState:UIControlStateNormal];
    }
}

- (void)registerBtnClicked
{
    [self endEditing:YES];
    if (self.registerCallback)
    {
        self.registerCallback(self.phoneLbl.text, self.phoneNumberTextfield.text, self.authCodeTextfield.text, self.passwordTextfield.text, _isagree);
    }
}


- (BOOL)isValidString:(NSString *)string
{
    return string.length > 0;
}

#pragma mark delegate methods
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField == self.areaTextfield && textField.isFirstResponder)
    {
        [self.phoneNumberTextfield resignFirstResponder];
        [self areaBtnClicked];
        return NO;
    } else if(textField == self.areaTextfield){
        return NO;
    }
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    if (textField == self.phoneNumberTextfield)
    {
        [self.authCodeTextfield becomeFirstResponder];
    }
    else if (textField == self.authCodeTextfield)
    {
        [self.passwordTextfield becomeFirstResponder];
    }
    else if (textField == self.passwordTextfield)
    {
        [self endEditing:YES];
    }
    return YES;
}

- (void)Agreeagreement
{
    _isagree = !_isagree;
    if (_isagree)
    {
        [self.agreementimageview setImage:[UIImage imageNamed:@"isselect"] forState:UIControlStateNormal];
    }
    else
    {
        [self.agreementimageview setImage:[UIImage imageNamed:@"register_select"] forState:UIControlStateNormal];
    }
}

- (void)Checktheagreement
{
    if (self.agreement)
    {
        self.agreement();
    }
}

//-(void)textFieldDidBeginEditing:(UITextField *)textField
//{
//    [self areaBtnClicked];
//}

@end
