//
//  ProductTypeModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/1.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProductTypeModel : NSObject

@property (nonatomic,copy)NSString *id;
@property (nonatomic,copy)NSString *code;
@property (nonatomic,copy)NSString *parent_id;
@property (nonatomic,copy)NSString *parent_code;
//注意
@property (nonatomic,copy)NSString *name;

@property (nonatomic,copy)NSString *note;
@property (nonatomic,copy)NSString *children;
@property (nonatomic,copy)NSString *syncCode;

@property (nonatomic,copy)NSString *path;
@property (nonatomic,copy)NSString *downFlag;

@end

NS_ASSUME_NONNULL_END
