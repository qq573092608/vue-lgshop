//
//  ProductTypeModel.m
//  BusinessOnline
//
//  Created by clitics on 2019/3/1.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "ProductTypeModel.h"

@implementation ProductTypeModel

@end
