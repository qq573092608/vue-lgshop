//
//  AdModel.h
//  BusinessOnline
//
//  Created by clitics on 2020/5/13.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AdModel : NSObject

@property (nonatomic,copy)NSString *advertisingPath;
@property (nonatomic,copy)NSString *advertisingDetailsPath;

@end

NS_ASSUME_NONNULL_END
