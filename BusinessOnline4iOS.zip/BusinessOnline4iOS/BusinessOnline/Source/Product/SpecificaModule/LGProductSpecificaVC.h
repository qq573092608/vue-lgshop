//
//  LGProductSpecificaVC.h
//  BusinessOnline
//
//  Created by lgerp on 2020/11/30.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ProductModel;

NS_ASSUME_NONNULL_BEGIN

typedef void(^LGSpecificaCallBack)(NSString * singlePrice, NSString *specificaStr, NSString *totalPriceStr);

/** 使用产品的模型来初始化对象 */
@interface LGProductSpecificaVC : UIViewController


@property (nonatomic, copy)LGSpecificaCallBack specificaCallBack;

///  初始化配置数据源
/// @param productModel 产品模型
/// @param isDefault 是否是默认选中的内容
/// @param modifyType 是否是默认选中的内容(是否从购物车跳转而来,从购物车来则只能修改不能新增，从其他页面来则只可以新增)
- (instancetype)initWithProductModel:(ProductModel *)productModel
                           isDefault:(BOOL)isDefault
                    specificaModifyType:(SpecificaModifyType)modifyType;

@end

NS_ASSUME_NONNULL_END
