//
//  LGProductSpecificaVC.m
//  BusinessOnline
//
//  Created by lgerp on 2020/11/30.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGProductSpecificaVC.h"
#import <STPopup/STPopup.h>
#import "LGSpecificaHeadView.h"
#import "LGSpecificaContentView.h"
#import "LGSpecifacaBottomView.h"

@interface LGProductSpecificaVC ()
{
    // 产品模型
    ProductModel * _productModel;
    // 是否展示默认
    BOOL _isDefaultShow;
    /**
        多规格修改类型
     */
    SpecificaModifyType _specificaModifyType;
}

@property (nonatomic, strong) LGSpecificaHeadView *headView;

@property (nonatomic, strong) LGSpecificaContentView *contentCollView;

@property (nonatomic, strong) LGSpecifacaBottomView *bottomView;

@end

@implementation LGProductSpecificaVC

- (instancetype)initWithProductModel:(ProductModel *)productModel
                           isDefault:(BOOL)isDefault
                 specificaModifyType:(SpecificaModifyType)modifyType
{
    self = [super init];
    if (self) {
        _productModel = productModel;
        _isDefaultShow = isDefault;
        _specificaModifyType = modifyType;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 设置视图
    [self setUpView];
}

- (void)setUpView
{
    self.contentSizeInPopup = CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT - 120);
    self.popupController.navigationBarHidden = YES;
    [self.view addSubview:self.headView];
    // 必须配置其相对父视图的布局
    [self.headView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.equalTo(self.view);
        make.height.mas_equalTo(144.0f);
    }];
    
    WEAK_SELF(weakSelf);
    self.headView.closeBtnClickBlock = ^{
        [weakSelf.popupController dismiss];
    };
    // 配置头部的数据源
    [self.headView configHeadViewWithProductModel:_productModel navigation:self];
    
    [self.view addSubview:self.bottomView];
    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(self.view);
        make.height.mas_equalTo(@155);
    }];
    
    self.bottomView.closeBtnCallBack = ^(NSString * singlePrice, NSString * specDes, NSString * totalPriceStr) {
        if (weakSelf.specificaCallBack) {
            weakSelf.specificaCallBack(singlePrice, specDes, totalPriceStr);
        }
        [weakSelf.popupController dismiss];
    };
    // 配置底部的数据源
    [self.bottomView configBottomViewWithProductModel:_productModel
                                        specificaType:_specificaModifyType];
    
    // 配置中间数据源
    [self.view addSubview:self.contentCollView];
    [self.contentCollView configDataSource:_productModel isDefaultShow:_isDefaultShow];
    [self.contentCollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.headView.mas_bottom).offset(16.0f);
        make.left.right.mas_equalTo(self.view);
        make.bottom.mas_equalTo(self.bottomView.mas_top);
    }];
}

#pragma mark - 懒加载
- (LGSpecificaHeadView *)headView {
    if (!_headView) {
        _headView = [[[NSBundle mainBundle] loadNibNamed:@"LGSpecificaHeadView"
                                                            owner:self
                                                          options:nil]
                              lastObject];
    }
    return _headView;
}


- (LGSpecificaContentView *)contentCollView {
    if (!_contentCollView) {
        _contentCollView = [[LGSpecificaContentView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 224)];
    }
    return _contentCollView;
}

// bottomView
- (LGSpecifacaBottomView *)bottomView {
    if (!_bottomView) {
        _bottomView = [[LGSpecifacaBottomView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 154.5)];
    }
    return _bottomView;
}
@end
