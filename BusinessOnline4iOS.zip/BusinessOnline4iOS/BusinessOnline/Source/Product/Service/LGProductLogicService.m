//
//  LGProductLogicService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/12/18.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGProductLogicService.h"
#import "ProductTypeModel.h"
#import "ProductModel.h"

@implementation LGProductLogicService

+ (void)saveAllType2Local:(NSArray *)array
{
    if (array.count == 0) {
        return;
    }
    
    NSMutableArray *typeArr = [[NSMutableArray alloc] init];
    for (ProductTypeModel *productModel in array) {
        [typeArr addObject:productModel.id];
    }
    [[NSUserDefaults standardUserDefaults] setValue:typeArr forKey:kAllTypesCollection];
}


+ (NSMutableArray *)getFinalProductListWithOutExplain:(NSArray *)sourceProductList
{
    if (sourceProductList.count == 0) {
        return [[NSMutableArray alloc] init];
    }
    
    NSMutableArray *finalArr = [[NSMutableArray alloc] init];
    for (ProductModel *productModel in sourceProductList) {
        if ([productModel.note containsString:@"explain"]) {
            continue;
        }
        [finalArr addObject:productModel];
    }
    return finalArr;
}


@end
