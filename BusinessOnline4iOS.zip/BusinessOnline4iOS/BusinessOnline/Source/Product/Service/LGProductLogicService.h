//
//  LGProductLogicService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/12/18.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
     产品的逻辑处理类
 */
@interface LGProductLogicService : NSObject

///   将所有的分类标题存储到本地
/// @param array 分类信息列表
+ (void)saveAllType2Local:(NSArray *)array;


/// 过滤掉备注字段里有“explain”的产品
/// @param sourceProductList 原始的数组
+ (NSMutableArray *)getFinalProductListWithOutExplain:(NSArray *)sourceProductList;

@end

NS_ASSUME_NONNULL_END
