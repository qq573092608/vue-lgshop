//
//  ScanController.m
//  BusinessOnline
//
//  Created by clitics on 2019/3/19.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "ScanController.h"

@interface ScanController ()

@end

@implementation ScanController

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.scanningView addTimer];
    [self.manager startRunning];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.scanningView removeTimer];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = NSLocalizedString(@"scanner", nil);
    
}

#pragma mark SGQRCodeScanManagerDelegate
- (void)QRCodeScanManager:(SGQRCodeScanManager *)scanManager didOutputMetadataObjects:(NSArray *)metadataObjects {
    
    if (metadataObjects != nil && metadataObjects.count > 0)
    {
        [scanManager stopRunning];
        
        AVMetadataMachineReadableCodeObject *obj = metadataObjects[0];
        
        if (obj.stringValue)
        {
            if (self.callback)
            {
                [self.navigationController popViewControllerAnimated:NO];
                self.callback(obj.stringValue);
            }
        }
        else
        {
            [scanManager startRunning];
        }
    }
    else
    {   
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"unidentification", nil)];
    }
}


@end
