//
//  ScanController.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/19.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "STDataCollectionController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ScanController : STDataCollectionController

@property (nonatomic,copy)void(^callback)(NSString *text);

@end

NS_ASSUME_NONNULL_END
