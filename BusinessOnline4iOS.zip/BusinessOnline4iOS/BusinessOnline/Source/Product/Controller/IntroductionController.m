//
//  IntroductionController.m
//  BusinessOnline
//
//  Created by clitics on 2020/5/4.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "IntroductionController.h"
#import <WebKit/WebKit.h>

@interface IntroductionController ()

@property (nonatomic,strong)WKWebView *WKwebView;

@end

@implementation IntroductionController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Languang Software";
    
    WKWebViewConfiguration *webConfiguration = [WKWebViewConfiguration new];
    _WKwebView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT) configuration:webConfiguration];
    NSURL *url = [NSURL URLWithString:self.url];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [_WKwebView loadRequest:request];
    
    [self.view addSubview:_WKwebView];
}



@end
