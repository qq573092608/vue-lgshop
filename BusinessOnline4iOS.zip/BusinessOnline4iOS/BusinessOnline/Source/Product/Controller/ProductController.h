//
//  ProductController.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "BaseViewController.h"
#import "SelectSpecificationsView.h"
#import "TypeView.h"

NS_ASSUME_NONNULL_BEGIN

@interface ProductController : BaseViewController

@property(nonatomic,strong)DWQSelectView *selectView;
@property(nonatomic,strong)DWQSelectAttributes *selectAttributes;
@property(nonatomic,strong)SelectSpecificationsView *selectspecificationview;
@property (nonatomic,strong)TypeView *typeview;

@property(nonatomic,strong)NSMutableArray *attributesArray;

@end

NS_ASSUME_NONNULL_END
