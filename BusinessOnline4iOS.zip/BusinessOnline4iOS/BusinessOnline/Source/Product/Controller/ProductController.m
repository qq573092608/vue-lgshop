//
//  ProductController.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "ProductController.h"
//#import "ProductTypeCell.h"
#import "ShufflingViewCell.h"
#import "ProductCell.h"
#import "PAddMerchantView.h"
#import "ProductTypeModel.h"
// #import "OLatestOrderController.h"
#import "PTypeProductController.h"
#import "ProductDetailController.h"
#import "ProductModel.h"
#import "SearchController.h"
#import "BaseNavigationController.h"
#import "ScanController.h"
#import "HomeController.h"
#import <SDWebImage/UIButton+WebCache.h>
#import "ClassViewController.h"
#import "TasteListModel.h"
#import "ChildrenModel.h"
#import "CacheProductModel.h"
#import "CacheModel.h"
#import "AppDelegate.h"
#import "AgreementController.h"
#import "PromptView.h"
#import "LoginController.h"
#import "AdModel.h"

#import "LgProductService.h"
#import "BaseService.h"
#import "LGProductNetWorkService.h"
#import "LgResultModel.h"
#import "STPopup.h"

#import "LGProductSpecificaVC.h"
#import "LGProductLogicService.h"
#import "LGMineNetWorkService.h"

@interface ProductController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,SelectAttributesDelegate,UITabBarControllerDelegate>
{
    int _quantity;
    ProductModel *_model;
    CacheProductModel *productModel;
    BOOL _ishidden;
}
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *dataSource;
@property (nonatomic,strong)NSMutableArray *modeldata;
@property (nonatomic,strong)NSMutableArray *imageurls;
@property (nonatomic,strong)NSMutableArray *httpurls;
@property (nonatomic,assign)ProductCellType type;
@property (nonatomic,copy)NSString *classid;
@property (nonatomic,copy)NSString *classname;

@property (nonatomic,strong)UIView *shoptypeview;
@property (nonatomic,strong)UIView *alphaview;
@property (nonatomic,strong)UIView *whiteview;

@property (nonatomic,strong)UIButton *newbutton;
@property (nonatomic,strong)UIButton *recommendBtn;
@property (nonatomic,strong)UIButton *lareBtn;

@property(nonatomic,strong)UIView *backgroundView;
@property(nonatomic,strong)NSMutableArray *standardList;
@property(nonatomic,strong)NSMutableArray *standardValueList;
@property (nonatomic,strong)NSMutableArray *specificationdata;
@property (nonatomic,strong)NSMutableArray *infolistiddata;
@property (nonatomic,assign)int goodsnumber;
@property (nonatomic,strong)AFNetworkReachabilityManager *mgr;

@property (nonatomic, strong) LgProductService *productService;

@property (nonatomic, strong) BaseService *baseService;


@end

@implementation ProductController

-(void)viewDidLoad
{
    [super viewDidLoad];
    _ishidden = NO;
    _type = ProductCellTypeNormal;
    _dataSource = [NSMutableArray arrayWithCapacity:5];
    _imageurls = [NSMutableArray array];
    _httpurls = [NSMutableArray array];
    _modeldata = [NSMutableArray array];
    self.productService = [[LgProductService alloc] init];
    
    NSArray *imagearray = @[
                            @"http://image.lgtechita.com:8001/LgPortal/banner1.png",
                            @"http://image.lgtechita.com:8001/LgPortal/banner2.png",
                            @"http://image.lgtechita.com:8001/LgPortal/banner3.png"
    ];
    
    for (int i=0; i<imagearray.count; i++)
    {
        AdModel *model = [[AdModel alloc] init];
        model.advertisingPath = imagearray[i];
        if (i==0) {
            model.advertisingDetailsPath = @"http://image.lgtechita.com:8001/LgPortal/advertising.png";
        } else {
            model.advertisingDetailsPath = @"http://www.lgtechita.com/";
        }
        [_modeldata addObject:model];
    }
    
    _imageurls = [imagearray mutableCopy];
    _standardList = [NSMutableArray array];
    _standardValueList = [NSMutableArray array];
    _specificationdata = [NSMutableArray array];
    _infolistiddata = [NSMutableArray array];
    _quantity = 0;
    self.tabBarController.delegate = self;
    [self setupSubViews];
//    [self doNetworkRequestForType];
//    [self getimageurlsnetwork];
    
    NSString *firstopen = [[NSUserDefaults standardUserDefaults] objectForKey:@"firstopen"];
    
    if (firstopen.boolValue)
    {
        [self doNetworkRequestForType];
        [self getimageurlsnetwork];
    } else {
        WEAK_SELF(weakeSelf);
        _mgr = [AFNetworkReachabilityManager sharedManager];
        [_mgr setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
            
            switch (status) {
                case AFNetworkReachabilityStatusNotReachable:
                    break;
                default:
                {
                    [weakeSelf getimageurlsnetwork];
                    [weakeSelf doNetworkRequestForType];
                }
                    break;
            }
        }];

        [_mgr startMonitoring];
        [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"firstopen"];
    }
    
    WEAK_SELF(weakeSelf);
    // 刷新状态(是否显示分类图标以及商品是单排显示还是双排显示)
    [_productService queryMerchantInfoSuccess:^(id  _Nonnull json) {
        [weakeSelf creatTableView];
    } failure:^(NSError * _Nonnull error) {
        [weakeSelf creatTableView];
    }];    
}



-(void)didReceivedProductNotification:(NSNotification *)notification
{
    ProductModel *model = notification.userInfo[kProductNotificationKey];
    ProductDetailController *pvc = [[ProductDetailController alloc] initWithText:model.goods_code
                                                                  invitationCode:@""
                                                                       indexPath:nil
                                                                    productModel:model
                                                               cacheProductModel:nil
                                                                isFromShoppingVC:NO
                                    ];
    [self.navigationController pushViewController:pvc animated:YES];
}

- (void)didreloadproductclass:(NSNotification *)notification
{
//    _classid = notification.userInfo[kProductclassidNotificationKey];
    
    ProductTypeModel *model = notification.userInfo[kProductclassidNotificationKey];
    
    if (model) {
        if ([model.downFlag isEqualToString:@"1"]) {
            ClassViewController *classVC = [[ClassViewController alloc] init];
            classVC.classID = model.id;
            classVC.title = model.name;
            [self.navigationController pushViewController:classVC animated:YES];
        }
    } else {
        ClassViewController *classVC = [[ClassViewController alloc] init];
        classVC.classID = @"";
        classVC.title = NSLocalizedString(@"分类", nil);
        [self.navigationController pushViewController:classVC animated:YES];
    }
}

- (void)didaddspecifications:(NSNotification *)notification
{
    [_standardList removeAllObjects];
    [_standardValueList removeAllObjects];
    [_specificationdata removeAllObjects];
    [_infolistiddata removeAllObjects];
    ProductModel *model = notification.userInfo[kProductspecificationsNotificationKey];
    CacheModel *cacheModel = [CacheModel shared];
    if (isNSString(model.goods_code)) {
        productModel = [cacheModel modelForKey:model.goods_code];
    }
    
    _quantity = productModel.count.intValue;

    NSDictionary *dic = model.mj_keyValues;
    NSArray *array = dic[@"tasteList"];
    for (NSDictionary *dic in array) {
        [self.standardList addObject:dic[@"zhName"]];
        NSArray *dicname = dic[@"children"];
        if (dicname.count)
        {
            NSMutableArray *namearray = [NSMutableArray array];
            for (NSDictionary *diclist in dicname) {
                ChildrenModel *model = [ChildrenModel mj_objectWithKeyValues:diclist];
                [namearray addObject:model];
            }
            [self.standardValueList addObject:namearray];
        }
    }
    NSLog(@"standlistvalue=%@",self.standardValueList);
    [self initSelectView:model];
}

-(void)initSelectView:(ProductModel *)model{
    LGProductSpecificaVC *specificaVa = [[LGProductSpecificaVC alloc] initWithProductModel:model
                                                                                 isDefault:NO
                                                                       specificaModifyType:kSpecificaModifyTypeADD];
    STPopupController *popVericodeController = [[STPopupController alloc] initWithRootViewController:specificaVa];
    popVericodeController.style = STPopupStyleBottomSheet;
    popVericodeController.hidesCloseButton = YES;
    [popVericodeController presentInViewController:self];
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)setupSubViews
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 35, 35);
    
    //马甲包改动
    NSString *btnImgNameStr = [self.baseService getHomeBtnImgNameByAPPTYPE:APPTYPE];
     [button setBackgroundImage:[UIImage imageNamed:btnImgNameStr]
                       forState:UIControlStateNormal];
    
    WEAK_SELF(weakeSelf);
    [button sd_setBackgroundImageWithURL:[[NSUserDefaults standardUserDefaults] objectForKey:kMerchantLogoUrl]
                                forState:UIControlStateNormal
                               completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        if (image) {
            image = [BaseService image:image scaleToSize:CGSizeMake(30, 30)];
            [button setBackgroundImage:image forState:UIControlStateNormal];
        } else {   //马甲包改动
            NSString *bgImgName = [weakeSelf.baseService getHomeBtnImgNameByAPPTYPE:APPTYPE];
            [button setBackgroundImage:[UIImage imageNamed:bgImgName] forState:UIControlStateNormal];            
        }
    }];
    [button addTarget:self action:@selector(clickimage) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = backItem;
    
    [self addTitleItem];
    
    UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    addBtn.frame = CGRectMake(0, 0, 30, 30);
//    addBtn.backgroundColor = MainColor;
    [addBtn setBackgroundImage:[UIImage imageNamed:@"014_g"] forState:UIControlStateNormal];
    [addBtn addTarget:self
               action:@selector(addBtnClicked)
     forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:addBtn];
    self.navigationItem.rightBarButtonItem = rightItem;
}

- (void)creatTableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(self.view);
        }];
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
        self.refresh = [[QPGRefreshTool alloc] init];
        WEAK_SELF(weakSelf);
        [self.refresh gifModelRefresh:self.tableView refreshType:RefreshTypeDropDown firstRefresh:NO dropDownBlock:^{
            if ([weakSelf.tableView.mj_header isRefreshing]) {
                [weakSelf doNetworkRequestForType];
            }
        } upDropBlock:nil];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
}

- (void)addTitleItem
{
    UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH-70, 30)];
    textField.delegate = self;
    textField.backgroundColor = MainBackgroundColor;
    textField.textAlignment = NSTextAlignmentLeft;
    textField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"searchTxt", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:12]}];
    textField.textColor = [UIColor whiteColor];
    textField.font = [UIFont systemFontOfSize:14];
    UIView *searchview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 40, 20)];
    UIImageView *pwLeftImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"home-btn-search"]];
    pwLeftImageView.frame = CGRectMake(10, 0, 20, 20);
    [searchview addSubview:pwLeftImageView];
    textField.leftView = searchview;
    textField.leftViewMode=UITextFieldViewModeAlways;
    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    textField.layer.borderColor = UIColorFromRGB(0xffffff).CGColor;
    textField.layer.borderWidth = 0.5;
    textField.layer.cornerRadius = 5;
    textField.layer.masksToBounds = YES;
    self.navigationItem.titleView = textField;
}

#pragma mark textfield delegate methods
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self performSelector:@selector(search) withObject:nil afterDelay:0.1];
    return NO;
}

- (void)search
{
    [self.navigationController pushViewController:[SearchController new] animated:NO];
}
//点击首页图标
- (void)clickimage
{
//    self.typeview = [[TypeView alloc] init];
//    [[UIApplication sharedApplication].keyWindow addSubview:self.typeview];
//
//
//    [self.typeview.newbutton addTarget:self action:@selector(pushview:) forControlEvents:UIControlEventTouchUpInside];
//
//    self.typeview.userInteractionEnabled = YES;
//    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(removeview)];
//    [self.typeview addGestureRecognizer:tap];
    
    self.shoptypeview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    [[UIApplication sharedApplication].keyWindow addSubview:self.shoptypeview];
    self.alphaview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    self.alphaview.backgroundColor = [UIColor blackColor];
    self.alphaview.alpha = 0.3;
    [self.shoptypeview addSubview:self.alphaview];

    CGFloat Btnwidth;
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    if ([appdelegate.language isEqualToString:@"意大利"]) {
        Btnwidth = 100.0;
    } else {
        Btnwidth = 180.0;
    }

    self.whiteview = [[UIView alloc] initWithFrame:CGRectMake(0, NAVIGATIONBAR_HIGHT+STATUSBAR_HEIGHT, Btnwidth, 150)];
    self.whiteview.backgroundColor = [UIColor whiteColor];
    [self.shoptypeview addSubview:self.whiteview];

    _newbutton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, Btnwidth, 50)];
    [_newbutton setTitle:NSLocalizedString(@"product_new", nil) forState:UIControlStateNormal];
    [_newbutton setTitleColor:UIColorFromRGB(colorTextBlack) forState:UIControlStateNormal];
    [_newbutton addTarget:self action:@selector(pushnewview) forControlEvents:UIControlEventTouchUpInside];
    [_newbutton setImage:[UIImage imageNamed:@"home-icon-new"] forState:UIControlStateNormal];
    [_newbutton setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -5)];
    [_newbutton setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 5)];
    [self.whiteview addSubview:_newbutton];

    _recommendBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 50, Btnwidth, 50)];
    [_recommendBtn setTitle:NSLocalizedString(@"product_recommend", nil) forState:UIControlStateNormal];
    [_recommendBtn setTitleColor:UIColorFromRGB(colorTextBlack) forState:UIControlStateNormal];
    [_recommendBtn addTarget:self action:@selector(pushrecommendview) forControlEvents:UIControlEventTouchUpInside];
    [_recommendBtn setImage:[UIImage imageNamed:@"home-icon-recommend"] forState:UIControlStateNormal];
    [_recommendBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -5)];
    [_recommendBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 5)];
    [self.whiteview addSubview:_recommendBtn];

    _lareBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 100, Btnwidth, 50)];
    [_lareBtn setTitle:NSLocalizedString(@"product_sale", nil) forState:UIControlStateNormal];
    [_lareBtn setTitleColor:UIColorFromRGB(colorTextBlack) forState:UIControlStateNormal];
    [_lareBtn addTarget:self action:@selector(pushsaleview) forControlEvents:UIControlEventTouchUpInside];
    [_lareBtn setImage:[UIImage imageNamed:@"home-icon-sale"] forState:UIControlStateNormal];
    [_lareBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -5)];
    [_lareBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 5)];
    [self.whiteview addSubview:_lareBtn];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                          action:@selector(removeview)];
    [self.shoptypeview addGestureRecognizer:tap];
    
}

- (void)addBtnClicked
{
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    AVCaptureDeviceInput *deviceInput = [AVCaptureDeviceInput deviceInputWithDevice:device error:nil];
    if (nil == deviceInput) {
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"请先打开摄像头权限", nil)];
        return;
    }
    
    ScanController *svc = [[ScanController alloc] init];
    WEAK_SELF(weakSelf);
    svc.callback = ^(NSString * _Nonnull text) {
        [weakSelf searchProductWithText:text];
    };
    [self.navigationController pushViewController:svc animated:YES];
}

- (void)searchProductWithText:(NSString *)text
{
    ProductDetailController *pvc = [[ProductDetailController alloc] initWithText:text
                                                                  invitationCode:@""
                                                                       indexPath:nil
                                                                    productModel:nil
                                                               cacheProductModel:nil
                                                                isFromShoppingVC:NO
                                    ];
    [self.navigationController pushViewController:pvc animated:YES];
}

- (void)doNetworkRequestForType
{
    [self.tableView.mj_header endRefreshing];
    WEAK_SELF(weakSelf);
    [MBProgressHUD showGifToView:nil];
    [LGProductNetWorkService getAllCategoryTypesWithCallBack:^(LgResultModel *resultModel, NSArray *arrList) {
        [MBProgressHUD hideHUD];
        
        [_mgr stopMonitoring];
        if (resultModel.isSucc) {
            if (arrList.count) {
                weakSelf.type = ProductCellTypeNormal;
            } else {
                weakSelf.type = ProductCellTypeNoData;
            }
            [weakSelf.dataSource removeAllObjects];
            
            [LGProductLogicService saveAllType2Local:arrList];
            [weakSelf.dataSource addObjectsFromArray:arrList];
        } else {
            if (resultModel.stateCode.length != 0) {
                [MBProgressHUD showErrorMessage:resultModel.message];
                weakSelf.type = ProductCellTypeNoData;
            } else {
                [MBProgressHUD showErrorMessage:resultModel.errMsg];
                weakSelf.type = ProductCellTypeNetworkError;
            }
        }
        [weakSelf.tableView reloadData];
    }];
}

- (void)getimageurlsnetwork
{
    WEAK_SELF(weakSelf);
    [LGProductNetWorkService getImgUrlsWithCallBack:^(LgResultModel *resultModel, NSArray *imgUrls) {
      //  [MBProgressHUD hideHUD];
       if (resultModel.isSucc) {
            if (imgUrls.count>0)
            {
                [_modeldata removeAllObjects];
                [_modeldata addObjectsFromArray:imgUrls];
            }
            
            [_imageurls removeAllObjects];
            for (AdModel *model in _modeldata)
            {
                [_imageurls addObject:model.advertisingPath];
            }
            [weakSelf.tableView reloadData];
        } else {
            
            if (resultModel.stateCode.length == 0) {
                self.type = ProductCellTypeNoData;
            }
           // [MBProgressHUD showErrorMessage:resultModel.message];
        }
    }];
}

#pragma mark tableView delegate methods
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

static CGFloat typeCellHeight = 170.0f;

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!indexPath.row) {
        if (_ishidden)  {
            return 0;
        } else {
            return typeCellHeight;
        }
    } else {
        if (_ishidden) {
            return SCREEN_HEIGHT-STATUSBAR_HEIGHT-NAVIGATIONBAR_HIGHT-self.navigationController.tabBarController.tabBar.frame.size.height;
        } else {
            return SCREEN_HEIGHT-STATUSBAR_HEIGHT-NAVIGATIONBAR_HIGHT-self.navigationController.tabBarController.tabBar.frame.size.height-typeCellHeight;
        }
    }
}

static NSString *productTypeCellId = @"ProductTypeCell";
static NSString *productCellId = @"ProductCell";

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!indexPath.row) {
        // 顶部的图片轮滑页面
        ShufflingViewCell *cell = [tableView dequeueReusableCellWithIdentifier:productTypeCellId];
        if (!cell) {
            cell = [[ShufflingViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:productTypeCellId];
            cell.scrollView.clickItemOperationBlock = ^(NSInteger currentIndex) {
                [self Clickontheads:currentIndex];
            };
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
        }
        
        cell.imageUrls = _imageurls;
        if (_ishidden) {
            cell.hidden = YES;
        } else {
            cell.hidden = NO;
        }
        return cell;
    } else {
        ProductCell *cell = [tableView dequeueReusableCellWithIdentifier:productCellId];
        if (!cell) {
            cell = [[ProductCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:productCellId];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
            cell.controller = self;
        }
        cell.type = self.type;
        cell.dataSource = self.dataSource;
        cell.classtype = @"0";
        WEAK_SELF(weakSelf);
        cell.callback = ^{
            [weakSelf doNetworkRequestForType];
        };
        return cell;
    }
}


#pragma mark --弹出规格属性

/**
 *  点击半透明部分或者取消按钮，弹出视图消失
 */
-(void)dismiss
{
    //    center.y = center.y+self.view.frame.size.height;
    [UIView animateWithDuration: 0.35 animations: ^{
        self.selectView.frame =CGRectMake(0, screen_Height, screen_Width, screen_Height);
        self.backgroundView.transform = CGAffineTransformIdentity;
    } completion: nil];
    
    [self.standardList removeAllObjects];
    [self.standardValueList removeAllObjects];
    
}
-(NSMutableArray *)attributesArray{
    
    if (_attributesArray == nil) {
        _attributesArray = [[NSMutableArray alloc] init];
    }
    return _attributesArray;
}

-(void)selectBtnTitle:(NSString *)title andBtn:(UIButton *)btn{
    
    [self.attributesArray removeAllObjects];
    for (int i=0; i < _standardList.count; i++)
    {
        DWQSelectAttributes *view = [self.view viewWithTag:8000+i];
        for (UIButton *obj in  view.btnView.subviews)
        {
            if(obj.selected){
                for (NSArray *arr in self.standardValueList)
                {
                    for (NSString *title in arr) {
                        if ([view.selectBtn.titleLabel.text isEqualToString:title]) {
                            [self.attributesArray addObject:view.selectBtn.titleLabel.text];
                        }
                    }
                }
            }
        }
    }
    NSLog(@"%@",self.attributesArray);
}

- (void)dismissclick
{
    [self.selectspecificationview removeFromSuperview];
}


- (void)removeview
{
    [self.shoptypeview removeFromSuperview];
}

- (void)pushnewview
{
    [self removeview];
    PTypeProductController *pvc = [[PTypeProductController alloc] initWithType:ProductTypeNew];
    [self.navigationController pushViewController:pvc animated:YES];
}

- (void)pushrecommendview
{
    [self removeview];
    PTypeProductController *pvc = [[PTypeProductController alloc] initWithType:ProductTypeRecommand];
    [self.navigationController pushViewController:pvc animated:YES];
}

- (void)pushsaleview
{
    [self removeview];
    PTypeProductController *pvc = [[PTypeProductController alloc] initWithType:ProductTypeDiscount];
    [self.navigationController pushViewController:pvc animated:YES];
}

- (void)hiddencell
{
    _ishidden = YES;
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
}

- (void)nothiddencell
{
    _ishidden = NO;
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
}

- (void)Clickontheads:(NSInteger)index
{
    AgreementController *agreeVC = [[AgreementController alloc] init];
    agreeVC.type = @"1";
    
//    if (self.httpurls.count>0)
//    {
//
//    }
//    else
//    {
//        if (index==0) {
//            agreeVC.htmlurl = @"http://image.lgtechita.com:8001/LgPortal/advertising.png";
//        }
//        else
//        {
//            agreeVC.htmlurl = @"http://www.lgtechita.com/";
//        }
//    }
    
    AdModel *model = _modeldata[index];
    NSString *urlstr = model.advertisingDetailsPath;
    
    if (urlstr.length>3)
    {
        agreeVC.htmlurl = urlstr;
    }
    else
    {
        return;
    }
    
    [self.navigationController pushViewController:agreeVC animated:YES];
}

- (void)cancelCallback
{
    [KLCPopup dismissAllPopups];
}

- (void)loginCallback
{
    [KLCPopup dismissAllPopups];
    HomeController *homeVC = [[HomeController alloc] init];
    homeVC.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:homeVC animated:YES completion:nil];
}

- (void)showpromptloginview
{
    PromptView *view = [[PromptView alloc] init];
    WEAK_SELF(weakSelf);
    view.cancel = ^{
        [weakSelf cancelCallback];
    };
    view.login = ^{
        [weakSelf loginCallback];
    };
    KLCPopup *popup = [KLCPopup popupWithContentView:view
                                            showType:KLCPopupShowTypeFadeIn
                                         dismissType:KLCPopupDismissTypeFadeOut
                                            maskType:KLCPopupMaskTypeDimmed
                            dismissOnBackgroundTouch:NO
                               dismissOnContentTouch:NO];
    [popup show];
}

- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController NS_AVAILABLE_IOS(3_0)
{
    NSString *islogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsLogin];
    NSString *iswechatlogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsWeChatLogin];
    
    if (viewController == tabBarController.viewControllers[2]) {
        if (!islogin.boolValue && !iswechatlogin.boolValue) {
            [self showpromptloginview];
            return NO;
        } else {
            return YES;
        }
    } else {
        return YES;
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didReceivedProductNotification:)
                                                 name:kProductNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didreloadproductclass:)
                                                 name:kProductclassidNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didaddspecifications:)
                                                 name:kProductspecificationsNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(hiddencell)
                                                 name:kProducthiddencellNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(nothiddencell)
                                                 name:kProductscrollowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(showpromptloginview)
                                                 name:kPromptLoginNotification
                                               object:nil];
    
    NSString *ishomehidden = [[NSUserDefaults standardUserDefaults] objectForKey:KHomeIsHidden];
    NSString *ishomerows = [[NSUserDefaults standardUserDefaults] objectForKey:kHomeIsRows];
    NSString *ishidden = [[NSUserDefaults standardUserDefaults] objectForKey:KIsHidden];
    NSString *isrows = [[NSUserDefaults standardUserDefaults] objectForKey:kIsRows];
    
    if (ishomehidden.intValue==ishidden.intValue && ishomerows.intValue==isrows.intValue) {
    } else {
        [[NSUserDefaults standardUserDefaults] setObject:ishidden forKey:KHomeIsHidden];
        [[NSUserDefaults standardUserDefaults] setObject:isrows forKey:kHomeIsRows];
        [self.refresh beginRefreshing];
    }
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (void)configBridgeNum:(NSNotification *)notification
{
    NSLog(@"============configBridgeNum===========");
    
    UITabBarController * root = self.tabBarController; // self当前的viewController
    UITabBarItem * tabBarItem = root.tabBar.items[1];
    [tabBarItem setBadgeColor:MainColor];
    
    NSNumber *allGoodsNum = notification.userInfo[@"allGoodsNum"];
    int a = [allGoodsNum intValue];
    if (a == 0) {
        [tabBarItem setBadgeValue:nil];// 隐藏角标
    } else {
        [tabBarItem setBadgeValue:[NSString stringWithFormat:@"%d",[allGoodsNum intValue]]];
    }
}


#pragma mark - 懒加载
- (BaseService *)baseService
{
    if (!_baseService) {
        _baseService = [[BaseService alloc] init];
    }
    return _baseService;
}

@end
