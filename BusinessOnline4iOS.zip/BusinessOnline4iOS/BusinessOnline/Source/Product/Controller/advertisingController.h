//
//  advertisingController.h
//  BusinessOnline
//
//  Created by clitics on 2020/5/4.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface advertisingController : UIViewController

@property (nonatomic,copy)NSString *url;


@end

NS_ASSUME_NONNULL_END
