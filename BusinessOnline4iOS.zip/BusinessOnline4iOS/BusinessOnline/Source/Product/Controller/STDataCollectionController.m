//
//  STDataCollectionController.m
//  SwiftTool
//
//  Created by clitics on 2018/9/5.
//  Copyright © 2018年 clitics. All rights reserved.
//

#import "STDataCollectionController.h"


@interface STDataCollectionController ()
{
    
}


@end

@implementation STDataCollectionController

#define debug 1



- (void)dealloc
{
    [self removeScanningView];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor clearColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self.view addSubview:self.scanningView];
    [self.scanningView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.bottom.right.mas_equalTo(self.view);
    }];
    
    [self setupQRCodeScanning];
}

- (SGQRCodeScanningView *)scanningView
{
    if (!_scanningView)
    {
        _scanningView = [[SGQRCodeScanningView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
        _scanningView.scanningImageName = @"SGQRCode.bundle/QRCodeScanningLine";
        _scanningView.scanningAnimationStyle = ScanningAnimationStyleDefault;
        _scanningView.cornerColor = [UIColor whiteColor];
        _scanningView.cornerWidth = 3;
        _scanningView.borderColor = [UIColor clearColor];
    }
    return _scanningView;
}

- (void)removeScanningView
{
    [self.scanningView removeTimer];
    [self.scanningView removeFromSuperview];
    self.scanningView = nil;
}

- (void)setupQRCodeScanning
{
    self.manager = [SGQRCodeScanManager sharedManager];
    NSArray *arr = @[AVMetadataObjectTypeCode128Code,AVMetadataObjectTypeEAN13Code,AVMetadataObjectTypeQRCode];
    [_manager setupSessionPreset:AVCaptureSessionPreset1920x1080 metadataObjectTypes:arr currentController:self];
    [_manager cancelSampleBufferDelegate];
    _manager.delegate = self;
}

#pragma mark - - - SGQRCodeScanManagerDelegate
- (void)QRCodeScanManager:(SGQRCodeScanManager *)scanManager didOutputMetadataObjects:(NSArray *)metadataObjects
{
    DEBUG_LOG(@"metadataObjects - - %@", metadataObjects);
    if (metadataObjects != nil && metadataObjects.count > 0)
    {
        [scanManager stopRunning];

//        AVMetadataMachineReadableCodeObject *obj = metadataObjects[0];
//        DEBUG_LOG(@"%@",obj.stringValue);

    }
    else
    {
        DEBUG_LOG(@"暂未识别出扫描的二维码");
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"unidentification", nil)];
    }
}

@end
