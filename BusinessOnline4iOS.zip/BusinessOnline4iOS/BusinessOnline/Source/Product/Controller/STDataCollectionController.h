//
//  STDataCollectionController.h
//  SwiftTool
//
//  Created by clitics on 2018/9/5.
//  Copyright © 2018年 clitics. All rights reserved.
//

#import "BaseViewController.h"

@interface STDataCollectionController : BaseViewController<SGQRCodeScanManagerDelegate>

@property (nonatomic, strong) SGQRCodeScanManager *manager;
@property (nonatomic, strong) SGQRCodeScanningView *scanningView;

@end
