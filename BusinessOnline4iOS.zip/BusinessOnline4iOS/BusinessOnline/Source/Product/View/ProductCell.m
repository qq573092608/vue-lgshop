//
//  ProductCell.m
//  BusinessOnline
//
//  Created by clitics on 2019/3/1.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "ProductCell.h"
#import "ProductListController.h"
#import "ProductTypeModel.h"
#import <JXCategoryView/JXCategoryView.h>
#import "UIImageView+WebCache.h"

@interface ProductCell ()<JXCategoryViewDelegate,JXCategoryListContainerViewDelegate>
{
    UIButton *_errorBtn;
}
@property (nonatomic, strong) JXCategoryTitleView *categoryView;
@property (nonatomic,strong)JXCategoryListContainerView *listContainerView;
@property (nonatomic,strong)JXCategoryTitleImageView *titleimageview;
@property (nonatomic,strong)UIButton *classBtn;
@property (nonatomic,assign)NSInteger index;

@end
@implementation ProductCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        _index = 0;
    }
    return self;
}

- (void)upupdateIndexAction:(NSNotification *)notification
{
    
    
}

- (void)setupSubViews
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(updateIndexAction:)
                                                 name:@"kUpdateIndex"
                                               object:nil];
    
    [self.categoryView removeFromSuperview];
    self.categoryView = nil;
    [self.titleimageview removeFromSuperview];
    self.titleimageview = nil;
    
    [self.contentView addSubview:self.listContainerView];
    NSString *isshow = [[NSUserDefaults standardUserDefaults] objectForKey:KIsHidden];
    // 没有图标的类型
    if (isshow.boolValue)
    {
        NSMutableArray *tempTitles = @[].mutableCopy;
        for (ProductTypeModel *model in self.dataSource) {
            if (isNSString(model.name)) {
                [tempTitles addObject:model.name];
            }
        }
        [self.contentView  addSubview:self.categoryView];
        self.categoryView.titles = tempTitles;
        //优化关联listContainer，以后后续比如defaultSelectedIndex等属性，才能同步给listContainer
        self.categoryView.listContainer = self.listContainerView;
        [self.categoryView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(self);
            make.width.mas_equalTo(SCREEN_WIDTH-60);
            make.height.mas_equalTo(50);
        }];
        
        [self.listContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.categoryView.mas_bottom);
            make.left.mas_equalTo(self.contentView.mas_left);
            make.right.mas_equalTo(self.contentView.mas_right);
            //make.height.mas_equalTo(self.contentView.bounds.size.height - 50);
            make.bottom.mas_equalTo(self.contentView.mas_bottom);
        }];
        
    // 有图标的类型
    } else {
        [self.contentView addSubview:self.titleimageview];

        //关联cotentScrollView，关联之后才可以互相联动！！！
        self.titleimageview.contentScrollView = self.listContainerView.scrollView;
        [self.titleimageview mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(self);
            make.width.mas_equalTo(SCREEN_WIDTH-60);
            make.height.mas_equalTo(90);
        }];

        NSMutableArray *temp = @[].mutableCopy;
        NSMutableArray *imageurls = @[].mutableCopy;
        NSMutableArray *types = @[].mutableCopy;
        NSMutableArray *imagenames = @[].mutableCopy;
        for (ProductTypeModel *model in self.dataSource) {
            if (isNSString(model.name)) {
                [temp addObject:model.name];
                if (model.path.length==0) {
                    [imageurls addObject:[NSURL URLWithString:@""]];
                } else {
                    [imageurls addObject:[NSURL URLWithString:model.path]];
                }
                [types addObject:@(0)];
                [imagenames addObject:@"022_x"];
            }
        }
        self.titleimageview.imageSize = CGSizeMake(50, 50);
        self.titleimageview.titleImageSpacing = 5.0;
        self.titleimageview.titles = temp;
        self.titleimageview.imageTypes = types;
        self.titleimageview.imageURLs = imageurls;
       // self.titleimageview.titleSelectedColor = [UIColor yellowColor];
        self.titleimageview.titleSelectedFont = [UIFont fontWithName:@"PingFangSC-Medium" size:13.0f];
        self.titleimageview.loadImageCallback = ^(UIImageView *imageView, NSURL *imageURL) {
            [imageView sd_setImageWithURL:imageURL placeholderImage:[UIImage imageNamed:@"022_x"]];
        };
        
        [self.listContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.mas_equalTo(self.contentView);
            make.top.mas_equalTo(self.titleimageview.mas_bottom);
        }];
    }
    
    // 分类按钮的显示布局
    _classBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.contentView addSubview:_classBtn];
    [self.classBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.right.mas_equalTo(self);
        make.width.mas_equalTo(60);
        if (isshow.boolValue) {
            make.height.mas_equalTo(50);
        } else {
            make.height.mas_equalTo(90);
        }
        
    }];
    [_classBtn setImage:[UIImage imageNamed:@"class"] forState:UIControlStateNormal];
    [_classBtn setImage:[UIImage imageNamed:@"class"] forState:UIControlStateHighlighted];
    [_classBtn addTarget:self
                  action:@selector(classBtnclick:)
        forControlEvents:UIControlEventTouchUpInside];
        
    if ([_classtype isEqualToString:@"1"]) {
        _classBtn.hidden = YES;
        // 根据排列方式来展示内容
        // 没有图标的类型
        if (isshow.boolValue){
            [self.categoryView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.left.right.mas_equalTo(self);
                make.height.mas_equalTo(50);
            }];
        } else {
            [self.titleimageview mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.left.right.mas_equalTo(self);
                make.height.mas_equalTo(90);
            }];
        }
    }
}

-(void)setDataSource:(NSMutableArray *)dataSource
{
    _dataSource = dataSource;
    if (_dataSource.count) {
        [self setupSubViews];
    } else {
    }
}

-(void)setType:(ProductCellType)type {
    _type = type;
    if (!_errorBtn) {
        _errorBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.contentView addSubview:_errorBtn];
        [_errorBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(100, 100));
            make.center.mas_equalTo(self);
        }];
        [self initButton:_errorBtn];
    }
    switch (_type) {
        case ProductCellTypeNoData: {
                _errorBtn.hidden = NO;;
                [_errorBtn setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
                [_errorBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"zusj", nil)
                                                                              attributes:@{
                                                                                  NSFontAttributeName:[UIFont systemFontOfSize:15],
                                                                                           NSForegroundColorAttributeName:UIColorFromRGB(colorTextMiddleLight)}]
                                     forState:UIControlStateNormal];
                [_errorBtn addTarget:self action:@selector(noDataBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
            }
            break;
        case ProductCellTypeNetworkError: {
            _errorBtn.hidden = NO;
            [_errorBtn setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
            [_errorBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"net_error", nil)
                                                                          attributes:@{
                                                                              NSFontAttributeName:[UIFont systemFontOfSize:15],
                                                                              NSForegroundColorAttributeName:UIColorFromRGB(colorTextMiddleLight)}] forState:UIControlStateNormal];
            [_errorBtn addTarget:self action:@selector(errorBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
            
        }
            break;
            
        default:
            _errorBtn.hidden = YES;
            break;
    }
}

- (void)errorBtnClicked:(UIButton *)button
{
    button.hidden = YES;
    if (self.callback)
    {
        self.callback();
    }
}

- (void)noDataBtnClicked:(UIButton *)button
{
    button.hidden = YES;
}

-(void)initButton:(UIButton*)btn
{
    CGSize imgViewSize,titleSize,btnSize;
    UIEdgeInsets imageViewEdge,titleEdge;
    
    CGFloat heightSpace = 10.0f;
    //设置按钮内边距
    imgViewSize = btn.imageView.bounds.size;
    titleSize = btn.titleLabel.bounds.size;
    btnSize = btn.bounds.size;
    imageViewEdge = UIEdgeInsetsMake(-2 * heightSpace,0.0, btnSize.height -imgViewSize.height - heightSpace, - titleSize.width);
    [btn setImageEdgeInsets:imageViewEdge];
    titleEdge = UIEdgeInsetsMake(imgViewSize.height +3*heightSpace, - imgViewSize.width, 0.0, 0.0);
    [btn setTitleEdgeInsets:titleEdge];
}

- (void)classBtnclick:(UIButton *)btn
{
//    [[self class] cancelPreviousPerformRequestsWithTarget:self selector:@selector(todosomething) object:btn];
//    [self performSelector:@selector(todosomething) withObject:btn afterDelay:0.2];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:kProductclassidNotification
                                                        object:self
                                                      userInfo:nil];
}

- (void)todosomething
{
    
}

#pragma mark delegate methods
//点击选中或者滚动选中都会调用该方法。适用于只关心选中事件，不关心具体是点击还是滚动选中的。
- (void)categoryView:(JXCategoryBaseView *)categoryView didSelectedItemAtIndex:(NSInteger)index
{
    ProductTypeModel *model = self.dataSource[index];
    [[NSNotificationCenter defaultCenter] postNotificationName:kProductisshowbuttonNotification
                                                        object:self
                                                      userInfo:@{
                                                          kProductisshowbuttonNotificationKey:model
                                                      }
     ];
}

//点击选中的情况才会调用该方法
- (void)categoryView:(JXCategoryBaseView *)categoryView didClickSelectedItemAtIndex:(NSInteger)index
{
    if (_index == index) {
        
        [self.listContainerView didClickSelectedItemAtIndex:index];
        [self.listContainerView.scrollView setContentOffset:CGPointMake(SCREEN_WIDTH*index, 0) animated:NO];
        
        ProductTypeModel *model = self.dataSource[index];
        if ([self.classtype isEqualToString:@"0"]) {
            [[NSNotificationCenter defaultCenter] postNotificationName:kProductclassidNotification
                                                                object:self
                                                              userInfo:@{kProductclassidNotificationKey:model}];
        } else {
            [[NSNotificationCenter defaultCenter] postNotificationName:kProductchildrenclassidNotification
                                                                object:self
                                                              userInfo:@{kProductchildrenclassidNotificationKey:model}];
        }
    } else {
        _index = index;
        [self.listContainerView didClickSelectedItemAtIndex:index];
        [self.listContainerView.scrollView setContentOffset:CGPointMake(SCREEN_WIDTH*index, 0)
                                                   animated:NO];
    }
}

//滚动选中的情况才会调用该方法
- (void)categoryView:(JXCategoryBaseView *)categoryView didScrollSelectedItemAtIndex:(NSInteger)index
{
    NSLog(@"滚动选中.......");
}

//正在滚动中的回调
- (void)categoryView:(JXCategoryBaseView *)categoryView scrollingFromLeftIndex:(NSInteger)leftIndex toRightIndex:(NSInteger)rightIndex ratio:(CGFloat)ratio
{
    
}

//自定义contentScrollView点击选中切换效果
- (void)categoryView:(JXCategoryBaseView *)categoryView didClickedItemContentScrollViewTransitionToIndex:(NSInteger)index
{
    
}

#pragma mark
//返回列表的数量
- (NSInteger)numberOfListsInlistContainerView:(JXCategoryListContainerView *)listContainerView
{
    return self.dataSource.count;
}
//返回遵从`JXCategoryListContentViewDelegate`协议的实例
- (id<JXCategoryListContentViewDelegate>)listContainerView:(JXCategoryListContainerView *)listContainerView initListForIndex:(NSInteger)index
{
    ProductTypeModel *model = self.dataSource[index];
    return (id<JXCategoryListContentViewDelegate>)[[ProductListController alloc] initWithProductType:model.id classType:_classtype];
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - 懒加载

- (JXCategoryTitleImageView *)titleimageview
{
    if (!_titleimageview) {
        
        _titleimageview = [[JXCategoryTitleImageView alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
        _titleimageview.delegate = self;
        _titleimageview.titleColorGradientEnabled = YES;
        _titleimageview.titleLabelZoomEnabled = YES;
        _titleimageview.titleLabelZoomScale = 1;
        _titleimageview.titleFont = [UIFont lgFontFamily:@"" size:13.0f];
        _titleimageview.titleSelectedColor = MainColor;
       // _titleimageview.titleSelectedFont = [UIFont fontWithName:@"PingFangSC-Medium" size:16.0f];

        JXCategoryIndicatorLineView *lineView = [[JXCategoryIndicatorLineView alloc] init];
        lineView.indicatorColor = MainColor;
        lineView.indicatorWidth = JXCategoryViewAutomaticDimension;
        _titleimageview.indicators = @[lineView];
        
    }
    return _titleimageview;
}

- (JXCategoryListContainerView *)listContainerView
{
    if (!_listContainerView) {
        _listContainerView = [[JXCategoryListContainerView alloc] initWithType:JXCategoryListContainerType_ScrollView
                                                                      delegate:self];
    }
    return _listContainerView;
}

- (JXCategoryTitleView *)categoryView
{
    if (!_categoryView) {
        _categoryView = [[JXCategoryTitleView alloc] init];
        _categoryView.delegate = self;
        _categoryView.defaultSelectedIndex = 0;
        JXCategoryIndicatorLineView *lineView = [[JXCategoryIndicatorLineView alloc] init];
        _categoryView.indicators = @[lineView];
         _categoryView.titleColor = MainColor;
      //  _categoryView.titleSelectedFont = [UIFont fontWithName:@"PingFangSC-Medium" size:16.0f];

    }
    return _categoryView;;
}



@end
