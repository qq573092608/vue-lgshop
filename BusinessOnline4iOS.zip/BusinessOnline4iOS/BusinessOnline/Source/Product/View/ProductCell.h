//
//  ProductCell.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/1.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, ProductCellType)
{
    ProductCellTypeNormal,
    ProductCellTypeNetworkError,
    ProductCellTypeNoData
};
NS_ASSUME_NONNULL_BEGIN

@interface ProductCell : UITableViewCell

@property (nonatomic,strong)UIViewController *controller;
@property (nonatomic,strong)NSMutableArray *dataSource;
@property (nonatomic,assign)ProductCellType type;
@property (nonatomic,copy)void(^callback)(void);
@property (nonatomic,copy)NSString *classtype;


@end

NS_ASSUME_NONNULL_END
