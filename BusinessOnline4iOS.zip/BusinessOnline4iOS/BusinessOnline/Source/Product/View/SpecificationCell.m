//
//  SpecificationCell.m
//  BusinessOnline
//
//  Created by clitics on 2020/4/23.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "SpecificationCell.h"
#import "ChildrenModel.h"

@interface SpecificationCell ()

@property(nonatomic,strong)UIButton *selectBtn;

@end

@implementation SpecificationCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        self.backgroundColor = [UIColor whiteColor];
        
        
        
        [self setupSubViews];
    }
    return self;
}

- (void)setupSubViews
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(10, 5, screen_Width, 110)];
    
    [self addSubview:view];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 60, 30)];
    //                label.backgroundColor = [UIColor redColor];
    
    label.text = @"haha";
    label.textColor = UIColorFromRGB(colorLoginEnable);
    label.font = [UIFont systemFontOfSize:20];
    [view addSubview:label];
    
    for (int i=0; i<_specification.count; i++) {
        ChildrenModel *model = _specification[i];
        UIButton *Btn = [[UIButton alloc] initWithFrame:CGRectMake(10+i*100, 50, 80, 50)];
        [Btn setTitle:model.zhName forState:UIControlStateNormal];
        Btn.titleLabel.font = [UIFont systemFontOfSize:20];
        
        [Btn addTarget:self action:@selector(selctbutton:) forControlEvents:UIControlEventTouchUpInside];
        //设置边框颜色
        Btn.layer.borderColor = [[UIColor redColor] CGColor];
        //设置边框宽度
        Btn.layer.borderWidth = 1.0f;
        //给按钮设置角的弧度
        Btn.layer.cornerRadius = 6.0f;
        Btn.tag = 100000+model.infoTasteId.intValue;
        
        if (i==0) {
            [Btn setTitleColor:UIColorFromRGB(colorFontWhite) forState:UIControlStateNormal];
            Btn.backgroundColor = UIColorFromRGB(colorLoginEnable);
            self.selectBtn = Btn;
        }
        else
        {
            [Btn setTitleColor:UIColorFromRGB(colorLoginEnable) forState:UIControlStateNormal];
            Btn.backgroundColor = UIColorFromRGB(colorFontWhite);
        }
        
        
        [view addSubview:Btn];
    }
}

- (void)selctbutton:(UIButton *)btn
{
    if (![self.selectBtn isEqual:btn]) {
        
        self.selectBtn.backgroundColor = UIColorFromRGB(colorFontWhite);
        [self.selectBtn setTitleColor:UIColorFromRGB(colorLoginEnable) forState:UIControlStateNormal];
        self.selectBtn.selected = NO;
        
        //        NSLog(@"%@-----%@",btn.titleLabel.text,[self.rankArray[btn.tag-10000] sequence]);
    }
    else{
        btn.backgroundColor = UIColorFromRGB(colorFontWhite);
        [btn setTitleColor:UIColorFromRGB(colorLoginEnable) forState:UIControlStateNormal];
    }
    btn.backgroundColor = UIColorFromRGB(colorLoginEnable);
    [btn setTitleColor:UIColorFromRGB(colorFontWhite) forState:UIControlStateNormal];
    btn.selected = YES;
    
    self.selectBtn = btn;
    
    if (self.callback)
    {
        self.callback(self.selectBtn.titleLabel.text,[NSString stringWithFormat:@"%ld",self.selectBtn.tag-100000]);
    }
    
}
@end
