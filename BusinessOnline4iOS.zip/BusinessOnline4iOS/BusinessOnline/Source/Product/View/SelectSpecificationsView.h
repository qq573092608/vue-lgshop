//
//  SelectSpecificationsView.h
//  BusinessOnline
//
//  Created by clitics on 2020/4/23.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SelectSpecificationsView : UIView

@property(nonatomic,strong)UIView *alphaView;
@property(nonatomic,strong)UILabel *goodsName;
@property(nonatomic,strong)UIView *whiteView;
@property (nonatomic,strong)ASTableNode *tableNode;
@property(nonatomic,strong)UIButton *cancelBtn;
@property(nonatomic,strong)UIButton *OKBtn;
@property(nonatomic,strong)NSMutableArray *standlist;
@property(nonatomic,strong)NSMutableArray *standlistvalue;
@property (nonatomic,copy)void(^callback)(NSString *text,NSString *infolistid,NSIndexPath *indexpath);
@property(nonatomic,strong)NSMutableArray *specificationdata;
@property(nonatomic,strong)NSMutableArray *infolistiddata;


- (instancetype)initWithStandlist:(NSMutableArray *)standlist standlistvalue:(NSMutableArray *)standlistvalue;

@end

NS_ASSUME_NONNULL_END
