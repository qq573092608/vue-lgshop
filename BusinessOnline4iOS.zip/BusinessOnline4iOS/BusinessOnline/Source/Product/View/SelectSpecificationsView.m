//
//  SelectSpecificationsView.m
//  BusinessOnline
//
//  Created by clitics on 2020/4/23.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "SelectSpecificationsView.h"
#import "SpecificationsNode.h"

@interface SelectSpecificationsView ()<ASTableDelegate,ASTableDataSource>

@end

@implementation SelectSpecificationsView

- (instancetype)initWithStandlist:(NSMutableArray *)standlist standlistvalue:(NSMutableArray *)standlistvalue{
    
    if (self = [super init]) {
        
        self.backgroundColor = [UIColor clearColor];
        _standlist = [NSMutableArray array];
        _standlistvalue = [NSMutableArray array];
        
        _specificationdata = [NSMutableArray array];
        _infolistiddata = [NSMutableArray array];
        
        for (int i=0; i<standlistvalue.count; i++) {
            
            NSArray *array = standlistvalue[i];
            ChildrenModel *model = [array firstObject];
            
            [_specificationdata addObject:model.zhName];
            [_infolistiddata addObject:model.infoTasteId];
        }
        
        _standlist = standlist;
        _standlistvalue = standlistvalue;
        //self.showSales = @"135";
        [self creatUI];
        
    }
    return self;
}

-(void)creatUI
{
    //半透明视图
    _alphaView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_Width, screen_Height)];
    _alphaView.backgroundColor = [UIColor blackColor];
    _alphaView.alpha = 0.3;
    [self addSubview:_alphaView];
    CGFloat tableheight = _standlist.count * 85 + 90;
    
    if (tableheight>screen_Height/2)
    {
        tableheight = screen_Height/2;
    }
    
//    _whiteView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_Width-40, screen_Height/5*2)];
    _whiteView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_Width-40, tableheight)];
    _whiteView.backgroundColor = [UIColor whiteColor];
    _whiteView.layer.cornerRadius = 6;
    _whiteView.center = CGPointMake(screen_Width/2, screen_Height/2);
    [self addSubview:_whiteView];
    
    _goodsName = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, SCREEN_WIDTH-100, 30)];
    _goodsName.backgroundColor = [UIColor whiteColor];
    _goodsName.text = @"商品名称";
    _goodsName.font = [UIFont systemFontOfSize:18];
    _goodsName.backgroundColor = [UIColor whiteColor];
    [_whiteView addSubview:_goodsName];
    
    _tableNode = [[ASTableNode alloc] initWithStyle:UITableViewStylePlain];
    [_whiteView addSubnode:_tableNode];
//    _tableNode.view.separatorColor = [UIColor whiteColor];
    _tableNode.backgroundColor = [UIColor whiteColor];
//    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, CGFLOAT_MIN)];
//    _tableNode.view.tableFooterView = footerView;
    _tableNode.frame = CGRectMake(0, 40, _whiteView.frame.size.width, tableheight-90);
    _tableNode.delegate = self;
    _tableNode.dataSource = self;
    
    
    _cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _cancelBtn.frame = CGRectMake(_whiteView.frame.size.width-40, 10, 25, 25);
    [_cancelBtn setBackgroundImage:[UIImage imageNamed:@"spe_cancel"] forState:0];
    [_whiteView addSubview:_cancelBtn];
    
    _OKBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _OKBtn.frame = CGRectMake(screen_Width-110, tableheight-45, 60, 40);
    [_OKBtn setTitle:@"OK" forState:UIControlStateNormal];
    [_OKBtn setTitleColor:MainColor forState:UIControlStateNormal];
    
    _OKBtn.layer.borderColor = [[UIColor redColor] CGColor];
    //设置边框宽度
    _OKBtn.layer.borderWidth = 1.0f;
    //给按钮设置角的弧度
    _OKBtn.layer.cornerRadius = 4.0f;
    [_whiteView addSubview:_OKBtn];
    
    
}


-(NSInteger)tableNode:(ASTableNode *)tableNode numberOfRowsInSection:(NSInteger)section
{
    return self.standlistvalue.count;
}

-(ASCellNode *)tableNode:(ASTableNode *)tableNode nodeForRowAtIndexPath:(NSIndexPath *)indexPath
{
    WEAK_SELF(weakeSelf);
    SpecificationsNode *node = [[SpecificationsNode alloc] initWithTitle:self.standlist[indexPath.row] specification:self.standlistvalue[indexPath.row]];
    
    node.callback = ^(NSString * _Nonnull text, NSString * _Nonnull infolistid) {
      
        [weakeSelf addspecification:text indexpath:indexPath infolistid:infolistid];
    };
    
    return node;
}

- (void)addspecification:(NSString *)text indexpath:(NSIndexPath *)indexpath infolistid:(NSString *)infolistid
{
    [_specificationdata replaceObjectAtIndex:indexpath.row withObject:text];
    [_infolistiddata replaceObjectAtIndex:indexpath.row withObject:infolistid];
    
    
}



@end
