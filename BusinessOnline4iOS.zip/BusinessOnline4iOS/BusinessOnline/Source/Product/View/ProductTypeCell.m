//
//  ProductTypeCell.m
//  BusinessOnline
//
//  Created by clitics on 2019/3/1.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "ProductTypeCell.h"

@implementation ProductTypeCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        self.backgroundColor = [UIColor whiteColor];
        
        [self setupSubViews];
    }
    return self;
}

static CGFloat edgSpacing = 0.0f;
static CGFloat viewSpacing = 0.0f;


- (void)setupSubViews
{
    
    UIButton *newProductBtn = [self createButtonWithTitle:NSLocalizedString(@"product_new", nil) imageName:@"018_c"];
    [newProductBtn addTarget:self action:@selector(newProductBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [newProductBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self).offset(-edgSpacing);
        make.width.mas_equalTo((SCREEN_WIDTH-3*viewSpacing-edgSpacing*2)/4);
        make.top.mas_equalTo(self).offset(edgSpacing);
        make.bottom.mas_equalTo(self).offset(-edgSpacing);
    }];
    
    UIButton *recommandProductBtn = [self createButtonWithTitle:NSLocalizedString(@"product_recommend", nil) imageName:@"016_e"];
    
    [self addEdgeuibutton:recommandProductBtn];
    [recommandProductBtn addTarget:self action:@selector(recommandProductBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [recommandProductBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(newProductBtn.mas_right).offset(viewSpacing);
        make.width.mas_equalTo((SCREEN_WIDTH-3*viewSpacing-edgSpacing*2)/4);
        make.top.mas_equalTo(self).offset(edgSpacing);
        make.bottom.mas_equalTo(self).offset(-edgSpacing);
    }];
    
    UIButton *discountProductBtn = [self createButtonWithTitle:NSLocalizedString(@"product_sale", nil) imageName:@"015_f"];
    
    [self addEdgeuibutton:discountProductBtn];

    [discountProductBtn addTarget:self action:@selector(discountProductBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [discountProductBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(recommandProductBtn.mas_right).offset(viewSpacing);
        make.width.mas_equalTo((SCREEN_WIDTH-3*viewSpacing-edgSpacing*2)/4);
        make.top.mas_equalTo(self).offset(edgSpacing);
        make.bottom.mas_equalTo(self).offset(-edgSpacing);
    }];
    
    UIButton *latestProductBtn = [self createButtonWithTitle:NSLocalizedString(@"product_recent", nil) imageName:@"017_d"];
    [latestProductBtn addTarget:self action:@selector(latestBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [latestProductBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(discountProductBtn.mas_right).offset(viewSpacing);
        make.width.mas_equalTo((SCREEN_WIDTH-3*viewSpacing-edgSpacing*2)/4);
        make.top.mas_equalTo(self).offset(edgSpacing);
        make.bottom.mas_equalTo(self).offset(-edgSpacing);
    }];
}

- (void)newProductBtnClicked
{
    if (self.callback)
    {
        self.callback(ProductCallbackTypeNew);
    }
}

- (void)recommandProductBtnClicked
{
    if (self.callback)
    {
        self.callback(ProductCallbackTypeRecommand);
    }
}

- (void)discountProductBtnClicked
{
    if (self.callback)
    {
        self.callback(ProductCallbackTypeDiscount);
    }
}

- (void)latestBtnClicked
{
    if (self.callback)
    {
        self.callback(ProductCallbackTypeLatest);
    }
}


- (UIButton *)createButtonWithTitle:(NSString *)title imageName:(NSString *)imageName
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0*(SCREEN_WIDTH-3*viewSpacing-edgSpacing*2)/4, (SCREEN_WIDTH-3*viewSpacing-edgSpacing*2)/4, self.frame.size.height);
    [button setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    button.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [button setTitleColor:UIColorFromRGB(colorTextMiddleLight) forState:UIControlStateNormal];

    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:12];
    [self initButton:button];
    [self addSubview:button];
    return button;
}

-(void)initButton:(UIButton*)btn
{
    CGSize imgViewSize,titleSize,btnSize;
    UIEdgeInsets imageViewEdge,titleEdge;
    
    CGFloat heightSpace = 10.0f;
    //设置按钮内边距
    imgViewSize = btn.imageView.bounds.size;
    titleSize = btn.titleLabel.bounds.size;
    btnSize = btn.bounds.size;
    imageViewEdge = UIEdgeInsetsMake(-2*heightSpace,0.0, btnSize.height -imgViewSize.height - heightSpace, - titleSize.width);
    [btn setImageEdgeInsets:imageViewEdge];
    titleEdge = UIEdgeInsetsMake(imgViewSize.height +3*heightSpace, - imgViewSize.width, 0.0, 0.0);
    [btn setTitleEdgeInsets:titleEdge];
//    [btn setImageEdgeInsets:imageViewEdge];
}

- (void)addEdgeuibutton:(UIButton *)btn {
    
    CGSize imgViewSize,titleSize,btnSize;
    CGFloat heightSpace = 10.0f;
    imgViewSize = btn.imageView.bounds.size;
    titleSize = btn.titleLabel.bounds.size;
    btnSize = btn.bounds.size;
    [btn setImageEdgeInsets:UIEdgeInsetsMake(-3*heightSpace-5,0.0, btnSize.height -imgViewSize.height - heightSpace, - titleSize.width)];
}

@end
