//
//  TypeView.m
//  BusinessOnline
//
//  Created by clitics on 2020/4/26.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "TypeView.h"

@implementation TypeView

-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        
        self.backgroundColor = [UIColor clearColor];
        
        //self.showSales = @"135";
        [self creatUI];
        
    }
    return self;
}

- (void)creatUI
{
    //半透明视图
    _alphaView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screen_Width, screen_Height)];
    _alphaView.backgroundColor = [UIColor blackColor];
    _alphaView.alpha = 0.3;
    [self addSubview:_alphaView];
    
    _whiteView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 90, 150)];
    _whiteView.backgroundColor = [UIColor whiteColor];
    [self addSubview:_whiteView];
                                                          
    _newbutton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 90, 50)];
    [_newbutton setTitle:NSLocalizedString(@"product_new", nil) forState:UIControlStateNormal];
    _newbutton.imageView.image = [UIImage imageNamed:@""];
    [_newbutton setTitleColor:UIColorFromRGB(colorTextBlack) forState:UIControlStateNormal];
    [_whiteView addSubview:_newbutton];
    
    _recommendBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 50, 90, 50)];
    [_recommendBtn setTitle:NSLocalizedString(@"product_recommend", nil) forState:UIControlStateNormal];
    _recommendBtn.imageView.image = [UIImage imageNamed:@""];
    [_recommendBtn setTitleColor:UIColorFromRGB(colorTextBlack) forState:UIControlStateNormal];
    [_whiteView addSubview:_recommendBtn];
    
    _saleBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 100, 90, 50)];
    [_saleBtn setTitle:NSLocalizedString(@"product_sale", nil) forState:UIControlStateNormal];
    _saleBtn.imageView.image = [UIImage imageNamed:@""];
    [_saleBtn setTitleColor:UIColorFromRGB(colorTextBlack) forState:UIControlStateNormal];
    [_whiteView addSubview:_saleBtn];
    
    
    
}

@end
