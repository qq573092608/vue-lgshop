//
//  ShufflingViewCell.h
//  BusinessOnline
//
//  Created by clitics on 2020/4/14.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ShufflingViewCell : UITableViewCell

@property (nonatomic,strong)NSMutableArray *imageUrls;
//@property (nonatomic,copy)void(^indexcallback)(NSInteger index);
@property (nonatomic,strong)SDCycleScrollView *scrollView;
@end

NS_ASSUME_NONNULL_END
