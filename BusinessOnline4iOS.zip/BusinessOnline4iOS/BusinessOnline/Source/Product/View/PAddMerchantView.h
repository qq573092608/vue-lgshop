//
//  PAddMerchantView.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/4.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PAddMerchantView : UIView

- (instancetype)initWithTitle:(NSString *)title;

@property (nonatomic,copy)void(^callback)(void);

@end

NS_ASSUME_NONNULL_END
