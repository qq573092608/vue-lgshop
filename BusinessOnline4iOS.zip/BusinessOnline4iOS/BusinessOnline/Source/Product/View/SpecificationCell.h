//
//  SpecificationCell.h
//  BusinessOnline
//
//  Created by clitics on 2020/4/23.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SpecificationCell : UITableViewCell

@property (nonatomic,copy)NSString *title;
@property (nonatomic,strong)NSMutableArray *specification;
@property (nonatomic,copy)void(^callback)(NSString *text,NSString *infolistid);

@end

NS_ASSUME_NONNULL_END
