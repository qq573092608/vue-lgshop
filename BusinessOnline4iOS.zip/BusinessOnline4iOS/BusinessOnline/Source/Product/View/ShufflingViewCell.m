//
//  ShufflingViewCell.m
//  BusinessOnline
//
//  Created by clitics on 2020/4/14.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "ShufflingViewCell.h"

@interface ShufflingViewCell ()<SDCycleScrollViewDelegate>



@end

@implementation ShufflingViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        self.backgroundColor = [UIColor whiteColor];
        _imageUrls = [NSMutableArray array];
        self.scrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 170)
                                                             delegate:(id)self
                                                     placeholderImage:[UIImage imageNamed:@"039_vac"]];
        [self.contentView addSubview:self.scrollView];
    }
    return self;
}

- (void)setsubview
{
    self.scrollView.imageURLStringsGroup = _imageUrls;
    //            self.scrollView.localizationImageNamesGroup = imageUrls;
    self.scrollView.backgroundColor = [UIColor clearColor];
    // self.scrollView.bannerImageViewContentMode = UIViewContentModeCenter;
    self.scrollView.bannerImageViewContentMode = UIViewContentModeScaleAspectFit;
    self.scrollView.showPageControl = YES;
    self.scrollView.autoScroll = (_imageUrls.count > 1);
    self.scrollView.pageControlDotSize = CGSizeMake(5, 5);
    self.scrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
    self.scrollView.autoScrollTimeInterval = 3.f;
    self.scrollView.delegate = self;
    
}

- (void)setImageUrls:(NSMutableArray *)imageUrls
{
    _imageUrls = imageUrls;
    if (_imageUrls.count)
    {
        [self setsubview];
    }
}

@end
