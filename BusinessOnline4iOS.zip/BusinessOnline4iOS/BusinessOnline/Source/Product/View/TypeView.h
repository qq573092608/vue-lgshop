//
//  TypeView.h
//  BusinessOnline
//
//  Created by clitics on 2020/4/26.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TypeView : UIView

@property(nonatomic,strong)UIView *alphaView;
@property(nonatomic,strong)UIView *whiteView;
@property(nonatomic,strong)UIButton *newbutton;
@property(nonatomic,strong)UIButton *recommendBtn;
@property(nonatomic,strong)UIButton *saleBtn;

@end

NS_ASSUME_NONNULL_END
