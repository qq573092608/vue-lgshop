//
//  ProductTypeCell.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/1.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, ProductCallbackType)
{
    ProductCallbackTypeNew,
    ProductCallbackTypeRecommand,
    ProductCallbackTypeDiscount,
    ProductCallbackTypeLatest
};
NS_ASSUME_NONNULL_BEGIN

@interface ProductTypeCell : UITableViewCell

@property (nonatomic,copy)void(^callback)(ProductCallbackType type);

@end

NS_ASSUME_NONNULL_END
