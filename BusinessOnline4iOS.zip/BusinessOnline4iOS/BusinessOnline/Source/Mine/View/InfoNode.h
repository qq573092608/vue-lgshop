//
//  InfoNode.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <AsyncDisplayKit/ASCellNode.h>
@class UserInfoModel;

NS_ASSUME_NONNULL_BEGIN

@interface InfoNode : ASCellNode

-(instancetype)initWithUserInfoModel:(UserInfoModel *)model;

@end

NS_ASSUME_NONNULL_END
