//
//  MineNode.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "MineNode.h"
#import "MineModel.h"

@interface MineNode ()
{
    MineModel *_model;
    ASImageNode *_iconNode;
    ASTextNode *_titleNode;
}
@end
@implementation MineNode

-(instancetype)initWithModel:(MineModel *)model
{
    if (self = [super init])
    {
        self.backgroundColor = [UIColor whiteColor];
        _model = model;
        
        _iconNode = [ASImageNode new];
        [self addSubnode:_iconNode];
        _iconNode.image = [UIImage imageNamed:_model.imageName];
//        _iconNode.backgroundColor = ASDisplayNodeDefaultTintColor();
        
        NSString *title = _model.title;
        if (!isNSString(title))
        {
            title = @"";
        }
        _titleNode = [ASTextNode new];
        [self addSubnode:_titleNode];
        _titleNode.attributedText = [[NSAttributedString alloc] initWithString:title attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    }
    return self;
}

-(ASLayoutSpec *)layoutSpecThatFits:(ASSizeRange)constrainedSize
{
    _iconNode.style.preferredSize = CGSizeMake(32, 32);
    ASStackLayoutSpec *spec = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal spacing:10 justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsCenter children:@[_iconNode,_titleNode]];
    return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(10, 20, 10, 20) child:spec];
}
@end
