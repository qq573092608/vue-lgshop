//
//  UnbindWeChatview.m
//  BusinessOnline
//
//  Created by clitics on 2020/7/2.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "UnbindWeChatview.h"

@implementation UnbindWeChatview

-(instancetype)init
{
    if (self = [super init])
    {
        self.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH-40, 150);
        
        
        UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:cancelBtn];
        [cancelBtn addTarget:self action:@selector(cancelBtnClicked) forControlEvents:UIControlEventTouchUpInside];
        [cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake((SCREEN_WIDTH-40)/2, 50));
            make.left.bottom.mas_equalTo(self);
        }];
        cancelBtn.backgroundColor = [UIColor whiteColor];
        [cancelBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"cancel", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}] forState:UIControlStateNormal];
        
        UIButton *logoutBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:logoutBtn];
        [logoutBtn addTarget:self action:@selector(logoutBtnClicked) forControlEvents:UIControlEventTouchUpInside];
        [logoutBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake((SCREEN_WIDTH-40)/2, 50));
            make.right.bottom.mas_equalTo(self);
        }];
        logoutBtn.backgroundColor = MainColor;
        [logoutBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"queding", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}] forState:UIControlStateNormal];
        
        UILabel *label = [[UILabel alloc] init];
        [self addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.mas_equalTo(self);
            make.bottom.mas_equalTo(cancelBtn.mas_top).offset(-0.5);
        }];
        label.backgroundColor = [UIColor whiteColor];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        style.alignment = NSTextAlignmentCenter;
        label.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"是否解除微信帐号关联？", nil) attributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(colorBlack),NSParagraphStyleAttributeName:style}];
        self.layer.cornerRadius = 5;
        self.layer.masksToBounds = YES;
    }
    return self;
}

- (void)cancelBtnClicked
{
    if (self.cancel)
    {
        self.cancel();
    }
}

- (void)logoutBtnClicked
{
    if (self.logout)
    {
        self.logout();
    }
}
@end
