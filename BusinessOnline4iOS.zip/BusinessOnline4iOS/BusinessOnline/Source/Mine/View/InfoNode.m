//
//  InfoNode.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "InfoNode.h"
#import "UserInfoModel.h"
#define NODE_HEIGHT (SCREEN_WIDTH*0.5)

@interface InfoNode ()
{
    ASImageNode *_backImageNode,*_editImageNode;
    ASNetworkImageNode *_iconNode;
    ASTextNode *_nameNode;
    UIImage *_image;
    UserInfoModel *_model;
}
@end
@implementation InfoNode

static CGFloat iconWidth = 80.0f;
static CGFloat editNodeWith = 20.0f;

-(instancetype)initWithUserInfoModel:(UserInfoModel *)model
{
    if (self = [super init])
    {
        self.backgroundColor = [UIColor whiteColor];
        
        _model = model;
        
        _backImageNode = [ASImageNode new];
        [self addSubnode:_backImageNode];
        _backImageNode.image = [UIImage imageNamed:@"044_e"];
        _backImageNode.contentMode = UIViewContentModeScaleAspectFill;
        
        _iconNode = [ASNetworkImageNode new];
        [self addSubnode:_iconNode];
        _iconNode.layer.cornerRadius = iconWidth/2;
        _iconNode.layer.masksToBounds = YES;
        
        NSString *imagestr = _model.avatarpath;
        if (imagestr.length>0){
            _iconNode.URL = [NSURL URLWithString:imagestr];
        } else  {
            _iconNode.image = [UIImage imageNamed:@"Avatar-nor"];
        }
        
        _iconNode.placeholderColor = MainBackgroundColor;
        
        _editImageNode = [ASImageNode new];
        [self addSubnode:_editImageNode];
        _editImageNode.image = [UIImage imageNamed:@"032_t"];
        
        _nameNode = [ASTextNode new];
        [self addSubnode:_nameNode];
            
        //名字赋值
        NSString *name;
        NSString *islogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsLogin];
        NSString *iswechatlogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsWeChatLogin];
        
        if (islogin.boolValue || iswechatlogin.boolValue) {
            name = _model.nickname;
            if (!isNSString(name)) {
                name = [[NSUserDefaults standardUserDefaults] objectForKey:kphoneNumberLogin];
            }
        } else {
            name = NSLocalizedString(@"未登录", nil);
            _iconNode.image = [UIImage imageNamed:@"Avatar-nor"];
        }
        
        if (!isNSString(name))
        {
            name = @"";
        }
        if (@available(iOS 8.2, *)) {
            _nameNode.attributedText = [[NSAttributedString alloc] initWithString:name attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:18 weight:UIFontWeightBold],NSForegroundColorAttributeName:UIColorFromRGB(0x666666)}];
        } else {
            _nameNode.attributedText = [[NSAttributedString alloc] initWithString:name attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:18],NSForegroundColorAttributeName:UIColorFromRGB(0x666666)}];
        }
        
//        _editImageNode.backgroundColor = [UIColor blackColor];
//        _backImageNode.backgroundColor = [UIColor orangeColor];
    }
    return self;
}


static CGFloat nodeSpacing = 20.0f;

-(ASLayoutSpec *)layoutSpecThatFits:(ASSizeRange)constrainedSize
{
    _backImageNode.style.preferredSize = CGSizeMake(SCREEN_WIDTH, NODE_HEIGHT);
    _backImageNode.style.layoutPosition = CGPointMake(0, 0);
    
    _nameNode.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH-40);
    
    _iconNode.style.preferredSize = CGSizeMake(iconWidth, iconWidth);
    _iconNode.style.layoutPosition = CGPointMake((SCREEN_WIDTH-iconWidth)/2, (NODE_HEIGHT-iconWidth-_nameNode.attributedText.size.height)/2);
    
    _editImageNode.style.preferredSize = CGSizeMake(editNodeWith, editNodeWith);
    _editImageNode.style.layoutPosition = CGPointMake(SCREEN_WIDTH/2+iconWidth/2-editNodeWith, (NODE_HEIGHT-iconWidth-_nameNode.attributedText.size.height)/2+iconWidth-editNodeWith);
    
    _nameNode.style.layoutPosition = CGPointMake((SCREEN_WIDTH-_nameNode.attributedText.size.width)/2, (NODE_HEIGHT-iconWidth-_nameNode.attributedText.size.height)/2+iconWidth+nodeSpacing-10);
    
    return [ASAbsoluteLayoutSpec absoluteLayoutSpecWithChildren:@[_iconNode,_editImageNode,_nameNode,_backImageNode]];
}

@end
