//
//  MineController.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "MineController.h"
#import "MineModel.h"
#import "MineNode.h"
#import "InfoNode.h"
#import "LogoutView.h"
#import "MInfoController.h"
#import "MAddressController.h"
#import "MRecommandController.h"
#import "MAboutController.h"
#import "YQPresentTransitionAnimated.h"
#import "YQDismissTransitionAnimated.h"
#import "BaseNavigationController.h"
#import "HomeController.h"
#import "MVipListController.h"
#import "AboutUsController.h"
#import "PromptView.h"
#import "LoginController.h"
#import "UserInfoModel.h"
#import "RelatedPhoneController.h"
#import "WXApi.h"
#import "UnbindWeChatview.h"

#import "BaseService.h"
#import "DataBaseManager.h"
#import "LGFileManager.h"
#import "LGUserNetWorkService.h"
#import "LgResultModel.h"

@interface MineController ()<ASTableDelegate,ASTableDataSource,UIViewControllerTransitioningDelegate>
{
    UIImage *_image;
    UserInfoModel *_model;
    NSString *_wechatid;
    NSString *_CompanyName;
}
@property (nonatomic,strong)ASTableNode *tableNode;
@property (nonatomic,strong)NSMutableArray *dataSource;
@property (nonatomic,strong)NSArray *titles;
@property (nonatomic,strong)NSArray *imageNames;

@property (nonatomic,strong)BaseService *baseService;


@end

@implementation MineController

//-(instancetype)init
//{
//    if (self = [super init])
//    {
//
//    }
//    return self;
//}

#pragma mark - UIViewControllerTransitioningDelegate
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return [[YQPresentTransitionAnimated alloc] init];
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    return [[YQDismissTransitionAnimated alloc] init];
}

- (void)setsubview
{
    _dataSource = [NSMutableArray arrayWithCapacity:4];
    _titles = [NSArray array];
    _imageNames = [NSArray array];
            
    //        NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    //
    //        if ([invitationCode isEqualToString:@"test"])
    //        {
    //            invitationCode = @"CasaOnline";
    //        }
            //马甲包改动
    _CompanyName = [self.baseService getCompanyNameByAPPTYPE:APPTYPE];
    _titles = @[
              //  NSLocalizedString(@"myMember", nil),
                NSLocalizedString(@"address", nil),
                _CompanyName,
                NSLocalizedString(@"logout", nil)
    ];
    _imageNames = @[
//                @"055",
        @"030_w",
        @"034_k",
        @"033_m"];
    [_dataSource removeAllObjects];
    for (int i = 0; i < _titles.count; i++)
    {
        MineModel *model = [MineModel new];
        model.imageName = _imageNames[i];
        model.title = _titles[i];
        [_dataSource addObject:model];
    }
    
    _tableNode = [[ASTableNode alloc] initWithStyle:UITableViewStyleGrouped];
    [self.view addSubnode:_tableNode];
//        _tableNode.view.bounces = NO;
    _tableNode.view.separatorColor = [UIColor whiteColor];
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, CGFLOAT_MIN)];
    _tableNode.view.tableFooterView = footerView;
    [_tableNode.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.mas_equalTo(self.view);
//            make.top.mas_equalTo(self.view).offset(-[UINavigationController new].navigationBar.frame.size.height-STATUSBAR_HEIGHT);
//            make.top.mas_equalTo(self.view).offset(0);
        make.top.mas_equalTo(self.view).offset(-[UINavigationController new].navigationBar.frame.size.height);
        
    }];
    NSLog(@"%f,%f",[UINavigationController new].navigationBar.frame.size.height,STATUSBAR_HEIGHT);
    _tableNode.delegate = self;
    _tableNode.dataSource = self;
    _tableNode.backgroundColor = MainBackgroundColor;
    WEAK_SELF(weakSelf);
    self.refresh = [[QPGRefreshTool alloc] init];
    [self.refresh gifModelRefresh:_tableNode.view refreshType:RefreshTypeDropDown firstRefresh:YES dropDownBlock:^{
        if ([weakSelf.tableNode.view.mj_header isRefreshing])
        {
            [weakSelf doNetworkRequestForHeader];
        }
    } upDropBlock:^{

    }];
}

-(void)viewDidLoad
{
    [super viewDidLoad];
    self.baseService = [[BaseService alloc] init];
    [self setsubview];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didReceivedUploadImageSuccessNotification:)
                                                 name:kUploadImageSuccessNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(bindwechat)
                                                 name:kWeChatSuccessNotification
                                               object:nil];
}

- (void)didReceivedUploadImageSuccessNotification:(NSNotification *)notification
{
    _image = [notification.userInfo objectForKey:kUploadImageSuccessNotification];
    [self.tableNode reloadData];
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
//    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
//    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    
//    [self.tableNode reloadData];
    NSIndexPath *indexPath=[NSIndexPath indexPathForRow:0 inSection:0];
    [self.tableNode reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];

    [self.navigationController setNavigationBarHidden:NO animated:YES];

}


#pragma mark delegate methods
-(NSInteger)numberOfSectionsInTableNode:(ASTableNode *)tableNode
{
    return self.dataSource.count + 1;
}

-(NSInteger)tableNode:(ASTableNode *)tableNode numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (!section)
    {
        return CGFLOAT_MIN;
    }
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return CGFLOAT_MIN;
}

-(ASCellNode *)tableNode:(ASTableNode *)tableNode nodeForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!indexPath.section)
    {
        InfoNode *node = [[InfoNode alloc] initWithUserInfoModel:_model];
        node.selectionStyle = UITableViewCellSelectionStyleNone;
        return node;
    }
    else
    {
        MineNode *node = [[MineNode alloc] initWithModel:self.dataSource[indexPath.section-1]];
        node.selectionStyle = UITableViewCellSelectionStyleNone;
        return node;
    }
}

-(void)tableNode:(ASTableNode *)tableNode didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *islogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsLogin];
    NSString *iswechatlogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsWeChatLogin];
    
    if (!islogin.boolValue && !iswechatlogin.boolValue)
    {
        [self showpromptloginview];
        return;
    }

    WEAK_SELF(weakSelf);
        //马甲包微信改动
    switch (APPTYPE) {
        case 24:
        {
            if (indexPath.section == 0)
            {
                MInfoController *lvc = [[MInfoController alloc] initWithImage:self->_image];
                lvc.userinfo = ^{
                    [weakSelf.refresh beginRefreshing];
                };
                [self.navigationController pushViewController:lvc animated:YES];
            } else if (indexPath.section == 1) {
                MineModel *model = self.dataSource[indexPath.section-1];
                
                if ([model.title isEqualToString:NSLocalizedString(@"已绑定微信", nil)])
                {
                    [self UnbindWeChat];
                } else if ([model.title isEqualToString:NSLocalizedString(@"未绑定微信", nil)]) {
                    [self wechatlogin];
                } else {
                    [self relatedphone];
                }
            } else if (indexPath.section == 2) {
//                MVipListController *lvc = [[MVipListController alloc] init];
//                [self.navigationController pushViewController:lvc animated:YES];
//            } else if (indexPath.section == 3) {
                MAddressController *lvc = [[MAddressController alloc] init];
                [self.navigationController pushViewController:lvc animated:YES];
            } else if (indexPath.section == 3) {
                MAboutController *lvc = [[MAboutController alloc] init];
                [self.navigationController pushViewController:lvc animated:YES];
            } else if (indexPath.section == 4) {
                [self logout];
            }
        }
            break;
            
        default:
        {
            if (!indexPath.section) {
                MInfoController *lvc = [[MInfoController alloc] initWithImage:self->_image];
                lvc.userinfo = ^{
                  [weakSelf.refresh beginRefreshing];
                };
                [self.navigationController pushViewController:lvc animated:YES];
            } else if (indexPath.section == 1) {
//                MVipListController *lvc = [[MVipListController alloc] init];
//                [self.navigationController pushViewController:lvc animated:YES];
//            } else if (indexPath.section == 2) {
                MAddressController *lvc = [[MAddressController alloc] init];
                [self.navigationController pushViewController:lvc animated:YES];
            } else if (indexPath.section == 2) {
                MAboutController *lvc = [[MAboutController alloc] init];
                [self.navigationController pushViewController:lvc animated:YES];
            } else if (indexPath.section == 3) {
                [self logout];
            }
        }
            break;
    }
}

- (void)logout
{
    //原有弹窗，使用的第三方库显示，不支持横屏
    LogoutView *view = [[LogoutView alloc] init];
    WEAK_SELF(weakSelf);
    view.cancel = ^{
        [weakSelf cancelCallback];
    };
    view.logout = ^{
        [weakSelf logoutCallback];
    };
    KLCPopup *popup = [KLCPopup popupWithContentView:view showType:KLCPopupShowTypeFadeIn dismissType:KLCPopupDismissTypeFadeOut maskType:KLCPopupMaskTypeDimmed dismissOnBackgroundTouch:NO dismissOnContentTouch:NO];
    [popup show];
}

- (void)logoutCallback
{
    [KLCPopup dismissAllPopups];
    [self doNetworkRequestForLogout];
}

- (void)doNetworkRequestForLogout
{
    [MBProgressHUD showGifToView:nil];
    [NetworkManager getWithURL:CREATE_URL(url_logout) params:nil success:^(id json) {
        [MBProgressHUD hideHUD];
        [self logoutSuccess:json];
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}

- (void)logoutSuccess:(id)json
{
    NSInteger state = [get_Value_for_key_from_obj(json, successKey) integerValue];
    switch (state) {
        case 1:
        {
            [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:kAutoLogin];
            [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kLoginCookies];
            
            // [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kUserName];
            [[NSUserDefaults standardUserDefaults] setValue:nil forKey:kUserName];
            [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kPassword];
                        
            // 退出完了要创建一个空的数据库
            DataBaseManager *db = [DataBaseManager shared];
            [db changeUser:nil];
            [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kIsLogin];
            [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kIsWeChatLogin];
            [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:Kopenid];
            [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kPhoneNumber];

            HomeController *bvc = [[HomeController alloc] init];
            bvc.isNeedShowTabbar = YES;
            [UIApplication sharedApplication].keyWindow.rootViewController = bvc;
            
        }
            break;
        default:
//            [MBProgressHUD showErrorMessage:get_Value_for_key_from_obj(json, messageKey)];
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"failure", nil)];
            break;
    }
}

- (void)cancelCallback
{
    [KLCPopup dismissAllPopups];
}

- (void)willPresentAlertView:(UIAlertView *)alertView {
    alertView.frame = CGRectMake( 110, 190, 100, 100 );
}

- (void)showpromptloginview
{
    PromptView *view = [[PromptView alloc] init];
    WEAK_SELF(weakSelf);
    view.cancel = ^{
        [weakSelf cancelCallback];
    };
    view.login = ^{
        [weakSelf loginCallback];
    };
    KLCPopup *popup = [KLCPopup popupWithContentView:view showType:KLCPopupShowTypeFadeIn dismissType:KLCPopupDismissTypeFadeOut maskType:KLCPopupMaskTypeDimmed dismissOnBackgroundTouch:NO dismissOnContentTouch:NO];
    [popup show];
}

- (void)loginCallback
{
    [KLCPopup dismissAllPopups];
    HomeController *homeVC = [[HomeController alloc] init];
    homeVC.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:homeVC animated:YES completion:nil];
}

- (void)doNetworkRequestForHeader
{
    
    NSString *islogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsLogin];
    NSString *iswechatlogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsWeChatLogin];
    
    if (!islogin.boolValue && !iswechatlogin.boolValue) {
        [self.refresh endRefresh];
        return;
    }
    
    WEAK_SELF(weakSelf);
    LGUserNetWorkService *userNetWorkService = [[LGUserNetWorkService alloc] init];
    [userNetWorkService getUserInfoWithCallBack:^(LgResultModel * _Nonnull result, UserInfoModel * _Nonnull userInfo) {
        [weakSelf.refresh endRefresh];

        if (result.isSucc) {
            _model = userInfo;
            [weakSelf refreshtablenode];
        } else {
            if ([result.stateCode intValue] == 0) {
                LGUserNetWorkService *userService = [[LGUserNetWorkService alloc] init];
                __strong __typeof(weakSelf)strongSelf = weakSelf;
                [userService autoLoginActionWithCallBack:^(LgResultModel * _Nonnull result, id  _Nullable json) {
                    if (result.isSucc) {
                        // 重新再调用一遍接口
                        [strongSelf doNetworkRequestForHeader];
                    } else {
                        HomeController *homeVC = [[HomeController alloc]init];
                        homeVC.modalPresentationStyle = UIModalPresentationFullScreen;
                        [strongSelf presentViewController:homeVC animated:YES completion:nil];
                    }
                }];
            } else {
                [MBProgressHUD showMessage:result.message];
            }
        }
    }];
}

- (void)refreshtablenode
{
    NSString *islogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsLogin];
    NSString *iswechatlogin = [[NSUserDefaults standardUserDefaults] objectForKey:kIsWeChatLogin];
    //马甲包微信改动
    switch (APPTYPE) {
        case 24:
        {
            if (islogin.boolValue || iswechatlogin.boolValue)
            {
                
                if (_model.phoneNumber.length>0)
                {
                    if (_model.weChatId.length>0)
                    {
                        _titles = @[NSLocalizedString(@"已绑定微信", nil),
                                    NSLocalizedString(@"myMember", nil),
                                    NSLocalizedString(@"address", nil),
                                    _CompanyName,
                                    NSLocalizedString(@"logout", nil)];
                        _imageNames = @[@"Wechat",@"055",@"030_w",@"034_k",@"033_m"];
                    }
                    else
                    {
                        _titles = @[NSLocalizedString(@"未绑定微信", nil),
                                    NSLocalizedString(@"myMember", nil),
                                    NSLocalizedString(@"address", nil),
                                    _CompanyName,
                                    NSLocalizedString(@"logout", nil)];
                        _imageNames = @[@"Mine_bindwechat",@"055",@"030_w",@"034_k",@"033_m"];
                    }
                }
                else
                {
                    _titles = @[NSLocalizedString(@"关联手机号码", nil),
                                NSLocalizedString(@"myMember", nil),
                                NSLocalizedString(@"address", nil),
                                _CompanyName,
                                NSLocalizedString(@"logout", nil)];
                    _imageNames = @[@"Mine_bindphone",@"055",@"030_w",@"034_k",@"033_m"];
                }
             
            }
            else
            {
                _titles = @[
//                            NSLocalizedString(@"myMember", nil),
                            NSLocalizedString(@"address", nil),
                            _CompanyName,
                            NSLocalizedString(@"logout", nil)];
                _imageNames = @[
//                            @"055",
                            @"030_w",
                            @"034_k",
                            @"033_m"];
            }
        }
            
            break;
        default:
        {
            _titles = @[
//                        NSLocalizedString(@"myMember", nil),
                        NSLocalizedString(@"address", nil),
                        _CompanyName,
                        NSLocalizedString(@"logout", nil)];
            _imageNames = @[
//                @"055",
                @"030_w",
                @"034_k",
                @"033_m"];
        }
            break;
    }
    [_dataSource removeAllObjects];
    for (int i = 0; i < _titles.count; i++)
    {
        MineModel *model = [MineModel new];
        model.imageName = _imageNames[i];
        model.title = _titles[i];
        [_dataSource addObject:model];
    }
    
    [self.tableNode reloadData];
}

- (void)bindwechat
{
    NSString *wechatid = [[NSUserDefaults standardUserDefaults] objectForKey:Kopenid];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:wechatid forKey:@"weChatId"];
    [params setObject:invitationCode forKey:@"invitationCode"];
    WEAK_SELF(weakeSelf);
    [MBProgressHUD showGifToView:nil];
    [NetworkManager postWithURL:CREATE_URL(url_user_bindingWeChat) params:params isUsedSignal:NO success:^(id json) {
        NSLog(@"Yjson=%@",json);
        [MBProgressHUD hideHUD];
        [weakeSelf bindwechatsuccess:json];
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}

- (void)UnbindWeChat
{
    UnbindWeChatview *view = [[UnbindWeChatview alloc] init];
    WEAK_SELF(weakSelf);
    view.cancel = ^{
        [weakSelf cancelCallback];
    };
    view.logout = ^{
        [weakSelf comfirmunbindwechat];
    };
    KLCPopup *popup = [KLCPopup popupWithContentView:view showType:KLCPopupShowTypeFadeIn dismissType:KLCPopupDismissTypeFadeOut maskType:KLCPopupMaskTypeDimmed dismissOnBackgroundTouch:NO dismissOnContentTouch:NO];
    [popup show];
}

- (void)comfirmunbindwechat
{
    [KLCPopup dismissAllPopups];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:invitationCode forKey:@"invitationCode"];
    WEAK_SELF(weakeSelf);
    [MBProgressHUD showGifToView:nil];
    [NetworkManager postWithURL:CREATE_URL(url_user_unbindWeChat) params:params isUsedSignal:NO success:^(id json) {
        [MBProgressHUD hideHUD];
        [weakeSelf unbindsuccesee:json];
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}

- (void)wechatlogin
{
    if ([WXApi isWXAppInstalled]) {
        
        NSString *openid = [[NSUserDefaults standardUserDefaults] objectForKey:Kopenid];
        
        if (openid.length>1)
        {
            [self bindwechat];
        }
        else
        {
            SendAuthReq *req = [[SendAuthReq alloc] init];
            req.state = @"App";
            req.scope = @"snsapi_userinfo";
            [WXApi sendReq:req completion:^(BOOL success) {
                
            }];
        }
        
    }
    else
    {
        
        [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:Kopenid];
        [MBProgressHUD showMessage:NSLocalizedString(@"您还没有安装微信", nil)];
    }
}

- (void)relatedphone
{
    RelatedPhoneController *rpVC = [[RelatedPhoneController alloc] init];
    rpVC.registerSuccessCallback = ^{
        [self.refresh beginRefreshing];
    };
    [self.navigationController pushViewController:rpVC animated:YES];
}

- (void)unbindsuccesee:(id)json
{
    NSString *state = get_Value_for_key_from_obj(json, successKey);
    
    if (state.intValue == 0)
    {
        HomeController *bvc = [[HomeController alloc] init];
        [UIApplication sharedApplication].keyWindow.rootViewController = bvc;
    }
    else if(state.intValue == 1)
    {
        [self .refresh beginRefreshing];
    }
    else
    {
        [MBProgressHUD showMessage:get_Value_for_key_from_obj(json, messageKey)];
    }
}

- (void)bindwechatsuccess:(id)json
{
    NSString *state = get_Value_for_key_from_obj(json, successKey);
    
    if (state.intValue == 0)
    {
        HomeController *bvc = [[HomeController alloc] init];
        [UIApplication sharedApplication].keyWindow.rootViewController = bvc;
    }
    else if(state.intValue == 1)
    {
        [self .refresh beginRefreshing];
    }
    else
    {
        [MBProgressHUD showMessage:get_Value_for_key_from_obj(json, messageKey)];
    }
}



@end
