//
//  UserInfoModel.h
//  BusinessOnline
//
//  Created by clitics on 2020/7/1.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UserInfoModel : NSObject

@property (nonatomic,copy)NSString *avatarpath;
@property (nonatomic,copy)NSString *cookie;
@property (nonatomic,copy)NSString *invitationQrImage;
@property (nonatomic,copy)NSString *isSale;
@property (nonatomic,copy)NSString *nickname;
@property (nonatomic,copy)NSString *phoneNumber;
@property (nonatomic,copy)NSString *userid;
@property (nonatomic,copy)NSString *weChat;
@property (nonatomic,copy)NSString *weChatId;

@end

NS_ASSUME_NONNULL_END
