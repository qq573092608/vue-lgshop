//
//  MineModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MineModel : NSObject

@property (nonatomic,copy)NSString *imageName;
@property (nonatomic,copy)NSString *title;

@end

NS_ASSUME_NONNULL_END
