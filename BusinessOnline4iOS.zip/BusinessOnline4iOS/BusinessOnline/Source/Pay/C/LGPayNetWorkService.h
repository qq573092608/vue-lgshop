//
//  LGPayNetWorkService.h
//  BusinessOnline
//
//  Created by lgerp on 2021/1/15.
//  Copyright © 2021 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LgResultModel;

/**
    绑定流水id的回调
 */
typedef void(^LGPayUpdateSerialNumberCallBack)(LgResultModel * _Nullable result);

/**
    Pending 或 Processed 或 Completed
 */
typedef void(^LGGetIpnCallBack)(LgResultModel * _Nullable result, NSString *paymentStatus);

/**
    更新支付状态的回调
 */
typedef void(^LGUpdatePayStateCallBack)(LgResultModel * _Nullable result);


NS_ASSUME_NONNULL_BEGIN

@interface LGPayNetWorkService : NSObject


// updatePayState

- (void)updatePayState:(NSString *)orderCodeStr
         paymentMethod:(NSString *)paymentMethod
              callBack:(LGUpdatePayStateCallBack)callBack;

/**
 流水id绑定给订单
 */
- (void)updatePaymentSerialNumberWithOrderCode:(NSString *)orderCode
                           paymentSerialNumber:(NSString *)paymentSerialNumber
                            callBack:(LGPayUpdateSerialNumberCallBack)callBack;

/**
   用交易id轮询等待真实交易结果
 */
- (void)getIpnWithTxnId:(NSString *)txnIdStr callBack:(LGGetIpnCallBack)callBack;

@end

NS_ASSUME_NONNULL_END
