//
//  PayViewController.h
//  BusinessOnline
//
//  Created by clitics on 2020/5/15.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PayViewController : UIViewController
@property (nonatomic,copy)NSString *currency;
@property (nonatomic,copy)NSString *clientid;
@property (nonatomic,copy)NSString *money;
@property (nonatomic,assign)int type;
@property (nonatomic,copy)NSString *ordercode;
@property (nonatomic,copy)NSString *paymethod;

/**
   交易流水号
 */
@property (nonatomic,copy)NSString *paymentSerialNumber;

@property (nonatomic,copy)void(^updatepaystate)(void);

@end

NS_ASSUME_NONNULL_END
