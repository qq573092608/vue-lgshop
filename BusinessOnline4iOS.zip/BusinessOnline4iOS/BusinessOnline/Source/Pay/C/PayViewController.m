//
//  PayViewController.m
//  BusinessOnline
//
//  Created by clitics on 2020/5/15.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "PayViewController.h"
#import <WebKit/WebKit.h>
#import "AppDelegate.h"
#import "NSString+Tool.h"
#import "LGPayLogicService.h"

#import "LGPayNetWorkService.h"
#import "LgResultModel.h"

@interface PayViewController ()<WKScriptMessageHandler,WKUIDelegate,WKNavigationDelegate> {
    
    /**
        时间事件源
     */
    dispatch_source_t _timer;
}
@property (nonatomic,strong)WKWebView *webView;
@property (nonatomic,assign)int ispay;
@property (nonatomic,copy)NSString *urlHost;

/**
   服务器端是否支付成功
 */
@property (nonatomic,assign)BOOL isServicerPaySucc;

@end

@implementation PayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _ispay = 0;
    [self setupSubViews];
    [self initWKWebView];
    self.isServicerPaySucc = NO;
}

- (void)initWKWebView {
    WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
    configuration.userContentController = [WKUserContentController new];

    WKPreferences *preferences = [WKPreferences new];
    preferences.javaScriptCanOpenWindowsAutomatically = YES;
    preferences.javaScriptEnabled = true;
//    preferences.minimumFontSize = 30.0;
//    WKProcessPool *processPool = [[WKProcessPool alloc] init];
//    configuration.processPool = processPool;
    configuration.preferences = preferences;
    
    WKUserContentController * wkUController = [[WKUserContentController alloc] init];
    [wkUController  addScriptMessageHandler:self name:@"interOp"];
    
//    WKUserScript * cookieScript = [[WKUserScript alloc] initWithSource:[self cookieJavaScriptString] injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
//    [wkUController addUserScript:cookieScript];
    
    configuration.userContentController = wkUController;
    
    self.webView = [[WKWebView alloc] initWithFrame:self.view.frame configuration:configuration];
    self.webView.UIDelegate = self;
    self.webView.navigationDelegate = self;

    NSString *urlStr = [[NSBundle mainBundle] pathForResource:@"paypal.html" ofType:nil];
    NSString *localHtml = [NSString stringWithContentsOfFile:urlStr encoding:NSUTF8StringEncoding error:nil];
    self.urlHost = urlStr;
    localHtml = [localHtml stringByReplacingOccurrencesOfString:@"{Currency}" withString:@"EUR"];
    localHtml = [localHtml stringByReplacingOccurrencesOfString:@"{ClientID}" withString:self.clientid];
    localHtml = [localHtml stringByReplacingOccurrencesOfString:@"{Money}" withString:self.money];
    NSURL *fileURL = [NSURL fileURLWithPath:urlStr];
    [self.webView loadHTMLString:localHtml baseURL:fileURL];
//    self.webView.UIDelegate = self;
//    self.webView.navigationDelegate = self;
    [self.view addSubview:self.webView];
}

- (void)setupSubViews
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 30, 30);
    [button setImage:[UIImage imageNamed:@"001_return"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = backItem;
}

#pragma mark - webview 代理
//开始加载
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
    NSLog(@"开始加载网页");
    [MBProgressHUD showGifToView:nil];
}
//加载完成
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    NSLog(@"加载完成");
    //加载完成隐藏progressView
    [MBProgressHUD hideHUD];
}
//加载失败
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    NSLog(@"加载失败");
    //加载失败隐藏progressView
    [MBProgressHUD hideHUD];
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message
{
    NSLog(@"name:%@\\\\n body:%@\\\\n frameInfo:%@\\\\n",message.name,message.body,message.frameInfo);
    
    if (message.body != nil) {
        
        NSDictionary *payDic = message.body;
                
        // 获取流水id
        NSArray *purchaseUnitsArr = payDic[@"purchase_units"];
        NSDictionary *paymentDic = [purchaseUnitsArr[0] valueForKey:@"payments"];
        NSArray *capturesArr = paymentDic[@"captures"];
        NSDictionary *payResDic = capturesArr[0];
        NSString *paymentSerialNumberIdStr = payResDic[@"id"];
        
        // 获取支付状态
       // NSString *payStateStr = payDic[@"status"];
        NSString *payStateStr = payResDic[@"status"];
        if (![paymentSerialNumberIdStr isEmptyString] && [LGPayLogicService isPaySuccess:payStateStr]) {
            _ispay = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:kPaymentcompletedNotification
                                                                object:self
                                                              userInfo:nil];
//            [MBProgressHUD showErrorMessage:NSLocalizedString(@"已付款", nil)];
            
            // 流水id绑定给订单
            [self updatePaymentSerialNumber:paymentSerialNumberIdStr orderCode:self.ordercode];

            // 用交易id轮询等待真实交易结果 (此处轮询30s 每1s查询一次)
            [self starTimeCount:paymentSerialNumberIdStr];
        }
    }
}

// 流水id绑定给订单
- (void)updatePaymentSerialNumber:(NSString *)paymentSerialNumberIdStr orderCode:(NSString *)orderCodeStr{
    
    LGPayNetWorkService *payNetWorkService = [[LGPayNetWorkService alloc] init];
    [payNetWorkService updatePaymentSerialNumberWithOrderCode:orderCodeStr
                                          paymentSerialNumber:paymentSerialNumberIdStr
                                                     callBack:^(LgResultModel * _Nullable result) {
        if (!result.isSucc) {
            [MBProgressHUD showErrorMessage:result.message];
        }
    }];
}

- (void)starTimeCount:(NSString *)serialNumberIdStr{
    NSDate * nowDate = [NSDate date];
    NSTimeInterval nowTime = [nowDate timeIntervalSince1970];
    [MBProgressHUD showGifToView:nil];
    [self getRealPayResultWithPayIdStr:serialNumberIdStr withStartTime:nowTime];
}

- (void)getRealPayResultWithPayIdStr:(NSString *)paymentSerialNumberIdStr withStartTime:(NSTimeInterval)startTime{
    
    LGPayNetWorkService *payNetWorkService = [[LGPayNetWorkService alloc] init];
    WEAK_SELF(weakSelf);
    [payNetWorkService getIpnWithTxnId:paymentSerialNumberIdStr
                              callBack:^(LgResultModel * _Nullable result, NSString *paymentStatus) {
        if (result.isSucc) {
            // 更新支付状态
            [weakSelf updatePayStateWithOrderCode:weakSelf.ordercode
                                paymentMethod:weakSelf.paymethod];
            [MBProgressHUD hideHUD];
            [weakSelf dismiss];
        } else {
            NSDate * nowDate = [NSDate date];
            NSTimeInterval now = [nowDate timeIntervalSince1970];
            NSTimeInterval newTime = now - startTime;
            if (newTime <= 30) {
                [weakSelf getRealPayResultWithPayIdStr:paymentSerialNumberIdStr withStartTime:startTime];
            } else {
                [MBProgressHUD hideHUD];
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"付款失败", nil)];
                [weakSelf dismiss];
            }
        }
    }];
}

- (void)updatePayStateWithOrderCode:(NSString *)orderCode
                      paymentMethod:(NSString *)paymentMethod {
    
    LGPayNetWorkService *payNetWorkService = [[LGPayNetWorkService alloc] init];
    [MBProgressHUD showGifToView:nil];
    [payNetWorkService updatePayState:orderCode
                        paymentMethod:paymentMethod
                             callBack:^(LgResultModel * _Nullable result) {
        [MBProgressHUD hideHUD];
        if (!result.isSucc) {
            [MBProgressHUD showErrorMessage:result.message];
        }
    }];
}

- (void)dismiss {
    if (_type == 0) {
        self.tabBarController.selectedIndex = 2;
        [[self navigationController] popToRootViewControllerAnimated:YES];
    } else {
        [self.navigationController popViewControllerAnimated:YES];
        if (_ispay==1) {
            if (self.updatepaystate) {
                self.updatepaystate();
            }
        }
    }
}



@end
