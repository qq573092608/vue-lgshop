//
//  LGPayNetWorkService.m
//  BusinessOnline
//
//  Created by lgerp on 2021/1/15.
//  Copyright © 2021 clitics. All rights reserved.
//

#import "LGPayNetWorkService.h"
#import "LgResultModel.h"
#import "LGPayLogicService.h"

@implementation LGPayNetWorkService

- (void)updatePaymentSerialNumberWithOrderCode:(NSString *)orderCode
                           paymentSerialNumber:(NSString *)paymentSerialNumber
                            callBack:(LGPayUpdateSerialNumberCallBack)callBack {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [params setValue:invitationCode forKey:@"invitationCode"];
    [params setValue:orderCode forKey:@"orderCode"];
    [params setValue:paymentSerialNumber forKey:@"paymentSerialNumber"];

    LgResultModel *resultModel = [[LgResultModel alloc] init];
    [NetworkManager postWithURL:CREATE_URL(url_updatePaymentSerialNumber) params:params isUsedSignal:NO success:^(id json) {
       
        resultModel.stateCode = get_Value_for_key_from_obj(json, successKey);
        resultModel.message = get_Value_for_key_from_obj(json, messageKey);
        if ([get_Value_for_key_from_obj(json, successKey) integerValue] == 1) {
            resultModel.isSucc = YES;
            callBack(resultModel);
        } else {
            resultModel.isSucc = NO;
            callBack(resultModel);
        }
    } failure:^(NSError *error) {
        resultModel.isSucc = NO;
        resultModel.message = error.localizedDescription;
        callBack(resultModel);
    }];
}

- (void)getIpnWithTxnId:(NSString *)txnIdStr callBack:(LGGetIpnCallBack)callBack {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [params setValue:invitationCode forKey:@"invitationCode"];
    [params setValue:txnIdStr forKey:@"txnId"];

    LgResultModel *resultModel = [[LgResultModel alloc] init];
    [NetworkManager postWithURL:CREATE_URL(url_getIpn) params:params isUsedSignal:NO success:^(id json) {
       
       // Pending 或 Processed 或 Completed
        resultModel.stateCode = get_Value_for_key_from_obj(json, successKey);
        resultModel.message = get_Value_for_key_from_obj(json, messageKey);
        
        NSString *paymentStatusStr = @"";
        NSLog(@"json is =======%@",json);
        
        if([json[@"data"] isKindOfClass:[NSDictionary class]]){
            paymentStatusStr = json[@"data"][@"paymentStatus"];
        }
        
        NSNumber *stateNum = get_Value_for_key_from_obj(json, successKey);
        if ([stateNum intValue] == 200
            && [LGPayLogicService isPaySuccess:paymentStatusStr]) {
            resultModel.isSucc = YES;
            callBack(resultModel,paymentStatusStr);
        } else {
            resultModel.isSucc = NO;
            callBack(resultModel,paymentStatusStr);
        }
    } failure:^(NSError *error) {
        resultModel.isSucc = NO;
        callBack(resultModel,@"");
    }];
}

- (void)updatePayState:(NSString *)orderCodeStr
         paymentMethod:(NSString *)paymentMethod
              callBack:(LGUpdatePayStateCallBack)callBack
{
    LgResultModel *resultModel = [[LgResultModel alloc] init];

    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:orderCodeStr forKey:@"orderCode"];
    [params setValue:invitationCode forKey:@"invitationCode"];
    [params setValue:paymentMethod forKey:@"paymentMethod"];
    
    [NetworkManager postWithURL:CREATE_URL(url_updatePayState)
                         params:params
                   isUsedSignal:NO
                        success:^(id json) {
        resultModel.message = get_Value_for_key_from_obj(json, messageKey);
        if ([get_Value_for_key_from_obj(json, successKey) integerValue] == 1) {
            resultModel.isSucc = YES;
        } else {
            resultModel.isSucc = NO;
        }
        
        callBack(resultModel);
    } failure:^(NSError *error) {
        resultModel.isSucc = NO;
        resultModel.message = error.localizedDescription;
        callBack(resultModel);
    }];
}

@end
