//
//  LGPayLogicService.m
//  BusinessOnline
//
//  Created by lgerp on 2021/1/15.
//  Copyright © 2021 clitics. All rights reserved.
//

#import "LGPayLogicService.h"

@implementation LGPayLogicService

+ (BOOL)isPaySuccess:(NSString *)payStatusStr
{
    BOOL isSucc = NO;
    NSString *stateStr = [payStatusStr uppercaseString];
    if ([stateStr isEqualToString:@"PENDING"]
        || [stateStr isEqualToString:@"PROCESSED"]
        || [stateStr isEqualToString:@"COMPLETED"]) {
        
        isSucc = YES;
    } else {
        isSucc = NO;
    }
    return isSucc;
}



@end
