//
//  LGAfterSaleDetailDesModel.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/15.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


/** 售后描述信息的对象 */
@interface LGAfterSaleDetailDesModel : NSObject

/** 描述的标题 */
@property (nonatomic, strong) NSString *detailTitleStr;

/** 描述的内容 */
@property (nonatomic, strong) NSString *detailContentStr;


@end

NS_ASSUME_NONNULL_END
