//
//  LGAfterSaleOrder.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/10.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGAfterSaleOrder : NSObject

/**
 请求参数：1.订单主键ID orderId
     2. 售后状态 orderState （2-仅退款，3-退货退款）
     3.详情集合 goodsOrderInfos
         对象属性：
             1.订单详情主键  orderInfoId
             2. 退款数量 quantity
     4.货物状态    cargoStatus（1 未收到货 ，2已收到货）
     5.退款原因 reasonForReturn（未收到货：1.空包裹/少货 2.快递一直未送到 3 其他， 已收到货：6.多拍/错拍/不想要 7.质量问题  8.其他）
     6.退货方式 returnMethod （1 送到店铺，2快递寄出）
     7.退款方式 refundMethod（1 PayPal，2 其他）
     8.退款说明 note
     9.微信 wechat
 */

/**
    订单主键ID
 */
@property (nonatomic, strong) NSString *orderId;

/**
    售后状态 orderState
 */
@property (nonatomic, strong) NSString *orderState;

/**
    详情集合 goodsOrderInfos
 */
@property (nonatomic, strong) NSArray *goodsOrderInfos;

/**
 .  货物状态    cargoStatus
 */
@property (nonatomic, strong) NSString *cargoStatus;

/**
 退款原因 reasonForReturn
 */
@property (nonatomic, strong) NSString *reasonForReturn;

/**
 .退货方式 returnMethod
 */
@property (nonatomic, strong) NSString *returnMethod;

/**
 退款方式 refundMethod
 */
@property (nonatomic, strong) NSString *refundMethod;

/**
 退款说明 note
 */
@property (nonatomic, strong) NSString *note;

/**
 微信 wechat
 */
@property (nonatomic, strong) NSString *wechat;

/** 总价 */
@property (nonatomic, strong) NSString *totalPrice;

/** 售后单的编号 */
@property (nonatomic, strong) NSString *bill_invoices_id;

/** 申请时间*/ 
@property (nonatomic, strong) NSString *applicationTime;

/** 退款方式的描述信息 */
@property (nonatomic, strong) NSString *returnMethodDesStr;



/// 初始化给（货物状态    cargoStatus、退款原因 reasonForReturn、退款方式 refundMethod)赋值
-(instancetype)init;


@end

NS_ASSUME_NONNULL_END
