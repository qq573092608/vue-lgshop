//
//  LGAfterSaleDetailDesModel.m
//  BusinessOnline
//
//  Created by lgerp on 2020/10/15.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGAfterSaleDetailDesModel.h"

@implementation LGAfterSaleDetailDesModel

@end
