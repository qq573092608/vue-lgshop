//
//  LGSellBackInfoModel.m
//  BusinessOnline
//
//  Created by lgerp on 2020/10/12.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGSellBackInfoModel.h"

@implementation LGSellBackInfoModel

@end
