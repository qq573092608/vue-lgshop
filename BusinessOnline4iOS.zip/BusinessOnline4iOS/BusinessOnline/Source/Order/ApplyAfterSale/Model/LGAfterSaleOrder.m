//
//  LGAfterSaleOrder.m
//  BusinessOnline
//
//  Created by lgerp on 2020/10/10.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGAfterSaleOrder.h"

@implementation LGAfterSaleOrder

-(instancetype)init
{
    self = [super init];
    if (self) {
        self.cargoStatus = @"";
        self.reasonForReturn = @"";
        self.refundMethod = @"";
        
    }
    return self;
}


@end
