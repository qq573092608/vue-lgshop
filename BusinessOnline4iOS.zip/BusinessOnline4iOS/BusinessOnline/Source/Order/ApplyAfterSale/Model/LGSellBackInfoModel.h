//
//  LGSellBackInfoModel.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/12.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGSellBackInfoModel : NSObject

/** 退货单单据id*/
@property (nonatomic, strong) NSString *sell_back_id;
/** 商品条码*/
@property (nonatomic, strong) NSString *goods_code;
/** 商品意大利名*/
@property (nonatomic, strong) NSString *italian_name;
/** 商品中文名称*/
@property (nonatomic, strong) NSString *zh_name;
/** 货号*/
@property (nonatomic, strong) NSString *spec;

/** 单品进价*/
@property (nonatomic, strong) NSString *p_price;
/** 单品售价*/
@property (nonatomic, strong) NSString *s_price;
/** iva*/
@property (nonatomic, strong) NSString *iva;
/** 退货小计*/
@property (nonatomic, strong) NSString *totalPrice;
/** 退货折扣价*/
@property (nonatomic, strong) NSString *discountPrice;

@property (nonatomic, strong) NSString *syncCode;
/** 售后单单据编号*/
@property (nonatomic, strong) NSString *bill_invoices_id;
/** 货物状态    1 未收到货 ，2已收到货*/
@property (nonatomic, strong) NSString *cargoStatus;
/** 退款原因  未收到货：1.空包裹/少货 2.快递一直未送到 3 其他， 已收到货：6.多拍/错拍/不想要 7.质量问题  8.其他*/
@property (nonatomic, strong) NSString *reasonForReturn;
/** 退货方式 1 送到店铺，2快递寄出*/
@property (nonatomic, strong) NSString *returnMethod;

/** 退款方式 1payPal，2其他*/
@property (nonatomic, strong) NSString *refundMethod;
/** 退款说明*/
@property (nonatomic, strong) NSString *note;
/** 申请时间*/
@property (nonatomic, strong) NSString *applicationTime;
/** 微信*/
@property (nonatomic, strong) NSString *wechat;
/** 退货数量*/
@property (nonatomic, assign) int returnQuantity;

/** 订单详情ID*/
@property (nonatomic, strong) NSString *goods_id;

@property (nonatomic, strong) NSString *tasteIds;

/** //售后单详情状态 0-等待审核，1-已同意，2-等待商家确认，3-等待用户确认，4-已完成，5-已拒绝*/
@property (nonatomic, strong) NSString *infoStatus;

/** 退货单据类型    1-取消订单，2-仅退款，3-退货退款 */
@property (nonatomic, strong) NSString *infoType;

@end

NS_ASSUME_NONNULL_END
