//
//  ApplyAfterSaleLogicService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/12.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LGAfterSaleDetailDesModel;

NS_ASSUME_NONNULL_BEGIN

typedef enum : NSUInteger {
    kGetProductTypeMoney,  // 退款
    kGetProductTypeMoneyAndGoods,  // 退货退款
} GetProductType;


/// 售后逻辑处理类
@interface ApplyAfterSaleLogicService : NSObject


/// 根据大类以及退货退款类别
/// @param singalOrMutablApplyType 单个商品还是批量商品
/// @param getProductType 退货退款
/// @param isPaypal 是否是Paypal支付
/// @param indexPath 选中的行树
+ (NSString *)getApplyReasonInfoByApplyType:(SingalOrMutableType)singalOrMutablApplyType
                            getProductType:(GetProductType)getProductType
                                   isPayPal:(BOOL)isPaypal
                                  indexPath:(NSIndexPath *)indexPath;



///  根据售后处理的状态显示对应的文案
/// @param backinfoStatus 售后处理的状态
+ (LGAfterSaleDetailDesModel *)getAfterSaleProcessingState:(NSString *)backinfoStatus backSaleType:(NSString *)backSaleType;


///  截取掉时间最后返回的".0"字符串
/// @param sourceTimeStr 服务器返回的时间
+ (NSString *)getApplycationTimeBySubString:(NSString *)sourceTimeStr;


///  是否超过申请售后的时间
/// @param comTime 完成时间
+ (BOOL)isAfterSaleOverTime:(NSString *)comTime;


///  是否是PayPal支付方式(YES:PayPal支付  NO:其他支付方式)
/// @param paymentMethodStr 支付方式的字符串
+ (BOOL)isPayPalPaymentMethod:(NSString *)paymentMethodStr;

@end

NS_ASSUME_NONNULL_END
