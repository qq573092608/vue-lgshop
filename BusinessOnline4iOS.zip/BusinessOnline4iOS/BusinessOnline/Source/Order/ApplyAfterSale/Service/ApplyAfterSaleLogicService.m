//
//  ApplyAfterSaleLogicService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/10/12.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "ApplyAfterSaleLogicService.h"
#import "LGAfterSaleDetailDesModel.h"
#import "NSString+Tool.h"
#import "BaseService.h"

@implementation ApplyAfterSaleLogicService


+ (NSString *)getApplyReasonInfoByApplyType:(SingalOrMutableType)singalOrMutablApplyType
                            getProductType:(GetProductType)getProductType
                                   isPayPal:(BOOL)isPaypal
                                  indexPath:(NSIndexPath *)indexPath
{
    if (singalOrMutablApplyType == kSingalOrMutableTypeSigal) {
        
        if (getProductType == kGetProductTypeMoney) {
            if (indexPath.section == 3) {
                // cargoStatus（1 未收到货 ，2已收到货）
                if (indexPath.row == 0) {
                    return @"1";
                } else if(indexPath.row == 1){
                    return @"2";
                }
            } else if (indexPath.section == 4) {
                // 退款原因 reasonForReturn（未收到货：1.空包裹/少货 2.快递一直未送到 3 其他， ）
                if (indexPath.row == 0) {
                    return @"1";
                } else if(indexPath.row == 1){
                    return @"2";
                } else if(indexPath.row == 2){
                    return @"3";
                }
            } else if (indexPath.section == 5) {
                //     7.退款方式 refundMethod（PayPal，其他）
                if (isPaypal) {
                    if (indexPath.row == 0) {
                        return @"PayPal:";
                    } else if(indexPath.row == 1){
                        return @"其他:";
                    }
                } else {
                    return @"其他";
                }
            }
        } else {
            if (indexPath.section == 3) {
                // 退款原因 reasonForReturn（已收到货：6.多拍/错拍/不想要 7.质量问题  8.其他）
                if (indexPath.row == 0) {
                    return @"6";
                } else if(indexPath.row == 1){
                    return @"7";
                } else if(indexPath.row == 2){
                    return @"8";
                }
            } else if (indexPath.section == 4) {
                //     7.退款方式 refundMethod（Paypal，其他）
                if (isPaypal) {
                    if (indexPath.row == 0) {
                        return @"PayPal:";
                    } else if(indexPath.row == 1){
                        return @"其他:";
                    }
                } else {
                    return @"其他";
                }
            }
        }
    } else {
        if (getProductType == kGetProductTypeMoney) {
            if (indexPath.section == 2) {
                // cargoStatus（1 未收到货 ，2已收到货）
                if (indexPath.row == 0) {
                    return @"1";
                } else if(indexPath.row == 1){
                    return @"2";
                }
            } else if (indexPath.section == 3) {
                // 退款原因 reasonForReturn（未收到货：1.空包裹/少货 2.快递一直未送到 3 其他， ）
                if (indexPath.row == 0) {
                    return @"1";
                } else if(indexPath.row == 1){
                    return @"2";
                } else if(indexPath.row == 2){
                    return @"3";
                }
            } else if (indexPath.section == 4) {
                //     7.退款方式 refundMethod（PayPal，其他）
                if (isPaypal) {
                    if (indexPath.row == 0) {
                        return @"PayPal:";
                    } else if(indexPath.row == 1){
                        return @"其他:";
                    }
                } else {
                    return @"其他";
                }
            }
        } else {
            if (indexPath.section == 2) {
                // 退款原因 reasonForReturn（已收到货：6.多拍/错拍/不想要 7.质量问题  8.其他）
                if (indexPath.row == 0) {
                    return @"6";
                } else if(indexPath.row == 1){
                    return @"7";
                } else if(indexPath.row == 2){
                    return @"8";
                }
            } else if (indexPath.section == 3) {
                //     7.退款方式 refundMethod（PayPal，其他）
                if (isPaypal) {
                    if (indexPath.row == 0) {
                        return @"PayPal:";
                    } else if(indexPath.row == 1){
                        return @"其他:";
                    }
                } else {
                    return @"其他";
                }
            }
        }
    }
    
    return @"";
}

+ (LGAfterSaleDetailDesModel *)getAfterSaleProcessingState:(NSString *)backinfoStatus backSaleType:(NSString *)backSaleType
{
    // 获取商家联系方式
    NSString *contactInfoStr = [[NSUserDefaults standardUserDefaults] valueForKey:kAfterSalesContactInformation];
    NSString *endStr = NSLocalizedString(@"进行沟通处理", nil);

    LGAfterSaleDetailDesModel *desModel = [[LGAfterSaleDetailDesModel alloc] init];
        
    if ([backSaleType isEqualToString:@"2"]) {
        
        if ([backinfoStatus isEqualToString:@"0"]) {
            desModel.detailTitleStr = NSLocalizedString(@"商家处理中", nil);
            desModel.detailContentStr = NSLocalizedString(@"您已成功发起退款申请，由于订单过多，请耐心等待商家处理", nil);
        } else if([backinfoStatus isEqualToString:@"1"]
                  || [backinfoStatus isEqualToString:@"2"]
                  || [backinfoStatus isEqualToString:@"3"]){
            
            desModel.detailTitleStr = NSLocalizedString(@"商家同意您的退款申请", nil);
            NSString *starStr = NSLocalizedString(@"商家已同意您的退款请求,稍后会将退款退还给您,若迟迟未收到退款,请联系商家", nil);
            desModel.detailContentStr = [NSString stringWithFormat:@"%@%@.",starStr,contactInfoStr];
        } else if([backinfoStatus isEqualToString:@"4"]){
            
            desModel.detailTitleStr = NSLocalizedString(@"该商品已退款完成", nil);
            desModel.detailContentStr = NSLocalizedString(@"商家已将退款退还给您,本次售后已完成,期待下次为您服务", nil);;
        } else if([backinfoStatus isEqualToString:@"5"]){
            
            desModel.detailTitleStr = NSLocalizedString(@"商家拒绝您的退款申请", nil);
            NSString *starStr = NSLocalizedString(@"商家已拒绝您的退款请求,若有其他疑问,请联系商家", nil);
            if ([BaseService isItalyLanguage]) {
                desModel.detailContentStr = [NSString stringWithFormat:@"%@%@%@",starStr,contactInfoStr,NSLocalizedString(@"意文商家", nil)];
            }  else if([BaseService isChinaLanguage]) {
                desModel.detailContentStr = [NSString stringWithFormat:@"%@%@%@",starStr,contactInfoStr,endStr];
            } else {
                desModel.detailContentStr = [NSString stringWithFormat:@"%@%@.",starStr,contactInfoStr];
            }
        }
    } else if ([backSaleType isEqualToString:@"3"]){
        
        if ([backinfoStatus isEqualToString:@"0"]) {
            desModel.detailTitleStr = NSLocalizedString(@"商家处理中", nil);
            desModel.detailContentStr = NSLocalizedString(@"您已成功发起退货申请,由于订单过多,请耐心等待商家处理", nil);
        }else if([backinfoStatus isEqualToString:@"1"]
                  || [backinfoStatus isEqualToString:@"2"]
                  || [backinfoStatus isEqualToString:@"3"]){
            desModel.detailTitleStr = NSLocalizedString(@"商家同意您的退货申请", nil);
            
            NSString *starStr = NSLocalizedString(@"商家已同意您的退货请求,请联系商家", nil);
            
            if ([BaseService isChinaLanguage]) {
                desModel.detailContentStr = [NSString stringWithFormat:@"%@%@%@",starStr,contactInfoStr,endStr];
            } else {
                desModel.detailContentStr = [NSString stringWithFormat:@"%@%@%@",starStr,contactInfoStr,NSLocalizedString(@"沟通退货", nil)];
            }
        } else if([backinfoStatus isEqualToString:@"4"]){
            
            desModel.detailTitleStr = NSLocalizedString(@"该商品已退货完成", nil);
            desModel.detailContentStr = NSLocalizedString(@"商家已收到您的退货商品,并已将退款退还给您,本次售后已完成,期待下次为您服务", nil);
        } else if([backinfoStatus isEqualToString:@"5"]){
            
            desModel.detailTitleStr = NSLocalizedString(@"商家拒绝您的退货申请", nil);
            NSString *starStr = NSLocalizedString(@"商家已拒绝您的退货请求,若有其他疑问,请联系商家", nil);
            if ([BaseService isItalyLanguage]) {
                desModel.detailContentStr = [NSString stringWithFormat:@"%@%@%@",starStr,contactInfoStr,NSLocalizedString(@"意文商家", nil)];
            } else if([BaseService isChinaLanguage]){
                desModel.detailContentStr = [NSString stringWithFormat:@"%@%@%@",starStr,contactInfoStr,endStr];
            } else {
                desModel.detailContentStr = [NSString stringWithFormat:@"%@%@.",starStr,contactInfoStr];
            }
        }
    }
    return  desModel;
}


+ (NSString *)getApplycationTimeBySubString:(NSString *)sourceTimeStr
{
    if (sourceTimeStr == nil
        || sourceTimeStr.length == 0) {
        return @"";
    }
    
    NSString *rightTimeStr = @"";
    if (sourceTimeStr.length == 21) {
        rightTimeStr = [sourceTimeStr substringToIndex:sourceTimeStr.length - 2];
    } else {
        rightTimeStr = sourceTimeStr;
    }
    return rightTimeStr;
}


+ (BOOL)isAfterSaleOverTime:(NSString *)comTime
{
    if (comTime.length != 0) {
        NSDateComponents *dateCom = [NSString getTimeInfoByStarTime:comTime];
        NSString *afterSaleValidPeriod = [[NSUserDefaults standardUserDefaults] valueForKey:kAfterSalesValidPeriod];
        // 时间超过售后申请的时限
        if (dateCom.day > afterSaleValidPeriod.integerValue) {
            return YES;
        } else {
            return NO;
        }
    } else {
        return NO;
    }
}

+ (BOOL)isPayPalPaymentMethod:(NSString *)paymentMethodStr
{
    if ([paymentMethodStr isEqualToString:@"PayPal"]) {
        return YES;
    } else {
        return NO;
    }
}

@end
