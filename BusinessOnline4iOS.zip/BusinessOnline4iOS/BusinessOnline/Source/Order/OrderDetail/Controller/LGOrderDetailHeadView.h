//
//  LGOrderDetailHeadView.h
//  BusinessOnline
//
//  Created by lgerp on 2020/11/20.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OrderStatusModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LGOrderDetailHeadView : UIView

// 内容部分
@property (weak, nonatomic) IBOutlet UILabel *userLbl;

@property (weak, nonatomic) IBOutlet UILabel *phoneLbl;

@property (weak, nonatomic) IBOutlet UILabel *orderTimeLbl;

@property (weak, nonatomic) IBOutlet UILabel *addressLbl;

@property (weak, nonatomic) IBOutlet UILabel *totalOrderPrice;

@property (weak, nonatomic) IBOutlet UILabel *deliveryMoneyLbl;


/** 根据订单信息填充内容 */
- (void)setUpViewWithOrderInfo:(OrderStatusModel *) orderInfo;


@end

NS_ASSUME_NONNULL_END
