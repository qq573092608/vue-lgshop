//
//  LGOrderDetailHeadView.m
//  BusinessOnline
//
//  Created by lgerp on 2020/11/20.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGOrderDetailHeadView.h"
#import "OrderStatusModel.h"

@interface LGOrderDetailHeadView ()

@property (weak, nonatomic) IBOutlet UILabel *contactLbl;
@property (weak, nonatomic) IBOutlet UILabel *orderRever;
@property (weak, nonatomic) IBOutlet UILabel *orderTime;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UILabel *amount;
@property (weak, nonatomic) IBOutlet UILabel *deliveryLbl;

@property (nonatomic, strong) OrderStatusModel *statusModel;

@end


@implementation LGOrderDetailHeadView


- (void)setUpViewWithOrderInfo:(OrderStatusModel *) orderInfo
{
    self.statusModel = orderInfo;
    
    self.contactLbl.text = NSLocalizedString(@"收货人", nil);
    self.orderRever.text = NSLocalizedString(@"联系方式", nil);
    self.orderTime.text = NSLocalizedString(@"下单时间", nil);
    self.address.text = NSLocalizedString(@"收货地址", nil);
    self.amount.text = NSLocalizedString(@"商品金额", nil);
    self.deliveryLbl.text = NSLocalizedString(@"配送费:", nil);
    NSString *name = self.statusModel.collectName;
    if (!isNSString(name)) {
        name = @"";
    }
    self.userLbl.text = name;
    
    NSString *phone = _statusModel.collectPhone;
    if (!isNSString(phone))
    {
        phone = @"";
    }
    self.phoneLbl.text = phone;

    NSString *time = _statusModel.createDate;
    if (!isNSString(time))
    {
        time = @"";
    }
    self.orderTimeLbl.text = time;

    NSString *address = _statusModel.address;
    if (!isNSString(address))
    {
        address = @"";
    }
    self.addressLbl.text = address;

    NSString *price = _statusModel.amount;
    if (!isNSString(price))
    {
        price = @"";
    }
    self.totalOrderPrice.text = [NSString stringWithFormat:@"€ %.2f ",price.floatValue];
//    self.totalOrderPrice.font = [UIFont systemFontOfSize:16.0f weight:bold];
    NSString *delivery = _statusModel.freightAmount;
    self.deliveryMoneyLbl.text = [NSString stringWithFormat:@"€ %.2f ",delivery.floatValue];
}


@end
