//
//  OrderDetailController.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "OrderDetailController.h"
#import "OrderStatusModel.h"
#import "OrderStatusNode.h"
#import "OrderProductNode.h"
#import "OrderDetailModel.h"
#import "OrderDetailOrderModel.h"
#import "HomeController.h"
#import "PayViewController.h"
#import "PayModel.h"

#import "BaseService.h"
#import "LGOrderNetWorkService.h"
#import "LgResultModel.h"
#import "LGApplyAfterSaleVC.h"
#import "OrderDetailBottomView.h"

#import "OrderDetailCell.h"
#import "OrderDetailHeadCell.h"
#import "ApplyAfterSaleDetail.h"
#import "NSString+Tool.h"

#import "ApplyAfterSaleLogicService.h"
#import "UIColor+HexString.h"
#import "LGOrderLogicService.h"
#import "LgMerchantNetworkService.h"
#import "MerchantInfoModel.h"

#import "LGOrderNetWorkService.h"
#import "LGOrderDetailHeadView.h"

@interface OrderDetailController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSString *_text;
    /** 包含订单的所有信息以及状态最外层的 */
    OrderStatusModel *_normalUserOrderModel;

    NSString *_ClientID;
    
    // 定义变量存储全选按钮
    UIButton *_tempSelAllBtn;
    
    // 定义变量存储批量申请按钮
    UIButton *_mutalApplyBtn;
    
    // 全选的标签
    UILabel *_checkAllLbl;
    
    /** 单个的选中项 */
    OrderProductListModel *_productModel;
    
    /** 选中的section */
    NSIndexPath *_selectedIndexPath;
    
    /** 底部视图 */
    OrderDetailBottomView *_tempBottomView;
}
@property (nonatomic,strong)UITableView *tableView;

/** 批量申请数据  */
@property (nonatomic,strong) NSMutableArray *mutalSendArr;

/** 商品请求服务类 */
@property (nonatomic, strong) LgMerchantNetworkService *merchantNetworkService;

/** 订单网络请求服务类 */
@property (nonatomic, strong) LGOrderNetWorkService *orderNetWorkService;

/** 产品头部视图 */
@property (nonatomic, strong) LGOrderDetailHeadView *productDetailHeadView;

@end

@implementation OrderDetailController

-(void)viewDidLoad
{
    [super viewDidLoad];
    self.title = NSLocalizedString(@"order_details", nil);
}

-(instancetype)initWithText:(NSString *)text indexPath:(nonnull NSIndexPath *)selectIndexPath
{
    if (self = [super init]) {
        if (!isNSString(text)) {
            text = @"";
        }
        _text = [text copy];
        _selectedIndexPath = selectIndexPath;
       
        [self.view addSubview:self.productDetailHeadView];
        [self.productDetailHeadView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.mas_equalTo(self.view);
            make.height.mas_equalTo(@(210 - 5));
        }];
        
        [self.view addSubview:self.tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.productDetailHeadView.mas_bottom).offset(15);
            make.left.bottom.right.mas_equalTo(self.view);
        }];
        // 加载数据
        [self doNetworkRequestForHeader];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        
        self.emptyModel = [[EmptyModel alloc] initWithScrollView:_tableView type:ControllerStateNormal];
    }
    return self;
}

- (void)doNetworkRequestForHeader {
    WEAK_SELF(weakSelf);
    LGOrderNetWorkService *orderNetworkService = [[LGOrderNetWorkService alloc] init];
    [orderNetworkService getOrderDetailByOrderCode:_text
                                      withCallBack:^(LgResultModel * _Nonnull res, OrderStatusModel * _Nullable orderStatusModel) {
        if (res.isSucc) {
            _normalUserOrderModel = orderStatusModel;
            if (!_normalUserOrderModel) {
                [weakSelf.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
                return;
            } else {
                [weakSelf configView];
            }
            [weakSelf.tableView reloadData];
        } else {
            [MBProgressHUD showErrorMessage:res.errMsg];
            [weakSelf.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
        }
    }];
}

- (void)isAfterSaleOverTime{
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"您已错过了申请售后的时间段,如果你有售后需求,请联系商家", nil)
                                                                       message:nil
                                                                preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* quedingAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"queding", nil) style:UIAlertActionStyleDefault
                                                              handler:^(UIAlertAction * action) {
                                                              }];
        [alert addAction:quedingAction];
        [self presentViewController:alert animated:YES completion:nil];
}

- (void)configView {
    
    if (_tempBottomView != nil) {
        [_tempBottomView removeFromSuperview];
    }
    // 填充头部数据
    [self.productDetailHeadView setUpViewWithOrderInfo:_normalUserOrderModel];
    
    if ([LGOrderLogicService isBottomViewNeedShowWithOrderState:_normalUserOrderModel.orderState
                                                      backState:_normalUserOrderModel.backStatus
                                                       isPayPal:_normalUserOrderModel.paymentMethod
                                                       payState:_normalUserOrderModel.payState.intValue
                                                 goodsOrderList:_normalUserOrderModel.goodsOrderInfos]) {
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.productDetailHeadView.mas_bottom).offset(15);
            make.left.right.mas_equalTo(self.view);
            make.bottom.mas_equalTo(self.view).offset(-55);
        }];

        WEAK_SELF(weakSelf);
        OrderDetailBottomView *bottomView = [[OrderDetailBottomView alloc] initWithOrderStatusModel:_normalUserOrderModel];
        /**全选按钮 */
        _tempSelAllBtn = bottomView.checkStateBtn;
        _mutalApplyBtn = bottomView.mutableCheckBtn;
        _checkAllLbl = bottomView.checkAll;
        _tempBottomView = bottomView;
        // 隐藏左边全选试图
        [self hiddenCheckAllView];
        // 全选按钮
        bottomView.selectAllCallBack = ^(UIButton *btn) {
            if ( !_normalUserOrderModel) {
                return;;
            }
            
            // 暂时不需要取消全选效果
            // 1代表全选 2:代表取消全选
            if (self.mutalSendArr.count == _normalUserOrderModel.goodsOrderInfos.count) {
                [weakSelf.tableView reloadData];
                btn.tag = 1;
                [btn setBackgroundImage:[UIImage imageNamed:@"icon_check_disa"]
                               forState:UIControlStateNormal];
                [self.mutalSendArr removeAllObjects];
            } else {
                [self.mutalSendArr removeAllObjects];
                [_normalUserOrderModel.goodsOrderInfos enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    [weakSelf.tableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:(idx)]
                                                    animated:NO
                                              scrollPosition:UITableViewScrollPositionNone];
                }];
                
                btn.tag = 2;
                [btn setBackgroundImage:[UIImage imageNamed:@"icon_check_sel"]
                               forState:UIControlStateNormal];
                // 全部添加
                [self.mutalSendArr addObjectsFromArray:_normalUserOrderModel.goodsOrderInfos];
            }
            
            [self setMutaApplyBtnStatus];
        };
        
        // 批量提交按钮
        bottomView.mutApplyCallBack = ^{
            
            if (weakSelf.mutalSendArr.count == 0) {
                if ([weakSelf.tableView isEditing]) {
                    [weakSelf.tableView setEditing:NO animated:YES];
                    [weakSelf hiddenCheckAllView];
                } else {
                    [weakSelf.tableView setEditing:YES animated:YES];
                    [weakSelf showCheckAllView];
                }
            } else {
                // _normalUserOrderModel.goodsOrderInfos[indexPath.section-1]
                LGApplyAfterSaleVC *applyVC = [[LGApplyAfterSaleVC alloc] init];
                if (weakSelf.mutalSendArr.count > 1) {
                    applyVC.singalOrMutableType = kSingalOrMutableTypeMutable;
                    applyVC.orderInfo = _normalUserOrderModel;
                    applyVC.sendMutalData = weakSelf.mutalSendArr;
                } else {
                    applyVC.singalOrMutableType = kSingalOrMutableTypeSigal;
                    applyVC.applySaleProductInfo = _productModel;
                    applyVC.orderInfo = _normalUserOrderModel;
                }
                [weakSelf.navigationController pushViewController:applyVC animated:YES];
            }
            [weakSelf setMutaApplyBtnStatus];
        };
        
        // 支付提交响应
        bottomView.paypalSubmitCallBack = ^(OrderStatusModel * _Nonnull orderStatusModel) {
            [weakSelf gotopaypalhtml];
        };
        
        // 取消订单
        bottomView.cancelOrderAction = ^{
            [weakSelf cancelOrderAction];
        };
        
        /**  确认完成 */
        bottomView.confrimFinishActionCallBack = ^{
            [weakSelf confrimOrderFinished];
        };
        
        [self.view addSubview:bottomView];
        [bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.mas_equalTo(self.view);
            make.height.equalTo(@55);
        }];
    } else {
        [self.tableView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.productDetailHeadView.mas_bottom).offset(15);
            make.left.bottom.right.mas_equalTo(self.view);
        }];
    }
}

#pragma mark delegate methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (_normalUserOrderModel.goodsOrderInfos.count) {
        return _normalUserOrderModel.goodsOrderInfos.count;
    }
    return 0;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   return 1;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleDelete | UITableViewCellEditingStyleInsert;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    WEAK_SELF(weakSelf);
    // 订单详情的列表信息
    OrderProductListModel *model = [OrderProductListModel mj_objectWithKeyValues:_normalUserOrderModel.goodsOrderInfos[indexPath.section]];
    OrderDetailCell *cell = [OrderDetailCell cellWithTableView:tableView
                                               withProductInfo:model
                                                    orderState:_normalUserOrderModel.orderState
                                               selectIndexPath:indexPath];
    _productModel = model;
    
    // 是否超过售后期限
    if ([ApplyAfterSaleLogicService isAfterSaleOverTime:_normalUserOrderModel.collectDate]) {
        [cell.applySellBtn setTitleColor:[UIColor ColorWithHexString:@"#E0E0E0"]
                                forState:UIControlStateNormal];
        cell.applySellBtn.layer.borderColor = [UIColor ColorWithHexString:@"#E6E6E6"].CGColor;
    } else {
        [cell.applySellBtn setTitleColor:[UIColor ColorWithHexString:@"#484244"] forState:UIControlStateNormal];
    }
    
    /** 只有在已完成状态下 才显示申请售后按钮 */
    if (![_normalUserOrderModel.orderState isEqualToString:@"3"]) {
        cell.applySellBtn.hidden = YES;
    } else {
        cell.applySellBtn.hidden = NO;
    }
    // 申请售后点击事件
    cell.applyActionCallBack = ^(OrderProductListModel *productModel, NSIndexPath *selectIndexPath) {
        
        // 是否超过申请售后的时限
        if ([ApplyAfterSaleLogicService isAfterSaleOverTime:_normalUserOrderModel.collectDate]) {
            [weakSelf isAfterSaleOverTime];
        } else {
            if (productModel.backInfoStatus.length == 0
                || ([productModel.infoType isEqualToString:@"1"]
                    && productModel.backInfoStatus.length != 0)) {
                
                LGApplyAfterSaleVC *applyVC = [[LGApplyAfterSaleVC alloc] init];
                if (self.mutalSendArr.count > 1) {
                    applyVC.singalOrMutableType = kSingalOrMutableTypeMutable;
                    applyVC.orderInfo = _normalUserOrderModel;
                    
                    if ([self.tableView isEditing]) {
                        applyVC.sendMutalData = self.mutalSendArr;
                    } else {
                        NSMutableArray *tempSendData = [[NSMutableArray alloc] init];
                        [tempSendData addObject:_normalUserOrderModel.goodsOrderInfos[selectIndexPath.section]];
                        applyVC.sendMutalData = tempSendData;
                    }
                } else {
                    applyVC.singalOrMutableType = kSingalOrMutableTypeSigal;
                    applyVC.applySaleProductInfo = productModel;
                    applyVC.orderInfo = _normalUserOrderModel;
                }
                
                [weakSelf.navigationController pushViewController:applyVC animated:YES];
            } else {
                // 跳转到状态页
                ApplyAfterSaleDetail *stateDetailVC = [[ApplyAfterSaleDetail alloc] init];
                stateDetailVC.backId = _normalUserOrderModel.backId;
                stateDetailVC.selectIndex = selectIndexPath.section;
                stateDetailVC.isFromDetailVC = YES;
                stateDetailVC.goodIdStr = productModel.orderInfoId;
                [weakSelf.navigationController pushViewController:stateDetailVC animated:YES];
            }
        }
    };
    
    //处理选中背景色问题
    cell.contentView.backgroundColor = [UIColor clearColor];
    UIView *backGroundView = [[UIView alloc]init];
    backGroundView.backgroundColor = [UIColor clearColor];
    cell.selectedBackgroundView = backGroundView;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 解决在一条数据下多次点击重复添加的问题
    if (!tableView.isEditing) {
        return;
    }
    
    [self.mutalSendArr addObject:_normalUserOrderModel.goodsOrderInfos[indexPath.section]];
    [self setSelectAllBtnStatus];
    // 当前选中的Cell
    _productModel = [OrderProductListModel mj_objectWithKeyValues:_normalUserOrderModel.goodsOrderInfos[indexPath.section]];
    if (tableView.isEditing) {
        [self setMutaApplyBtnStatus];
    }
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.mutalSendArr removeObject:_normalUserOrderModel.goodsOrderInfos[indexPath.section]];
    [self setSelectAllBtnStatus];
    
    if (tableView.isEditing) {
        [self setMutaApplyBtnStatus];
    }
}

// 设置全选按钮的状态
- (void)setSelectAllBtnStatus
{
    if (self.mutalSendArr.count == _normalUserOrderModel.goodsOrderInfos.count) {
        [_tempSelAllBtn setBackgroundImage:[UIImage imageNamed:@"icon_check_sel"]
                       forState:UIControlStateNormal];
    } else {
        [_tempSelAllBtn setBackgroundImage:[UIImage imageNamed:@"icon_check_disa"]
                       forState:UIControlStateNormal];
    }
}

/** 隐藏全选的小视图 */
- (void)hiddenCheckAllView
{
    _tempSelAllBtn.hidden = YES;
    _checkAllLbl.hidden = YES;
}

/** 显示全选的小视图 */
- (void)showCheckAllView
{
    _tempSelAllBtn.hidden = NO;
    _checkAllLbl.hidden = NO;
}

// 设置批量申请按钮的状态
- (void)setMutaApplyBtnStatus
{
    if (self.mutalSendArr.count == 0) {       
        if (![self.tableView isEditing]) {
            [_mutalApplyBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [_mutalApplyBtn setBackgroundColor:MainColor];
        } else {
            [_mutalApplyBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [_mutalApplyBtn setBackgroundColor:UnderLineColor];
        }
        
       // _mutalApplyBtn.enabled = NO;
    } else {
        [_mutalApplyBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_mutalApplyBtn setBackgroundColor:MainColor];
       // _mutalApplyBtn.enabled = YES;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([LGOrderLogicService isNeedHiddenApplyBtn:_normalUserOrderModel]) {
        return 162 - 42;
    } else {
        return 162;
    }
}

#pragma mark - 调整section之间的间距
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 5;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return [[UIView alloc] init];
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return [[UIView alloc] init];
}

#pragma mark - 事件响应
- (void)cancelOrderAction
{
    WEAK_SELF(weakSelf);
    [MBProgressHUD showGifToView:nil];
    [self.orderNetWorkService getOrderCancelWithOrderId:_normalUserOrderModel.orderId
                                               callBack:^(LgResultModel * _Nonnull res) {
        [MBProgressHUD hideHUD];
        if (res.isSucc) {
            [MBProgressHUD showMessage:NSLocalizedString(@"后台审核中,请稍后查看", nil) displayTime:2.0];
            [weakSelf doNetworkRequestForHeader];
            if (weakSelf.refreshSelectCellCallBack) {
                weakSelf.refreshSelectCellCallBack(_selectedIndexPath);
            }
        } else {
            if ([res.stateCode isEqualToString:@"2"]) {
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"售后单状态已拒绝，操作失败!", nil)];
            } else {
                [MBProgressHUD showErrorMessage:res.errMsg];
            }
        }
    }];
}

- (void)confrimOrderFinished
{
    [MBProgressHUD showGifToView:nil];
    WEAK_SELF(weakSelf);
    [self.orderNetWorkService doConfirmFinishOrderWithBackId:_normalUserOrderModel.backId
                                          callBack:^(LgResultModel * _Nonnull res) {
        [MBProgressHUD hideHUD];
        if (res.isSucc) {
            [MBProgressHUD showMessage:NSLocalizedString(@"确认完成", nil)];
            [weakSelf doNetworkRequestForHeader];
            if (weakSelf.refreshSelectCellCallBack) {
                weakSelf.refreshSelectCellCallBack(_selectedIndexPath);
            }
        } else {
            [MBProgressHUD showErrorMessage:res.errMsg];
        }
    }];
}

- (void)gotopaypalhtml
{
    WEAK_SELF(weakSelf);
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [MBProgressHUD showGifToView:nil];
    [NetworkManager postWithURL:CREATE_URL(url_merchantinfo) params:@{@"invitationCode":invitationCode} isUsedSignal:NO success:^(id json) {
        [MBProgressHUD hideHUD];
        
    //          [weakSelf headerCallback:json];
        [BaseService updateClassificationIconAndProductList:json];
        [weakSelf Validpaymentmethod:json];
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}

- (void)Validpaymentmethod:(id)json
{
    if (!isNSDictionary(json)) {
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"unknownerror", nil)];
            return;
    }
    if ([get_Value_for_key_from_obj(json, @"success") integerValue] == 0) {
        HomeController *homeVC = [[HomeController alloc]init];
        homeVC.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:homeVC animated:YES completion:nil];
    } else if ([get_Value_for_key_from_obj(json, @"success") integerValue] == 1) {
        NSDictionary *dic = get_Value_for_key_from_obj(json, dataKey);
        NSArray *temp = [PayModel mj_objectArrayWithKeyValuesArray:get_Value_for_key_from_obj(dic, @"payCompanyList")];
        
        if (temp.count > 0) {
            BOOL ispaypal = NO;
            for (PayModel *model in temp)
            {
                if ([model.payName isEqualToString:@"PayPal"])
                {
                    ispaypal = YES;
                    _ClientID = model.majorkey;
                }
            }
            
            if (ispaypal) {
                PayViewController *payVC = [[PayViewController alloc] init];
                payVC.money = _normalUserOrderModel.totalAmount;
                payVC.clientid = _ClientID;
                payVC.ordercode = _normalUserOrderModel.orderCode;
                payVC.type = 1;
                payVC.paymethod = _normalUserOrderModel.paymentMethod;
                payVC.updatepaystate = ^{
                    self->_normalUserOrderModel.payState = @"1";
                    [_tableView reloadData];
                    
                };
                [self.navigationController pushViewController:payVC animated:YES];
            } else {
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"商家暂不支持PayPal支付", nil)];
            }
            
        } else {
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"商家收款信息不完整", nil)];
            return;
        }
    } else {
        [self.emptyModel setStatus:get_Value_for_key_from_obj(json, messageKey)];
    }
}

#pragma mark - 懒加载
- (LGOrderNetWorkService *)orderNetWorkService
{
    if (!_orderNetWorkService) {
        _orderNetWorkService = [[LGOrderNetWorkService alloc] init];
    }
    return _orderNetWorkService;
}

- (LgMerchantNetworkService *)merchantNetworkService
{
    if (!_merchantNetworkService) {
        _merchantNetworkService = [[LgMerchantNetworkService alloc] init];
    }
    return _merchantNetworkService;
}

- (NSMutableArray *)mutalSendArr
{
    if (!_mutalSendArr) {
        _mutalSendArr = [[NSMutableArray alloc] init];
    }
    return _mutalSendArr;
}

-(UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        UINib *detailCellNib = [UINib nibWithNibName:NSStringFromClass([OrderDetailCell class]) bundle:nil];
        [_tableView registerNib:detailCellNib forCellReuseIdentifier:@"OrderDetailCell"];
        _tableView.separatorColor = [UIColor whiteColor];
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, CGFLOAT_MIN)];
        _tableView.tableFooterView = footerView;
        _tableView.estimatedRowHeight = 162;

        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.tableHeaderView = [[UIView alloc]initWithFrame:CGRectMake(0.0f,0.0f,_tableView.bounds.size.width,0.01f)];

    }
    return _tableView;
}

- (LGOrderDetailHeadView *)productDetailHeadView
{
    if (!_productDetailHeadView) {
        _productDetailHeadView = [[[NSBundle mainBundle] loadNibNamed:@"LGOrderDetailHeadView" owner:self options:nil] lastObject];
    }
    return _productDetailHeadView;
}

@end
