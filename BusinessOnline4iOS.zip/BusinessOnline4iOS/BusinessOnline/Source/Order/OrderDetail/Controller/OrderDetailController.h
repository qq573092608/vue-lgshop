//
//  OrderDetailController.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "BaseViewController.h"

@class OrderListNormalModel;


typedef void(^RefreshCellCallBack)(NSIndexPath *selectIndexPath);


NS_ASSUME_NONNULL_BEGIN

@interface OrderDetailController : BaseViewController

/// 刷新选中的cell
@property (nonatomic, copy) RefreshCellCallBack refreshSelectCellCallBack;

- (instancetype)initWithText:(NSString *)text
                indexPath:(NSIndexPath *)selectIndexPath;

@end

NS_ASSUME_NONNULL_END
