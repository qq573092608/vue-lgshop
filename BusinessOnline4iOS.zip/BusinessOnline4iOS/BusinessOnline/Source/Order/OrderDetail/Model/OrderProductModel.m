//
//  OrderProductModel.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "OrderProductModel.h"

@implementation OrderProductModel

+(NSDictionary *)mj_objectClassInArray
{
    return @{@"photoList":@"PhotoModel"};
}

@end
