//
//  OrderProductListModel.m
//  BusinessOnline
//
//  Created by clitics on 2019/3/7.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "OrderProductListModel.h"

@implementation OrderProductListModel

@end
