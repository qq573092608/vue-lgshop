//
//  OrderProductModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PhotoModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface OrderProductModel : NSObject

@property (nonatomic , copy) NSString              * aux_barcode_id;
@property (nonatomic , copy) NSString              * p_price_old;
@property (nonatomic , copy) NSString              * s_price_old;
@property (nonatomic , copy) NSString              * temp_goods_info_code;
@property (nonatomic , copy) NSString              *type_id;

@property (nonatomic , copy) NSString              * s_price2;
@property (nonatomic , copy) NSString              *id;
@property (nonatomic , copy) NSString              * push_money;
@property (nonatomic , assign) NSInteger              is_show_webhome;
@property (nonatomic , copy) NSString              * s_discount4;

@property (nonatomic , copy) NSString              * actual_p_price;
@property (nonatomic , copy) NSString              * p_subtotal;
@property (nonatomic , copy) NSString              * web_time;
@property (nonatomic , copy) NSString              * spec;
@property (nonatomic , copy) NSString              * note;

@property (nonatomic , assign) NSInteger              w_h;
@property (nonatomic , copy) NSString              * supplier_id;
@property (nonatomic , copy) NSString              * text1;
@property (nonatomic , copy) NSString              * store_time;
@property (nonatomic , copy) NSString              * p_price;

@property (nonatomic , copy) NSString              * supplier_name;
@property (nonatomic , copy) NSString              * italian_name;
@property (nonatomic , copy) NSString              * aux_info;
@property (nonatomic , assign) NSInteger              goods_int1;
@property (nonatomic , copy) NSString              * location;

@property (nonatomic , copy) NSString            * auxBarCodeList;
@property (nonatomic , copy) NSString              * business;
@property (nonatomic , assign) NSInteger              qtb;
@property (nonatomic , assign) NSInteger              goods_int2;
@property (nonatomic , copy) NSString              * text2;

@property (nonatomic , copy) NSString              * create_time;
@property (nonatomic , copy) NSString              * zh_name;
@property (nonatomic , assign) NSInteger              is_default_new;
@property (nonatomic , copy) NSString              * syncCode;
@property (nonatomic , copy) NSString              * warehouse_name;
/** 折扣字段 APP专用 */
@property (nonatomic , assign) NSInteger              s_discount;
@property (nonatomic , assign) NSInteger              inventory_warning;
@property (nonatomic , assign) NSInteger              warehouse_id;
@property (nonatomic , assign) NSInteger              iva;
@property (nonatomic , copy) NSString              * text3;

/** 单品售价 无用字段 */
@property (nonatomic , copy) NSString              * s_price;
@property (nonatomic , copy) NSString              * warehouses;
@property (nonatomic , copy) NSString              * web_goods_describe;
/**
    photoList:规则第0个是原图，第1个是压缩图
 */
@property (nonatomic , strong) NSArray<PhotoModel *>              * photoList;
@property (nonatomic , copy) NSString              * goods_code;

/** 线上售价 APP专用 */
@property (nonatomic , copy) NSString              * web_order_price;
@property (nonatomic , assign) NSInteger              s_discount2;
@property (nonatomic , copy) NSString              * numeric2;
@property (nonatomic , assign) NSInteger              real_inventory;
@property (nonatomic , copy) NSString              * type_name;

@property (nonatomic , assign) NSInteger              invoice_inventory;
@property (nonatomic , assign) NSInteger              is_publish_weborder;
@property (nonatomic , copy) NSString              * profits_than;
@property (nonatomic , assign) NSInteger              quantity;
@property (nonatomic , assign) NSInteger              is_default_recom;

@property (nonatomic , assign) NSInteger              s_discount3;
@property (nonatomic , assign) NSInteger              packquantity;
@property (nonatomic , assign) NSString             *tasteIds;
@property (nonatomic , assign) NSString             *tasteData;


@end


NS_ASSUME_NONNULL_END
