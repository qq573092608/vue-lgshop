//
//  OrderDetailModel.m
//  BusinessOnline
//
//  Created by clitics on 2019/4/29.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "OrderDetailModel.h"

@implementation OrderDetailModel

+(NSDictionary *)mj_objectClassInArray
{
    return @{@"goodsOrderInfos":@"OrderDetailOrderModel"};
}
@end
