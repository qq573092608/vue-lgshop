//
//  OrderDetailProductModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/4/29.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OrderDetailProductModel : NSObject
/*
 "id": 1,
 "goods_code": "001809",
 "type_id": 1,
 "supplier_id": "9999",
 "italian_name": "LUCI PER",
 
 "p_price": 2.0,
 "s_price": 3.9,
 "qtb": 0,
 "packquantity": 0,
 "s_discount": 0,
 
 "s_discount2": 0,
 "s_discount3": 0,
 "quantity": 0,
 "warehouse_id": 1,
 "iva": 0,
 
 "real_inventory": 0,
 "invoice_inventory": 0,
 "inventory_warning": 0,
 "text1": "",
 "text2": "",
 
 "text3": "0",
 "goods_int1": 1,
 "goods_int2": 0,
 "numeric2": 0.0,
 "note": "",
 
 "is_default_new": 1,
 "is_default_recom": 1,
 "is_show_webhome": 1,
 "is_publish_weborder": 1,
 "web_goods_describe": "",
 
 "web_order_price": 20.56,
 "p_subtotal": 0.0,
 "actual_p_price": 0.0,
 "s_price2": 0.0,
 "auxBarCodeList": [],
 
 "photoList": []
 */
@property (nonatomic,copy)NSString *id;
@property (nonatomic,copy)NSString *goods_code;
@property (nonatomic,copy)NSString *type_id;
@property (nonatomic,copy)NSString *supplier_id;
@property (nonatomic,copy)NSString *italian_name;

@property (nonatomic,copy)NSString *p_price;
@property (nonatomic,copy)NSString *s_price;
@property (nonatomic,copy)NSString *qtb;
@property (nonatomic,copy)NSString *packquantity;
@property (nonatomic,copy)NSString *s_discount;

@property (nonatomic,copy)NSString *s_discount2;
@property (nonatomic,copy)NSString *s_discount3;
@property (nonatomic,copy)NSString *quantity;
@property (nonatomic,copy)NSString *warehouse_id;
@property (nonatomic,copy)NSString *iva;

@property (nonatomic,copy)NSString *real_inventory;
@property (nonatomic,copy)NSString *invoice_inventory;
@property (nonatomic,copy)NSString *inventory_warning;
@property (nonatomic,copy)NSString *text1;
@property (nonatomic,copy)NSString *text2;

@property (nonatomic,copy)NSString *text3;
@property (nonatomic,copy)NSString *goods_int1;
@property (nonatomic,copy)NSString *goods_int2;
@property (nonatomic,copy)NSString *numeric2;
@property (nonatomic,copy)NSString *note;

@property (nonatomic,copy)NSString *is_default_new;
@property (nonatomic,copy)NSString *is_default_recom;
@property (nonatomic,copy)NSString *is_show_webhome;
@property (nonatomic,copy)NSString *is_publish_weborder;
@property (nonatomic,copy)NSString *web_goods_describe;

@property (nonatomic,copy)NSString *web_order_price;
@property (nonatomic,copy)NSString *p_subtotal;
@property (nonatomic,copy)NSString *actual_p_price;
@property (nonatomic,copy)NSString *s_price2;
@property (nonatomic,copy)NSString *auxBarCodeList;

@property (nonatomic,strong)NSMutableArray *photoList;


/*
 "italianName": "ADIDAS DEO BODY TEAM FORCE",
 "quantity": 4,  //重复
 "orderId": 0,
 "goodsId": 1447,
 "discount": 0,
 
 "syncCode": "",
 "packquantity": 0,
 "orderInfoId": 1,
 "zhName": "",
 "price": 2.85,
 
 "orderCode": "GO15559908065099507398",
 "typeId": 2,
 "goodsCode": "3607345266084",
 "qtb": 0  //重复
 */
@property (nonatomic,copy)NSString *italianName;
@property (nonatomic,copy)NSString *orderId;
@property (nonatomic,copy)NSString *goodsId;
@property (nonatomic,copy)NSString *discount;

@property (nonatomic,copy)NSString *syncCode;
@property (nonatomic,copy)NSString *orderInfoId;
@property (nonatomic,copy)NSString *zhName;
@property (nonatomic,copy)NSString *price;

@property (nonatomic,copy)NSString *orderCode;
@property (nonatomic,copy)NSString *typeId;
@property (nonatomic,copy)NSString *goodsCode;

@end

NS_ASSUME_NONNULL_END
