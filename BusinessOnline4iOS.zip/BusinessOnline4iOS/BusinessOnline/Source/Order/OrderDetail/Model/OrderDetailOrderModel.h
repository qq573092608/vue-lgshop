//
//  OrderDetailOrderModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/4/29.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OrderDetailOrderModel : NSObject
/*
 "orderInfoId": 115,
 "goodsId": 1,
 "discount": 0.00,
 "price": 20.56,
 "goodsCode": "001809",
 
 "qtb": 0,
 "packquantity": 0,
 "quantity": 1,
 "italianName": "LUCI PER",
 "typeId": 1,
 
 "syncCode": "81adce8b-c11e-427d-a4b1-2fa65d7fbb0d"
 "goodsInfo": []
 */
@property (nonatomic,copy)NSString *orderInfoId;
@property (nonatomic,copy)NSString *goodsId;
@property (nonatomic,copy)NSString *discount;
@property (nonatomic,copy)NSString *price;
@property (nonatomic,copy)NSString *goodsCode;

@property (nonatomic,copy)NSString *qtb;
@property (nonatomic,copy)NSString *packquantity;
@property (nonatomic,copy)NSString *quantity;
@property (nonatomic,copy)NSString *italianName;
@property (nonatomic,copy)NSString *zhName;
@property (nonatomic,copy)NSString *typeId;

@property (nonatomic,copy)NSString *syncCode;
@property (nonatomic,strong)NSMutableArray *goodsInfo;

@end

NS_ASSUME_NONNULL_END
