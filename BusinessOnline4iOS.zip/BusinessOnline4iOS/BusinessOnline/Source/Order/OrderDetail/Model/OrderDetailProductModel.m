//
//  OrderDetailProductModel.m
//  BusinessOnline
//
//  Created by clitics on 2019/4/29.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "OrderDetailProductModel.h"

@implementation OrderDetailProductModel

+(NSDictionary *)mj_objectClassInArray
{
    return @{@"photoList":@"PhotoModel"};
}

@end
