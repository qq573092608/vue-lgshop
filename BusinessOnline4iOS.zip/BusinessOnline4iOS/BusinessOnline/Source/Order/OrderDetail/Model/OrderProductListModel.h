//
//  OrderProductListModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/7.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OrderProductModel.h"

NS_ASSUME_NONNULL_BEGIN

/**
     单个商品的信息
 */
@interface OrderProductListModel : NSObject

/**
 backInfoStatus = "";
 discount = "0.00";
 goodsCode = 8021256783136;
 goodsId = 8916983;
 goodsInfo = "";
 italianName = "POE NVR KIT 4 CANALE 2,0MPX";
 iva = "";
 oldGoodsInfo =                 {
     "actual_p_price" = "0.00";
     "aux_barcode_id" = "";
     "aux_info" = "";
     brandId = "";
     "create_time" = "2020-10-10 17:41:14.0";
     extflds =                     {
         companyId = "";
         companyInvitationCode = "";
         detImgurls = "";
         "extfids_img_file" = "";
         goodsCode = "";
         height = "";
         id = "";
         ingredients = "";
         waitMins = "";
         weightKg = "";
         width = "";
     };
     "goods_code" = 8021256783136;
     "goods_int1" = 0;
     "goods_int2" = 0;
     id = 8916983;
     "inventory_warning" = 0;
     "invoice_inventory" = 19657;
     "is_default_new" = 0;
     "is_default_recom" = 0;
     "is_publish_weborder" = 1;
     "is_show_webhome" = 0;
     "italian_name" = "POE NVR KIT 4 CANALE 2,0MPX";
     iva = 0;
     location = "";
     note = "POE4\U8def\U5957\U88c5";
     numeric2 = "0.00";
     onlineWeight = "";
     "p_price" = "0.00";
     "p_price_old" = "";
     "p_subtotal" = "0.00";
     packquantity = 0;
     photoList =                     (
     );
     "profits_than" = "";
     "push_money" = "";
     qtb = 0;
     quantity = 0;
     "real_inventory" = 19652;
     "s_discount" = 0;
     "s_discount2" = 0;
     "s_discount3" = 0;
     "s_discount4" = 0;
     "s_price" = "85.00";
     "s_price2" = "0.00";
     "s_price3" = "0.00";
     "s_price4" = "0.00";
     "s_price5" = "0.00";
     "s_price_old" = "";
     "sale_type" = 1;
     spec = "POE4CH-83136";
     "store_time" = "";
     "supplier_id" = 48;
     "supplier_name" = "";
     syncCode = "";
     tasteIds = "";
     tasteList =                     (
     );
     "temp_goods_info_code" = "";
     text1 = "";
     text2 = "VIDEO SOVERGLIANZA  ? ACCESSORE VARI";
     text3 = "\U4e54\U6cf0\U7535\U5b50";
     "type_Id" = 30309;
     "type_id" = 30309;
     "type_name" = "";
     videoFilePath = "";
     "w_h" = "-100";
     "warehouse_id" = "";
     "warehouse_name" = "";
     "web_goods_describe" = "";
     "web_online_weight" = "90.00";
     "web_order_price" = "85.00";
     "web_publish_weborder" = 1;
     "web_time" = "2020-10-10 17:41:14.0";
     weightKg = "";
     "zh_name" = "POE4\U8def\U5957\U88c5";
 };
 orderCode = "";
 orderId = "";
 orderInfoId = 15983;
 packquantity = 0;
 postalCode = "";
 price = "85.00";
 qtb = 0;
 quantity = 1;
 syncCode = "e6eab0b9-77be-4c3a-b243-697c621cd163";
 tasteData = "";
 tasteIds = "";
 totalPPrice = "";
 totalPrice = "";
 typeId = 30309;
 zhName = "POE4\U8def\U5957\U88c5";
 */

/** 折扣率 */
@property (nonatomic , copy) NSString * discount;
/**
  售后单详情状态 0-等待审核，1-已同意，2-等待商家确认，3-等待用户确认，4-已完成，5-已拒绝
 */
@property (nonatomic , copy) NSString * backInfoStatus;
@property (nonatomic , copy) NSString * goodsId;
@property (nonatomic , copy) NSString * goodsInfo;
@property (nonatomic , copy) NSString * italianName;
@property (nonatomic , copy) NSString * iva;
@property (nonatomic , copy) NSString * orderCode;
@property (nonatomic , copy) NSString * orderId;
@property (nonatomic , copy) NSString * orderInfoId;
/**
     包装数(点击一下的步长，针对购物车的操作，只针对加，减则是1)
 */
@property (nonatomic , copy) NSString * packquantity;
@property (nonatomic , copy) NSString * postalCode;

/** 订单详情中的价格 */
@property (nonatomic , copy) NSString * price;
@property (nonatomic , copy) NSString * qtb;
@property (nonatomic , copy) NSString * syncCode;
// 多规格的id
@property (nonatomic , copy) NSString * tasteIds;
@property (nonatomic , copy) NSString * totalPPrice;
@property (nonatomic , copy) NSString * totalPrice;
@property (nonatomic , copy) NSString * typeId;
@property (nonatomic , copy) NSString * zhName;


@property (nonatomic , copy) NSString              * goodsCode;
@property (nonatomic , assign) NSInteger              id;
@property (nonatomic , assign) NSInteger              ord_id;
/**
     个数
 */
@property (nonatomic , assign) NSInteger              quantity;
// 多规格内容
@property (nonatomic , copy) NSString              * tasteData;
/**
   库存内容
 */
@property (nonatomic , strong) OrderProductModel              * oldGoodsInfo;

/** 1:取消订单  2:退款 3:退货退款 */
@property (nonatomic , copy) NSString              * infoType;
/** 折扣价格 */
@property (nonatomic , copy) NSString              * discountPrice;

@end

NS_ASSUME_NONNULL_END
