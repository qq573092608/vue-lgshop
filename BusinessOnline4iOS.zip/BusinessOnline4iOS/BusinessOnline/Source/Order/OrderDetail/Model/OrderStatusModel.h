//
//  OrderStatusModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OrderProductListModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface OrderStatusModel : NSObject

@property (nonatomic , copy) NSString              * id;
@property (nonatomic , assign) BOOL              is_collect;
@property (nonatomic , copy) NSString              * consignee;
@property (nonatomic , copy) NSString              * bus_name;
@property (nonatomic , copy) NSString              * detail;
@property (nonatomic , copy) NSString              * order_createtime;
@property (nonatomic , copy) NSString              * contactnumber;
@property (nonatomic , copy) NSString              * user_id;
@property (nonatomic , copy) NSString              * pay_mode;
@property (nonatomic , copy) NSString              * product_num;
@property (nonatomic , assign) BOOL              is_deliver;
@property (nonatomic , copy) NSString              * order_code;
@property (nonatomic , copy) NSString              * product_id;
@property (nonatomic , assign) NSInteger              order_state;
@property (nonatomic , copy) NSString              * deliver_time;
@property (nonatomic , strong) NSArray<OrderProductListModel *>              * ord_proLst;
@property (nonatomic , strong) NSArray<OrderProductListModel *>              * goodsOrderInfos;
@property (nonatomic , copy) NSString              * remarks;
@property (nonatomic , copy) NSString              * collect;
@property (nonatomic , copy) NSString              * order_price;

//@property (nonatomic,strong)NSMutableArray *goodsOrderInfos;
@property (nonatomic,copy)NSString *orderId;
@property (nonatomic,copy)NSString *orderCode;

/** 0:申请取消 1:等待处理 2:处理中 3:已完成 6:已取消 */
@property (nonatomic,copy)NSString *orderState;
@property (nonatomic,copy)NSString *createDate;

@property (nonatomic,copy)NSString *userName;
@property (nonatomic,copy)NSString *userPhone;
@property (nonatomic,copy)NSString *collectAddress;
@property (nonatomic,copy)NSString *taxCode;
@property (nonatomic,copy)NSString *companyTaxCode;

@property (nonatomic,copy)NSString *address;

@property (nonatomic,copy)NSString *amount;
/** 单纯的商品金额不包含运费 */
@property (nonatomic,copy)NSString *totalAmount;
@property (nonatomic,copy)NSString *discountAmount;
@property (nonatomic,copy)NSString *depositAmount;

@property (nonatomic,copy)NSString *paymentMethod;
@property (nonatomic,copy)NSString *overDel;
//@property (nonatomic,copy)NSString *remarks;
@property (nonatomic,copy)NSString *overDeliver;
@property (nonatomic,copy)NSString *overCollect;

@property (nonatomic,copy)NSString *collectName;
@property (nonatomic,copy)NSString *collectPhone;
@property (nonatomic,copy)NSString *salesPersonName;
@property (nonatomic,copy)NSString *salesPersonInvitation;
@property (nonatomic,copy)NSString *syncCode;

@property (nonatomic,copy)NSString *tasteIds;
@property (nonatomic,copy)NSString *payState;
@property (nonatomic,copy)NSString *freightAmount;

/** 退货单id */
@property (nonatomic,copy)NSString *backId;

/** 售后处理状态  0-等待审核，1-已同意，2-等待商家确认，3-等待用户确认，4-已完成，5-已拒绝
 */
@property (nonatomic,copy)NSString *backStatus;

/**
   * 完成收货时间
*/
@property (nonatomic,copy)NSString *collectDate;


@end

NS_ASSUME_NONNULL_END
