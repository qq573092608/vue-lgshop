//
//  OrderDetailModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/4/29.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OrderProductListModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface OrderDetailModel : NSObject
/*
 "goodsOrderInfos": []
 "orderId": 82,
 "orderCode": "GO15565200058179507435",
 "orderState": 1,
 "createDate": "Apr 29, 2019 2:40:06 PM",
 
 "userName": "",
 "userPhone": "15875319507",
 "collectAddress": "双双",
 "taxCode": "",
 "companyTaxCode": "66782",
 
 "address": "双双",
 "amount": 20.56,
 "totalAmount": 20.56,
 "discountAmount": 0.00,
 "depositAmount": 0.00,
 
 "paymentMethod": "1",
 "overDel": false,
 "remarks": "",
 "overDeliver": false,
 "overCollect": false,
 
 "collectName": "hj",
 "collectPhone": "15777639276",
 "salesPersonName": "dong",
 "salesPersonInvitation": "dong",
 "syncCode": "2c3197d6-48aa-4812-82a7-c6c6c02c9b55"
 */
@property (nonatomic,strong)NSMutableArray *goodsOrderInfos;
@property (nonatomic,copy)NSString *orderId;
@property (nonatomic,copy)NSString *orderCode;
@property (nonatomic,copy)NSString *orderState;
@property (nonatomic,copy)NSString *createDate;

@property (nonatomic,copy)NSString *userName;
@property (nonatomic,copy)NSString *userPhone;
@property (nonatomic,copy)NSString *collectAddress;
@property (nonatomic,copy)NSString *taxCode;
@property (nonatomic,copy)NSString *companyTaxCode;

@property (nonatomic,copy)NSString *address;
@property (nonatomic,copy)NSString *amount;
@property (nonatomic,copy)NSString *totalAmount;
@property (nonatomic,copy)NSString *discountAmount;
@property (nonatomic,copy)NSString *depositAmount;

@property (nonatomic,copy)NSString *paymentMethod;
@property (nonatomic,copy)NSString *overDel;
@property (nonatomic,copy)NSString *remarks;
@property (nonatomic,copy)NSString *overDeliver;
@property (nonatomic,copy)NSString *overCollect;

@property (nonatomic,copy)NSString *collectName;
@property (nonatomic,copy)NSString *collectPhone;
@property (nonatomic,copy)NSString *salesPersonName;
@property (nonatomic,copy)NSString *salesPersonInvitation;
@property (nonatomic,copy)NSString *syncCode;

@property (nonatomic , strong) NSArray<OrderProductListModel *> * ord_proLst;

@end

NS_ASSUME_NONNULL_END
