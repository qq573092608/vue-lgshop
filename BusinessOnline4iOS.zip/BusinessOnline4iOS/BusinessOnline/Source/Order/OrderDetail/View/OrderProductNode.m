//
//  OrderProductNode.m
//  BusinessOnline
//
//  Created by clitics on 2019/3/8.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "OrderProductNode.h"
#import "OrderDetailProductModel.h"
#import "PhotoModel.h"
#import "OrderProductListModel.h"
#import "AppDelegate.h"

#import "BaseService.h"

@interface OrderProductNode ()
{
    OrderDetailProductModel *_model;
    OrderProductListModel *_productModel;
    ASTextNode *_textNode0,*_textNode1,*_textNode2,*_textNode3;
    ASNetworkImageNode *_iconNode;
}

///  申请售后按钮
@property (nonatomic, strong) ASButtonNode *applyAfterSaleBtn;

@end
@implementation OrderProductNode

-(instancetype)initWithProductModel:(OrderProductListModel *)productModel
{
    if (self = [super init]) {
        self.backgroundColor = [UIColor whiteColor];
        _productModel = productModel;
        
        _textNode0 = [ASTextNode new];
        [self addSubnode:_textNode0];
        _textNode0.attributedText = [[NSAttributedString alloc] initWithString:_productModel.oldGoodsInfo.italian_name
                                                                    attributes:@{
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),
                                                                        NSFontAttributeName:[UIFont systemFontOfSize:18]
                                                                    }
                                     ];
        
        _textNode1 = [ASTextNode new];
        [self addSubnode:_textNode1];
        NSString *phone = _productModel.tasteData;
        if (!isNSString(phone))
        {
            phone = @"";
        }
        _textNode1.attributedText = [[NSAttributedString alloc] initWithString:phone
                                                                    attributes:@{
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),
                                                                        NSFontAttributeName:[UIFont systemFontOfSize:18]}
                                     ];
        
        _textNode2 = [ASTextNode new];
        [self addSubnode:_textNode2];
        NSMutableAttributedString *priceAttributes = [[NSMutableAttributedString alloc] init];
        if (@available(iOS 8.2, *)) {
            [priceAttributes appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %.2f ",_productModel.oldGoodsInfo.web_order_price.floatValue]
                                                                                    attributes:@{
                                                                                        NSForegroundColorAttributeName:MainColor,
                                                                                        NSFontAttributeName:[UIFont systemFontOfSize:18 weight:UIFontWeightBold]}]
             ];
        } else {
            [priceAttributes appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %.2f ",_productModel.oldGoodsInfo.web_order_price.floatValue]
                                                                                    attributes:@{
                                                                                        NSForegroundColorAttributeName:MainColor,
                                                                                        NSFontAttributeName:[UIFont systemFontOfSize:18]}]
             ];
        }
        [priceAttributes appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"x%ld",(long)_productModel.quantity]
                                                                                attributes:@{
                                                                                    NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),
                                                                                    NSFontAttributeName:[UIFont systemFontOfSize:18]}]
         ];
        _textNode2.attributedText = priceAttributes;
        
        _textNode3 = [ASTextNode new];
        [self addSubnode:_textNode3];
        if (@available(iOS 8.2, *)) {
            _textNode3.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %.2f ",(_productModel.oldGoodsInfo.web_order_price.floatValue)*_productModel.quantity]
                                                                        attributes:@{
                                                                            NSForegroundColorAttributeName:MainColor,
                                                                            NSFontAttributeName:[UIFont systemFontOfSize:18 weight:UIFontWeightBold]}
                                         ];
        } else {
            _textNode3.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %.2f ",(_productModel.oldGoodsInfo.web_order_price.floatValue)*_productModel.quantity]
                                                                        attributes:@{
                                                                            NSForegroundColorAttributeName:MainColor,
                                                                            NSFontAttributeName:[UIFont systemFontOfSize:18]}
                                         ];
        }
        
        _iconNode = [ASNetworkImageNode new];
        //        [self addSubnode:_iconNode];
        _iconNode.backgroundColor = [UIColor whiteColor];
        //        _iconNode.defaultImage = [UIImage imageNamed:@"036_vic"];
        _iconNode.contentMode = UIViewContentModeScaleAspectFit;
        _iconNode.forcedSize = CGSizeMake(100, 100);
        [self addSubnode:_iconNode];
        UIImage *defaultImage = [UIImage imageNamed:@"036_vic"];
        _iconNode.defaultImage = [BaseService image:defaultImage scaleToSize:CGSizeMake(100, 100)];
        if (_productModel.oldGoodsInfo.photoList.count >= 2)
        {
            PhotoModel *photoModel = _productModel.oldGoodsInfo.photoList[1];
            _iconNode.URL = [NSURL URLWithString:photoModel.pathName];
        }
        
        // 添加申请售后按钮
        [self addSubnode:self.applyAfterSaleBtn];
        self.applyAfterSaleBtn.layer.cornerRadius = 3;
        self.applyAfterSaleBtn.layer.borderWidth = 1;
        self.applyAfterSaleBtn.layer.borderColor = [UIColorFromRGB(0xE6E6E6) CGColor];
        [self.applyAfterSaleBtn addTarget:self
                                action:@selector(applyAfterSaleAction)
                      forControlEvents:ASControlNodeEventTouchUpInside];
    }
    return self;
}
-(instancetype)initWithModel:(OrderDetailProductModel *)model
{
    if (self = [super init])
    {
        self.backgroundColor = [UIColor whiteColor];
        _model = model;
        
        BOOL isSaler = [[[NSUserDefaults standardUserDefaults] objectForKey:kIsSale] boolValue];
        NSString *name = isSaler?_model.italianName:_model.italian_name;
        if (!isNSString(name))
        {
            name = @"";
        }
        _textNode0 = [ASTextNode new];
        [self addSubnode:_textNode0];
        _textNode0.attributedText = [[NSAttributedString alloc] initWithString:name attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        _textNode1 = [ASTextNode new];
        [self addSubnode:_textNode1];
        NSString *phone = isSaler?_model.goodsCode:_model.goods_code;
        if (!isNSString(phone))
        {
            phone = @"";
        }
        _textNode1.attributedText = [[NSAttributedString alloc] initWithString:phone attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        _textNode2 = [ASTextNode new];
        [self addSubnode:_textNode2];
        NSMutableAttributedString *priceAttributes = [[NSMutableAttributedString alloc] init];
        [priceAttributes appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %.2f ",isSaler?_model.price.floatValue:_model.web_order_price.floatValue] attributes:@{NSForegroundColorAttributeName:MainColor,NSFontAttributeName:[UIFont systemFontOfSize:15]}]];
        [priceAttributes appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"x%ld",(long)_model.quantity.integerValue] attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),NSFontAttributeName:[UIFont systemFontOfSize:16]}]];
        _textNode2.attributedText = priceAttributes;
        
        _textNode3 = [ASTextNode new];
        [self addSubnode:_textNode3];
        _textNode3.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"                        € %.2f ",(isSaler?_model.price.floatValue:_model.web_order_price.floatValue)*_model.quantity.integerValue] attributes:@{NSForegroundColorAttributeName:MainColor,NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        _iconNode = [ASNetworkImageNode new];
//        [self addSubnode:_iconNode];
        _iconNode.backgroundColor = [UIColor whiteColor];
//        _iconNode.defaultImage = [UIImage imageNamed:@"036_vic"];
        _iconNode.contentMode = UIViewContentModeScaleAspectFit;
        
        _iconNode.forcedSize = CGSizeMake(100, 100);
        [self addSubnode:_iconNode];
        UIImage *defaultImage = [UIImage imageNamed:@"036_vic"];
        _iconNode.defaultImage = [BaseService image:defaultImage scaleToSize:CGSizeMake(100, 100)];
        if (_model.photoList.count >= 2)
        {
            PhotoModel *photoModel = _model.photoList[1];
            _iconNode.URL = [NSURL URLWithString:photoModel.pathName];
        }
    }
    return self;
}

static CGFloat edgSpacing = 15.0f;
static CGFloat nodeSpacing = 8.0f;
static CGFloat totalPriceNodeWidth = 200.0f;

-(ASLayoutSpec *)layoutSpecThatFits:(ASSizeRange)constrainedSize
{
    // 配置取消订单的属性
    self.applyAfterSaleBtn.style.height = ASDimensionMakeWithPoints(36);
    self.applyAfterSaleBtn.style.width = ASDimensionMakeWithPoints(80);
    
    _iconNode.style.preferredSize = CGSizeMake(100, 100);
    _textNode3.style.maxWidth = ASDimensionMakeWithPoints(totalPriceNodeWidth);
    _textNode0.style.width = ASDimensionMakeWithPoints(SCREEN_WIDTH-_iconNode.image.size.width-2*edgSpacing-nodeSpacing);
    _textNode1.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH);
    CGFloat textNode3Width;
    if (_textNode3.attributedText.size.width > totalPriceNodeWidth)
    {
        textNode3Width = totalPriceNodeWidth;
    } else {
        textNode3Width = _textNode3.attributedText.size.width;
    }
    _textNode2.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH);
    
    ASLayoutSpec *spacing = [ASLayoutSpec new];
    spacing.style.flexGrow = 1.0;
    
    ASStackLayoutSpec *spec1 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentSpaceAround
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_textNode2,spacing,_textNode3]];
    ASStackLayoutSpec *spec2 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStretch
                                                                      children:@[_textNode0,_textNode1,spec1]];
    ASStackLayoutSpec *spec3 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_iconNode,spec2]];
    ASStackLayoutSpec *applyAfterSaleSpec = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentEnd
                                                                    alignItems:ASStackLayoutAlignItemsEnd
                                                                      children:@[spec3,self.applyAfterSaleBtn]];
    return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(edgSpacing, edgSpacing, edgSpacing, edgSpacing)
                                                  child:applyAfterSaleSpec];
}


#pragma mark - 自定义事件
- (void)applyAfterSaleAction
{
    if (self.applyCallBack) {
        self.applyCallBack(_productModel.oldGoodsInfo);
    }
}

#pragma mark - 懒加载
- (ASButtonNode *)applyAfterSaleBtn
{
    if (!_applyAfterSaleBtn) {
        _applyAfterSaleBtn = [[ASButtonNode alloc] init];
        [_applyAfterSaleBtn setTitle:NSLocalizedString(@"申请售后", nil)
                                withFont:[UIFont lgFontFamily:@"" size:16.0f]
                                withColor:UIColorFromRGB(0x484244)
                            forState:UIControlStateNormal];
    }
    return _applyAfterSaleBtn;
}




@end
