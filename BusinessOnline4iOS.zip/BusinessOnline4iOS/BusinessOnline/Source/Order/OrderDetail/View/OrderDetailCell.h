//
//  OrderDetailCell.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

@class OrderProductListModel,OrderProductModel;

typedef void(^LGApplyActionCallBack)(OrderProductListModel *productModel, NSIndexPath *selectIndexPath);

NS_ASSUME_NONNULL_BEGIN

@interface OrderDetailCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *productIcon;

@property (weak, nonatomic) IBOutlet UILabel *productName;

@property (weak, nonatomic) IBOutlet UILabel *sigalPrice;

@property (weak, nonatomic) IBOutlet UILabel *numLbl;

@property (weak, nonatomic) IBOutlet UILabel *totalPriceLbl;

/** 申请售后的按钮 */
@property (weak, nonatomic) IBOutlet UIButton *applySellBtn;

/** 折扣价标签 */
@property (weak, nonatomic) IBOutlet UILabel *disCountLbl;

@property (nonatomic, copy) LGApplyActionCallBack applyActionCallBack;

+ (instancetype)cellWithTableView:(UITableView *)tableView
                  withProductInfo:(OrderProductListModel *)productInfo
                       orderState:(NSString *)orderState
                  selectIndexPath:(NSIndexPath *)indexPath;


@end

NS_ASSUME_NONNULL_END
