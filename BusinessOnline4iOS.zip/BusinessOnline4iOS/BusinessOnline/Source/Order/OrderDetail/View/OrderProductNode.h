//
//  OrderProductNode.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/8.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <AsyncDisplayKit/ASCellNode.h>
@class OrderDetailProductModel,OrderProductListModel,OrderProductModel;

NS_ASSUME_NONNULL_BEGIN

typedef void(^LGApplyCallBack)(OrderProductModel *productModel);

@interface OrderProductNode : ASCellNode

@property (nonatomic, copy) LGApplyCallBack applyCallBack;

- (instancetype)initWithModel:(OrderDetailProductModel *)model;

- (instancetype)initWithProductModel:(OrderProductListModel *)productModel;

@end

NS_ASSUME_NONNULL_END
