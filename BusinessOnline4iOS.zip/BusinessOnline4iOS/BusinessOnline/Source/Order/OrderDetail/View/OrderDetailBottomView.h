//
//  OrderDetailBottomView.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>
@class OrderStatusModel;

typedef void(^MutApplyCallBack)(void);

/** 选中的状态  YES:已选中  NO:未选中 */
typedef void(^SelectAllCallBack)(UIButton *btn);

/** 取消订单 */
typedef void(^CancelOrderActionCallBack)(void);

/** 确认完成的Block */
typedef void(^ConfrimOrderFinishActionCallBack)(void);


NS_ASSUME_NONNULL_BEGIN

@interface OrderDetailBottomView : UIView

@property(copy, nonatomic) MutApplyCallBack mutApplyCallBack;
@property(copy, nonatomic) SelectAllCallBack selectAllCallBack;

/** 支付按钮的响应事件 */
@property (nonatomic,copy)void(^paypalSubmitCallBack)(OrderStatusModel *model);

/** 取消订单的响应事件 */
@property (nonatomic,copy) CancelOrderActionCallBack cancelOrderAction;

/** 确认订单完成的回调 */
@property (nonatomic,copy) ConfrimOrderFinishActionCallBack confrimFinishActionCallBack;

/** 全选按钮 */
@property (nonatomic, strong) UIButton *checkStateBtn;

/** 批量申请的按钮 */
@property (nonatomic, strong) UIButton *mutableCheckBtn;

/** 取消订单按钮 */
@property (nonatomic, strong) UIButton *cancelBtn;

/** 确认完成按钮  */
@property (nonatomic, strong) UIButton *confrimFinishedBtn;

/** 立即支付按钮 */
@property (nonatomic, strong) UIButton *paypalPayBtn;

/** 全选的标签 */
@property (nonatomic, strong) UILabel *checkAll;


///  根据订单的状态来显示底部导航栏的中的状态
/// @param orderStatusModel 订单状态模型
- (instancetype)initWithOrderStatusModel:(OrderStatusModel *)orderStatusModel;


@end

NS_ASSUME_NONNULL_END
