//
//  OrderDetailHeadCell.m
//  BusinessOnline
//
//  Created by lgerp on 2020/10/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "OrderDetailHeadCell.h"
#import "OrderStatusModel.h"

@interface OrderDetailHeadCell ()
@property (weak, nonatomic) IBOutlet UILabel *contactLbl;
@property (weak, nonatomic) IBOutlet UILabel *orderRever;
@property (weak, nonatomic) IBOutlet UILabel *orderTime;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UILabel *amount;
@property (weak, nonatomic) IBOutlet UILabel *deliveryLbl;

@property (nonatomic, strong) OrderStatusModel *statusModel;

@end

@implementation OrderDetailHeadCell

+(instancetype)cellWithTableView:(UITableView *)tableView orderInfo:(OrderStatusModel *)statusModel
{
    //封装cell创建过程
    static NSString *ID = @"OrderDetailHeadCell";
    OrderDetailHeadCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle]loadNibNamed:NSStringFromClass([OrderDetailHeadCell class])
                                             owner:nil
                                           options:nil] lastObject];
    }
    cell.statusModel = statusModel;
    [cell setUpView];
    return cell;
}

- (void)setUpView{
    
    self.contactLbl.text = NSLocalizedString(@"收货人", nil);
    self.orderRever.text = NSLocalizedString(@"联系方式", nil);
    self.orderTime.text = NSLocalizedString(@"下单时间", nil);
    self.address.text = NSLocalizedString(@"收货地址", nil);
    self.amount.text = NSLocalizedString(@"商品金额", nil);
    self.deliveryLbl.text = NSLocalizedString(@"配送费:", nil);
    NSString *name = self.statusModel.collectName;
    if (!isNSString(name))
    {
        name = @"";
    }
    self.userLbl.text = name;
    
    NSString *phone = _statusModel.collectPhone;
    if (!isNSString(phone))
    {
        phone = @"";
    }
    self.phoneLbl.text = phone;

    NSString *time = _statusModel.createDate;
    if (!isNSString(time))
    {
        time = @"";
    }
    self.orderTimeLbl.text = time;

    NSString *address = _statusModel.address;
    if (!isNSString(address))
    {
        address = @"";
    }
    self.addressLbl.text = address;

    NSString *price = _statusModel.amount;
    if (!isNSString(price))
    {
        price = @"";
    }
    self.totalOrderPrice.text = [NSString stringWithFormat:@"€ %.2f ",price.floatValue];
//    self.totalOrderPrice.font = [UIFont systemFontOfSize:16.0f weight:bold];
    NSString *delivery = _statusModel.freightAmount;
    self.deliveryMoneyLbl.text = [NSString stringWithFormat:@"€ %.2f ",delivery.floatValue];
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)layoutSubviews
{
    for (UIControl *control in self.subviews){
        if ([control isMemberOfClass:NSClassFromString(@"UITableViewCellEditControl")]){
            for (UIView *v in control.subviews)
            {
                if ([v isKindOfClass: [UIImageView class]]) {
                    UIImageView *img=(UIImageView *)v;
                    if (self.selected) {
                        img.image=[UIImage imageNamed:@"icon_check_sel"];
                    }else
                    {
                        img.image=[UIImage imageNamed:@"icon_check_disa"];
                    }
                }
            }
        }
    }
    [super layoutSubviews];
}

@end
