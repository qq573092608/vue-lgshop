//
//  OrderDetailHeadCell.h
//  BusinessOnline
//
//  Created by lgerp on 2020/10/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

@class OrderStatusModel;

NS_ASSUME_NONNULL_BEGIN

@interface OrderDetailHeadCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *userLbl;

@property (weak, nonatomic) IBOutlet UILabel *phoneLbl;

@property (weak, nonatomic) IBOutlet UILabel *orderTimeLbl;

@property (weak, nonatomic) IBOutlet UILabel *addressLbl;

@property (weak, nonatomic) IBOutlet UILabel *totalOrderPrice;

/** 配送费 */
@property (weak, nonatomic) IBOutlet UILabel *deliveryMoneyLbl;

+(instancetype)cellWithTableView:(UITableView *)tableView orderInfo:(OrderStatusModel *)statusModel;


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier;

@end

NS_ASSUME_NONNULL_END
