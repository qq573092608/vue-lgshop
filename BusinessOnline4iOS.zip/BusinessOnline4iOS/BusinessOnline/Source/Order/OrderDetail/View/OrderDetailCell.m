//
//  OrderDetailCell.m
//  BusinessOnline
//
//  Created by lgerp on 2020/10/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "OrderDetailCell.h"
#import "OrderProductListModel.h"
#import "LGOrderLogicService.h"
#import "LGSpecifiLogicService.h"

@interface OrderDetailCell(){
}

@property (nonatomic, strong) OrderProductListModel *productInfo;

@property (nonatomic, strong) NSIndexPath *selectIndexPath;

@property (nonatomic, strong) NSString *orderState;

@property (weak, nonatomic) IBOutlet UIView *superMainView;

@property (weak, nonatomic) IBOutlet UIButton *applyBtn;
/**
   多规格标签
 */
@property (weak, nonatomic) IBOutlet UILabel *speciLbl;

@end

@implementation OrderDetailCell

+ (instancetype)cellWithTableView:(UITableView *)tableView
                  withProductInfo:(OrderProductListModel *)productInfo
                       orderState:(NSString *)orderState
                  selectIndexPath:(NSIndexPath *)indexPath
{
    //封装cell创建过程
    static NSString *ID = @"OrderDetailCell";
    OrderDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle]loadNibNamed:NSStringFromClass([OrderDetailCell class])
                                             owner:nil
                                           options:nil] lastObject];
    }
    cell.selectIndexPath = indexPath;
    cell.productInfo = productInfo;
    cell.orderState = orderState;
    [cell setUpView];
    return cell;
}

- (void)setUpView{
    
    self.applyBtn.layer.borderWidth = 1.0f;
    self.applyBtn.layer.borderColor = UIColorFromRGB(0xE6E6E6).CGColor;
    self.applyBtn.layer.cornerRadius = 3.0f;
    
    if (self.productInfo.oldGoodsInfo.photoList.count >= 2) {
        PhotoModel *photoModel = self.productInfo.oldGoodsInfo.photoList[1];
        [self.productIcon sd_setImageWithURL:[NSURL URLWithString:photoModel.pathName]
                            placeholderImage:[UIImage imageNamed:@"041_in"]];
    }
    
    [self.applyBtn setTitle:[self getShowTitleStr:self.productInfo.backInfoStatus backType:self.productInfo.infoType]
                   forState:UIControlStateNormal];
    
    self.productName.text = self.productInfo.italianName;
    self.numLbl.text = [NSString stringWithFormat:@"x%ld",(long)self.productInfo.quantity];
    
    self.speciLbl.text = [LGSpecifiLogicService getFinalSpecifiFormate:self.productInfo.tasteData];
    if (self.productInfo.discount.floatValue > 0) {
        self.disCountLbl.hidden = NO;
        NSString *targetStr = [NSString stringWithFormat:@"€ %.2f ",self.productInfo.price.floatValue];
        
        NSMutableAttributedString * priceAttrString =[[NSMutableAttributedString alloc]initWithString:targetStr];
        [priceAttrString addAttribute:NSStrikethroughStyleAttributeName
                                value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle)
                                range:NSMakeRange(0, priceAttrString.length)];
        self.disCountLbl.attributedText = priceAttrString;
        
        self.sigalPrice.text = [NSString stringWithFormat:@"€ %.2f ",self.productInfo.discountPrice.floatValue];
        self.totalPriceLbl.text = [NSString stringWithFormat:@"€ %.2f ",(self.productInfo.discountPrice.floatValue) * self.productInfo.quantity];
    } else {
        self.disCountLbl.hidden = YES;
        self.disCountLbl.text = [NSString stringWithFormat:@"€ %.2f ",self.productInfo.discountPrice.floatValue];
        // 不存在折扣则self.productInfo.oldGoodsInfo为空，应该取productInfo.price
        self.sigalPrice.text = [NSString stringWithFormat:@"€ %.2f ",self.productInfo.price.floatValue];
        self.totalPriceLbl.text = [NSString stringWithFormat:@"€ %.2f ",(self.productInfo.price.floatValue) * self.productInfo.quantity];
    }
}

- (NSString *)getShowTitleStr:(NSString *)backInfoStatus backType:(NSString *)backType
{
    NSString *showStr = @"";
    if ([backInfoStatus isEqualToString:@"0"]) {
        showStr = NSLocalizedString(@"处理中", nil);
    } else {
        // 退款
        if ([backType isEqualToString:@"2"]) {
            if ([backInfoStatus isEqualToString:@"1"]
                       || [backInfoStatus isEqualToString:@"2"]
                       || [backInfoStatus isEqualToString:@"3"]){
                showStr = NSLocalizedString(@"同意退款", nil);
            } else if ([backInfoStatus isEqualToString:@"4"]) {
                showStr = NSLocalizedString(@"退款完成", nil);
            } else if ([backInfoStatus isEqualToString:@"5"]) {
                showStr = NSLocalizedString(@"拒绝退款", nil);
            } else {
                showStr = NSLocalizedString(@"申请售后", nil);
            }
            // 退货退款
        } else if ([backType isEqualToString:@"3"]) {
            if ([backInfoStatus isEqualToString:@"1"]
                       || [backInfoStatus isEqualToString:@"2"]
                       || [backInfoStatus isEqualToString:@"3"]){
                showStr = NSLocalizedString(@"同意退货", nil);
            } else if ([backInfoStatus isEqualToString:@"4"]) {
                showStr = NSLocalizedString(@"退货退款完成", nil);
            } else if ([backInfoStatus isEqualToString:@"5"]) {
                showStr = NSLocalizedString(@"拒绝退货", nil);
            } else {
                showStr = NSLocalizedString(@"申请售后", nil);
            }
        } else {
            showStr = NSLocalizedString(@"申请售后", nil);
        }
    }
    
    return showStr;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


- (IBAction)applyAfterSaleAction:(id)sender {
    
    if (self.applyActionCallBack) {
        self.applyActionCallBack(self.productInfo,self.selectIndexPath);
    }
}


//处理选中背景色问题
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    if (!self.editing) {
        return;
    }
    [super setSelected:selected animated:animated];
    
    if (self.editing) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        self.backgroundColor = [UIColor whiteColor];
        self.productName.backgroundColor = [UIColor clearColor];
        self.sigalPrice.backgroundColor = [UIColor clearColor];
        self.superMainView.backgroundColor = [UIColor whiteColor];
        
        self.numLbl.backgroundColor = [UIColor clearColor];
        self.totalPriceLbl.backgroundColor = [UIColor clearColor];
        self.disCountLbl.backgroundColor = [UIColor clearColor];
      
    }
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    for (UIControl *control in self.subviews){
        if ([control isMemberOfClass:NSClassFromString(@"UITableViewCellEditControl")]){
            for (UIView *v in control.subviews)
            {
                if ([v isKindOfClass: [UIImageView class]]) {
                    UIImageView *img=(UIImageView *)v;
                    if (self.selected) {
                        img.image=[UIImage imageNamed:@"icon_check_sel"];
                    }else
                    {
                        img.image=[UIImage imageNamed:@"icon_check_disa"];
                    }
                }
            }
        }
    }
    [super layoutSubviews];
}

@end
