//
//  OrderDetailBottomView.m
//  BusinessOnline
//
//  Created by lgerp on 2020/10/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "OrderDetailBottomView.h"
#import "UIColor+HexString.h"
#import "OrderStatusModel.h"
#import "LGOrderLogicService.h"

@interface OrderDetailBottomView(){
    
    // 订单信息
    OrderStatusModel *_orderInfo;
}

@end

@implementation OrderDetailBottomView


- (instancetype)initWithOrderStatusModel:(OrderStatusModel *)orderStatusModel
{
    self = [super init];
    if (self) {
        _orderInfo = orderStatusModel;
        [self setUpView];
    }
    return self;
}

- (void)setUpView
{
    self.backgroundColor = [UIColor whiteColor];
  
    // 配置视图的阴影部分
    self.layer.shadowColor = [UIColor colorWithRed:78/255.0 green:78/255.0 blue:78/255.0 alpha:0.1].CGColor;
    self.layer.shadowOffset = CGSizeMake(0,0);
    self.layer.shadowOpacity = 1;
    self.layer.shadowRadius = 16;
    
    
    // 全选的按钮与标签
    self.checkStateBtn = [[UIButton alloc] init];
    self.checkStateBtn.tag = 1;
    [self addSubview:self.checkStateBtn];
    [self.checkStateBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@20);
        make.height.equalTo(@20);
        make.left.mas_equalTo(self.mas_left).offset(20);
        make.centerY.mas_equalTo(self);
    }];
    [self.checkStateBtn setBackgroundImage:[UIImage imageNamed:@"icon_check_disa"]
                             forState:UIControlStateNormal];
    self.checkAll = [[UILabel alloc] init];
    [self addSubview:self.checkAll];
    [self.checkAll mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.checkStateBtn.mas_right).offset(5);
        make.centerY.mas_equalTo(self.checkStateBtn);
    }];
    self.checkAll.text = NSLocalizedString(@"全选", nil);
    self.checkAll.font = [UIFont fontWithName:@"PingFang SC" size: 14];
    self.checkAll.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1.0];
    
    UIButton *maskBtn = [[UIButton alloc] init];
    [self addSubview:maskBtn];
    [maskBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.checkStateBtn.mas_left);
        make.top.mas_equalTo(self.mas_top);
        make.right.mas_equalTo(self.checkAll.mas_right);
        make.bottom.mas_equalTo(self.mas_bottom);
    }];
    [maskBtn addTarget:self
                action:@selector(choiseAll)
      forControlEvents:UIControlEventTouchUpInside];
    
    // 配置底部视图
    [self mutableAppylViewConfig];
}

- (void)mutableAppylViewConfig
{
    // 先判断是否显示批量完成按钮
    if ([LGOrderLogicService isNeedShowMutableApplyBtnWith:_orderInfo]) {
        // 批量申请按钮
        self.mutableCheckBtn = [[UIButton alloc] init];
        [self addSubview:self.mutableCheckBtn];
        [self.mutableCheckBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo([self getBtnWidth]);
            make.height.equalTo([self getBtnHeight]);
            make.right.mas_equalTo(self.mas_right).offset(-20);
            make.centerY.mas_equalTo(self);
        }];
        
        [self.mutableCheckBtn setTitle:NSLocalizedString(@"批量申请", nil) forState:UIControlStateNormal];
        [self.mutableCheckBtn setBackgroundColor:MainColor];
        
        self.mutableCheckBtn.titleLabel.font = [UIFont fontWithName:@"PingFang SC" size: 14];
        [self.mutableCheckBtn setTitleColor:[UIColor ColorWithHexString:@"#FFFFFF"]
                                   forState:UIControlStateNormal];
        self.mutableCheckBtn.layer.cornerRadius = 3.0f;
        [self.mutableCheckBtn addTarget:self
                            action:@selector(mutalApply)
                  forControlEvents:UIControlEventTouchUpInside];
        
        // 在判断是否显示paypal
        [self payMentViewConfig:YES];
    } else {
        [self payMentViewConfig:NO];
    }
}

- (void)payMentViewConfig:(BOOL)isMutableApplyBtnExist{
    if ([_orderInfo.paymentMethod isEqualToString:@"PayPal"])
    {
        if (_orderInfo.payState.intValue != 1 && ![LGOrderLogicService isPaypalSubmitBtnEnableWithOrderState:_orderInfo.orderState backStatus:_orderInfo.backStatus]) {
            [self cancelBtnViewConfig:isMutableApplyBtnExist isPaypalBtnExist:NO];
            return;
        }
        
        [self addSubview:self.paypalPayBtn];
        [self.paypalPayBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo([self getBtnWidth]);
            make.height.equalTo([self getBtnHeight]);
            if (isMutableApplyBtnExist) {
                make.right.mas_equalTo(self.mutableCheckBtn.mas_left).offset(-20);
            } else {
                make.right.mas_equalTo(self.mas_right).offset(-20);
            }
            make.centerY.mas_equalTo(self);
        }];
        
        if (_orderInfo.payState.intValue == 1) {
            // 已付款
            [self.paypalPayBtn setTitle:NSLocalizedString(@"已付款", nil) forState:UIControlStateNormal];
            // #8BC34A
            [self.paypalPayBtn setTitleColor:MainColor
                                       forState:UIControlStateNormal];
            self.paypalPayBtn.layer.borderWidth = 1;
            self.paypalPayBtn.layer.borderColor = MainColor.CGColor;
            [self.paypalPayBtn setBackgroundColor:[UIColor clearColor]];
        } else {
            if ([LGOrderLogicService isPaypalSubmitBtnEnableWithOrderState:_orderInfo.orderState backStatus:_orderInfo.backStatus]) {
                // 立即支付
                [self.paypalPayBtn setTitle:NSLocalizedString(@"立即支付", nil) forState:UIControlStateNormal];
                [self.paypalPayBtn setTitleColor:[UIColor whiteColor]
                                           forState:UIControlStateNormal];
                [self.paypalPayBtn addTarget:self
                                      action:@selector(payclick)
                            forControlEvents:UIControlEventTouchUpInside];
                [self.paypalPayBtn setBackgroundColor:MainColor];
            }
        }
        
        [self cancelBtnViewConfig:isMutableApplyBtnExist isPaypalBtnExist:YES];
    } else {
        [self cancelBtnViewConfig:isMutableApplyBtnExist isPaypalBtnExist:NO];
    }
}

- (void)cancelBtnViewConfig:(BOOL)isMutableApplyBtnExist isPaypalBtnExist:(BOOL)isPaypalBtnExist
{
    if ([LGOrderLogicService isNeedShowCancelBtnWith:_orderInfo.orderState backStatus:_orderInfo.backStatus]) {
       
        [self addSubview:self.cancelBtn];
        [self.cancelBtn addTarget:self
                           action:@selector(cancelAction)
                 forControlEvents:UIControlEventTouchUpInside];
        [self.cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo([self getBtnWidth]);
            make.height.equalTo([self getBtnHeight]);
            
            if (isPaypalBtnExist) {
                make.right.mas_equalTo(self.paypalPayBtn.mas_left).offset(-20);
            } else {
                if (isMutableApplyBtnExist) {
                    make.right.mas_equalTo(self.mutableCheckBtn.mas_left).offset(-20);
                } else {
                    make.right.mas_equalTo(self).offset(-20);
                }
            }
            make.centerY.mas_equalTo(self);
        }];
        // 是否显示确认完成的按钮
        [self confrimBtnViewConfig:isMutableApplyBtnExist
                  isPaypalBtnExist:isPaypalBtnExist
                  isCancelBtnExist:YES];
    } else {
        // 是否显示确认完成的按钮
        [self confrimBtnViewConfig:isMutableApplyBtnExist
                  isPaypalBtnExist:isPaypalBtnExist
                  isCancelBtnExist:NO];
    }
}

- (void)confrimBtnViewConfig:(BOOL)isMutableApplyBtnExist
            isPaypalBtnExist:(BOOL)isPaypalBtnExist
            isCancelBtnExist:(BOOL)isCancelBtnExist
{
    if ([LGOrderLogicService isNeedShowConfrimFinishBtnWithBackStatus:_orderInfo.backStatus]) {
        [self addSubview:self.confrimFinishedBtn];
        [self.confrimFinishedBtn addTarget:self
                                    action:@selector(confrimFinishBtnAction)
                          forControlEvents:UIControlEventTouchUpInside];
        [self.confrimFinishedBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo([self getBtnWidth]);
            make.height.equalTo([self getBtnHeight]);
            if (isCancelBtnExist) {
                make.right.mas_equalTo(self.cancelBtn.mas_left).offset(-20);
            } else {
                if (isPaypalBtnExist) {
                    make.right.mas_equalTo(self.paypalPayBtn.mas_left).offset(-20);
                } else {
                    if (isMutableApplyBtnExist) {
                        make.right.mas_equalTo(self.mutableCheckBtn.mas_left).offset(-20);
                    } else {
                        make.right.mas_equalTo(self.mas_right).offset(-20);
                    }
                }
            }
            make.centerY.mas_equalTo(self);
        }];
    }
}

#pragma mark - 属性定义
- (NSNumber *) getBtnHeight{
    return @36;
}

- (NSNumber *) getBtnWidth{
    return @80;
}

#pragma mark - 按钮的回调事件

- (void)confrimFinishBtnAction
{
    if (self.confrimFinishActionCallBack) {
        self.confrimFinishActionCallBack();
    }
}

- (void)cancelAction
{
    if (self.cancelOrderAction) {
        self.cancelOrderAction();
    }
}

- (void)payclick {
    if (self.paypalSubmitCallBack) {
        self.paypalSubmitCallBack(_orderInfo);
    }
}

- (void)choiseAll {
    if (self.selectAllCallBack) {
        self.selectAllCallBack(self.checkStateBtn);
    }
}

- (void)mutalApply
{
    if (self.mutApplyCallBack) {
        self.mutApplyCallBack();
    }
}

#pragma mark - 懒加载

- (UIButton *)confrimFinishedBtn
{
    if (!_confrimFinishedBtn) {
        _confrimFinishedBtn = [[UIButton alloc] init];
        [_confrimFinishedBtn setTitle:NSLocalizedString(@"确认完成", nil)
                             forState:UIControlStateNormal];
        [_confrimFinishedBtn setTitleColor:[UIColor whiteColor]
                                   forState:UIControlStateNormal];
        _confrimFinishedBtn.titleLabel.font = [UIFont lgFontFamily:@"" size:16.0f];
        _confrimFinishedBtn.layer.cornerRadius = 3;
        [_confrimFinishedBtn setBackgroundColor:MainColor];
    }
    return _confrimFinishedBtn;
}

- (UIButton *)cancelBtn
{
    if (!_cancelBtn) {
        _cancelBtn = [[UIButton alloc] init];
        [_cancelBtn setTitle:NSLocalizedString(@"取消订单", nil) forState:UIControlStateNormal];
        [_cancelBtn setTitleColor:[UIColor ColorWithHexString:@"#1D1D1D"]
                                   forState:UIControlStateNormal];
        _cancelBtn.titleLabel.font = [UIFont lgFontFamily:@"" size:16.0f];
        _cancelBtn.layer.cornerRadius = 3;
        _cancelBtn.layer.borderWidth = 1;
        _cancelBtn.layer.borderColor = [UIColor ColorWithHexString:@"#D7D7D7"].CGColor;
    }
    return _cancelBtn;
}

- (UIButton *)paypalPayBtn
{
    if (!_paypalPayBtn) {
        _paypalPayBtn = [[UIButton alloc] init];
        _paypalPayBtn.layer.cornerRadius = 3.0f;
        _paypalPayBtn.titleLabel.font = [UIFont lgFontFamily:@"" size:16.0f];
    }
    return _paypalPayBtn;
}



@end
