//
//  OrderStatusNode.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "OrderStatusNode.h"
#import "OrderDetailModel.h"
#import "OrderStatusModel.h"

@interface OrderStatusNode ()
{
//    OrderDetailModel *_model;
    OrderStatusModel *_model;
    OrderStatusModel *_statusModel;
    //*_textNode4,*_textNode14,
    ASTextNode *_textNode0,*_textNode1,*_textNode2,*_textNode3,*_textNode5,*_textNode10,*_textNode11,*_textNode12,*_textNode13,*_textNode15,*_freightKey,*_freightValue;
    ASButtonNode *_paypalnode;
}
@end
@implementation OrderStatusNode

-(instancetype)initWithStatusModel:(OrderStatusModel *)statusModel
{
    if (self = [super init]) {
        self.backgroundColor = [UIColor whiteColor];
        _statusModel = statusModel;
        
        _textNode0 = [ASTextNode new];
        [self addSubnode:_textNode0];
        _textNode0.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"shouhuoren2", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:17]}];
        
        NSString *name = _statusModel.collectName;
        if (!isNSString(name))
        {
            name = @"";
        }
        _textNode10 = [ASTextNode new];
        [self addSubnode:_textNode10];
        _textNode10.attributedText = [[NSAttributedString alloc] initWithString:name attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),NSFontAttributeName:[UIFont systemFontOfSize:17]}];
        
        _textNode1 = [ASTextNode new];
        [self addSubnode:_textNode1];
        _textNode1.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"phonetxt", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:17]}];
        
        NSString *phone = _statusModel.collectPhone;
        if (!isNSString(phone))
        {
            phone = @"";
        }
        _textNode11 = [ASTextNode new];
        [self addSubnode:_textNode11];
        _textNode11.attributedText = [[NSAttributedString alloc] initWithString:phone attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),NSFontAttributeName:[UIFont systemFontOfSize:17]}];
        
        _textNode2 = [ASTextNode new];
        [self addSubnode:_textNode2];
        _textNode2.attributedText = [[NSAttributedString alloc] initWithString:localizableString(@"xiadanTime") attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:17]}];
        
        NSString *time = _statusModel.createDate;
        if (!isNSString(time))
        {
            time = @"";
        }
        _textNode12 = [ASTextNode new];
        [self addSubnode:_textNode12];
        _textNode12.attributedText = [[NSAttributedString alloc] initWithString:time attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),NSFontAttributeName:[UIFont systemFontOfSize:17]}];
        
        _textNode3 = [ASTextNode new];
        [self addSubnode:_textNode3];
        _textNode3.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"shouhuodizhi2", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:17]}];
        
        NSString *address = _statusModel.address;
        if (!isNSString(address))
        {
            address = @"";
        }
        _textNode13 = [ASTextNode new];
        [self addSubnode:_textNode13];
        _textNode13.attributedText = [[NSAttributedString alloc] initWithString:address
                                                                     attributes:@{
                                                                         NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack),
                                                                         NSFontAttributeName:[UIFont systemFontOfSize:17]}
                                      ];
        
        _textNode5 = [ASTextNode new];
        [self addSubnode:_textNode5];
        _textNode5.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"订单金额", nil)
                                                                    attributes:@{
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),
                                                                        NSFontAttributeName:[UIFont systemFontOfSize:17]}
                                     ];
        
        NSString *price = _statusModel.totalAmount;
        if (!isNSString(price))
        {
            price = @"";
        }
        _textNode15 = [ASTextNode new];
        [self addSubnode:_textNode15];
        if (@available(iOS 8.2, *)) {
            _textNode15.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %@",price] attributes:@{NSForegroundColorAttributeName:MainColor,NSFontAttributeName:[UIFont systemFontOfSize:17 weight:UIFontWeightBold]}];
        } else {
            _textNode15.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %@",price] attributes:@{NSForegroundColorAttributeName:MainColor,NSFontAttributeName:[UIFont systemFontOfSize:17]}];
        }
        
        _paypalnode = [ASButtonNode new];
        [self addSubnode:_paypalnode];
        _paypalnode.layer.cornerRadius = 3;
        _paypalnode.layer.borderWidth = 1;
        if (_statusModel.payState.intValue == 1)
        {
            [_paypalnode setTitle:NSLocalizedString(@"已付款", nil) withFont:[UIFont systemFontOfSize:16] withColor:UIColorFromRGB(0x8BC34A) forState:UIControlStateNormal];
            _paypalnode.layer.borderColor = [UIColorFromRGB(0x8BC34A) CGColor];
        }
        else
        {
            [_paypalnode setTitle:NSLocalizedString(@"立即支付", nil)
                         withFont:[UIFont systemFontOfSize:16]
                        withColor:UIColorFromRGB(0x2196F3)
                         forState:UIControlStateNormal];
            [_paypalnode addTarget:self
                            action:@selector(payclick)
                  forControlEvents:ASControlNodeEventTouchUpInside];
            _paypalnode.layer.borderColor = [UIColorFromRGB(0x2196F3) CGColor];
        }
        
        _freightKey = [ASTextNode new];
        [self addSubnode:_freightKey];
        _freightKey.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"配送费:", nil)
                                                                     attributes:@{
                                                                         NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),
                                                                                  NSFontAttributeName:[UIFont systemFontOfSize:17]}];
        
        NSString *freight = _statusModel.freightAmount;
        if (!isNSString(freight))
        {
            freight = @"";
        }
        
        _freightValue = [ASTextNode new];
        [self addSubnode:_freightValue];
        if (@available(iOS 8.2, *)) {
            _freightValue.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %@",freight]
                                                                           attributes:@{NSForegroundColorAttributeName:FreightColor,
                                                                                        NSFontAttributeName:[UIFont systemFontOfSize:17 weight:UIFontWeightBold]}];
        } else {
            _freightValue.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %@",freight]
                                                                           attributes:@{NSForegroundColorAttributeName:FreightColor,
                                                                                        NSFontAttributeName:[UIFont systemFontOfSize:17]}];
        }
        
    }
    return self;
}
-(instancetype)initWithModel:(OrderStatusModel *)model
{
    if (self = [super init])
    {
        self.backgroundColor = [UIColor whiteColor];
        _model = model;
        
        _textNode0 = [ASTextNode new];
        [self addSubnode:_textNode0];
        _textNode0.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"shouhuoren2", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        NSString *name = _model.collectName;
        if (!isNSString(name))
        {
            name = @"";
        }
        _textNode10 = [ASTextNode new];
        [self addSubnode:_textNode10];
        _textNode10.attributedText = [[NSAttributedString alloc] initWithString:name attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        _textNode1 = [ASTextNode new];
        [self addSubnode:_textNode1];
        _textNode1.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"phonetxt", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        NSString *phone = _model.collectPhone;
        if (!isNSString(phone))
        {
            phone = @"";
        }
        _textNode11 = [ASTextNode new];
        [self addSubnode:_textNode11];
        _textNode11.attributedText = [[NSAttributedString alloc] initWithString:phone attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        _textNode2 = [ASTextNode new];
        [self addSubnode:_textNode2];
        _textNode2.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"xiadanTime", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        NSString *time = _model.createDate;
        if (!isNSString(time))
        {
            time = @"";
        }
        _textNode12 = [ASTextNode new];
        [self addSubnode:_textNode12];
        _textNode12.attributedText = [[NSAttributedString alloc] initWithString:time attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        _textNode3 = [ASTextNode new];
        [self addSubnode:_textNode3];
        _textNode3.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"shouhuodizhi2", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        NSString *address = _model.address;
        if (!isNSString(address))
        {
            address = @"";
        }
        _textNode13 = [ASTextNode new];
        [self addSubnode:_textNode13];
        _textNode13.attributedText = [[NSAttributedString alloc] initWithString:address attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        _textNode5 = [ASTextNode new];
        [self addSubnode:_textNode5];
        _textNode5.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"订单金额", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight),NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        
        NSString *price = _model.totalAmount;
        if (!isNSString(price))
        {
            price = @"";
        }
        _textNode15 = [ASTextNode new];
        [self addSubnode:_textNode15];
        if (@available(iOS 8.2, *)) {
            _textNode15.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %@",price] attributes:@{NSForegroundColorAttributeName:MainColor,NSFontAttributeName:[UIFont systemFontOfSize:15 weight:UIFontWeightBold]}];
        } else {
            _textNode15.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %@",price] attributes:@{NSForegroundColorAttributeName:MainColor,NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        }
        
    }
    return self;
}

static CGFloat keyWidth = 100.0f;
static CGFloat edgSpacing = 15.0f;
static CGFloat nodeSpacing = 10.0f;

-(ASLayoutSpec *)layoutSpecThatFits:(ASSizeRange)constrainedSize
{
    _textNode0.style.width = ASDimensionMakeWithPoints(keyWidth);
    _textNode1.style.width = ASDimensionMakeWithPoints(keyWidth);
    _textNode2.style.width = ASDimensionMakeWithPoints(keyWidth);
    _textNode3.style.width = ASDimensionMakeWithPoints(keyWidth);
    _textNode5.style.width = ASDimensionMakeWithPoints(keyWidth);
    _freightKey.style.width = ASDimensionMakeWithPoints(keyWidth);
    _paypalnode.style.height = ASDimensionMakeWithPoints(36);
    _paypalnode.style.width = ASDimensionMakeWithPoints(80);
    
    _textNode10.style.width = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-keyWidth);
    _textNode11.style.width = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-keyWidth);
    _textNode12.style.width = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-keyWidth);
    _textNode13.style.width = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-keyWidth);
    _textNode15.style.width = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-keyWidth);
    _freightValue.style.width = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-keyWidth);
    
    ASStackLayoutSpec *spec1 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal spacing:nodeSpacing justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsStart children:@[_textNode0,_textNode10]];
    ASStackLayoutSpec *spec2 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal spacing:nodeSpacing justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsStart children:@[_textNode1,_textNode11]];
    ASStackLayoutSpec *spec3 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal spacing:nodeSpacing justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsStart children:@[_textNode2,_textNode12]];
    ASStackLayoutSpec *spec4 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal spacing:nodeSpacing justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsStart children:@[_textNode3,_textNode13]];
    ASStackLayoutSpec *spec6 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal spacing:nodeSpacing justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsStart children:@[_textNode5,_textNode15]];
    ASStackLayoutSpec *spec7 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal spacing:nodeSpacing justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsStart children:@[_freightKey,_freightValue]];
    ASStackLayoutSpec *spec8 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical spacing:nodeSpacing justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsStart children:@[spec1,spec2,spec3,spec4,spec6,spec7]];
    
    if ([_statusModel.paymentMethod isEqualToString:@"PayPal"])
    {
        ASStackLayoutSpec *spec9 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical spacing:nodeSpacing justifyContent:ASStackLayoutJustifyContentEnd alignItems:ASStackLayoutAlignItemsEnd children:@[spec8,_paypalnode]];
        return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(edgSpacing, edgSpacing, edgSpacing/2, edgSpacing) child:spec9];;
    }
    else
    {
        return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(edgSpacing, edgSpacing, edgSpacing, edgSpacing) child:spec8];
    }
    
    
}

- (void)payclick
{
    if (self.paycallback)
    {
        self.paycallback(_statusModel);
    }
}

@end
