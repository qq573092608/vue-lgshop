//
//  OrderStatusNode.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <AsyncDisplayKit/ASCellNode.h>
@class OrderDetailModel,OrderStatusModel;

NS_ASSUME_NONNULL_BEGIN

@interface OrderStatusNode : ASCellNode

@property (nonatomic,copy)void(^paycallback)(OrderStatusModel *model);

- (instancetype)initWithModel:(OrderStatusModel *)model;

- (instancetype)initWithStatusModel:(OrderStatusModel *)statusModel;

@end

NS_ASSUME_NONNULL_END
