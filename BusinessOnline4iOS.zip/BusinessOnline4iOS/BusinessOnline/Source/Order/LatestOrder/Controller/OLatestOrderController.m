//
//  OLatestOrderController.m
//  BusinessOnline
//
//  Created by clitics on 2019/3/8.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "OLatestOrderController.h"
#import "OrderListModel.h"
#import "OrderListNode.h"
#import "OrderDetailController.h"
#import "HomeController.h"

@interface OLatestOrderController ()<ASTableDelegate,ASTableDataSource>
{
    NSString *_lately;
}
@property (nonatomic,strong)ASTableNode *tableNode;
@property (nonatomic,strong)NSMutableArray *dataSource;

@end

@implementation OLatestOrderController

-(instancetype)init
{
    if (self = [super init])
    {
        _dataSource = [NSMutableArray array];
        _lately = @"1";
        
        _tableNode = [[ASTableNode alloc] initWithStyle:UITableViewStyleGrouped];
        [self.view addSubnode:_tableNode];
        _tableNode.view.separatorColor = [UIColor whiteColor];
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, CGFLOAT_MIN)];
        _tableNode.view.tableFooterView = footerView;
        [_tableNode.view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.bottom.right.mas_equalTo(self.view);
        }];
        WEAK_SELF(weakSelf);
        self.refresh = [[QPGRefreshTool alloc] init];
        [self.refresh gifModelRefresh:_tableNode.view refreshType:RefreshTypeDouble firstRefresh:YES dropDownBlock:^{
            if ([weakSelf.tableNode.view.mj_header isRefreshing])
            {
                [weakSelf doNetworkRequestForHeader];
            }
        } upDropBlock:^{
            if ([weakSelf.tableNode.view.mj_footer isRefreshing])
            {
                [weakSelf doNetworkRequestForFooter];
            }
        }];
        _tableNode.delegate = self;
        _tableNode.dataSource = self;
        
        self.emptyModel = [[EmptyModel alloc] initWithScrollView:_tableNode.view type:ControllerStateNormal];
        //        [self.refresh beginRefreshing];
    }
    return self;
}

- (void)doNetworkRequestForHeader
{
    [self.tableNode.view.mj_footer resetNoMoreData];
    [self.dataSource removeAllObjects];
    [self.tableNode reloadData];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
//    [params setObject:@"1" forKey:@"orderType"];
    [params setObject:@(1) forKey:pageKey];
    [params setObject:@(_rows) forKey:rowsKey];
    WEAK_SELF(weakSelf);
    [NetworkManager getWithURL:CREATE_URL(url_order_list) params:params success:^(id json) {

        [weakSelf headerCallback:json];
    } failure:^(NSError *error) {
        [self.refresh endRefresh];
        [self.emptyModel setState:ControllerStateNoNetwork];
    }];
}

- (void)headerCallback:(id)json
{
    [self.refresh endRefresh];
    if (!isNSDictionary(json))
    {
        [self.emptyModel setStatus:NSLocalizedString(@"unknownerror", nil)];
        return;
    }
    if ([get_Value_for_key_from_obj(json, successKey) integerValue] == 0) {
        HomeController *homeVC = [[HomeController alloc]init];
        homeVC.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:homeVC animated:YES completion:nil];
    }
    else if ([get_Value_for_key_from_obj(json, successKey) integerValue] == 1)
    {
        NSArray *temp = [OrderListModel mj_objectArrayWithKeyValuesArray:get_Value_for_key_from_obj(json, dataKey)];
        _total = [get_Value_for_key_from_obj(json, totalKey) integerValue];
        if (!temp.count)
        {
//            [self.emptyModel setStatus:get_Value_for_key_from_obj(json, messageKey)];
            [self.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
            return;
        }
        [self.dataSource addObjectsFromArray:temp];
        if (temp.count == _total)
        {
            [self.tableNode.view.mj_footer endRefreshingWithNoMoreData];
        }
        [self.tableNode reloadData];
        _page = 2;
    }
    else
    {
//        [self.emptyModel setStatus:get_Value_for_key_from_obj(json, messageKey)];
        [self.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
    }
}

- (void)doNetworkRequestForFooter
{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:@"1" forKey:@"orderType"];
    [params setObject:@(_page) forKey:pageKey];
    [params setObject:@(_rows) forKey:rowsKey];

    WEAK_SELF(weakSelf);
    [NetworkManager postWithURL:CREATE_URL(url_order_list) params:params isUsedSignal:NO success:^(id json) {
        [weakSelf headerCallback:json];
    } failure:^(NSError *error) {
        [self.refresh endRefresh];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}

- (void)footerCallback:(id)json
{
    [self.refresh endRefresh];
    if (!isNSDictionary(json))
    {
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"unknownerror", nil)];
        return;
    }
    if ([get_Value_for_key_from_obj(json, successKey) integerValue])
    {
        NSArray *temp = [OrderListModel mj_objectArrayWithKeyValuesArray:get_Value_for_key_from_obj(json, dataKey)];
        [self.dataSource addObjectsFromArray:temp];
        if (self.dataSource.count == _total)
        {
            [self.tableNode.view.mj_footer endRefreshingWithNoMoreData];
        }
        [self.tableNode reloadData];
        _page++;
    }
    else
    {
        [MBProgressHUD showErrorMessage:NSLocalizedString(@"net_error", nil)];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    dispatch_async(dispatch_get_main_queue(), ^{
        self.title = NSLocalizedString(@"order_list", nil);
    });
}


#pragma mark delegate methods
-(NSInteger)numberOfSectionsInTableNode:(ASTableNode *)tableNode
{
    return self.dataSource.count;
}

-(NSInteger)tableNode:(ASTableNode *)tableNode numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return CGFLOAT_MIN;
}

-(ASCellNode *)tableNode:(ASTableNode *)tableNode nodeForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OrderListNode *node = [[OrderListNode alloc] initWithModel:self.dataSource[indexPath.section]];
    node.selectionStyle = UITableViewCellSelectionStyleNone;
    return node;
}

-(void)tableNode:(ASTableNode *)tableNode didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    OrderListModel *model = self.dataSource[indexPath.section];
    OrderDetailController *ovc = [[OrderDetailController alloc] initWithText:model.orderCode indexPath:indexPath];
    [self.navigationController pushViewController:ovc animated:YES];
}

@end
