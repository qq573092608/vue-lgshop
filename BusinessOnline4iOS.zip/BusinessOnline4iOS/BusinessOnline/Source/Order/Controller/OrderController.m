//
//  OrderController.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/25.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "OrderController.h"
#import "OrderListController.h"
#import "NSString+Size.h"
#import "BaseService.h"

#import "JXCategoryView.h"
#import "JXCategoryListContainerView.h"

@interface OrderController ()<JXCategoryListContainerViewDelegate,JXCategoryViewDelegate>

@property (nonatomic,strong)NSMutableArray *dataSource;
@property (nonatomic,strong)OrderListController *allTypeController;
@property (nonatomic,strong)OrderListController *disposingTypeController;
@property (nonatomic,strong)OrderListController *disposedTypeController;
@property (nonatomic,strong)OrderListController *refundTypeController;

@property (nonatomic, strong) JXCategoryTitleView *categoryView;
@property (nonatomic, strong) JXCategoryListContainerView *listContainerView;

@end

@interface OrderController (){
    NSMutableArray *_titles;
}

@end


@implementation OrderController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = NSLocalizedString(@"ordermanager", nil);
    self.tabBarItem.title = NSLocalizedString(@"order", nil);
    [self addSubViews];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(reloadDataAction)
                                                 name:@"reloadOrderListAction" object:nil];
}

- (void)reloadDataAction
{
    self.categoryView.defaultSelectedIndex = 0;
    self.categoryView.titles = _titles;
    [self.categoryView reloadData];
}

- (void)addSubViews
{
    self.listContainerView = [[JXCategoryListContainerView alloc] initWithType:JXCategoryListContainerType_ScrollView delegate:self];
    [self.view addSubview:self.listContainerView];
    NSArray *titles = @[
                        [NSLocalizedString(@"order_all", nil) uppercaseStringWithLocale:[NSLocale currentLocale]],
                        [NSLocalizedString(@"order_ing", nil) uppercaseStringWithLocale:[NSLocale currentLocale]],
                        [NSLocalizedString(@"order_done", nil) uppercaseStringWithLocale:[NSLocale currentLocale]],
                        [NSLocalizedString(@"order_after", nil) uppercaseStringWithLocale:[NSLocale currentLocale]]
                      ];
    _titles = titles.mutableCopy;
    self.categoryView = [[JXCategoryTitleView alloc] init];
    //优化关联listContainer，以后后续比如defaultSelectedIndex等属性，才能同步给listContainer
    self.categoryView.listContainer = self.listContainerView;
    self.categoryView.delegate = self;
    self.categoryView.titles = _titles;
    self.categoryView.titleSelectedColor = MainColor;
//    self.categoryView.titleSelectedFont = [UIFont fontWithName:@"PingFangSC-Medium" size:16.0f];
    
    // PingFang-SC-Medium
    self.categoryView.titleFont = [UIFont fontWithName:@"PingFang SC" size: 16.0f];
    self.categoryView.defaultSelectedIndex = 0;
    JXCategoryIndicatorLineView *lineView = [[JXCategoryIndicatorLineView alloc] init];
    lineView.indicatorColor = MainColor;
    self.categoryView.indicators = @[lineView];
    [self.view addSubview:self.categoryView];
}

#pragma mark - defaultDelegate

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = (self.categoryView.selectedIndex == 0);
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    // 设置宽高
    self.categoryView.frame = CGRectMake(0, 0, self.view.bounds.size.width, 50);
    self.listContainerView.frame = CGRectMake(0, 50, self.view.bounds.size.width, self.view.bounds.size.height - 50);
}

#pragma mark - JXCategoryListContainerViewDelegate

- (id<JXCategoryListContentViewDelegate>)listContainerView:(JXCategoryListContainerView *)listContainerView
                                          initListForIndex:(NSInteger)index {
    
    if (!index) {
         return self.allTypeController;
        // return [[OrderListController alloc] initWithType:OrderListTypeAll];
    } else if (index == 1) {
         return self.disposingTypeController;
        // return [[OrderListController alloc] initWithType:OrderListTypeDisposing];;
    } else if (index == 2){
        return self.disposedTypeController;
        // return [[OrderListController alloc] initWithType:OrderListTypeDisposed];
    } else {
        return self.refundTypeController;
        // return [[OrderListController alloc] initWithType:OrderListTypeRefund];
    }
}

- (NSInteger)numberOfListsInlistContainerView:(JXCategoryListContainerView *)listContainerView {
    return _titles.count;
}

#pragma mark - JXCategoryViewDelegate

- (void)categoryView:(JXCategoryBaseView *)categoryView didSelectedItemAtIndex:(NSInteger)index {
    //侧滑手势处理
    self.navigationController.interactivePopGestureRecognizer.enabled = (index == 0);
}

#pragma  mark - 懒加载
-(NSMutableArray *)dataSource
{
    if (!_dataSource)
    {
        _dataSource = [NSMutableArray array];
    }
    return _dataSource;
}

// 全部订单
-(OrderListController *)allTypeController
{
    if (!_allTypeController)
    {
        _allTypeController = [[OrderListController alloc] initWithType:OrderListTypeAll];
    }
    return _allTypeController;
}

// 处理中的订单
-(OrderListController *)disposingTypeController
{
    if (!_disposingTypeController)
    {
        _disposingTypeController = [[OrderListController alloc] initWithType:OrderListTypeDisposing];
    }
    return _disposingTypeController;
}

// 处理完成的订单
-(OrderListController *)disposedTypeController
{
    if (!_disposedTypeController)
    {
        _disposedTypeController = [[OrderListController alloc] initWithType:OrderListTypeDisposed];
    }
    return _disposedTypeController;
}

// 退换货订单
- (OrderListController *)refundTypeController {
    if (!_refundTypeController) {
        _refundTypeController = [[OrderListController alloc] initWithType:OrderListTypeRefund];
    }
    return _refundTypeController;
}


@end
