//
//  OrderListNode.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "OrderListNode.h"
#import "OrderListModel.h"
#import "OrderListNormalModel.h"
#import "LGOrderLogicService.h"
#import "UIColor+HexString.h"

@interface OrderListNode ()
{
    ASTextNode *_textNode1,*_textNode11,*_textNode2,*_textNode12,*_textNode3,*_textNode13,*_textNode4,*_textNode14,*_textNode5,*_textNode15,*_textNode6,*_textNode16,*_textNode7,*_textNode17;
    ASDisplayNode *_lineNode;
    OrderListModel *_model;
    OrderListNormalModel *_normalModel;
    ASButtonNode *_paypalnode;
    /// 售后状态
    ASTextNode *_afterSaleState;
    /// 售后内容
    ASTextNode *_afterSaleCtx;
    
    // 当前操作的索引
    NSIndexPath *_currentIndexPath;
    // 最底部的下划线
    ASDisplayNode *_bottomLine;
}

@property (nonatomic, strong)ASButtonNode *cancelOrderBtn;
@property (nonatomic, strong)ASButtonNode *payRightNowBtn;

// 确认完成的按钮
@property (nonatomic, strong)ASButtonNode *confrimCompleteNode;


@end
@implementation OrderListNode

-(instancetype)initWithNormalModel:(OrderListNormalModel *)normalModel andIndexPath:(NSIndexPath *)selectIndexPath
{
    if (self = [super init])
    {
        self.backgroundColor = [UIColor whiteColor];
        _normalModel = normalModel;
        
        _currentIndexPath = selectIndexPath;
        
        _lineNode = [ASDisplayNode new];
        [self addSubnode:_lineNode];
        _lineNode.backgroundColor = UnderLineColor;
        
        _bottomLine = [ASDisplayNode new];
        [self addSubnode:_bottomLine];
        _bottomLine.backgroundColor = UnderLineColor;
        
        _textNode1 = [ASTextNode new];
        [self addSubnode:_textNode1];
        if (@available(iOS 8.2, *)) {
            _textNode1.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_form", nil)
                                                                        attributes:@{
                                                                            NSFontAttributeName:[UIFont systemFontOfSize:17 weight:UIFontWeightBold],
                                                                            NSForegroundColorAttributeName:UIColorFromRGB(colorBlack)}
                                         ];
        } else {
            _textNode1.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_form", nil)
                                                                        attributes:@{
                                                                            NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                            NSForegroundColorAttributeName:UIColorFromRGB(colorBlack)}
                                         ];
        }
        
        NSString *supplier = _normalModel.companyName;
//        NSString *supplier = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
        if (!isNSString(supplier)) {
            supplier = @"";
        }
        _textNode11 = [ASTextNode new];
        [self addSubnode:_textNode11];
        _textNode11.attributedText = [[NSAttributedString alloc] initWithString:supplier
                                                                     attributes:@{
                                                                         NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                         NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)
                                                                     }
                                      ];
        
        _textNode2 = [ASTextNode new];
        [self addSubnode:_textNode2];
        if (@available(iOS 8.2, *)) {
            _textNode2.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_code", nil)
                                                                        attributes:@{
                                                                            NSFontAttributeName:[UIFont systemFontOfSize:17 weight:UIFontWeightBold],
                                                                            NSForegroundColorAttributeName:UIColorFromRGB(colorBlack)}
                                         ];
        } else {
            _textNode2.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_code", nil)
                                                                        attributes:@{
                                                                            NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                            NSForegroundColorAttributeName:UIColorFromRGB(colorBlack)}
                                         ];
        }
        
        NSString *orderCode = _normalModel.orderCode;
        if (!isNSString(orderCode))
        {
            orderCode = @"";
        }
        _textNode12 = [ASTextNode new];
        [self addSubnode:_textNode12];
        _textNode12.attributedText = [[NSAttributedString alloc] initWithString:orderCode
                                                                     attributes:@{
                                                                         NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                         NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}
                                      ];
        
        _textNode3 = [ASTextNode new];
        [self addSubnode:_textNode3];
        _textNode3.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"订单金额", nil)
                                                                    attributes:@{
                                                                        NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)}
                                     ];
        
        NSString *orderCharge = [NSString stringWithFormat:@"%.2f",_normalModel.totalAmount.floatValue];
        if (!isNSString(orderCharge)) {
            orderCharge = @"";
        }
        _textNode13 = [ASTextNode new];
        [self addSubnode:_textNode13];
        if (@available(iOS 8.2, *)) {
            _textNode13.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %.2f",orderCharge.floatValue]
                                                                         attributes:@{
                                                                             NSFontAttributeName:[UIFont systemFontOfSize:17 weight:UIFontWeightBold],
                                                                             NSForegroundColorAttributeName:MainColor}
                                          ];
        } else {
            _textNode13.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %.2f",orderCharge.floatValue]
                                                                         attributes:@{
                                                                             NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                             NSForegroundColorAttributeName:MainColor}
                                          ];
        }
        
        _textNode4 = [ASTextNode new];
        [self addSubnode:_textNode4];
        _textNode4.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_time", nil)
                                                                    attributes:@{
                                                                        NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)}
                                     ];
        
        NSString *orderTime = _normalModel.createDate;
        if (!isNSString(orderTime))
        {
            orderTime = @"";
        }
        _textNode14 = [ASTextNode new];
        [self addSubnode:_textNode14];
        _textNode14.attributedText = [[NSAttributedString alloc] initWithString:orderTime
                                                                     attributes:@{
                                                                         NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                         NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}
                                      ];
        
        _textNode5 = [ASTextNode new];
        [self addSubnode:_textNode5];
        _textNode5.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"pay_mode", nil)
                                                                    attributes:@{
                                                                        NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)}
                                     ];
        
        NSString *orderType = _normalModel.paymentMethod;
        if (!isNSString(orderType))
        {
            orderType = @"";
        }
        _textNode15 = [ASTextNode new];
        [self addSubnode:_textNode15];
        _textNode15.attributedText = [[NSAttributedString alloc] initWithString:orderType attributes:@{
                                                                        NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
        
        _textNode6 = [ASTextNode new];
        [self addSubnode:_textNode6];
        _textNode6.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_state", nil)
                                                                    attributes:@{
                                                                        NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)}];
        
        NSString *orderStatus = [LGOrderLogicService getOrderStateStr:_normalModel.orderState];;
        if (!isNSString(orderStatus))
        {
            orderStatus = @"";
        }
        _textNode16 = [ASTextNode new];
        [self addSubnode:_textNode16];
        _textNode16.attributedText = [[NSAttributedString alloc] initWithString:orderStatus
                                                                     attributes:@{
                                                                         NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                         NSForegroundColorAttributeName:MainColor}
                                      ];
        
        _afterSaleState = [ASTextNode new];
        [self addSubnode:_afterSaleState];
        _afterSaleState.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"售后状态", nil)
                                                                    attributes:@{
                                                                        NSFontAttributeName:[UIFont lgFontFamily:@"" size:17.0],
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)}
                                          ];
        _afterSaleCtx = [ASTextNode new];
        [self addSubnode:_afterSaleCtx];
        _afterSaleCtx.attributedText = [[NSAttributedString alloc] initWithString:[OrderListNormalModel afterSaleState:_normalModel.backStatus]
                                                                     attributes:@{
                                                                         NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                         NSForegroundColorAttributeName:MainColor}
                                      ];
        
        _textNode7 = [ASTextNode new];
        [self addSubnode:_textNode7];
        _textNode7.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_mark", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17],NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)}];
        
        NSString *remark = _normalModel.remarks;
        if (!isNSString(remark) || remark.length==0)
        {
            remark = NSLocalizedString(@"msg15", nil);
        }
        _textNode17 = [ASTextNode new];
        [self addSubnode:_textNode17];
//        remark = [NSString stringWithFormat:@"%ld-%ld",(long)_currentIndexPath.section,(long)_currentIndexPath.row];
        _textNode17.attributedText = [[NSAttributedString alloc] initWithString:remark attributes:@{
                                                                NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
        
        _paypalnode = [ASButtonNode new];
        [self addSubnode:_paypalnode];
        _paypalnode.layer.cornerRadius = 3;
        if (_normalModel.payState.intValue == 1) {
            
            _paypalnode.layer.borderWidth = 1;
            [_paypalnode setTitle:NSLocalizedString(@"已付款", nil)
                         withFont:[UIFont systemFontOfSize:16]
                        withColor:MainColor
                         forState:UIControlStateNormal];
            _paypalnode.layer.borderColor = [MainColor CGColor];
            [_paypalnode setBackgroundColor:[UIColor clearColor]];
        } else {
            [_paypalnode setTitle:NSLocalizedString(@"立即支付", nil)
                         withFont:[UIFont systemFontOfSize:16]
                        withColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [_paypalnode addTarget:self
                            action:@selector(payclick)
                  forControlEvents:ASControlNodeEventTouchUpInside];
           // _paypalnode.layer.borderColor = [UIColorFromRGB(0x2196F3) CGColor];
            [_paypalnode setBackgroundColor:MainColor];
            if ([LGOrderLogicService isPaypalSubmitBtnEnableWithOrderState:_normalModel.orderState backStatus:_normalModel.backStatus]) {
                [self enablePaypalSubmitBtn];
            } else {
                [self disablePaypalSubmitBtn];
            }
        }
        
        [self addSubnode:self.cancelOrderBtn];
        [self.cancelOrderBtn addTarget:self
                                action:@selector(cancelAction)
                      forControlEvents:ASControlNodeEventTouchUpInside];
        
        // 0的时候 这个按钮是没有的 1、3 这个按钮是出现并且可以点击 2、4、5是禁止点击
        [self addSubnode:self.confrimCompleteNode];
        
        // 确认完成按钮的状态
        /**
        if ([_normalModel.backStatus isEqualToString:@"1"]
            || [_normalModel.backStatus isEqualToString:@"3"]) {
            [self enableConfirmBtn];
        } else if([_normalModel.backStatus isEqualToString:@"2"]
                  || [_normalModel.backStatus isEqualToString:@"4"]
                  || [_normalModel.backStatus isEqualToString:@"5"]){
            [self disableConfirmBtn];
        }
         */
        [self.confrimCompleteNode addTarget:self
                                action:@selector(confrimAction)
                      forControlEvents:ASControlNodeEventTouchUpInside];
    }
    return self;
}

/** paypal支付可以点击 */
- (void)enablePaypalSubmitBtn
{
//    _paypalnode.layer.borderColor = [UIColorFromRGB(0x2196F3) CGColor];
    [_paypalnode setTitle:NSLocalizedString(@"立即支付", nil)
                         withFont:[UIFont systemFontOfSize:16]
                        withColor:[UIColor whiteColor]
                         forState:UIControlStateNormal];
    [_paypalnode setBackgroundColor:MainColor];
    _paypalnode.enabled = YES;
    _paypalnode.hidden = NO;
}

/** paypal支付禁用 */
- (void)disablePaypalSubmitBtn
{
 //   _paypalnode.layer.borderColor = [UIColorFromRGB(0xE6E6E6) CGColor];
    _paypalnode.enabled = NO;
    _paypalnode.hidden = YES;
    [_paypalnode setTitle:NSLocalizedString(@"立即支付", nil)
                         withFont:[UIFont systemFontOfSize:16]
                        withColor:[UIColor whiteColor]
                         forState:UIControlStateNormal];
    [_paypalnode setBackgroundColor:MainColor];
}

/**
- (void)enableConfirmBtn
{
    self.confrimCompleteNode.layer.borderColor = [UIColorFromRGB(0x2196F3) CGColor];
    [_confrimCompleteNode setTitle:NSLocalizedString(@"确认完成", nil)
                         withFont:[UIFont systemFontOfSize:16]
                        withColor:UIColorFromRGB(0x2196F3)
                         forState:UIControlStateNormal];
    self.confrimCompleteNode.enabled = YES;
}

- (void)disableConfirmBtn
{
    self.confrimCompleteNode.layer.borderColor = [UIColorFromRGB(0xE6E6E6) CGColor];
    self.confrimCompleteNode.enabled = NO;
    [_confrimCompleteNode setTitle:NSLocalizedString(@"确认完成", nil)
                         withFont:[UIFont systemFontOfSize:16]
                        withColor:UIColorFromRGB(0xE6E6E6)
                         forState:UIControlStateNormal];
}
 */

static CGFloat edgSpacing = 20.0f;
static CGFloat nodeSpacing = 15.0f;
static CGFloat nodeWidth = 90.0f;

-(ASLayoutSpec *)layoutSpecThatFits:(ASSizeRange)constrainedSize
{
    _lineNode.style.preferredSize = CGSizeMake(SCREEN_WIDTH-2*edgSpacing, 0.5);
    _bottomLine.style.preferredSize = CGSizeMake(SCREEN_WIDTH-2*edgSpacing, 0.5);
    _textNode1.style.width = ASDimensionMakeWithPoints(nodeWidth);
    _textNode2.style.width = ASDimensionMakeWithPoints(nodeWidth);
    _textNode3.style.width = ASDimensionMakeWithPoints(nodeWidth);
    _textNode4.style.width = ASDimensionMakeWithPoints(nodeWidth);
    _textNode5.style.width = ASDimensionMakeWithPoints(nodeWidth);
    _textNode6.style.width = ASDimensionMakeWithPoints(nodeWidth);
    _textNode7.style.width = ASDimensionMakeWithPoints(nodeWidth);
    _paypalnode.style.height = ASDimensionMakeWithPoints(36);
    _paypalnode.style.width = ASDimensionMakeWithPoints(80);
    
    // 配置取消订单的属性
    self.cancelOrderBtn.style.height = ASDimensionMakeWithPoints(36);
    self.cancelOrderBtn.style.width = ASDimensionMakeWithPoints(80);

    self.confrimCompleteNode.style.height = ASDimensionMakeWithPoints(36);
    self.confrimCompleteNode.style.width = ASDimensionMakeWithPoints(80);
    
    _textNode11.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-nodeWidth);
    _textNode12.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-nodeWidth);
    _textNode13.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-nodeWidth);
    _textNode14.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-nodeWidth);
    _textNode15.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-nodeWidth);
    _textNode16.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-nodeWidth);
    _textNode17.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-nodeWidth);
    
    // 新增的售后状态
    _afterSaleState.style.width = ASDimensionMakeWithPoints(nodeWidth);
    _afterSaleCtx.style.maxWidth = ASDimensionMakeWithPoints(SCREEN_WIDTH-2*edgSpacing-nodeSpacing-nodeWidth);
    
    ASStackLayoutSpec *spec1 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_textNode1,_textNode11]];
    ASStackLayoutSpec *spec2 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_textNode2,_textNode12]];
    ASStackLayoutSpec *spec3 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_textNode3,_textNode13]];
    ASStackLayoutSpec *spec4 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_textNode4,_textNode14]];
    ASStackLayoutSpec *spec5 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_textNode5,_textNode15]];
    ASStackLayoutSpec *afterState = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_afterSaleState,_afterSaleCtx]];
    ASStackLayoutSpec *spec6 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_textNode6,_textNode16]];
    ASStackLayoutSpec *spec7 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                       spacing:nodeSpacing
                                                                justifyContent:ASStackLayoutJustifyContentStart
                                                                    alignItems:ASStackLayoutAlignItemsStart
                                                                      children:@[_textNode7,_textNode17]];
    ASStackLayoutSpec *spec8 = nil;
    
    // 售后单详情状态(是否显示售后状态)
    if(_normalModel.backStatus !=nil
       && _normalModel.backStatus.length !=0
       && ![_normalModel.backStatus isEqual:@""]
       && _normalModel.backStatus != NULL
       && ![_normalModel.backStatus isEqualToString:@""]){

        spec8 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                           spacing:nodeSpacing / 2
                                                                    justifyContent:ASStackLayoutJustifyContentStart
                                                                        alignItems:ASStackLayoutAlignItemsStart
                                                                          children:@[spec1,spec2,_lineNode,spec3,spec4,spec5,afterState,spec6,spec7]];
    } else {
        spec8 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                           spacing:nodeSpacing / 2
                                                                    justifyContent:ASStackLayoutJustifyContentStart
                                                                        alignItems:ASStackLayoutAlignItemsStart
                                                                          children:@[spec1,spec2,_lineNode,spec3,spec4,spec5,spec6,spec7]];
    }
    
    ASStackLayoutSpec *specWithBottomLine = nil;
    if (([_normalModel.paymentMethod isEqualToString:@"PayPal"]
        && [LGOrderLogicService isPaypalSubmitBtnEnableWithOrderState:_normalModel.orderState backStatus:_normalModel.backStatus])
        || ([LGOrderLogicService isNeedShowCancelBtnWith:_normalModel.orderState backStatus:_normalModel.backStatus])
        || ([_normalModel.backStatus isEqualToString:@"1"] || [_normalModel.backStatus isEqualToString:@"3"])) {
        specWithBottomLine = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                        spacing:nodeSpacing / 2
                                                 justifyContent:ASStackLayoutJustifyContentStart
                                                     alignItems:ASStackLayoutAlignItemsStart
                                                       children:@[spec8,_bottomLine]];
    } else {
        specWithBottomLine = spec8;
    }
    
    // 不仅仅是paypal而且还要求支付按钮可以点击
    if ([_normalModel.paymentMethod isEqualToString:@"PayPal"]
        && [LGOrderLogicService isPaypalSubmitBtnEnableWithOrderState:_normalModel.orderState backStatus:_normalModel.backStatus])
    {
        if ([LGOrderLogicService isNeedShowCancelBtnWith:_normalModel.orderState backStatus:_normalModel.backStatus]) {
            ASStackLayoutSpec *specBtn = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                                 spacing:nodeSpacing
                                                                          justifyContent:ASStackLayoutJustifyContentStart
                                                                              alignItems:ASStackLayoutAlignItemsStart
                                                                                children:@[self.cancelOrderBtn,_paypalnode]];
            ASStackLayoutSpec *spec9 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                               spacing:edgSpacing / 2
                                                                        justifyContent:ASStackLayoutJustifyContentEnd
                                                                            alignItems:ASStackLayoutAlignItemsEnd
                                                                              children:@[specWithBottomLine,specBtn]];
            return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(edgSpacing, edgSpacing, edgSpacing/2, edgSpacing)
                                                          child:spec9];
        } else {
            
            // 是否显示确认完成的按钮
            if ([_normalModel.backStatus isEqualToString:@"1"]
                || [_normalModel.backStatus isEqualToString:@"3"]) {
                
                ASStackLayoutSpec *specBtn = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal
                                                                                     spacing:nodeSpacing
                                                                              justifyContent:ASStackLayoutJustifyContentStart
                                                                                  alignItems:ASStackLayoutAlignItemsStart
                                                                                    children:@[self.confrimCompleteNode,_paypalnode]];
                ASStackLayoutSpec *spec9 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                                   spacing:edgSpacing/2
                                                                            justifyContent:ASStackLayoutJustifyContentEnd
                                                                                alignItems:ASStackLayoutAlignItemsEnd
                                                                                  children:@[specWithBottomLine,specBtn]];
                return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(edgSpacing, edgSpacing, edgSpacing/2, edgSpacing)
                                                              child:spec9];
            }
            
            ASStackLayoutSpec *spec9 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                               spacing:edgSpacing / 2
                                                                        justifyContent:ASStackLayoutJustifyContentEnd
                                                                            alignItems:ASStackLayoutAlignItemsEnd
                                                                              children:@[specWithBottomLine,_paypalnode]];
            return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(edgSpacing, edgSpacing, edgSpacing / 2, edgSpacing)
                                                          child:spec9];
        }
    } else {
        if ([LGOrderLogicService isNeedShowCancelBtnWith:_normalModel.orderState backStatus:_normalModel.backStatus]) {
            ASStackLayoutSpec *spec9 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                               spacing:edgSpacing/2
                                                                        justifyContent:ASStackLayoutJustifyContentEnd
                                                                            alignItems:ASStackLayoutAlignItemsEnd
                                                                              children:@[specWithBottomLine,self.cancelOrderBtn]];
            return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(edgSpacing, edgSpacing, edgSpacing/2, edgSpacing)
                                                          child:spec9];
        } else {
            // 是否显示确认完成的按钮
            if ( [_normalModel.backStatus isEqualToString:@"1"]
                || [_normalModel.backStatus isEqualToString:@"3"]
                ) {
                ASStackLayoutSpec *spec9 = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical
                                                                                   spacing:edgSpacing/2
                                                                            justifyContent:ASStackLayoutJustifyContentEnd
                                                                                alignItems:ASStackLayoutAlignItemsEnd
                                                                                  children:@[specWithBottomLine,self.confrimCompleteNode]];
                return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(edgSpacing, edgSpacing, edgSpacing/2, edgSpacing)
                                                              child:spec9];
            }
            
            return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(edgSpacing, edgSpacing, edgSpacing, edgSpacing)
                                                          child:specWithBottomLine];
        }
    }
}

#pragma mark - 事件响应处理
- (void)cancelAction{
    if (self.cancelBtnCallBack) {
        self.cancelBtnCallBack(_normalModel.orderId,_currentIndexPath);
    }
}

- (void)confrimAction
{
    if (self.confirmBtnCallBack) {
        self.confirmBtnCallBack(_normalModel.backId,_currentIndexPath);
    }
}

- (void)payclick {
    if (self.paycallback) {
        self.paycallback(_normalModel,_currentIndexPath);
    }
}

#pragma mark - 懒加载
- (ASButtonNode *)cancelOrderBtn
{
    if (!_cancelOrderBtn) {
            _cancelOrderBtn = [[ASButtonNode alloc] init];
            [_cancelOrderBtn setTitle:NSLocalizedString(@"取消订单", nil)
                                 withFont:[UIFont systemFontOfSize:14]
                                withColor:[UIColor ColorWithHexString:@"#1D1D1D"]
                                 forState:UIControlStateNormal];
        _cancelOrderBtn.layer.cornerRadius = 3;
        _cancelOrderBtn.layer.borderWidth = 1;
        _cancelOrderBtn.layer.borderColor = [UIColor ColorWithHexString:@"#D7D7D7"].CGColor;
    }
    return _cancelOrderBtn;
}

- (ASButtonNode *)confrimCompleteNode
{
    if (!_confrimCompleteNode) {
        _confrimCompleteNode = [[ASButtonNode alloc] init];
            [_confrimCompleteNode setTitle:NSLocalizedString(@"确认完成", nil)
                                 withFont:[UIFont lgFontFamily:@"" size:14.0f]
                                withColor:[UIColor whiteColor]
                                 forState:UIControlStateNormal];
        _confrimCompleteNode.layer.cornerRadius = 3;
        _confrimCompleteNode.backgroundColor = MainColor;
    }
    return _confrimCompleteNode;
}

/** 估计是垃圾代码 */
-(instancetype)initWithModel:(OrderListModel *)model
{
    if (self = [super init])
    {
        self.backgroundColor = [UIColor whiteColor];
        _model = model;
        
        _lineNode = [ASDisplayNode new];
        [self addSubnode:_lineNode];
        _lineNode.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
        
        _textNode1 = [ASTextNode new];
        [self addSubnode:_textNode1];
        _textNode1.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_form", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17],NSForegroundColorAttributeName:UIColorFromRGB(colorBlack)}];
        
        NSString *supplier;
        
        supplier = _model.companyName;
        
        if (!isNSString(supplier)) {
            supplier = @"";
        }
        _textNode11 = [ASTextNode new];
        [self addSubnode:_textNode11];
        _textNode11.attributedText = [[NSAttributedString alloc] initWithString:supplier
                                                                     attributes:@{
                                                                         NSFontAttributeName:[UIFont lgFontFamily:@"" size:17.0f],
                                                                         NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}
                                      ];
        
        _textNode2 = [ASTextNode new];
        [self addSubnode:_textNode2];
        _textNode2.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_code", nil)
                                                                    attributes:@{
                                                                        NSFontAttributeName:[UIFont lgFontFamily:@"" size:17.0f],
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorBlack)}
                                     ];
        
        NSString *orderCode = _model.orderCode;
        if (!isNSString(orderCode)) {
            orderCode = @"";
        }
        _textNode12 = [ASTextNode new];
        [self addSubnode:_textNode12];
        _textNode12.attributedText = [[NSAttributedString alloc] initWithString:orderCode attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
        
        _textNode3 = [ASTextNode new];
        [self addSubnode:_textNode3];
        _textNode3.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"订单金额", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)}];
        
        NSString *orderCharge;
        orderCharge = _model.totalAmount;
        
        if (!isNSString(orderCharge))
        {
            orderCharge = @"";
        }
        _textNode13 = [ASTextNode new];
        [self addSubnode:_textNode13];
        _textNode13.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"€ %.2f",orderCharge.floatValue]
                                                                     attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],
                                                                                  NSForegroundColorAttributeName:MainColor}
                                      ];
        
        _textNode4 = [ASTextNode new];
        [self addSubnode:_textNode4];
        _textNode4.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_time", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)}];
        
        NSString *orderTime;
        orderTime = _model.createDate;
        if (!isNSString(orderTime))
        {
            orderTime = @"";
        }
        _textNode14 = [ASTextNode new];
        [self addSubnode:_textNode14];
        _textNode14.attributedText = [[NSAttributedString alloc] initWithString:orderTime
                                                                     attributes:@{
                                                                         NSFontAttributeName:[UIFont systemFontOfSize:15],
                                                                         NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)
                                                                     }];
        
        _textNode5 = [ASTextNode new];
        [self addSubnode:_textNode5];
        _textNode5.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"pay_mode", nil)
                                                                    attributes:@{
                                                                        NSFontAttributeName:[UIFont systemFontOfSize:15],
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)
                                                                    }];
        
        NSString *orderType;
        
        orderType = _model.paymentMethod;
        
        if (!isNSString(orderType)) {
            orderType = @"";
        }
        _textNode15 = [ASTextNode new];
        [self addSubnode:_textNode15];
        _textNode15.attributedText = [[NSAttributedString alloc] initWithString:orderType
                                                                     attributes:@{
                                                                         NSFontAttributeName:[UIFont systemFontOfSize:15],
                                                                         NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)
                                                                     }];
        
        _textNode6 = [ASTextNode new];
        [self addSubnode:_textNode6];
        _textNode6.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_state", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)}];
        
        NSString *orderStatus = [LGOrderLogicService getOrderStateStr:_model.orderState];
        _textNode16 = [ASTextNode new];
        [self addSubnode:_textNode16];
        _textNode16.attributedText = [[NSAttributedString alloc] initWithString:orderStatus
                                                                     attributes:@{
                                                                         NSFontAttributeName:[UIFont lgFontFamily:@"" size:15.0f],
                                                                         NSForegroundColorAttributeName:MainColor
                                                                     }
                                      ];
        
        _textNode7 = [ASTextNode new];
        [self addSubnode:_textNode7];
        
        _textNode7.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"order_mark", nil)
                                                                    attributes:@{
                                                                        NSFontAttributeName:[UIFont lgFontFamily:@"" size:15.0f],
                                                                        NSForegroundColorAttributeName:UIColorFromRGB(colorTextLight)
                                                                    }
                                     ];
        
        NSString *remark = _model.remarks;
        if (!isNSString(remark))
        {
            remark = @"";
        }
        _textNode17 = [ASTextNode new];
        [self addSubnode:_textNode17];
        _textNode17.attributedText = [[NSAttributedString alloc] initWithString:remark attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    }
    return self;
}

@end
