//
//  OrderListNode.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <AsyncDisplayKit/ASCellNode.h>
@class OrderListModel,OrderListNormalModel;

NS_ASSUME_NONNULL_BEGIN

typedef void(^CancelBtnClickCallBack)(NSString *orderId, NSIndexPath *selectIndexPath);

typedef void(^ConfirmBtnClickCallBack)(NSString *orderId, NSIndexPath *selectIndexPath);


@interface OrderListNode : ASCellNode

@property (nonatomic,copy)void(^paycallback)(OrderListNormalModel *model,NSIndexPath *selectIndexPath);

// 取消订单的回调事件
@property (nonatomic, copy) CancelBtnClickCallBack cancelBtnCallBack;

// 确认按钮的回调事件
@property (nonatomic, copy) ConfirmBtnClickCallBack confirmBtnCallBack;


- (instancetype)initWithModel:(OrderListModel *)model;


/// 首页订单管理列表中所用到的Cell的初始化
/// @param normalModel cell模型信息
- (instancetype)initWithNormalModel:(OrderListNormalModel *)normalModel andIndexPath:(NSIndexPath *)selectIndexPath;


@end

NS_ASSUME_NONNULL_END
