//
//  LGOrderNetWorkService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/9/22.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LgResultModel,OrderStatusModel,LGAfterSaleOrder;

NS_ASSUME_NONNULL_BEGIN

typedef void(^LGOrderListCallBack)(LgResultModel *res, NSArray * _Nullable callBackList, int total, int totalPage);
typedef void(^LGOrderDetailCallBack)(LgResultModel *res, OrderStatusModel * _Nullable orderStatusModel);

typedef void(^LGOrderCancelCallBack)(LgResultModel *res);
typedef void(^LGConfirmOrderCancelCallBack)(LgResultModel *res);

// 退款状态详情
typedef void(^LGSellBackInfosCallBack)(LgResultModel *res, id  _Nullable orderStatusModel);

/// 订单管理页面的网络请求封装
@interface LGOrderNetWorkService : NSObject

/**
    查询订单列表的回调(orderType:空代表查询全部  2:代表处理中 3:代表已完成 6:代表售后)
 */
- (void)getOrderListByOrderType:(NSInteger )orderType withCallBack:(LGOrderListCallBack)callBack;

/**
    根据订单编号查询订单详情
 */
- (void)getOrderDetailByOrderCode:(NSString *)orderCode withCallBack:(LGOrderDetailCallBack)callBack;

/**
    取消订单
 */
- (void)getOrderCancelWithOrderId:(NSString *)orderId callBack:(LGOrderCancelCallBack)callBack;

/**
    确认完成订单
 */
- (void)doConfirmFinishOrderWithBackId:(NSString *)backId callBack:(LGConfirmOrderCancelCallBack)callBack;

/**
      退货退款接口
 */
- (void)afterSaleOrder:(LGAfterSaleOrder *)afterSaleOrder callBack:(LGConfirmOrderCancelCallBack)callBack;

/**
    退款进度详情页面
 */
- (void)getsellBackInfosWithBackId:(NSString *)backId callBack:(LGSellBackInfosCallBack)callBack;

@end

NS_ASSUME_NONNULL_END
