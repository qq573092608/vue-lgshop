//
//  LGOrderLogicService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/9/22.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>


@class OrderProductModel,OrderListNormalModel,LgResultModel,OrderStatusModel;

typedef void(^LGCancelOrConfrimOrderCallBack)(LgResultModel * _Nonnull res, NSArray * _Nullable orderList, int total, int totalPage);


NS_ASSUME_NONNULL_BEGIN

@interface LGOrderLogicService : NSObject


///  根据接口返回的状态返回订单状态
/// @param orderState 订单状态
+ (NSString *)getOrderStateStr:(NSString *)orderState;


/// 是否显示取消按钮
/// @param orderState 订单状态
/// @param backStatus 售后状态
+ (BOOL) isNeedShowCancelBtnWith:(NSString *)orderState backStatus:(NSString *)backStatus;

/// 收否需要显示确认完成按钮
/// @param backStatusStr 售后状态
+ (BOOL) isNeedShowConfrimFinishBtnWithBackStatus:(NSString *)backStatusStr;

/// 根据列表单个元素对象判断paypal支付按钮是否能被点击(YES：可以点击 NO:不可以点击)
/// @param orderState 订单状态
/// @param backStatus 售后状态

+ (BOOL) isPaypalSubmitBtnEnableWithOrderState:(NSString *)orderState backStatus:(NSString *)backStatus;

/// 取消订单的操作(包含刷新列表的请求)
/// @param orderType  操作的类型
/// @param orderIdStr  订单编号
/// @param callBack 返回的回调
- (void) doCancelOrderActionWithType:(NSInteger )orderType
                             orderId:(NSString *)orderIdStr
                            callBack:(LGCancelOrConfrimOrderCallBack)callBack;


/// 订单确认完成的操作(包含刷新列表的请求)
/// @param orderType 操作的类型
/// @param orderIdStr 订单编号
/// @param callBack 返回的回调
- (void) doConfrimOrderActionWithType:(NSInteger )orderType
                             orderId:(NSString *)orderIdStr
                            callBack:(LGCancelOrConfrimOrderCallBack)callBack;


/// 判断批量申请按钮是否需要显示
/// @param orderInfo 订单信息
+ (BOOL)isNeedShowMutableApplyBtnWith:(OrderStatusModel *)orderInfo;


///  是否需要隐藏申请售后按钮
/// @param orderInfo 订单信息
+ (BOOL)isNeedHiddenApplyBtn:(OrderStatusModel *)orderInfo;

///  根据订单状态以及售后状态来决定底部文本框是否需要显示(YES:需要显示 NO:不需要显示)
/// @param orderState 订单状态
/// @param backState 售后状态
/// @param payMethod 是否是paypal支付
/// @param payState 是否是paypal支付
+ (BOOL)isBottomViewNeedShowWithOrderState:(NSString *)orderState
                                 backState:(NSString *)backState
                                  isPayPal:(NSString *)payMethod
                                  payState:(int)payState
                                goodsOrderList:(NSArray *)goodsOrderList;
@end

NS_ASSUME_NONNULL_END
