//
//  LGOrderNetWorkService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/9/22.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGOrderNetWorkService.h"

#import "LgResultModel.h"
#import "OrderListNormalModel.h"
#import "OrderStatusModel.h"
#import "LGAfterSaleOrder.h"

#import "LGSellBackInfoModel.h"

@implementation LGOrderNetWorkService

- (void)getOrderListByOrderType:(NSInteger)orderType withCallBack:(LGOrderListCallBack)callBack
{
    NSString *orderTypeParam = @"";
    if (orderType == 2) {
        orderTypeParam = @"2";
    } else if (orderType == 3) {
        orderTypeParam = @"3";
    } else if (orderType == 6) {
        orderTypeParam = @"6";
    }
        
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSString *invitationcode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [params setObject:orderTypeParam forKey:@"orderType"];
    [params setObject:invitationcode forKey:@"invitationCode"];
    LgResultModel *result = [[LgResultModel alloc] init];
    [NetworkManager getWithURL:CREATE_URL(url_order_list)
                        params:params
                       success:^(id json) {
        LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
        if ([tempResModel.stateCode isEqualToString:@"1"]) {
            
            NSArray *resArr = [OrderListNormalModel mj_objectArrayWithKeyValuesArray:tempResModel.data];
            NSNumber *total = [json valueForKey:@"total"];
            NSNumber *totalpage = [json valueForKey:@"totalpage"];
            tempResModel.isSucc = YES;
            callBack(tempResModel,resArr,[total intValue],[totalpage intValue]);
        } else {
            callBack(tempResModel,nil,0,0);
        }
    } failure:^(NSError *error) {
        result.isSucc = NO;
        result.errMsg = error.localizedDescription;
        callBack(result,nil,0,0);
    }];
}


- (void)getOrderDetailByOrderCode:(NSString *)orderCode withCallBack:(LGOrderDetailCallBack)callBack
{
    LgResultModel *resModel = [[LgResultModel alloc] init];

    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [params setObject:invitationCode forKey:@"invitationCode"];
    [params setObject:orderCode forKey:@"orderCode"];

    [NetworkManager getWithURL:CREATE_URL(url_order_detail) params:params success:^(id json) {
        LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
        if ([tempResModel.stateCode isEqualToString:@"1"]) {
            OrderStatusModel *detailModel = [OrderStatusModel mj_objectWithKeyValues:tempResModel.data];
            tempResModel.isSucc = YES;
            callBack(tempResModel,detailModel);
        } else {
            resModel.isSucc = NO;
            resModel.errMsg = tempResModel.message;
            resModel.stateCode = tempResModel.stateCode;
            callBack(resModel,nil);
        }
    } failure:^(NSError *error) {
        resModel.isSucc = NO;
        resModel.errMsg = error.localizedDescription;
        callBack(resModel,nil);
    }];
}

- (void)getOrderCancelWithOrderId:(NSString *)orderId callBack:(LGOrderCancelCallBack)callBack{
    LgResultModel *resModel = [[LgResultModel alloc] init];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:orderId forKey:@"orderId"];
    [params setObject:@"0" forKey:@"orderState"];
    
    [NetworkManager getWithURL:CREATE_URL(url_saler_order_cancel) params:params success:^(id json) {
        LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
        if ([tempResModel.stateCode isEqualToString:@"1"]) {
            tempResModel.isSucc = YES;
            callBack(tempResModel);
        } else {
            resModel.isSucc = NO;
            resModel.errMsg = tempResModel.message;
            resModel.stateCode = tempResModel.stateCode;
            callBack(resModel);
        }
    } failure:^(NSError *error) {
        resModel.isSucc = NO;
        resModel.errMsg = error.localizedDescription;
        callBack(resModel);
    }];
}

- (void)doConfirmFinishOrderWithBackId:(NSString *)backId callBack:(LGConfirmOrderCancelCallBack)callBack
{
    LgResultModel *resModel = [[LgResultModel alloc] init];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:backId forKey:@"backId"];
    [params setObject:@"2" forKey:@"status"];

    [NetworkManager getWithURL:CREATE_URL(url_saler_confirm_order_cancel) params:params success:^(id json) {
        LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
        if ([tempResModel.stateCode isEqualToString:@"1"]) {
            tempResModel.isSucc = YES;
            callBack(tempResModel);
        } else {
            resModel.isSucc = NO;
            resModel.errMsg = tempResModel.message;
            resModel.stateCode = tempResModel.stateCode;
            callBack(resModel);
        }
    } failure:^(NSError *error) {
        resModel.isSucc = NO;
        resModel.errMsg = error.localizedDescription;
        callBack(resModel);
    }];
}

- (void)afterSaleOrder:(LGAfterSaleOrder *)afterSaleOrder callBack:(LGConfirmOrderCancelCallBack)callBack
{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:afterSaleOrder.orderId
              forKey:@"orderId"];
    [params setValue:afterSaleOrder.goodsOrderInfos
              forKey:@"goodsOrderInfos"];
    [params setValue:@(afterSaleOrder.orderState.integerValue)
              forKey:@"orderState"];
    
    NSString *cargoStatusStr = @"1";
    if (afterSaleOrder.cargoStatus != nil) {
        cargoStatusStr = afterSaleOrder.cargoStatus;
    }
    [params setValue:@(cargoStatusStr.integerValue)
              forKey:@"cargoStatus"];
    
    NSString *reasonForReturnStr = @"1";
    if (afterSaleOrder.reasonForReturn != nil) {
        reasonForReturnStr = afterSaleOrder.reasonForReturn;
    }
    [params setValue:@(reasonForReturnStr.integerValue)
              forKey:@"reasonForReturn"];
    
    [params setValue:afterSaleOrder.refundMethod
              forKey:@"refundMethod"];
    [params setValue:afterSaleOrder.note
              forKey:@"note"];
    [params setValue:afterSaleOrder.wechat
              forKey:@"wechat"];
    LgResultModel *resModel = [[LgResultModel alloc] init];
    [NetworkManager postWithURL:CREATE_URL(url_order_after_Sale)
                         params:params
                   isUsedSignal:NO
                        success:^(id json) {
        LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
        if ([tempResModel.stateCode isEqualToString:@"1"]) {
            tempResModel.isSucc = YES;
            callBack(tempResModel);
        } else {
            resModel.isSucc = NO;
            resModel.errMsg = tempResModel.message;
            resModel.stateCode = tempResModel.stateCode;
            callBack(resModel);
        }
    } failure:^(NSError *error) {
        resModel.errMsg = error.localizedDescription;
        callBack(resModel);
    }];
}

- (void)getsellBackInfosWithBackId:(NSString *)backId callBack:(LGSellBackInfosCallBack)callBack{
    LgResultModel *resModel = [[LgResultModel alloc] init];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:backId forKey:@"backId"];
    
    [NetworkManager postWithURL:CREATE_URL(url_order_sellBackInfos)
                         params:params
                   isUsedSignal:NO
                        success:^(id json) {
                LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
                if ([tempResModel.stateCode isEqualToString:@"1"]) {
                    tempResModel.isSucc = YES;
                    callBack(tempResModel,tempResModel.data);
                } else {
                    resModel.isSucc = NO;
                    resModel.errMsg = tempResModel.message;
                    resModel.stateCode = tempResModel.stateCode;
                    callBack(resModel,nil);
                }
            } failure:^(NSError *error) {
                resModel.isSucc = NO;
                resModel.errMsg = error.localizedDescription;
                callBack(resModel,nil);
            }];
}


@end
