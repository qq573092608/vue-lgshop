//
//  LGOrderLogicService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/9/22.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGOrderLogicService.h"
#import "OrderProductModel.h"
#import "AppDelegate.h"
#import "OrderListNormalModel.h"
#import "LGOrderNetWorkService.h"

#import "LgResultModel.h"
#import "ApplyAfterSaleLogicService.h"
#import "OrderStatusModel.h"

@interface LGOrderLogicService()

@property (nonatomic, strong) LGOrderNetWorkService *orderNetWorkService;

@end

@implementation LGOrderLogicService

+ (NSString *)getOrderStateStr:(NSString *)orderState
{
    NSString *finalOrderStateStr = @"";
    
    if ([orderState isEqualToString:@"0"]) {
        finalOrderStateStr = [NSLocalizedString(@"申请取消", nil) uppercaseStringWithLocale:[NSLocale currentLocale]];
    } else if ([orderState isEqualToString:@"1"]) {
        finalOrderStateStr = [NSLocalizedString(@"WCL", nil) uppercaseStringWithLocale:[NSLocale currentLocale]];
    } else if ([orderState isEqualToString:@"2"]) {
        finalOrderStateStr = [NSLocalizedString(@"order_ing", nil) uppercaseStringWithLocale:[NSLocale currentLocale]];
    } else if ([orderState isEqualToString:@"3"]) {
        finalOrderStateStr = [NSLocalizedString(@"order_done", nil) uppercaseStringWithLocale:[NSLocale currentLocale]];
    } else if ([orderState isEqualToString:@"6"]) {
        finalOrderStateStr = [NSLocalizedString(@"已取消", nil) uppercaseStringWithLocale:[NSLocale currentLocale]];
    }
    
    return  finalOrderStateStr;
}


+ (BOOL) isNeedShowCancelBtnWith:(NSString *)orderState backStatus:(NSString *)backStatus
{
    // 只有未处理跟处理中的订单才能取消
    if (([orderState isEqualToString:@"1"]
        || [orderState isEqualToString:@"2"])
        && backStatus.length == 0) {
        return YES;
    }
    return NO;
}

+ (BOOL) isNeedShowConfrimFinishBtnWithBackStatus:(NSString *)backStatusStr
{
    if ([backStatusStr isEqualToString:@"1"]
        || [backStatusStr isEqualToString:@"3"]) {
        return YES;
    } else {
        return NO;
    }
}

+ (BOOL) isPaypalSubmitBtnEnableWithOrderState:(NSString *)orderState backStatus:(NSString *)backStatus
{
    BOOL btnEnable = NO;
    // 订单状态不是正在处理而且 无任何售后状态
    if ([orderState isEqualToString:@"1"]
        && backStatus.length == 0) {
        return YES;
    }
    
    return btnEnable;
}

- (void) doCancelOrderActionWithType:(NSInteger)orderType
                             orderId:(NSString *)orderIdStr
                            callBack:(LGCancelOrConfrimOrderCallBack)callBack
{
    WEAK_SELF(weakSelf);
    [self.orderNetWorkService getOrderCancelWithOrderId:orderIdStr
                                               callBack:^(LgResultModel * _Nonnull resModel) {
        if (resModel.isSucc) {
            [weakSelf.orderNetWorkService getOrderListByOrderType:orderType
                                                     withCallBack:^(LgResultModel * _Nonnull res, NSArray * _Nullable callBackList, int total, int totalPage) {
                if (res.isSucc) {
                    callBack(res,callBackList, total, totalPage);
                } else {
                    callBack(res,nil, 0, 0);
                }
            }];
        } else {
            callBack(resModel,nil, 0, 0);
        }
    }];
}

- (void) doConfrimOrderActionWithType:(NSInteger )orderType
                             orderId:(NSString *)orderIdStr
                            callBack:(LGCancelOrConfrimOrderCallBack)callBack
{
    WEAK_SELF(weakSelf);
    [self.orderNetWorkService doConfirmFinishOrderWithBackId:orderIdStr
                                                    callBack:^(LgResultModel * _Nonnull resModel) {
        if (resModel.isSucc) {
            [weakSelf.orderNetWorkService getOrderListByOrderType:orderType
                                                     withCallBack:^(LgResultModel * _Nonnull res, NSArray * _Nullable callBackList, int total, int totalPage) {
                if (res.isSucc) {
                    callBack(res,callBackList, total, totalPage);
                } else {
                    callBack(res,nil, 0, 0);
                }
            }];
        } else {
            callBack(resModel,nil, 0, 0);
        }
    }];
}

+ (BOOL)isNeedShowMutableApplyBtnWith:(OrderStatusModel *)orderInfo
{
    if (orderInfo.goodsOrderInfos.count > 1
        && ![self isNeedHiddenApplyBtn:orderInfo]
        && ![self isBackStatusing:orderInfo]
        // 没有超过售后期限
        && ![ApplyAfterSaleLogicService isAfterSaleOverTime:orderInfo.collectDate]) {
        return YES;
    } else {
        return NO;
    }
}

/** 只有订单状态为3(已完成才显示申请售后按钮) */
+ (BOOL)isNeedHiddenApplyBtn:(OrderStatusModel *)orderInfo
{
    if (![orderInfo.orderState isEqualToString:@"3"]) {
        return YES;
    } else {
        return NO;
    }
}

/** 是否处于售后中 */
+ (BOOL)isBackStatusing:(OrderStatusModel *)orderInfo
{
    if (orderInfo.backStatus.length == 0) {
        return NO;
    } else {
        return YES;
    }
}

+ (BOOL)isBottomViewNeedShowWithOrderState:(NSString *)orderState
                                 backState:(NSString *)backState
                                  isPayPal:(NSString *)payMethodStr
                                  payState:(int)payState
                            goodsOrderList:(NSArray *)goodsOrderList
{
    if ([payMethodStr isEqualToString:@"PayPal"] && payState == 1) {
        return  YES;
    }
    
   // 订单状态 1:未处理   2:处理中 3:已完成  6:已取消
   // 售后状态  0-等待审核，1-已同意，2-等待商家确认，3-等待用户确认，4-已完成，5-已拒绝
    BOOL isNeedBottomViewShow = NO;
    if ([orderState isEqualToString:@"1"]
        || [orderState isEqualToString:@"2"]) {
        isNeedBottomViewShow  = YES;
        
        if ([orderState isEqualToString:@"1"] && [backState isEqualToString:@"5"]) {
            isNeedBottomViewShow = NO;
        }
    }  else if ([orderState isEqualToString:@"3"]){
        if (backState.length == 0) {
            // 批量申请售后
            if (goodsOrderList.count > 1) {
                isNeedBottomViewShow = YES;
            } else {
                // 单个申请售后
                isNeedBottomViewShow = NO;
            }
        } else if ([backState isEqualToString:@"0"]) {
            isNeedBottomViewShow = NO;
        } else if ([backState isEqualToString:@"1"]) {
            isNeedBottomViewShow = YES;
        } else if ([backState isEqualToString:@"2"]) {
            isNeedBottomViewShow = NO;
        } else if ([backState isEqualToString:@"3"]) {
            isNeedBottomViewShow = YES;
        } else if ([backState isEqualToString:@"4"]) {
            isNeedBottomViewShow = NO;
        } else if ([backState isEqualToString:@"5"]) {
            isNeedBottomViewShow = NO;
        }
    } else if ([orderState isEqualToString:@"6"]){
        if ([backState isEqualToString:@"1"]) {
            isNeedBottomViewShow = YES;
        } else if ([backState isEqualToString:@"3"]) {
            isNeedBottomViewShow = YES;
        }
    }
    return isNeedBottomViewShow;
}

#pragma mark - 懒加载
- (LGOrderNetWorkService *)orderNetWorkService
{
    if (!_orderNetWorkService) {
        _orderNetWorkService = [[LGOrderNetWorkService alloc] init];
    }
    return _orderNetWorkService;
}


@end
