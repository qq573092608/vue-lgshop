//
//  OrderListController.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "BaseViewController.h"
#import "JXCategoryListContainerView.h"

typedef NS_ENUM(NSInteger, OrderListType)
{
    /**全部*/
    OrderListTypeAll       = 0,
    /**处理中*/
    OrderListTypeDisposing = 2,
    /**已完成*/
    OrderListTypeDisposed  = 3,
    /**退款/售后*/
    OrderListTypeRefund    = 6
};
NS_ASSUME_NONNULL_BEGIN

@interface OrderListController : BaseViewController<JXCategoryListContentViewDelegate>

- (instancetype)initWithType:(OrderListType)type;

@end

NS_ASSUME_NONNULL_END
