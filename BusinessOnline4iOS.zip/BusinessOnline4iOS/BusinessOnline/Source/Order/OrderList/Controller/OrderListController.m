//
//  OrderListController.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "OrderListController.h"
#import "OrderListModel.h"
#import "OrderListNode.h"
#import "OrderDetailController.h"
#import "OrderListNormalModel.h"
#import "HomeController.h"
#import "PayViewController.h"
#import "PayModel.h"

#import "BaseService.h"
#import "LGOrderNetWorkService.h"
#import "LgResultModel.h"
#import "LgMerchantNetworkService.h"
#import "MerchantInfoModel.h"

#import "LGOrderLogicService.h"
#import "LGProductNetWorkService.h"
#import "ShoppingEmptyCell.h"
#import "ShoppingRecommendCell.h"
#import "ProductDetailController.h"
#import "ProductModel.h"

#import "LGPayNetWorkService.h"
#import "NSString+Tool.h"

@interface OrderListController ()<ASTableDelegate,ASTableDataSource>
{
    OrderListType _type;
    OrderListNormalModel *_paymodel;
    NSString *_ClientID;
    
    // 当前页
    int _currentTuiJianPage;
    /**
       当前分类页
     */
    int _currentCategoryPage;
    
    // 总的数据条数(包含推荐跟首页)
    int _totalSumNum;
    // 推荐总条数
    int _totalTuiJianSumNum;
    // 首页分类总条数
    int _totalCategorySumNum;
    /**
     当前产品页索引
     */
    int _currentProductPageIndex;
    
    /**
        单条分类的总个数
     */
    int _categorySingalSumNum;
}
@property (nonatomic,strong)ASTableNode *tableNode;
@property (nonatomic,strong)NSMutableArray *dataSource;

/** 网络请求的服务类 */
@property (nonatomic, strong)LGOrderNetWorkService *orderNetWorkService;

/** 业务逻辑的服务类 */
@property (nonatomic, strong)LGOrderLogicService *orderLogicService;

// 商家信息
@property (nonatomic, strong) LgMerchantNetworkService *merchantNetworkService;

/**
     推荐的产品列表
 */
@property (nonatomic,strong)NSMutableArray *productListSource;

@end

@implementation OrderListController

-(instancetype)initWithType:(OrderListType)type
{
    if (self = [super init])
    {
        _type = type;
        _currentTuiJianPage = 1;
        _currentCategoryPage = 1;
        _totalSumNum = 0;
        _totalTuiJianSumNum = 0;
        _totalCategorySumNum = 0;
        _currentProductPageIndex = 0;
        _dataSource = [NSMutableArray array];
        
        _tableNode = [[ASTableNode alloc] initWithStyle:UITableViewStyleGrouped];
        [self.view addSubnode:_tableNode];
        _tableNode.backgroundColor = MainBackgroundColor;
        _tableNode.view.separatorColor = MainBackgroundColor;
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, CGFLOAT_MIN)];
        _tableNode.view.tableFooterView = footerView;
        [_tableNode.view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.bottom.right.mas_equalTo(self.view);
        }];
        WEAK_SELF(weakSelf);
        self.refresh = [[QPGRefreshTool alloc] init];
        [self.refresh gifModelRefresh:_tableNode.view refreshType:RefreshTypeDouble firstRefresh:YES dropDownBlock:^{
            if ([weakSelf.tableNode.view.mj_header isRefreshing]) {
                [weakSelf doNetworkRequestForHeader];
            }
        } upDropBlock:^{
            if ([weakSelf.tableNode.view.mj_footer isRefreshing]) {
                [weakSelf doNetworkRequestForFooter];
            }
        }];
        _tableNode.delegate = self;
        _tableNode.dataSource = self;
        
        self.emptyModel = [[EmptyModel alloc] initWithScrollView:_tableNode.view type:ControllerStateNormal];
//        [self.refresh beginRefreshing];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
   // self.view.backgroundColor = [UIColor whiteColor];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didReceivedAddOrderSuccessNotification:)
                                                 name:kCommitOrderNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(updateorderpaystate)
                                                 name:kPaymentcompletedNotification
                                               object:nil];
}

- (void)didReceivedAddOrderSuccessNotification:(NSNotification *)notification
{
    [self.refresh beginRefreshing];
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark delegate methods
-(NSInteger)numberOfSectionsInTableNode:(ASTableNode *)tableNode {
    if (self.dataSource.count == 0) {
        return 2;
    } else {
        return self.dataSource.count;
    }
    return 0;
}

-(NSInteger)tableNode:(ASTableNode *)tableNode numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 5;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return CGFLOAT_MIN;
}

-(ASCellNode *)tableNode:(ASTableNode *)tableNode nodeForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.dataSource.count == 0) {
        if (indexPath.section == 0) {
            ShoppingEmptyCell *node = nil;
            if (self.productListSource.count == 0) {
                node = [[ShoppingEmptyCell alloc] initWithEmptyViewIsEmpImgShow:YES
                                                              isNeedHiddenBgImg:YES
                                                                    isFullTable:YES
                        ];
            } else {
                node = [[ShoppingEmptyCell alloc] initWithEmptyViewIsEmpImgShow:YES
                                                              isNeedHiddenBgImg:NO
                                                                    isFullTable:NO];
            }
            return node;
        } else {
            ShoppingRecommendCell *node = [[ShoppingRecommendCell alloc] initWithProductInfoList:self.productListSource];
            WEAK_SELF(weakSelf);
            node.recommendCellClickCallBack = ^(ProductModel * _Nonnull productModel) {
                ProductDetailController *pvc = [[ProductDetailController alloc] initWithText:productModel.goods_code
                                                                              invitationCode:@""
                                                                                   indexPath:nil
                                                                                productModel:productModel
                                                                           cacheProductModel:nil
                                                                            isFromShoppingVC:NO
                                                ];
                [weakSelf.navigationController pushViewController:pvc animated:YES];
            };
            return node;
        }
        return nil;
    } else {
        OrderListNode *node = [[OrderListNode alloc] initWithNormalModel:self.dataSource[indexPath.section]
                                                            andIndexPath:indexPath];
        WEAK_SELF(weakSelf);
        node.paycallback = ^(OrderListNormalModel * _Nonnull model,NSIndexPath *currentIndexPath) {
            self->_paymodel = model;
            if (![model.paymentSerialNumber isEmptyString]) {
                LGPayNetWorkService *payNetWorkService = [[LGPayNetWorkService alloc] init];
                [payNetWorkService getIpnWithTxnId:model.paymentSerialNumber
                                          callBack:^(LgResultModel * _Nullable result, NSString *paymentStatus) {
                    if (result.isSucc) {
                        [weakSelf updatePayStateWithOrderCode:model.orderCode
                                                paymentMethod:model.paymentMethod
                                             currentIndexPath:currentIndexPath ];
                    } else {
                        [weakSelf gotopaypalhtml];
                    }
                }];
            } else {
                [weakSelf gotopaypalhtml];
            }
    //        [weakeSelf.refresh beginRefreshing];
        };
        // 取消事件
        node.cancelBtnCallBack = ^(NSString * _Nonnull orderId, NSIndexPath *selectIndexPath) {
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"确定取消订单吗?", nil)
                                                                           message:nil
                                                                    preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"cancel", nil)
                                                                   style:UIAlertActionStyleDefault
                                                                 handler:nil];
            __strong __typeof(weakSelf)strongSelf = weakSelf;
            UIAlertAction* quedingAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"queding", nil)
                                                                    style:UIAlertActionStyleDefault
                                                                  handler:^(UIAlertAction * action) {
                                                                        [strongSelf cancelOrderActionWithOrderId:orderId
                                                                                                       indexPath:selectIndexPath];
                                                                  }];
            [alert addAction:cancelAction];
            [alert addAction:quedingAction];
            [weakSelf presentViewController:alert animated:YES completion:nil];
        };
        
        // 确认取消完成点击事件
        node.confirmBtnCallBack = ^(NSString * _Nonnull backId, NSIndexPath *selectIndexPath) {
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"是否确认该售后单已完成?", nil)
                                                                           message:nil
                                                                    preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"cancel", nil)
                                                                   style:UIAlertActionStyleDefault
                                                                 handler:nil];
            __strong __typeof(weakSelf)strongSelf = weakSelf;
            UIAlertAction* quedingAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"queding", nil)
                                                                    style:UIAlertActionStyleDefault
                                                                  handler:^(UIAlertAction * action) {
                                                                        [strongSelf confirmOrderSucc:backId indexPath:selectIndexPath];
                                                                  }];
            [alert addAction:cancelAction];
            [alert addAction:quedingAction];
            [weakSelf presentViewController:alert animated:YES completion:nil];
        };
        node.selectionStyle = UITableViewCellSelectionStyleNone;
        return node;
    }
}

- (void)updatePayStateWithOrderCode:(NSString *)orderCode
                      paymentMethod:(NSString *)paymentMethod
                   currentIndexPath:(NSIndexPath *)currentIndexPath {
    
    [MBProgressHUD showGifToView:nil];

    LGPayNetWorkService *payNetWorkService = [[LGPayNetWorkService alloc] init];
    WEAK_SELF(weakSelf);
    [payNetWorkService updatePayState:orderCode
                        paymentMethod:paymentMethod
                             callBack:^(LgResultModel * _Nullable result) {
        [MBProgressHUD hideHUD];
        if (!result.isSucc) {
            [MBProgressHUD showErrorMessage:result.message];
        } else {
            [weakSelf.refresh beginRefreshing];
        }
    }];
}

-(void)tableNode:(ASTableNode *)tableNode didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    OrderListNormalModel *model = self.dataSource[indexPath.section];
    OrderDetailController *ovc = [[OrderDetailController alloc] initWithText:model.orderCode
                                                                   indexPath:indexPath];
    
    WEAK_SELF(weakSelf);
    ovc.refreshSelectCellCallBack = ^(NSIndexPath *selectIndexPath) {
        
        [weakSelf.dataSource removeAllObjects];
        WEAK_SELF(weakSelf);
        [MBProgressHUD showGifToView:nil];
        [self.orderNetWorkService getOrderListByOrderType:_type
                                           withCallBack:^(LgResultModel * _Nonnull res, NSArray * _Nullable orderList, int total, int totalPage) {
            [MBProgressHUD hideHUD];
            if (res.isSucc) {
                
                // 原来表格刷新的逻辑
                if (!orderList.count) {
                    [weakSelf.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
                    return;
                }
                _total = total;
                [weakSelf.dataSource addObjectsFromArray:orderList];
                [weakSelf.tableNode reloadData];
                if (orderList.count == _total) {
                    [weakSelf.tableNode.view.mj_footer endRefreshingWithNoMoreData];
                }
                 [weakSelf.tableNode reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
                _page = 2;
            }
        }];
    };
    [self.navigationController pushViewController:ovc animated:YES];
}

- (void)gotopaypalhtml
{
    WEAK_SELF(weakSelf);
    [MBProgressHUD showGifToView:nil];
    [self.merchantNetworkService queryMerchantInfoCallBack:^(LgResultModel * _Nonnull result, MerchantInfoModel * _Nullable merchantInfo) {
        [MBProgressHUD hideHUD];
        
        if (result.isSucc) {
            NSArray *temp = [PayModel mj_objectArrayWithKeyValuesArray:merchantInfo.payCompanyList];

            if (temp.count>0) {
                BOOL ispaypal = NO;
                for (PayModel *model in temp) {
                    if ([model.payName isEqualToString:@"PayPal"]) {
                        ispaypal = YES;
                        _ClientID = model.majorkey;
                    }
                }
                
                if (ispaypal)
                {
                    PayViewController *payVC = [[PayViewController alloc] init];
                    payVC.money = _paymodel.totalAmount;
                    payVC.clientid = _ClientID;
                    payVC.ordercode = _paymodel.orderCode;
                    payVC.type = 1;
                    payVC.paymethod = _paymodel.paymentMethod;
        
                    [weakSelf.navigationController pushViewController:payVC animated:YES];
                } else {
                    [MBProgressHUD showErrorMessage:NSLocalizedString(@"商家暂不支持PayPal支付", nil)];
                }
            } else {
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"商家收款信息不完整", nil)];
                return;
            }
        } else {
            [MBProgressHUD showErrorMessage:result.errMsg];
        }
    }];
}

- (void)updateorderpaystate {
    [self.refresh beginRefreshing];
}

#pragma mark - 接口操作

- (void)doNetworkRequestForHeader
{
    _currentTuiJianPage = 1;
    _currentCategoryPage = 1;
    _totalSumNum = 0;
    _totalTuiJianSumNum = 0;
    _totalCategorySumNum = 0;
    _currentProductPageIndex = 0;
    
    [self.tableNode.view.mj_footer resetNoMoreData];
    [self.dataSource removeAllObjects];
    [self.productListSource removeAllObjects];
    [self.tableNode reloadData];
    
    WEAK_SELF(weakSelf);
    [self.orderNetWorkService getOrderListByOrderType:_type
                                    withCallBack:^(LgResultModel * _Nonnull res, NSArray * _Nullable orderList, int total, int totalPage) {
        [weakSelf.refresh endRefresh];

        if (res.isSucc) {
            if (!orderList.count) {
               // [weakSelf.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
                [MBProgressHUD showGifToView:nil];
                // 查询推荐商品
                __strong OrderListController *strongSelf = weakSelf;
                [LGProductNetWorkService getProductListWithType:@"2"
                                                        pageNum:@(1)
                                                        rowsNum:@(20)
                                                       callBack:^(LgResultModel *resultModel, NSArray *productList,int totalNum) {
                    [MBProgressHUD hideHUD];
                    if (resultModel.isSucc) {
                        _currentTuiJianPage = 2;
                        _totalTuiJianSumNum = totalNum;
                        [strongSelf.productListSource addObjectsFromArray:productList];
                        [strongSelf.tableNode reloadData];
                    } else {
                        [MBProgressHUD hideHUDForView:weakSelf.view animated:NO];
                      //  [MBProgressHUD showErrorMessage:resultModel.errMsg];
                    }
                }];
            } else {
                _total = total;
                [weakSelf.dataSource addObjectsFromArray:orderList];
                if (orderList.count == _total) {
                    [weakSelf.tableNode.view.mj_footer endRefreshingWithNoMoreData];
                }
                [weakSelf.tableNode reloadData];
                _page = 2;
            }
        } else {
            [weakSelf.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
        }
    }];
}

#pragma mark - 底部刷新===============STAR==============
- (void)doNetworkRequestForFooter{
    
    WEAK_SELF(weakSelf);
    [LGProductNetWorkService getProductListWithType:@"2"
                                            pageNum:@(_currentTuiJianPage)
                                            rowsNum:@(20)
                                           callBack:^(LgResultModel *resultModel, NSArray *productList,int totalNum) {
        [MBProgressHUD hideHUDForView:weakSelf.view animated:NO];
        [weakSelf.refresh endRefresh];
        if (resultModel.isSucc) {
            _totalTuiJianSumNum = totalNum;
            // 没有更多数据了
            if (weakSelf.productListSource.count >= (_totalTuiJianSumNum)) {
                // 加载首页产品的列表
                [weakSelf.tableNode.view.mj_footer endRefreshingWithNoMoreData];
            } else {
                [weakSelf.productListSource addObjectsFromArray:productList];
                _currentTuiJianPage ++;
                [weakSelf.tableNode reloadData];
            }
        } else {
           // [MBProgressHUD showErrorMessage:resultModel.errMsg];
        }
    }];
}
#pragma mark - 底部刷新===============END==============

- (void)cancelOrderActionWithOrderId:(NSString *)orderIdStr indexPath:(NSIndexPath *)indexPath {
    [self.dataSource removeAllObjects];

    [MBProgressHUD showGifToView:nil];
    WEAK_SELF(weakSelf);
    [self.orderLogicService doCancelOrderActionWithType:_type
                                                orderId:orderIdStr
                                               callBack:^(LgResultModel * _Nonnull res, NSArray * _Nullable orderList, int total, int totalPage) {
        [MBProgressHUD hideHUD];
        if (res.isSucc) {
            [MBProgressHUD showMessage:NSLocalizedString(@"后台审核中,请稍后查看", nil) displayTime:2.0];
            
            // 原来表格刷新的逻辑
            if (!orderList.count) {
                [weakSelf.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
                return;
            }
            _total = total;
            [weakSelf.dataSource addObjectsFromArray:orderList];
            if (orderList.count == _total) {
                [weakSelf.tableNode.view.mj_footer endRefreshingWithNoMoreData];
            }
            
            [weakSelf.tableNode reloadData];
            // [weakSelf.tableNode reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            // NSSet *updateSet = [[NSSet alloc] initWithArray:@[indexPath]];
            // [weakSelf.tableNode reloadSections:updateSet withRowAnimation:UITableViewRowAnimationNone];
            _page = 2;
        } else {
            if ([res.stateCode isEqualToString:@"2"]) {
                [MBProgressHUD showErrorMessage:NSLocalizedString(@"售后单状态已拒绝，操作失败!", nil)];
            } else {
                [MBProgressHUD showErrorMessage:res.errMsg];
            }
        }
    }];
}

- (void)confirmOrderSucc:(NSString *)backId indexPath:(NSIndexPath *)indexPath
{
    [self.dataSource removeAllObjects];

    [MBProgressHUD showGifToView:nil];
    WEAK_SELF(weakSelf);
    [self.orderLogicService doConfrimOrderActionWithType:_type
                                                 orderId:backId
                                                callBack:^(LgResultModel * _Nonnull res, NSArray * _Nullable orderList, int total, int totalPage) {
        [MBProgressHUD hideHUD];
        if (res.isSucc) {
            [MBProgressHUD showMessage:NSLocalizedString(@"确认完成", nil)];
            
            // 原来表格刷新的逻辑
            if (!orderList.count) {
                [weakSelf.emptyModel setStatus:NSLocalizedString(@"zusj", nil)];
                return;
            }
            _total = total;
            [weakSelf.dataSource addObjectsFromArray:orderList];
            [weakSelf.tableNode reloadData];
            if (orderList.count == _total) {
                [weakSelf.tableNode.view.mj_footer endRefreshingWithNoMoreData];
            }
             [weakSelf.tableNode reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            _page = 2;
        } else {
            [MBProgressHUD showErrorMessage:res.message];
        }
    }];
}


#pragma mark - 懒加载
- (LGOrderNetWorkService *)orderNetWorkService {
    if (!_orderNetWorkService) {
        _orderNetWorkService = [[LGOrderNetWorkService alloc] init];
    }
    return _orderNetWorkService;
}

- (LgMerchantNetworkService *)merchantNetworkService {
    if (!_merchantNetworkService) {
        _merchantNetworkService = [[LgMerchantNetworkService alloc] init];
    }
    return _merchantNetworkService;
}

- (LGOrderLogicService *)orderLogicService
{
    if (!_orderLogicService) {
        _orderLogicService = [[LGOrderLogicService alloc] init];
    }
    return _orderLogicService;
}

#pragma mark - 懒加载
- (NSMutableArray *)productListSource {
    if (!_productListSource) {
        _productListSource = [[NSMutableArray alloc] init];
    }
    return _productListSource;
}

#pragma mark - JXCategoryListContentViewDelegate

- (UIView *)listView {
    return self.view;
}
@end
