//
//  OrderListNormalModel.m
//  BusinessOnline
//
//  Created by clitics on 2019/5/17.
//  Copyright © 2019 clitics. All rights reserved.
//

#import "OrderListNormalModel.h"
#import "BaseService.h"

@interface OrderListNormalModel()


@property (nonatomic, strong) NSDictionary *afterSaleStateDic;

@end

@implementation OrderListNormalModel

//  售后单详情状态 0-等待审核，1-已同意，2-等待商家确认，3-等待用户确认，4-已完成，5-已拒绝
+ (NSString *)afterSaleState:(NSString *)afterSaleStateStr{
    
    NSString *finalState = @"";
    
    if (afterSaleStateStr.length == 0 || afterSaleStateStr == nil) {
        return @"";
    } else {
        if ([afterSaleStateStr isEqualToString:@"0"]) {
            finalState = [NSLocalizedString(@"等待审核", nil) uppercaseStringWithLocale:[NSLocale currentLocale]];
        } else if ([afterSaleStateStr isEqualToString:@"1"]) {
            finalState = [NSLocalizedString(@"已同意", nil) uppercaseStringWithLocale:[NSLocale currentLocale]];
        } else if ([afterSaleStateStr isEqualToString:@"2"]) {
            finalState = [NSLocalizedString(@"等待商家确认", nil) uppercaseStringWithLocale:[NSLocale currentLocale]];
        } else if ([afterSaleStateStr isEqualToString:@"3"]) {
            finalState = [NSLocalizedString(@"等待用户确认", nil) uppercaseStringWithLocale:[NSLocale currentLocale]];
        } else if ([afterSaleStateStr isEqualToString:@"4"]) {
            finalState = [NSLocalizedString(@"已完成", nil) uppercaseStringWithLocale:[NSLocale currentLocale]];
        } else if ([afterSaleStateStr isEqualToString:@"5"]) {
            finalState = [NSLocalizedString(@"已拒绝", nil) uppercaseStringWithLocale:[NSLocale currentLocale]];
        }
    }
    return finalState;;
}


@end
