//
//  OrderListModel.m
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "OrderListModel.h"

@implementation OrderListModel

@end
