//
//  OrderListNormalModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/5/17.
//  Copyright © 2019 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OrderListNormalModel : NSObject
/*
 "bus_name" = test;
 collect = "\U8054\U7cfb\U4eba";
 consignee = "\U8054\U7cfb\U4eba";
 contactnumber = 13724169766;
 "deliver_time" = "";
 
 detail = "\U5730\U5740";
 id = "";
 invitationCode = test;
 "is_collect" = 0;
 "is_deliver" = 0;
 
 "ord_proLst" = "";
 "order_code" = GO15580813758671446921;
 "order_createtime" = "2019-05-17 10:22:56";
 "order_state" = 1;
 
 "pay_mode" = 3456;
 "product_id" = "";
 "product_num" = "";
 remarks = "";
 user = "";
 
 "user_id" = "";
 */
//@property (nonatomic,copy)NSString *bus_name;
//@property (nonatomic,copy)NSString *collect;
//@property (nonatomic,copy)NSString *consignee;
@property (nonatomic,copy)NSString *address;
@property (nonatomic,copy)NSString *collectName;
//@property (nonatomic,copy)NSString *contactnumber;
//@property (nonatomic,copy)NSString *collectPhone;

@property (nonatomic,copy)NSString *deliverTime;
//@property (nonatomic,copy)NSString *detail;
//@property (nonatomic,copy)NSString *id;
@property (nonatomic,copy)NSString *orderId;
@property (nonatomic,copy)NSString *invitationCode;
//@property (nonatomic,copy)NSString *is_collect;
//@property (nonatomic,copy)NSString *is_deliver;
@property (nonatomic,copy)NSString *overCollect;
@property (nonatomic,copy)NSString *overDeliver;

//@property (nonatomic,copy)NSString *order_code;
@property (nonatomic,copy)NSString *orderCode;
//@property (nonatomic,copy)NSString *ord_proLst;
//@property (nonatomic,copy)NSString *order_createtime;
@property (nonatomic,copy)NSString *createDate;
//@property (nonatomic,copy)NSString *order_price;

/** totalAmount:包含商品金额 + 运费 */
@property (nonatomic,copy)NSString *totalAmount;
//@property (nonatomic,copy)NSString *order_state;
/** 订单状态 1:等待处理   2:处理中 3:已完成  6:已取消*/
@property (nonatomic,copy)NSString *orderState;

//@property (nonatomic,copy)NSString *pay_mode;
@property (nonatomic,copy)NSString *paymentMethod;
//@property (nonatomic,copy)NSString *product_id;
//@property (nonatomic,copy)NSString *product_num;
@property (nonatomic,copy)NSString *remarks;
//@property (nonatomic,copy)NSString *user;
//@property (nonatomic,copy)NSString *user_id;
@property (nonatomic,copy)NSString *userName;
@property (nonatomic,copy)NSString *userPhone;
/** amount:商品金额  不包含运费*/
@property (nonatomic,copy)NSString *amount;
@property (nonatomic,copy)NSString *collectAddress;
@property (nonatomic,copy)NSString *collectDate;
@property (nonatomic,copy)NSString *collectPhone;
@property (nonatomic,copy)NSString *companyTaxCode;
@property (nonatomic,copy)NSString *depositAmount;
@property (nonatomic,copy)NSString *discountAmount;
@property (nonatomic,copy)NSString *overDel;
@property (nonatomic,copy)NSString *payDate;
@property (nonatomic,copy)NSString *salesPersonInvitation;
@property (nonatomic,copy)NSString *salesPersonName;
@property (nonatomic,copy)NSString *syncCode;
@property (nonatomic,copy)NSString *taxCode;
@property (nonatomic,copy)NSString *companyName;
@property (nonatomic,copy)NSString *order_code;
@property (nonatomic,copy)NSString *bus_name;
@property (nonatomic,copy)NSString *order_price;
@property (nonatomic,copy)NSString *order_createtime;
@property (nonatomic,copy)NSString *pay_mode;
//@property (nonatomic,copy)NSString *order_state;
@property (nonatomic,copy)NSString *payState;
@property (nonatomic,copy)NSString *freightAmount;

/**
   交易流水号
 */
@property (nonatomic,copy)NSString *paymentSerialNumber;

/**
 售后单详情状态 0-等待审核，1-已同意，2-等待商家确认，3-等待用户确认，4-已完成，5-已拒绝 
 */
@property (nonatomic, copy) NSString *backStatus;

/**
    退货单Id
 */
@property (nonatomic, copy) NSString *backId;


/**
      最终处理后的售后状态信息
 */
+ (NSString *)afterSaleState:(NSString *)afterSaleStateStr;
@end

NS_ASSUME_NONNULL_END
