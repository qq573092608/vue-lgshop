//
//  OrderListModel.h
//  BusinessOnline
//
//  Created by clitics on 2019/2/26.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OrderListModel : NSObject

/*
 "address": "双双",
 "amount": 700.00,
 "collectAddress": "双双",
 "collectName": "hj",
 "collectPhone": "15777639276",
 
 "companyTaxCode": "66782",
 "createDate": 1554366473000,
 "depositAmount": 0.00,
 "discountAmount": 0.00,
 "orderCode": "GO15543664731459507639",
 
 "orderId": 66,
 "orderState": 2,
 "overCollect": false,
 "overDel": 0,
 "overDeliver": false,
 
 "paymentMethod": "哈哈哈",
 "salesPersonInvitation": "Zwen",
 "salesPersonName": "Zwen",
 "syncCode": "66af7785-d38d-44ff-a4d8-7952e7abfc5b",
 "totalAmount": 700.00,
 
 "userPhone": "15875319507"
 "remarks":""
 "invitationCode": "lgerp"
 */
@property (nonatomic,copy)NSString *address;
@property (nonatomic,copy)NSString *amount;
@property (nonatomic,copy)NSString *collectAddress;
@property (nonatomic,copy)NSString *collectName;
@property (nonatomic,copy)NSString *collectPhone;

@property (nonatomic,copy)NSString *companyTaxCode;
@property (nonatomic,copy)NSString *createDate;
@property (nonatomic,copy)NSString *depositAmount;
@property (nonatomic,copy)NSString *discountAmount;
@property (nonatomic,copy)NSString *orderCode;

@property (nonatomic,copy)NSString *orderId;
@property (nonatomic,copy)NSString *orderState;
@property (nonatomic,copy)NSString *overCollect;
@property (nonatomic,copy)NSString *overDel;
@property (nonatomic,copy)NSString *overDeliver;

@property (nonatomic,copy)NSString *paymentMethod;
@property (nonatomic,copy)NSString *salesPersonInvitation;
@property (nonatomic,copy)NSString *salesPersonName;
@property (nonatomic,copy)NSString *syncCode;
@property (nonatomic,copy)NSString *totalAmount;

@property (nonatomic,copy)NSString *userPhone;
@property (nonatomic,copy)NSString *remarks;
@property (nonatomic,copy)NSString *companyInvitationCode;
@property (nonatomic,copy)NSString *companyName;

@property (nonatomic,copy)NSString *order_code;
@property (nonatomic,copy)NSString *bus_name;
@property (nonatomic,copy)NSString *order_price;
@property (nonatomic,copy)NSString *order_createtime;
@property (nonatomic,copy)NSString *pay_mode;
@property (nonatomic,copy)NSString *order_state;



@end

NS_ASSUME_NONNULL_END
