//
//  LgShoppingService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/9/11.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LgShoppingService.h"

@implementation LgShoppingService

+ (BOOL) isWeChatPay
{
    BOOL res = NO;
    NSString *paymentTypeStr = [[NSUserDefaults standardUserDefaults] valueForKey:kPaymentType];
    // 2代表微信支付
    if ([paymentTypeStr isEqualToString:@"2"]) {
        res = YES;
    }
    return res;
}

@end
