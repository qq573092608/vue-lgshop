//
//  LgShoppingService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/9/11.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LgShoppingService : NSObject


/// 是否是微信支付(YES:是微信支付  NO:默认的支付方式)
+ (BOOL) isWeChatPay;


@end

NS_ASSUME_NONNULL_END
