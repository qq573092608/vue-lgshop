//
//  LgAddressNetworkService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/9/18.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LgAddressNetworkService.h"
#import "LgResultModel.h"
#import "AreaDetailModel.h"
#import "NetworkManager.h"
#import "LgAddressBLogicService.h"

#import "MAddressModel.h"

@implementation LgAddressNetworkService


- (void)addAddressInfo:(MAddressModel *)addressModel callBack:(AddAddressCallBcak)callBack {
 
    LgResultModel *result = [[LgResultModel alloc] init];
    
    NSString *addressdetail = [NSString stringWithFormat:@"[%@] [%@] [%@] %@",
                               addressModel.areaDetailModel.regionalName,
                               addressModel.areaDetailModel.provincesName,
                               addressModel.areaDetailModel.cityName,
                               addressModel.addrDetail];
    
    NSMutableDictionary *mSendPic = [[NSMutableDictionary alloc] init];
    [mSendPic setValue:addressdetail forKey:@"addrDetail"];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [mSendPic setValue:invitationCode forKey:@"companyInvitationCode"];
    [mSendPic setValue:addressModel.areaDetailModel.cityid forKey:@"districtId"];
    NSString *tempAddressIdStr = addressModel.addressId == nil ? @"" : addressModel.addressId;
    [mSendPic setValue:tempAddressIdStr forKey:@"addressId"];
    [mSendPic setValue:addressModel.consignee forKey:@"consignee"];
    [mSendPic setValue:addressModel.contactnumber forKey:@"contactnumber"];
    [mSendPic setValue:addressModel.postalCode forKey:@"postalCode"];
    [mSendPic setValue:addressModel.email forKey:@"email"];
    [mSendPic setValue:addressModel.isChoose forKey:@"isChoose"];

    [NetworkManager postWithURL:CREATE_URL(url_create_address) params:[mSendPic copy] isUsedSignal:NO success:^(id json) {
       
        LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
        result.stateCode = tempResModel.stateCode;
        result.message = tempResModel.message;
        
        if ([tempResModel.stateCode isEqualToString:@"1"]) {
            result.isSucc = YES;
        } else {
            result.isSucc = NO;
            result.errMsg = NSLocalizedString(@"msg8", nil);
        }
        callBack(result);
    } failure:^(NSError *error) {
        result.isSucc = NO;
        result.errMsg = error.localizedDescription;
        callBack(result);
    }];
}

- (void)getAddressDetailInfoWithAddressId:(NSString *)addressId
                                 callBack:(AddressHandleCallBack)callBack {
    LgResultModel *result = [[LgResultModel alloc] init];
    [NetworkManager postWithURL:CREATE_URL(url_address_info)
                         params:@{@"addressId":addressId}
                   isUsedSignal:NO
                        success:^(id json) {
        
            if (json && [[json valueForKey:@"stateCode"] isEqualToString:@"1"]) {
                
                MAddressModel *addressModel = [MAddressModel mj_objectWithKeyValues:[json valueForKey:@"data"]];

                LgAddressBLogicService *addressLogicService = [[LgAddressBLogicService alloc] init];
                AreaDetailModel *areaDetail = [addressLogicService getSelectAreaModelByArr:addressModel.districList];
                addressModel.areaDetailModel = areaDetail;
                
                result.isSucc = YES;
                callBack(result,addressModel);
            } else {
                result.isSucc = NO;
                result.errMsg = NSLocalizedString([json valueForKey:@"stateCode"], nil);
                callBack(result,nil);
            }
        } failure:^(NSError *error) {
            result.isSucc = NO;
            result.errMsg = error.localizedDescription;
            callBack(result,nil);
    }];
}

- (void)delAddressInfoWithAddressId:(NSString *)addressId callBack:(AddressHandleCallBcak)callBack
{
    LgResultModel *resultModel = [[LgResultModel alloc] init];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:addressId forKey:@"addressId"];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [params setValue:invitationCode forKey:@"companyInvitationCode"];
    [NetworkManager postWithURL:CREATE_URL(url_address_delete) params:params isUsedSignal:NO success:^(id json) {
       
        LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
        resultModel.stateCode = tempResModel.stateCode;
        resultModel.message = tempResModel.message;
        
        if ([resultModel.stateCode isEqualToString:@"1"]) {
            resultModel.isSucc = YES;
        } else {
            resultModel.isSucc = NO;
            resultModel.errMsg = NSLocalizedString(@"msg8", nil);
        }
        callBack(resultModel);
    } failure:^(NSError *error) {
        resultModel.isSucc = NO;
        callBack(resultModel);
    }];
}

- (void)getAddressListWithCallBack:(LGAddressListCallBcak)callBack
{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [params setObject:invitationCode forKey:@"companyInvitationCode"];
    
    LgResultModel *resultModel = [[LgResultModel alloc] init];
    [NetworkManager postWithURL:CREATE_URL(url_address_list) params:params isUsedSignal:NO success:^(id json) {
       
        resultModel.stateCode = get_Value_for_key_from_obj(json, successKey);
        resultModel.message = get_Value_for_key_from_obj(json, messageKey);
        if ([get_Value_for_key_from_obj(json, successKey) integerValue] == 0
            || [get_Value_for_key_from_obj(json, successKey) integerValue] == 2) {
            resultModel.isSucc = NO;
            callBack(resultModel,nil);
        } else if ([get_Value_for_key_from_obj(json, successKey) integerValue] == 1) {
            NSArray *temp = [MAddressModel mj_objectArrayWithKeyValuesArray:get_Value_for_key_from_obj(json, dataKey)];
            if (!temp.count) {
                return;
            }
            resultModel.isSucc = YES;
            callBack(resultModel,temp);
        } 
    } failure:^(NSError *error) {
        resultModel.isSucc = NO;
        callBack(resultModel,nil);
    }];
}
@end
