//
//  LgAddressLogicService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/9/18.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LgAddressLogicService : NSObject

@end

NS_ASSUME_NONNULL_END
