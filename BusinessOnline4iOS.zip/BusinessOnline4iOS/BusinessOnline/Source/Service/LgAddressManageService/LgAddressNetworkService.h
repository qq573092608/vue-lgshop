//
//  LgAddressNetworkService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/9/18.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@class LgResultModel,AreaDetailModel,MAddressModel,MAddressModel;

typedef void(^AddAddressCallBcak)(LgResultModel *result);
typedef void(^AddressHandleCallBcak)(LgResultModel *result);
typedef void(^AddressHandleCallBack)(LgResultModel *result, MAddressModel * _Nullable areaModel);

/**
      查询地址列表
 */
typedef void(^LGAddressListCallBcak)(LgResultModel *result,NSArray * _Nullable addressList);

/**
      涉及地址的接口类
 */
@interface LgAddressNetworkService : NSObject



///  新增地址接口
/// @param addressModel 地址的模型
/// @param callBack 返回操作结果的回调
- (void)addAddressInfo:(MAddressModel *)addressModel callBack:(AddAddressCallBcak)callBack;

/**
      查询地址详情的接口
 */
- (void)getAddressDetailInfoWithAddressId:(NSString *)addressId
                                 callBack:(AddressHandleCallBack)callBack;

/**
   根据地址id删除地址信息
 */
- (void)delAddressInfoWithAddressId:(NSString *)addressId
                           callBack:(AddressHandleCallBcak)callBack;


/**
    查询地址列表
 */
- (void)getAddressListWithCallBack:(LGAddressListCallBcak)callBack;

@end

NS_ASSUME_NONNULL_END
