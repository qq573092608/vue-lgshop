//
//  LgProductService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/9/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LgProductService.h"
#import "NetworkManager.h"
#import "BaseService.h"

@interface LgProductService()

@end

@implementation LgProductService

- (void)queryMerchantInfoSuccess:(void (^)(id json))success failure:(void (^)(NSError *error))failure
{
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [NetworkManager postWithURL:CREATE_URL(url_merchantinfo)
                         params:@{@"invitationCode":invitationCode}
                   isUsedSignal:NO
                        success:^(id json) {
        [BaseService updateClassificationIconAndProductList:json];
        success(json);
    } failure:^(NSError *error) {
        failure(error);
    }];
}

@end
