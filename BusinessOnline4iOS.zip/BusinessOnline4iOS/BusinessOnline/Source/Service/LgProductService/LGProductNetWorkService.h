//
//  LgProductNetWorkService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/9/18.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>
@class LgResultModel;

typedef void(^LGGetAllCategoryCallBack)(LgResultModel *resultModel,NSArray *arrList);
typedef void(^LGImgUrlsCallBack)(LgResultModel *resultModel, NSArray *imgUrls);

/**
     推荐、新品、促销的回调
 */
typedef void(^LGProductListWithTypeCallBack)(LgResultModel *resultModel,NSArray *productList,int totalData);
/**
     商品列表的回调
 */
typedef void(^LGProductIndexListCallBack)(LgResultModel *resultModel,NSArray *productList,int totalData);


NS_ASSUME_NONNULL_BEGIN

@interface LGProductNetWorkService : NSObject


///  查询所有分类信息
/// @param categoryCallBack 返回的回调信息
+ (void)getAllCategoryTypesWithCallBack:(LGGetAllCategoryCallBack)categoryCallBack;

/**
    查询后台配置的轮播图信息
 */
+ (void)getImgUrlsWithCallBack:(LGImgUrlsCallBack)imgsCallBack;

/**
     根据传入的类型查询商品的分类信息(新品、推荐、促销)
 */

/// 根据传入的类型查询商品的分类信息(新品、推荐、促销)
/// @param typeStr  (新品、推荐、促销)
/// @param pageNum  当前页数
/// @param rowsNum  当前页显示的条数
/// @param callBack 返回的回调
+ (void)getProductListWithType:(NSString *)typeStr
                       pageNum:(NSNumber *)pageNum
                       rowsNum:(NSNumber *)rowsNum
                      callBack:(LGProductListWithTypeCallBack)callBack;

/**
     根据typeId查询首页商品列表的信息
 */

/// 根据传入的类型查询商品的分类信息(新品、推荐、促销)
/// @param typeStr  (新品、推荐、促销)
/// @param pageNum  当前页数
/// @param rowsNum  当前页显示的条数
/// @param callBack 返回的回调
+ (void)getIndexProductListWithType:(NSString *)typeStr
                       pageNum:(NSNumber *)pageNum
                       rowsNum:(NSNumber *)rowsNum
                      callBack:(LGProductListWithTypeCallBack)callBack;
@end

NS_ASSUME_NONNULL_END
