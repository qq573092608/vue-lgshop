//
//  LgProductService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/9/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LgProductService : NSObject


/// 查询商家信息
/// @param success 成功的回调
/// @param failure 失败的回调
- (void)queryMerchantInfoSuccess:(void (^)(id json))success failure:(void (^)(NSError *error))failure;

@end

NS_ASSUME_NONNULL_END
