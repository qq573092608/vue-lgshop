//
//  LgProductNetWorkService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/9/18.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LGProductNetWorkService.h"
#import "ProductTypeModel.h"
#import "LgResultModel.h"
#import "AdModel.h"
#import "ProductModel.h"

#import "ProductModel.h"
#import "NSString+Tool.h"

@implementation LGProductNetWorkService

+ (void)getAllCategoryTypesWithCallBack:(LGGetAllCategoryCallBack)categoryCallBack
{
    LgResultModel *result = [[LgResultModel alloc] init];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [NetworkManager postWithURL:CREATE_URL(url_get_all_types)
                         params:@{@"invitationCode":invitationCode}
                   isUsedSignal:NO
                        success:^(id json) {
        
        LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
        result.stateCode = tempResModel.stateCode;
        result.message = tempResModel.message;
        
        if ([tempResModel.stateCode isEqualToString:@"1"]) {
            result.isSucc = YES;
            NSArray *temp = [ProductTypeModel mj_objectArrayWithKeyValuesArray:get_Value_for_key_from_obj(json, dataKey)];
            categoryCallBack(result,temp);
        } else {
            result.isSucc = NO;
            categoryCallBack(result,nil);
        }
    } failure:^(NSError *error) {
        result.isSucc = NO;
        result.errMsg = error.localizedDescription;
        categoryCallBack(result,nil);
    }];
}

+ (void)getImgUrlsWithCallBack:(LGImgUrlsCallBack)imgsCallBack
{
    LgResultModel *result = [[LgResultModel alloc] init];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [NetworkManager postWithURL:CREATE_URL(url_imageurls)
                         params:@{@"companyInvitationCode":invitationCode}
                   isUsedSignal:NO
                        success:^(id json) {
        
        LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
        result.stateCode = tempResModel.stateCode;
        result.message = tempResModel.message;
        
        if ([tempResModel.stateCode isEqualToString:@"200"]) {
            NSArray *temp = [AdModel mj_objectArrayWithKeyValuesArray:get_Value_for_key_from_obj(json, dataKey)];
            
            NSMutableArray *finalArr = [[NSMutableArray alloc] init];
            for (AdModel *adModelObj in temp) {
                if (adModelObj.advertisingDetailsPath.isEmptyString
                    || adModelObj.advertisingDetailsPath.isEmptyString) {
                    continue;
                }
                [finalArr addObject:adModelObj];
            }
            if (finalArr.count > 0) {
                result.isSucc = YES;
                imgsCallBack(result,temp);
            } else {
                result.isSucc = NO;
                imgsCallBack(result,nil);
            }
            
        } else {
            result.isSucc = NO;
            imgsCallBack(result,nil);
        }
    } failure:^(NSError *error) {
        result.isSucc = NO;
        result.message = error.localizedDescription;
        imgsCallBack(result,nil);
    }];
}

// 根据商品类型查询对应的列表
+ (void)getProductListWithType:(NSString *)typeStr
                       pageNum:(NSNumber *)pageNum
                       rowsNum:(NSNumber *)rowsNum
                      callBack:(LGProductListWithTypeCallBack)callBack {
        
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:typeStr forKey:@"goods_int1"];
    [params setObject:pageNum forKey:@"page"];
    [params setObject:rowsNum forKey:@"rows"];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    if (isNSString(invitationCode)) {
        [params setObject:invitationCode forKey:@"invitationCode"];
    }
    LgResultModel *result = [[LgResultModel alloc] init];
    [NetworkManager getWithURL:CREATE_URL(url_product_list) params:params success:^(id json) {
        NSArray *temp = [ProductModel mj_objectArrayWithKeyValuesArray:get_Value_for_key_from_obj(json, @"lstPro")];
        NSNumber *total = [json valueForKey:@"total"];
        if ([[json valueForKey:@"stateCode"] isEqualToString:@"1"]) {
            if (temp.count != 0) {
                result.isSucc = YES;
                result.errMsg = get_Value_for_key_from_obj(json, messageKey);
                callBack(result,temp,total.intValue);
            } else {
                result.isSucc = YES;
                result.errMsg = get_Value_for_key_from_obj(json, messageKey);
                callBack(result,nil,total.intValue);
            }
        } else {
            result.isSucc = NO;
            result.errMsg = [json valueForKey:@"message"];
            callBack(result,nil,0);
        }
    } failure:^(NSError *error) {
        result.isSucc = NO;
        result.stateCode = [LgResultModel getServiceError:error.code];
        result.errMsg = error.localizedDescription;
        callBack(result,nil,0);
    }];
}


+ (void)getIndexProductListWithType:(NSString *)typeStr
                       pageNum:(NSNumber *)pageNum
                       rowsNum:(NSNumber *)rowsNum
                           callBack:(LGProductListWithTypeCallBack)callBack{
    
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:typeStr forKey:@"typeId"];
    [params setObject:pageNum forKey:@"page"];
    [params setObject:rowsNum forKey:@"rows"];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    if (isNSString(invitationCode))
    {
        [params setObject:invitationCode forKey:@"invitationCode"];
    }

    LgResultModel *result = [[LgResultModel alloc] init];
    [NetworkManager getWithURL:CREATE_URL(url_product_list) params:params success:^(id json) {
        NSArray *temp = [ProductModel mj_objectArrayWithKeyValuesArray:get_Value_for_key_from_obj(json, @"lstPro")];
        NSNumber *total = [json valueForKey:@"total"];
        
        if ([[json valueForKey:@"stateCode"] isEqualToString:@"1"]) {
            if (temp.count != 0) {
                result.isSucc = YES;
                result.errMsg = get_Value_for_key_from_obj(json, messageKey);
                callBack(result,temp,total.intValue);
            } else {
                result.isSucc = YES;
                result.errMsg = get_Value_for_key_from_obj(json, messageKey);
                callBack(result,nil,total.intValue);
            }
        } else {
            result.isSucc = NO;
            result.errMsg = [json valueForKey:@"message"];
            callBack(result,nil,0);
        }
    } failure:^(NSError *error) {
        result.isSucc = NO;
        result.message = error.localizedDescription;
        result.stateCode = [LgResultModel getServiceError:error.code];
        
        callBack(result,nil,0);
    }];
}







@end
