//
//  LGUserNetWorkService.h
//  BusinessOnline
//
//  Created by lgerp on 2021/1/12.
//  Copyright © 2021 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>
@class LgResultModel,UserInfoModel;

NS_ASSUME_NONNULL_BEGIN

typedef void(^LGLoginCallBack)(LgResultModel *result, id  _Nullable json);
typedef void(^LGSendAuthCodeCallBack)(LgResultModel *result);

typedef void(^LGUserInfoCallBack)(LgResultModel *result, UserInfoModel *userInfo);


@interface LGUserNetWorkService : NSObject

/**
    自动登录接口
 */
- (void)autoLoginActionWithCallBack:(LGLoginCallBack)callBack;

/**
    发送验证码
 */
- (void)sendAuthCodeWithPhone:(NSString *)phoneNum withCallBack:(LGSendAuthCodeCallBack)callBack;

/**
    查询用户信息
 */
- (void)getUserInfoWithCallBack:(LGUserInfoCallBack)callBack;


@end

NS_ASSUME_NONNULL_END
