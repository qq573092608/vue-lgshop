//
//  LGUserNetWorkService.m
//  BusinessOnline
//
//  Created by lgerp on 2021/1/12.
//  Copyright © 2021 clitics. All rights reserved.
//

#import "LGUserNetWorkService.h"
#import "LgResultModel.h"
#import "UserInfoModel.h"

@implementation LGUserNetWorkService

- (void)autoLoginActionWithCallBack:(LGLoginCallBack)callBack
{
    NSString *phoneNumber = [[NSUserDefaults standardUserDefaults] objectForKey:kUserName];
    NSString *password = [[NSUserDefaults standardUserDefaults] objectForKey:kPassword];
    
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:phoneNumber forKey:@"phone"];
    [params setObject:password forKey:@"password"];
    [params setObject:invitationCode forKey:@"invitationCode"];
    
    LgResultModel *resultModel = [[LgResultModel alloc] init];
    
    [NetworkManager postWithURL:CREATE_URL(url_login) params:params isUsedSignal:NO success:^(id json) {
                
        NSString *stateCodeStr = get_Value_for_key_from_obj(json, successKey);
        resultModel.stateCode = stateCodeStr;
        resultModel.message = get_Value_for_key_from_obj(json, messageKey);
        if ([stateCodeStr isEqualToString:@"1"]) {
            resultModel.isSucc = YES;
            NSDictionary *data = get_Value_for_key_from_obj(json, dataKey);
            NSString *cookie = [data objectForKey:@"cookie"];
            // 更新cookie
            [[NSUserDefaults standardUserDefaults] setObject:cookie forKey:kLoginCookies];
            callBack(resultModel,json);
        } else {
            resultModel.isSucc = NO;
            callBack(resultModel,nil);
        }
    } failure:^(NSError *error) {
        resultModel.message = error.localizedDescription;
        resultModel.isSucc = NO;
        [Bugly reportException:[NSException exceptionWithName:@"HttpError"
                                                       reason:@"自动登录接口Http请求错误" userInfo:@{@"error":error.localizedDescription}]];
        callBack(resultModel,nil);
    }];
}

- (void)sendAuthCodeWithPhone:(NSString *)phoneNum withCallBack:(LGSendAuthCodeCallBack)callBack
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithCapacity:4];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [params setObject:phoneNum forKey:@"phone"];
    [params setObject:@"updatePwd" forKey:@"operation"];
    [params setObject:invitationCode forKey:@"invitationCode"];
    
    LgResultModel *resultModel = [[LgResultModel alloc] init];
    resultModel.isSucc = NO;
    [NetworkManager postWithURL:CREATE_URL(url_send_auth_code) params:params isUsedSignal:NO success:^(id json) {

        NSInteger state = [get_Value_for_key_from_obj(json, successKey) integerValue];
        switch (state) {
            case 1:
                resultModel.isSucc = YES;
                resultModel.message = NSLocalizedString(@"msg1", nil);
                break;
            case 2:
                resultModel.message = NSLocalizedString(@"msg3", nil);
                break;
            case 3:
                resultModel.message = NSLocalizedString(@"msg2", nil);
                break;
            default:
                resultModel.message = NSLocalizedString(@"phonenone", nil);
                break;
        }
        
        callBack(resultModel);
    } failure:^(NSError *error) {
        resultModel.message = error.localizedDescription;
        callBack(resultModel);
    }];
}

- (void)getUserInfoWithCallBack:(LGUserInfoCallBack)callBack{
    
    LgResultModel *resultModel = [[LgResultModel alloc] init];
    resultModel.isSucc = NO;
    
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:invitationCode forKey:@"invitationCode"];
    [NetworkManager postWithURL:CREATE_URL(url_userinfo) params:params isUsedSignal:NO success:^(id json) {

        NSInteger state = [get_Value_for_key_from_obj(json, successKey) integerValue];
        if (state == 0) {
            resultModel.stateCode = get_Value_for_key_from_obj(json, successKey);
            resultModel.message = get_Value_for_key_from_obj(json, messageKey);
            callBack(resultModel,nil);
        } else if (state == 1){
            resultModel.isSucc = YES;
            UserInfoModel *userInfoModel = [UserInfoModel mj_objectWithKeyValues:get_Value_for_key_from_obj(json, dataKey)];
            callBack(resultModel,userInfoModel);
        } else {
            resultModel.message = get_Value_for_key_from_obj(json, messageKey);
            callBack(resultModel,nil);
        }
    } failure:^(NSError *error) {
        resultModel.message = error.localizedDescription;
        callBack(resultModel,nil);
    }];
}

@end
