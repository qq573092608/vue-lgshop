//
//  LgResultModel.h
//  BusinessOnline
//
//  Created by lgerp on 2020/9/16.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LgResultModel : NSObject

/**
     状态码
 */
@property (nonatomic, strong) NSString *stateCode;


/**
    最终返回的结果
 */
@property (nonatomic, strong) id data;

/**
    信息内容
 */
@property (nonatomic, strong) NSString *message;


/**
    是否成功(YES:成功   NO:失败)
 */
@property (nonatomic, assign) BOOL isSucc;

/**
    错误信息
 */
@property (nonatomic, strong) NSString *errMsg;

/**
    包含所有错误信息的对象
 */
@property (nonatomic, strong) NSError *err;

/**
   获取服务器错误
 */
+ (NSString *)getServiceError:(NSInteger)code;

@end

NS_ASSUME_NONNULL_END
