//
//  BaseService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/9/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseService : NSObject


///  根据APPType获取邀请码
/// @param appType APPTYPE
- (NSString *)getInvitationCodeByAPPTYPE:(int)appType;


///  根据APPType获取图片名称
/// @param appType APPTYPE
- (NSString *)getImgNameByAPPTYPE:(int)appType;


///  根据APPType获取公司名称
/// @param appType APPTYPE
- (NSString *)getCompanyNameByAPPTYPE:(int)appType;


///  根据类型获取对应的加载的LaunchImg
/// @param appType APPTYPE
- (NSString *)getLaunchImgByAPPType:(int)appType;


/// 根据APPType获取首页左上角图标
/// @param appType APPTYPE
- (NSString *)getHomeBtnImgNameByAPPTYPE:(int)appType;


///  根据接口处理分类图标和商品列表的状态
/// @param jsonData 商家信息接口返回的内容
+ (void)updateClassificationIconAndProductList:(id)jsonData;

///  将
/// @param image 目标图片
/// @param size 最终要放入的尺寸大小
+ (UIImage*)image:(UIImage *)image scaleToSize:(CGSize)size;

///  判断当前语言是否是意大利语
+ (BOOL)isItalyLanguage;

/// 判断是否是中文
+ (BOOL)isChinaLanguage;


@end

NS_ASSUME_NONNULL_END
