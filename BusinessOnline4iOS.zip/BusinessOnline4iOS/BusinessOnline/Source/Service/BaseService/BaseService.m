//
//  BaseService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/9/9.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "BaseService.h"
#import "MerchantInfoModel.h"
#import "AppDelegate.h"
#import "PayModel.h"

@interface BaseService ()

// APPTYPE与邀请码的对应关系
@property (nonatomic, copy) NSDictionary *invitaCodeDic;

// APPTYPE与图片名称的对应关系
@property (nonatomic, copy) NSDictionary *appTypeImgDic;

// APPTYPE与公司名称的对应关系
@property (nonatomic, copy) NSDictionary *appTypeCompanyNameDic;

// APPTYPE与LaunchImg的对应关系
@property (nonatomic, copy) NSDictionary *appTypeLaunchImgDic;

// APPTYPE与首页左上角的对应关系
@property (nonatomic, copy) NSDictionary *homeBtnImgsDic;

@end


@implementation BaseService

- (NSString *)getInvitationCodeByAPPTYPE:(int)appType
{
    NSString *appTypeStr = [NSString stringWithFormat:@"%d",appType];
    
    if ([appTypeStr isEqualToString:@""] || appTypeStr == nil) {
        return @"";
    }
//   return self.invitaCodeDic[appTypeStr];
    
#ifdef DEBUG
//    return  @"eachitaly";
    return self.invitaCodeDic[appTypeStr];
#else
    return self.invitaCodeDic[appTypeStr];
#endif
}

- (NSString *)getImgNameByAPPTYPE:(int)appType
{
    NSString *appTypeStr = [NSString stringWithFormat:@"%d",appType];
   if ([appTypeStr isEqualToString:@""] || appTypeStr == nil) {
       return @"";
   }
    return  self.appTypeImgDic[appTypeStr];
}

- (NSString *)getCompanyNameByAPPTYPE:(int)appType
{
    NSString *appTypeStr = [NSString stringWithFormat:@"%d",appType];
    if ([appTypeStr isEqualToString:@""] || appTypeStr == nil) {
        return @"";
    }
     return  self.appTypeCompanyNameDic[appTypeStr];
}

- (NSString *)getLaunchImgByAPPType:(int)appType
{
    NSString *appTypeStr = [NSString stringWithFormat:@"%d",appType];
    
    if ([appTypeStr isEqualToString:@""] || appTypeStr == nil) {
        return @"";
    }
    return self.appTypeLaunchImgDic[appTypeStr];
}

- (NSString *)getHomeBtnImgNameByAPPTYPE:(int)appType
{
    NSString *appTypeStr = [NSString stringWithFormat:@"%d",appType];
       
    if ([appTypeStr isEqualToString:@""] || appTypeStr == nil) {
        return @"";
    }
    return self.homeBtnImgsDic[appTypeStr];
}


+ (void)updateClassificationIconAndProductList:(id)jsonData
{
    if ([get_Value_for_key_from_obj(jsonData, @"success") integerValue] == 1) {
        NSLog(@"jsonData====>%@",jsonData);
        MerchantInfoModel *model = [MerchantInfoModel mj_objectWithKeyValues:get_Value_for_key_from_obj(jsonData, dataKey)];
   
        // 保存商家声明 
        [[NSUserDefaults standardUserDefaults] setValue:model.companyStatement forKey:kCompanyStatement];
        
        // 默认不展示Paypal支付
        [[NSUserDefaults standardUserDefaults] setBool:false forKey:kIsPayPalShow];
        if (model.payCompanyList.count != 0) {
            for (NSDictionary *payModelDic in model.payCompanyList) {
                PayModel *payModel = [PayModel mj_objectWithKeyValues:payModelDic];
                if ([payModel.payName isEqualToString:@"PayPal"]) {
                    if (payModel.whetherShow == 0) {
                        // 配置Paypal是否展示
                        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:kIsPayPalShow];
                    } else {
                        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:kIsPayPalShow];
                    }
                }
            }
        }
        
        // 存储售后有效期限
        [[NSUserDefaults standardUserDefaults] setValue:model.afterSalesValidPeriod forKey:kAfterSalesValidPeriod];
        
        // 存储商家售后信息
        [[NSUserDefaults standardUserDefaults] setValue:model.afterSalesContactInformation forKey:kAfterSalesContactInformation];
        
        // 显示图标
        if ([model.classifyImgShow isEqualToString:@"1"]) {
            [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:KIsHidden];
            // 不显示图标     
        } else if( [model.classifyImgShow isEqualToString:@"2"]) {
            [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:KIsHidden];
        }
        
        // 表格单排排显示
        if ([model.productsShow isEqualToString:@"1"]) {
            [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:kIsRows];
            // 表格双排排显示
        } else if ([model.productsShow isEqualToString:@"2"]) {
            [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:kIsRows];
        }
        
        // 存储返回回来的支付方式(paymentMethod:1为默认支付方式 2:微信支付)
        if ([model.paymentMethod isEqualToString:@"1"]) {
            [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:kPaymentType];
        } else if ([model.paymentMethod isEqualToString:@"2"]) {
            [[NSUserDefaults standardUserDefaults] setValue:@"2" forKey:kPaymentType];
        }
    } else {
        [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:KIsHidden];
        [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:kIsRows];
    }
}

+ (UIImage*)image:(UIImage *)image scaleToSize:(CGSize)size{
    
    // 得到图片上下文，指定绘制范围
    UIGraphicsBeginImageContext(size);
    
    // 将图片按照指定大小绘制
    [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
    
    // 从当前图片上下文中导出图片
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // 当前图片上下文出栈
    UIGraphicsEndImageContext();
    
    // 返回新的改变大小后的图片
    return scaledImage;
}


+ (BOOL)isItalyLanguage
{
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    if ([appdelegate.language isEqualToString:@"意大利"])
    {
        return YES;
    } else {
        return NO;
    }
}

+ (BOOL)isChinaLanguage
{
    BOOL isChinaLan = NO;
    NSArray *languages = [NSLocale preferredLanguages];
    if (languages.count>0 && [languages.firstObject hasPrefix:@"zh"]) {
        isChinaLan = YES;
    } else {
        isChinaLan = NO;
    }
    return isChinaLan;
}


#pragma mark - 初始化
- (NSDictionary *)homeBtnImgsDic
{
    if (!_homeBtnImgsDic) {
        _homeBtnImgsDic = @{
            @"1" : @"023_a",
            @"2" : @"CasaOnline_home",
            @"3" : @"ideastore_home",
            @"4" : @"SuperBON_home",
            @"5" : @"CasaMia_home",
            
            @"6" : @"HL_home",
            @"7" : @"OceanCasa_home",
            @"9" : @"DamaiShop_home",
            @"10" : @"Eurasia_home",
            
            @"11" : @"SuperShop_home",
            @"12" : @"LuLuOnline_home",
            @"13" : @"MFStore_home",
            @"14" : @"GM_home",
            @"15" : @"G.Market_home",
            
            @"16" : @"EcoCasa_home",
            @"17" : @"IperStore_home",
            @"18" : @"CasaFelice_home",
            @"19" : @"Emporio_home",
            @"20" : @"TBStore_home",
            
            @"21" : @"LingZuiFang_home",
            @"22" : @"SuperPanda_home",
            @"23" : @"PuntoCasa_home",
            @"24" : @"Aky_home",
            @"26" : @"Punto.Casa_home",
            
            @"27" : @"OrienShop_home",
            @"29" : @"Deidou_home",
            @"30" : @"Multiethnic_home",
            
            @"31" : @"Lhshopping_home",
            @"32" : @"Multiethnic_home",
            @"33" : @"Ecoshopping_home",
            @"34" : @"Mallmai_home",
            @"35" : @"Multiethnic_home",
            @"36" : @"ideacasa_mechant",

        };
    }
    return _homeBtnImgsDic;
}


- (NSDictionary *)invitaCodeDic
{
    if (!_invitaCodeDic) {
        _invitaCodeDic = @{
            @"1" : @"test0430",
            @"2" : @"test",
            @"3" : @"ideastore",
            @"4" : @"haoyouduo",
            @"5" : @"casamia",
            
            @"6" : @"hl",
            @"7" : @"jubaopen",
            @"9" : @"qingqing",
            @"10" : @"eurasia",
            
            @"11" : @"supershopping",
            @"12" : @"luluonline",
            @"13" : @"mfstore",
            @"14" : @"gmarket",
            @"15" : @"globalmarket",
            
            @"16" : @"ecocasa",
            @"17" : @"awei",
            @"18" : @"casafelice",
            @"19" : @"emporio",
            @"20" : @"beststore",
            
            @"21" : @"LingZuiFang",
            @"22" : @"superpanda",
            @"23" : @"punto",
            @"24" : @"akyaky",
            @"26" : @"puntocasa",
            
            @"27" : @"orien",
            @"29" : @"Deidou",
            @"30" : @"multiethnic",
            @"31" : @"lhshopping",
            @"32" : @"linqdilijun",
            @"33" : @"ecoshopping",
            @"34" : @"mallmai",
            @"35" : @"asialed",
            @"36" : @"ideacasa",
        };
    }
    return _invitaCodeDic;
}

- (NSDictionary *)appTypeImgDic
{
    if (!_appTypeImgDic) {
        _appTypeImgDic = @{
            @"1" : @"037_va",
            @"2" : @"CassaOnlineicon",
            @"3" : @"ideastore_mechant",
            @"4" : @"SuperBON_Merchant",
            @"5" : @"CasaMia_merchant",
            
            @"6" : @"HL_merchant",
            @"7" : @"OceanCasa_merchant",
            @"9" : @"DamaiShop_merchant",
            @"10" : @"Eurasia_merchant",
            
            @"11" : @"SuperShop_merchant",
            @"12" : @"LuLuOnline_merchant",
            @"13" : @"MFStore_merchant",
            @"14" : @"GM_merchant",
            @"15" : @"G.Market_merchant",
            
            @"16" : @"EcoCasa_merchant",
            @"17" : @"IperStore_merchant",
            @"18" : @"CasaFelice_merchant",
            @"19" : @"Emporio_merchant",
            @"20" : @"TBStore_merchant",
            
            @"21" : @"LingZuiFang_merchant",
            @"22" : @"SuperPanda_merchant",
            @"23" : @"PuntoCasa_merchant",
            @"24" : @"Aky_merchant",
            @"26" : @"Punto.Casa_merchant",
            
            @"27" : @"OrienShop_merchant",
            @"29" : @"Deidou_merchant",
            @"30" : @"Multiethnic_merchant",
            
            @"31" : @"Lhshopping_merchant",
            @"32" : @"linqdilijun",
            @"33" : @"Ecoshopping_mechant",
            @"34" : @"Mallmai_merchant",
            @"35" : @"asialed",
            @"36" : @"ideacasa_mechant",
        };
    }
    
    return _appTypeImgDic;
}

- (NSDictionary *)appTypeLaunchImgDic
{
    if (!_appTypeLaunchImgDic) {
        _appTypeLaunchImgDic = @{
            @"1" : @"60_g",
            @"2" : @"CassaOnline",
            @"3" : @"IdeaStoreLaunch",
            @"4" : @"SuperBONLaunch",
            @"5" : @"CasaMiaLaunch",
            
            @"6" : @"H&LLaunch",
            @"7" : @"OceanCasaLaunch",
            @"9" : @"Damai ShopLaunch",
            @"10" : @"EurasiaLaunch",
            @"11" : @"SuperShopLaunch",
            
            @"12" : @"LuLuOnlineLaunch",
            @"13" : @"MFStoreLaunch",
            @"14" : @"GMLaunch",
            @"15" : @"GMarketInfoLaunch",
            @"16" : @"EcoCasaLaunch",
            
            @"17" : @"IperStoreLaunch",
            @"18" : @"CasaFeliceLaunch",
            @"19" : @"EmporioLaunch",
            @"20" : @"TBStoreLaunch",
            @"21" : @"LingZuiFangLaunch",
            
            @"22" : @"SuperPandaLaunch",
            @"23" : @"PuntoCasaLaunch",
            @"24" : @"AkyLaunch",
            @"26" : @"Punto.CasaLaunch",
            @"27" : @"OrienShopLaunch",
            
            @"29" : @"DeidouLaunch",
            @"30" : @"MultiethnicLaunch",
            
            @"31" : @"LhshoppingLaunch",
            @"32" : @"linqdilijun",
            @"33" : @"EcoshoppingLaunch",
            @"34" : @"MallmaiLaunch",
            @"35" : @"asialed",
            @"36" : @"IdeaCasaLaunch",
        };
    }
    return _appTypeLaunchImgDic;
}


- (NSDictionary *)appTypeCompanyNameDic
{
    if (!_appTypeCompanyNameDic) {
        _appTypeCompanyNameDic = @{
            @"1" : @"test0430",
            @"2" : @"CasaOnline",
            @"3" : @"Idea Store",
            @"4" : @"SuperBON",
            @"5" : @"Casa Mia",
            
            @"6" : @"H&L",
            @"7" : @"Ocean Casa",
            @"9" : @"Damai Shop",
            @"10" : @"Eurasia",
            
            @"11" : @"Super Shop",
            @"12" : @"LuLu Online",
            @"13" : @"MF Store",
            @"14" : @"G&M",
            @"15" : @"G.Market",
            
            @"16" : @"Eco Casa",
            @"17" : @"Iper Store",
            @"18" : @"CasaFelice",
            @"19" : @"Emporio",
            @"20" : @"TB Store",
            
            @"21" : @"LingZuiFang",
            @"22" : @"SuperPanda",
            @"23" : @"PuntoCasa",
            @"24" : @"Aky宠物",
            @"26" : @"Punto.Casa",
            
            @"27" : @"OrienShop",
            @"29" : @"Deidou",
            @"30" : @"Multiethnic",
            
            @"31" : @"lhshopping",
            @"32" : @"linqdilijun",
            @"33" : @"ecoshopping",
            @"34" : @"mallmai",
            @"35" : @"asialed",
            @"36" : @"365 GIORNI",
        };
    }
    
    return _appTypeCompanyNameDic;
}


@end
