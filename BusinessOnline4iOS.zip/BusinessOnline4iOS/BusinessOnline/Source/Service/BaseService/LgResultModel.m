//
//  LgResultModel.m
//  BusinessOnline
//
//  Created by lgerp on 2020/9/16.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LgResultModel.h"

@implementation LgResultModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.errMsg = @"";
    }
    return self;
}

+ (NSString *)getServiceError:(NSInteger)code
{
    NSString *errorCode = @"";
    if (code == -1004) {
        errorCode = LGConServiceErrCodeStr;
    } else {
        errorCode = LGConServiceUnknowErrorStr;
    }
    return errorCode;
}

@end
