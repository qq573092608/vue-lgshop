//
//  LgMerchantNetworkService.h
//  BusinessOnline
//
//  Created by lgerp on 2020/9/18.
//  Copyright © 2020 clitics. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class LgResultModel,MerchantInfoModel;
typedef void(^MerchanNetworkHandleCallBack)(LgResultModel *result, MerchantInfoModel * _Nullable merchantInfo);

/**
   商家信息相关的网络接口信息类
 */
@interface LgMerchantNetworkService : NSObject

/**
    查询商家信息
 */
- (void)queryMerchantInfoCallBack:(MerchanNetworkHandleCallBack)callBack;


@end

NS_ASSUME_NONNULL_END
