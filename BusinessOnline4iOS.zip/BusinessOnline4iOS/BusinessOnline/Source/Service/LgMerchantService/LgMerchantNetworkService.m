//
//  LgMerchantNetworkService.m
//  BusinessOnline
//
//  Created by lgerp on 2020/9/18.
//  Copyright © 2020 clitics. All rights reserved.
//

#import "LgMerchantNetworkService.h"
#import "NetworkManager.h"
#import "LgResultModel.h"
#import "BaseService.h"
#import "MerchantInfoModel.h"

#import "NSString+check.h"

@implementation LgMerchantNetworkService

- (void)queryMerchantInfoCallBack:(MerchanNetworkHandleCallBack)callBack
{
    LgResultModel *result = [[LgResultModel alloc] init];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [NetworkManager postWithURL:CREATE_URL(url_merchantinfo)
                         params:@{@"invitationCode":invitationCode}
                   isUsedSignal:NO
                        success:^(id json) {
        LgResultModel *tempResModel = [LgResultModel mj_objectWithKeyValues:json];
        result.stateCode = tempResModel.stateCode;
        result.message =  tempResModel.message;
        if ([tempResModel.stateCode isEqualToString:@"200"]) {
            [BaseService updateClassificationIconAndProductList:json];
            result.isSucc = YES;
            
            if ([NSString isBlankDictionary:tempResModel.data]) {
                callBack(result,nil);
            } else {
                MerchantInfoModel *merchantInfo = [MerchantInfoModel mj_objectWithKeyValues:tempResModel.data];
                callBack(result,merchantInfo);
            }
        } else {
            result.isSucc = NO;
            result.errMsg = NSLocalizedString(@"unknownerror", nil);
            callBack(result,nil);
        }
    } failure:^(NSError *error) {
        result.isSucc = NO;
        result.errMsg = error.localizedDescription;
        callBack(result,nil);
    }];
}

@end
