//
//  ForgetPasswordView.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/1.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ForgetPasswordView : UIScrollView

@property (nonatomic,copy)void(^forgetPasswordCallback)(NSString *phoneNumber, NSString *authCode, NSString *password);
@property (nonatomic,copy)void(^dismissCallback)(void);
@property (nonatomic,copy)void(^sendAuthCodeCallback)(NSString *phone);

@end

NS_ASSUME_NONNULL_END
