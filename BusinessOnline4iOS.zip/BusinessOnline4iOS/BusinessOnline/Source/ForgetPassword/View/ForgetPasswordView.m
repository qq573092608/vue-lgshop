//
//  ForgetPasswordView.m
//  BusinessOnline
//
//  Created by clitics on 2019/3/1.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "ForgetPasswordView.h"

@interface ForgetPasswordView ()<UITextFieldDelegate>
{
    NSTimer *_timer;
    NSInteger _timeForAuthBtnActive;
}
@property (nonatomic,strong)UITextField *phoneNumberTextfield;
@property (nonatomic,strong)UITextField *authCodeTextfield;
@property (nonatomic,strong)UITextField *passwordTextfield;
@property (nonatomic,strong)UITextField *repeatTextfield;
@property (nonatomic,strong)UIView *whiteview;
@property (nonatomic,strong)UIButton *commitBtn;
@property (nonatomic,strong)UIButton *authCodeBtn;
@property (nonatomic,assign)BOOL shouldAuthCodeBtnCanChangeBackgroundColor;

@end
@implementation ForgetPasswordView

NSInteger timeSpacing = 5;

-(instancetype)init
{
    if (self = [super init])
    {
        _timeForAuthBtnActive = timeSpacing;
        _shouldAuthCodeBtnCanChangeBackgroundColor = YES;
        
        [self setupSubViews];
    }
    return self;
}

static CGFloat edgSpacing = 20.0f;
static CGFloat viewSpacing = 10.0f;

- (void)setupSubViews
{
    UIView *container = [UIView new];
    container.userInteractionEnabled = YES;
    [self addSubview:container];
    [container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
        make.width.equalTo(self);
    }];
    
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [container addSubview:backBtn];
    [backBtn setImage:[UIImage imageNamed:@"001_return"] forState:UIControlStateNormal];
    [backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(container).offset(edgSpacing);
        make.top.mas_equalTo(container).offset(edgSpacing+STATUSBAR_HEIGHT);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    [backBtn addTarget:self action:@selector(backBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    [container addSubview:titleLabel];
    if (@available(iOS 8.2, *)) {
        titleLabel.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"forgetPwd2", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:20 weight:UIFontWeightBold],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    } else {
        titleLabel.attributedText = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"forgetPwd2", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:20],NSForegroundColorAttributeName:UIColorFromRGB(colorTextBlack)}];
    }
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(backBtn.mas_right).offset(viewSpacing);
        make.right.mas_equalTo(-60);
        make.centerY.mas_equalTo(backBtn.mas_centerY);
        make.height.mas_equalTo(30);
    }];
    
    self.phoneNumberTextfield = [[UITextField alloc] init];
    self.phoneNumberTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"hint3", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.phoneNumberTextfield.borderStyle = UITextBorderStyleNone;
    self.phoneNumberTextfield.keyboardType = UIKeyboardTypeNumberPad;
    self.phoneNumberTextfield.delegate = self;
    self.phoneNumberTextfield.returnKeyType = UIReturnKeyNext;
    UIImageView *phoneNumberImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"registered-icon-phone"]];
    phoneNumberImageView.frame = CGRectMake(0, 3, 20, 20);
    UIView *phonenumberView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [phonenumberView addSubview:phoneNumberImageView];
    self.phoneNumberTextfield.leftView = phonenumberView;
    self.phoneNumberTextfield.leftViewMode = UITextFieldViewModeAlways;
    self.phoneNumberTextfield.clearButtonMode = UITextFieldViewModeWhileEditing;
    [container addSubview:self.phoneNumberTextfield];
    [self.phoneNumberTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.mas_equalTo(titleLabel.mas_bottom).offset(40);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
        
    }];
    
    UIView *line1 = [UIView new];
    [container addSubview:line1];
    line1.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.phoneNumberTextfield.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    
    self.authCodeTextfield = [[UITextField alloc] init];
    self.authCodeTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"hint4", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.authCodeTextfield.borderStyle = UITextBorderStyleNone;
    self.authCodeTextfield.keyboardType = UIKeyboardTypeNumberPad;
    self.authCodeTextfield.delegate = self;
    self.authCodeTextfield.returnKeyType = UIReturnKeyNext;
    UIImageView *authImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"registered-icon-check"]];
    authImageView.frame = CGRectMake(0, 3, 20, 20);
    UIView *authView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [authView addSubview:authImageView];
    self.authCodeTextfield.leftView = authView;
    self.authCodeTextfield.leftViewMode = UITextFieldViewModeAlways;
    self.authCodeTextfield.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.authCodeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.authCodeBtn.frame = CGRectMake(0, 0, 100, 40);
    self.authCodeBtn.layer.cornerRadius = 5.0f;
    self.authCodeBtn.layer.masksToBounds = YES;
    [self.authCodeBtn addTarget:self action:@selector(authCodeBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    self.authCodeBtn.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [self.authCodeBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"getcode", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}] forState:UIControlStateNormal];
    self.whiteview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 100, 40)];
    self.whiteview.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    self.whiteview.layer.cornerRadius = 5;
    self.whiteview.layer.masksToBounds = YES;
    [self.whiteview addSubview:self.authCodeBtn];
    self.authCodeTextfield.rightView = self.whiteview;
    self.authCodeTextfield.rightViewMode = UITextFieldViewModeAlways;
    [container addSubview:self.authCodeTextfield];
    [self.authCodeTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(line1.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    UIView *line2 = [UIView new];
    [container addSubview:line2];
    line2.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.authCodeTextfield.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    
    self.passwordTextfield = [[UITextField alloc] init];
    self.passwordTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"hint6", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.passwordTextfield.borderStyle = UITextBorderStyleNone;
    self.passwordTextfield.delegate = self;
    self.passwordTextfield.returnKeyType = UIReturnKeyDone;
    self.passwordTextfield.secureTextEntry = YES;
    UIImageView *passwordImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"registered-icon-password"]];
    passwordImageView.frame = CGRectMake(0, 3, 20, 20);
    UIView *passwordview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [passwordview addSubview:passwordImageView];
    self.passwordTextfield.leftView = passwordview;
    self.passwordTextfield.leftViewMode = UITextFieldViewModeAlways;
    self.passwordTextfield.clearButtonMode = UITextFieldViewModeWhileEditing;
    [container addSubview:self.passwordTextfield];
    [self.passwordTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.mas_equalTo(line2.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    UIView *line3 = [UIView new];
    [container addSubview:line3];
    line3.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [line3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.passwordTextfield.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(0.5);
    }];
    
    self.repeatTextfield = [[UITextField alloc] init];
    self.repeatTextfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"hint7", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorTextPlaceholder)}];
    self.repeatTextfield.borderStyle = UITextBorderStyleNone;
    self.repeatTextfield.delegate = self;
    self.repeatTextfield.returnKeyType = UIReturnKeyDone;
    self.repeatTextfield.secureTextEntry = YES;
    UIImageView *repeatImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"registered-icon-password"]];
    repeatImageView.frame = CGRectMake(0, 3, 20, 20);
    UIView *repeatview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [repeatview addSubview:repeatImageView];
    self.repeatTextfield.leftView = repeatview;
    self.repeatTextfield.leftViewMode = UITextFieldViewModeAlways;
    self.repeatTextfield.clearButtonMode = UITextFieldViewModeWhileEditing;
    [container addSubview:self.repeatTextfield];
    [self.repeatTextfield mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.mas_equalTo(line3.mas_bottom).offset(viewSpacing);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(40);
    }];
    
    self.commitBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.commitBtn.backgroundColor = UIColorFromRGB(colorLoginNotEnable);
    [self.commitBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"queding", nil) attributes:@{NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite),NSFontAttributeName:[UIFont systemFontOfSize:17]}] forState:UIControlStateNormal];
    self.commitBtn.layer.cornerRadius = 5.0;
    self.commitBtn.layer.masksToBounds = YES;
    [self.commitBtn addTarget:self action:@selector(commitBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:self.commitBtn];
    [self.commitBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.repeatTextfield.mas_bottom).offset(40);
        make.left.mas_equalTo(container.mas_left).offset(edgSpacing);
        make.right.mas_equalTo(container.mas_right).offset(-edgSpacing);
        make.height.mas_equalTo(50);
        make.bottom.mas_equalTo(container.mas_bottom).offset(-10);
    }];
    
    [[self.phoneNumberTextfield.rac_textSignal
      map:^id(NSString *text) {
          return @([self isValidString:text]);
      }] subscribeNext:^(NSNumber *valid) {
          if (self.shouldAuthCodeBtnCanChangeBackgroundColor)
          {
              self.authCodeBtn.enabled = valid.boolValue;
              if (valid.boolValue)
              {
                  self.authCodeBtn.backgroundColor = MainColor;
              }
              else
              {
                  self.authCodeBtn.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
              }
          }
      }];
    RACSignal *validPhoneNumberSignal = [self.phoneNumberTextfield.rac_textSignal
                                         map:^id(NSString *text) {
                                             return @([self isValidString:text]);
                                         }];
    RACSignal *validAuthCodeSignal = [self.authCodeTextfield.rac_textSignal
                                      map:^id(NSString *text) {
                                          return @([self isValidString:text]);
                                      }];
    RACSignal *validPasswordSignal = [self.passwordTextfield.rac_textSignal
                                      map:^id(NSString *text) {
                                          return @([self isValidString:text]);
                                      }];
    RACSignal *validRepeatSignal = [self.repeatTextfield.rac_textSignal
                                      map:^id(NSString *text) {
                                          return @([self isValidString:text] && [self.repeatTextfield.text isEqualToString:self.passwordTextfield.text]);
                                      }];
    RACSignal *signUpActiveSignal = [RACSignal combineLatest:@[validPhoneNumberSignal, validAuthCodeSignal,validPasswordSignal,validRepeatSignal]
                                                      reduce:^id(NSNumber *phoneNumberValid, NSNumber *authCodeValid, NSNumber *passwordValid, NSNumber *repeatValid){
                                                          return @(phoneNumberValid.boolValue && authCodeValid.boolValue && passwordValid.boolValue && repeatValid.boolValue);
                                                      }];
    
    [signUpActiveSignal subscribeNext:^(NSNumber *signupActive) {
        self.commitBtn.enabled = signupActive.boolValue;
        if (self.commitBtn.enabled)
        {
            self.commitBtn.backgroundColor = MainColor;
        }
        else
        {
            self.commitBtn.backgroundColor = UIColorFromRGB(colorLoginNotEnable);
        }
    }];
    //    self.areaTextfield.text = @"xxxxxx";
}

- (void)backBtnClicked
{
    [self endEditing:YES];
    if (self.dismissCallback)
    {
        self.dismissCallback();
    }
}

- (void)commitBtnClicked
{
    [self endEditing:YES];
    if (self.forgetPasswordCallback)
    {
        self.forgetPasswordCallback(self.phoneNumberTextfield.text, self.authCodeTextfield.text, self.passwordTextfield.text);
    }
}

- (BOOL)isValidString:(NSString *)string
{
    return string.length > 0;
}

- (void)authCodeBtnClicked
{
    
    
    
    if (self.sendAuthCodeCallback)
    {
        self.sendAuthCodeCallback(self.phoneNumberTextfield.text);
    }
    self.shouldAuthCodeBtnCanChangeBackgroundColor = NO;
    self.authCodeBtn.enabled = NO;
    self.authCodeBtn.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    self.whiteview.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
    [self.authCodeBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@(%lu)",NSLocalizedString(@"getcode2", nil),(long)_timeForAuthBtnActive] attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}] forState:UIControlStateNormal];
    
    _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerAction) userInfo:nil repeats:YES];
    [_timer fire];
}

- (void)timerAction
{
    _timeForAuthBtnActive--;
    if (_timeForAuthBtnActive > 0)
    {
        [self.authCodeBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@(%lu)",NSLocalizedString(@"getcode2", nil),(long)_timeForAuthBtnActive] attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}] forState:UIControlStateNormal];
    }
    else
    {
        [_timer invalidate];
        self.authCodeBtn.enabled = YES;
        self.shouldAuthCodeBtnCanChangeBackgroundColor = YES;
        _timeForAuthBtnActive = timeSpacing;
        if ([self isValidString:self.phoneNumberTextfield.text])
        {
            self.authCodeBtn.backgroundColor = MainColor;
            self.whiteview.backgroundColor = MainColor;
        }
        else
        {
            self.authCodeBtn.backgroundColor = UIColorFromRGB(colorTextPlaceholder);
            self.whiteview.backgroundColor = MainColor;
        }
        
        [self.authCodeBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"getcode", nil) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:UIColorFromRGB(colorFontWhite)}] forState:UIControlStateNormal];
    }
}

#pragma mark delegate methods

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    if (textField == self.phoneNumberTextfield)
    {
        [self.authCodeTextfield becomeFirstResponder];
    }
    else if (textField == self.authCodeTextfield)
    {
        [self.passwordTextfield becomeFirstResponder];
    }
    else if (textField == self.passwordTextfield)
    {
        [self.repeatTextfield becomeFirstResponder];
    }
    else if (textField == self.repeatTextfield)
    {
        [self endEditing:YES];
    }
    return YES;
}

@end
