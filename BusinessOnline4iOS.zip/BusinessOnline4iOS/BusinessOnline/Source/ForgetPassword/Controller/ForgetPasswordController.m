//
//  ForgetPasswordController.m
//  BusinessOnline
//
//  Created by clitics on 2019/3/1.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "ForgetPasswordController.h"
#import "ForgetPasswordView.h"

@interface ForgetPasswordController ()

@end

@implementation ForgetPasswordController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupSubViews];
}

- (void)setupSubViews
{
    ForgetPasswordView *fpView = [[ForgetPasswordView alloc] init];
    [self.view addSubview:fpView];
    [fpView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    WEAK_SELF(weakSelf);
    fpView.forgetPasswordCallback = ^(NSString * _Nonnull phoneNumber, NSString * _Nonnull authCode, NSString * _Nonnull password) {
        [weakSelf forgetPasswordViewCallback:phoneNumber authCode:authCode password:password];
    };
    fpView.dismissCallback = ^{
        [weakSelf dismissCallback];
    };
    fpView.sendAuthCodeCallback = ^(NSString * _Nonnull phone) {
        [weakSelf authCodeCallback:phone];
    };
}

- (void)forgetPasswordViewCallback:(NSString *)phoneNumber authCode:(NSString *)authCode password:(NSString *)password
{
    if (!isNSString(phoneNumber))
    {
        return;
    }
    if (!isNSString(authCode))
    {
        return;
    }
    if (!isNSString(password))
    {
        return;
    }
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithCapacity:5];
    [params setObject:phoneNumber forKey:@"phone"];
    [params setObject:authCode forKey:@"sum"];
    [params setObject:password forKey:@"password"];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [params setObject:invitationCode forKey:@"invitationCode"];
    [self doNetworkRequestForForgetpasswordWithParams:params];
}

- (void)doNetworkRequestForForgetpasswordWithParams:(NSDictionary *)params
{
    [MBProgressHUD showGifToView:nil];
    [NetworkManager postWithURL:CREATE_URL(url_forget_password) params:params isUsedSignal:NO success:^(id json) {
        [MBProgressHUD hideHUD];
        [self forgetpasswordSuccessCallback:json];
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}

- (void)forgetpasswordSuccessCallback:(id)json
{
    NSInteger state = [get_Value_for_key_from_obj(json, successKey) integerValue];
    switch (state) {
        case 1:
        {
//            [MBProgressHUD showMessage:get_Value_for_key_from_obj(json, messageKey)];
            [MBProgressHUD showMessage:NSLocalizedString(@"pwdupdateok", nil)];
            [self dismissCallback];
        }
            break;
        default:
//            [MBProgressHUD showErrorMessage:get_Value_for_key_from_obj(json, messageKey)];
             [MBProgressHUD showMessage:NSLocalizedString(@"pwdupdateerror", nil)];
            break;
    }
}

- (void)dismissCallback
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)authCodeCallback:(NSString *)phone
{
    [self.view endEditing:YES];
    if (!isNSString(phone))
    {
        return;
    }
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithCapacity:4];
    NSString *invitationCode = [[NSUserDefaults standardUserDefaults] objectForKey:KInvitationCode];
    [params setObject:phone forKey:@"phone"];
    [params setObject:@"updatePwd" forKey:@"operation"];
    [params setObject:invitationCode forKey:@"invitationCode"];
    [self doNetworkRequestForAuthCode:params];
}

- (void)doNetworkRequestForAuthCode:(NSDictionary *)params
{
    [MBProgressHUD showGifToView:nil];
    [NetworkManager postWithURL:CREATE_URL(url_send_auth_code) params:params isUsedSignal:NO success:^(id json) {
        [MBProgressHUD hideHUD];
        [self authCodeSuccessCalback:json];
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showErrorMessage:error.localizedDescription];
    }];
}

- (void)authCodeSuccessCalback:(id)json
{
    NSInteger state = [get_Value_for_key_from_obj(json, successKey) integerValue];
    
    switch (state) {
        case 1:
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"msg1", nil)];
            break;
        case 2:
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"msg3", nil)];
            break;
        case 3:
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"msg2", nil)];
            break;
        default:
            [MBProgressHUD showErrorMessage:NSLocalizedString(@"phonenone", nil)];
            break;
    }
    
//    [MBProgressHUD showErrorMessage:get_Value_for_key_from_obj(json, messageKey)];
}

@end
