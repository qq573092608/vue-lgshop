//
//  ForgetPasswordController.h
//  BusinessOnline
//
//  Created by clitics on 2019/3/1.
//  Copyright © 2019年 clitics. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ForgetPasswordController : BaseViewController

@end

NS_ASSUME_NONNULL_END
